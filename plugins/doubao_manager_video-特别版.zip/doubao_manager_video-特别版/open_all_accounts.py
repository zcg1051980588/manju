# -*- coding: utf-8 -*-
"""打开豆包管理器的全部账号（插件自包含，纯标准库）。

背景
----
桥接原有的 open_all_accounts() 靠点击界面上文字为「打开」的按钮，但当前
管理器渲染层根本没有这个按钮，实测 opened=0。真正可用的是渲染层全局函数
window.openAccount(data-id)，账号卡片是 .account-card[data-id]。本模块直连
CDP，用 Runtime.evaluate 逐个调用它；该函数幂等，已打开的账号不会重复建标签。

不依赖 websockets 第三方库，也不依赖桥接 HTTP 接口：只要管理器的 CDP 在线
就能工作。视频/图片两个插件目录各放一份，内容逐字节一致。

用法
----
    from open_all_accounts import open_all
    r = open_all(cdp_port=39233, wait_cdp=30)

    python open_all_accounts.py [cdp端口]

返回字段
--------
    ok, skipped, opened, total, before, after, cdp_port,
    accounts, reason, msg
"""
import base64
import json
import os
import re
import socket
import struct
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

_CDP_FIRST = 39233
_CDP_FALLBACK = tuple(range(39234, 39241))
_IDENTITY = "豆包管理器"

# 本地 CDP 请求必须绕开系统代理：全局代理会把 127.0.0.1 也转发出去返回 502。
_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

# 跨调用去重：scheduler.tick() 与插件 ping 会并发开号。谁先成功就把结果写进
# 临时文件，15 秒内的另一方直接复用，避免两边各点 8 次 openAccount 并各自
# 等满 settle，把 renderer 负载翻倍。
_STATE_FILE = Path(tempfile.gettempdir()) / "dbm_open_all_state.json"
_STATE_TTL = 15.0


def _load_state():
    try:
        d = json.loads(_STATE_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else None
    except Exception:
        return None


def _save_state(total, after):
    try:
        _STATE_FILE.write_text(json.dumps({
            "ok": True, "total": int(total), "after": int(after),
            "ts": time.time(),
        }), encoding="utf-8")
    except Exception:
        pass


_PROBE_JS = (
    "(function(){return JSON.stringify({"
    "openAccount: typeof window.openAccount,"
    "cards: [].slice.call(document.querySelectorAll('.account-card'))"
    ".map(function(c){return c.getAttribute('data-id');})});})()"
)
_OPEN_JS = (
    "(function(){try{window.openAccount(%s);"
    "return JSON.stringify({ok:true});}"
    "catch(e){return JSON.stringify({ok:false,err:String(e)});}})()"
)


def _http_json(url, timeout=2.0):
    try:
        with _OPENER.open(url, timeout=timeout) as resp:
            return json.load(resp)
    except Exception as exc:
        return {"__error__": str(exc)}


def _listening(port, timeout=0.15):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        return s.connect_ex(("127.0.0.1", int(port))) == 0
    except Exception:
        return False
    finally:
        s.close()


def _cdp_is_manager(port):
    if not _listening(port):
        return False
    ver = _http_json("http://127.0.0.1:%d/json/version" % int(port), timeout=1.2)
    ua = ver.get("User-Agent", "") if isinstance(ver, dict) else ""
    return _IDENTITY in ua


def _devtools_ports():
    """顺延端口兜底：管理器被占用时把真实端口写进 DevToolsActivePort。"""
    out = []
    appdata = os.environ.get("APPDATA", "")
    if not appdata:
        return out
    for d in (Path(appdata) / "DoubaoAccountManager",
              Path(appdata) / _IDENTITY):
        try:
            f = d / "DevToolsActivePort"
            if f.is_file():
                p = int(f.read_text(encoding="utf-8", errors="ignore")
                         .splitlines()[0].strip())
                if 1 < p < 65536:
                    out.append(p)
        except Exception:
            pass
    return out


def _port_candidates(preferred):
    seen, out = set(), []
    for p in (preferred, _CDP_FIRST) + _CDP_FALLBACK + tuple(_devtools_ports()):
        try:
            p = int(p)
        except Exception:
            continue
        if 1 < p < 65536 and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def _targets(port):
    d = _http_json("http://127.0.0.1:%d/json/list" % int(port), timeout=2.5)
    return d if isinstance(d, list) else []


def _webview_accounts(port):
    out = []
    for t in _targets(port):
        if isinstance(t, dict) and t.get("type") == "webview":
            out.append({"title": t.get("title") or "豆包",
                        "url": (t.get("url") or "")[:160],
                        "busy": False})
    return out


class _MiniWS:
    """极简 RFC6455 客户端，只用于 CDP Runtime.evaluate（纯标准库）。"""

    def __init__(self, url, timeout=10):
        m = re.match(r"ws://([^:/]+)(?::(\d+))?(/.*)", url)
        if not m:
            raise ValueError("非法 CDP ws 地址: %s" % url)
        host, port, path = m.group(1), int(m.group(2) or 80), m.group(3)
        self.sock = socket.create_connection((host, port), timeout=timeout)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        req = ("GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\n"
               "Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\n"
               "Sec-WebSocket-Version: 13\r\n\r\n" % (path, host, port, key))
        self.sock.sendall(req.encode("ascii"))
        raw = b""
        while b"\r\n\r\n" not in raw:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("CDP WebSocket 握手被关闭")
            raw += chunk
        head, self._buf = raw.split(b"\r\n\r\n", 1)
        if b"101" not in head.split(b"\r\n", 1)[0]:
            raise ConnectionError("CDP WebSocket 握手被拒: %r" % head[:120])
        self._id = 0

    def _readn(self, n):
        buf = self._buf
        self._buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("CDP WebSocket 已关闭")
            buf += chunk
        if len(buf) > n:
            self._buf = buf[n:]
            return buf[:n]
        return buf

    def _send_frame(self, data, opcode=0x1):
        # 客户端帧必须 mask
        mask = os.urandom(4)
        n = len(data)
        if n < 126:
            head = bytes([0x80 | opcode, 0x80 | n])
        elif n < 65536:
            head = bytes([0x80 | opcode, 0x80 | 126]) + struct.pack(">H", n)
        else:
            head = bytes([0x80 | opcode, 0x80 | 127]) + struct.pack(">Q", n)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        self.sock.sendall(head + mask + masked)

    def _recv_message(self):
        frag = b""
        while True:
            b1, b2 = self._readn(2)
            fin = (b1 & 0x80) != 0
            opcode = b1 & 0x0F
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._readn(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._readn(8))[0]
            payload = self._readn(n) if n else b""
            if opcode == 0x9:
                self._send_frame(payload, 0xA)
                continue
            if opcode == 0x8:
                raise ConnectionError("CDP WebSocket 被对端关闭")
            frag += payload
            if fin:
                return frag

    def call(self, method, params, timeout=20):
        self._id += 1
        mid = self._id
        self._send_frame(json.dumps({"id": mid, "method": method,
                                     "params": params}).encode("utf-8"))
        self.sock.settimeout(timeout)
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                msg = json.loads(self._recv_message().decode("utf-8", "ignore"))
            except (ValueError, UnicodeDecodeError):
                continue
            if msg.get("id") == mid:
                return msg
        raise TimeoutError("CDP %s 超时" % method)

    def evaluate(self, expression, timeout=20):
        r = self.call("Runtime.evaluate", {
            "expression": expression, "returnByValue": True,
            "awaitPromise": True, "userGesture": True,
        }, timeout=timeout)
        res = r.get("result") or {}
        if res.get("exceptionDetails"):
            raise RuntimeError(str(res["exceptionDetails"].get("text", "JS 异常"))[:160])
        return (res.get("result") or {}).get("value")

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


def _fail(port, before, total, reason, msg):
    return {"ok": False, "skipped": False, "opened": 0, "total": total,
            "before": before, "after": before, "accounts": [],
            "cdp_port": port, "reason": reason, "msg": msg}


def open_all(cdp_port=_CDP_FIRST, wait_cdp=30, gap=0.3, settle=6,
             force=False):
    """等 CDP 就绪后打开全部账号；已全开时直接跳过（force=True 强制重跑）。"""
    ports = _port_candidates(cdp_port)

    # 去重：15 秒内已有一次成功的全量开号（多半是 scheduler.tick 抢先跑了），
    # 且当前 webview 数达标，就直接复用结果，不再重复点 8 次 openAccount。
    if not force:
        _cached = _load_state()
        if (_cached and _cached.get("ok")
                and time.time() - float(_cached.get("ts") or 0) < _STATE_TTL):
            for _p in ports:
                if not _cdp_is_manager(_p):
                    continue
                _acc = _webview_accounts(_p)
                _total = int(_cached.get("total") or 0)
                if _total and len(_acc) >= _total:
                    return {"ok": True, "skipped": True, "deduplicated": True,
                            "opened": 0, "total": _total,
                            "before": len(_acc), "after": len(_acc),
                            "accounts": _acc, "cdp_port": _p, "reason": "",
                            "msg": "账号已全部打开（%d/%d），15 秒内已开过，跳过重复开号"
                                   % (len(_acc), _total)}
                break

    # 1) 等管理器 CDP 上线并校验身份，避免把别的 Electron 程序误当管理器
    port = None
    deadline = time.time() + max(1, wait_cdp)
    while True:
        for p in ports:
            if _cdp_is_manager(p):
                port = p
                break
        if port or time.time() >= deadline:
            break
        time.sleep(0.25)
    if not port:
        return _fail(None, 0, 0, "cdp_not_ready",
                     "%d 秒内没发现管理器的 CDP（%s 及顺延端口），"
                     "请确认管理器由插件拉起、不要手动双击 exe"
                     % (wait_cdp, _CDP_FIRST))

    # 2) 找主窗口 page target（管理器刚启动时可能还没建好）
    page = None
    page_deadline = time.time() + min(15, max(3, wait_cdp))
    while True:
        for t in _targets(port):
            if (isinstance(t, dict) and t.get("type") == "page"
                    and (_IDENTITY in (t.get("title") or "")
                         or "index.html" in (t.get("url") or ""))):
                page = t
                break
        if page or time.time() >= page_deadline:
            break
        time.sleep(0.25)
    if not page or not page.get("webSocketDebuggerUrl"):
        return _fail(port, 0, 0, "manager_page_not_found",
                     "CDP 已就绪但找不到管理器主窗口 page target")

    before_list = _webview_accounts(port)
    before = len(before_list)
    ws = None
    try:
        ws = _MiniWS(page["webSocketDebuggerUrl"], timeout=10)
        ws.call("Runtime.enable", {}, timeout=10)

        # 3) 账号卡片可能还在渲染，轮询等 DOM 就绪
        info = {}
        for _ in range(12):
            try:
                val = ws.evaluate(_PROBE_JS, timeout=15)
                info = json.loads(val) if val else {}
            except Exception:
                info = {}
            if info.get("cards"):
                break
            time.sleep(0.4)
        ids = [x for x in info.get("cards", []) if x]
        total = len(ids)

        if info.get("openAccount") != "function":
            return _fail(port, before, total, "openAccount_missing",
                         "管理器渲染层没有 window.openAccount，无法自动打开账号")
        if not total:
            return _fail(port, before, 0, "no_account_cards",
                         "管理器里没读到账号卡片（.account-card），可能账号列表尚未加载")

        # 4) 幂等：已全开就直接返回，不重复点、不占资源
        if not force and before >= total:
            acc = _webview_accounts(port)
            _save_state(total, len(acc))
            return {"ok": True, "skipped": True, "opened": 0,
                    "total": total, "before": before, "after": len(acc),
                    "accounts": acc, "cdp_port": port, "reason": "",
                    "msg": "账号已全部打开（%d/%d），无需重复打开" % (len(acc), total)}

        # 5) 逐个调用渲染层 openAccount；已开的会被它自己跳过
        for aid in ids:
            try:
                ws.evaluate(_OPEN_JS % json.dumps(aid), timeout=15)
            except Exception:
                pass
            time.sleep(gap)

        # 6) 等 webview 真正建出来（openAccount 是异步建标签）
        acc = before_list
        end = time.time() + max(1, settle)
        while True:
            acc = _webview_accounts(port)
            if len(acc) >= total or time.time() >= end:
                break
            time.sleep(0.4)
        after = len(acc)
        opened = max(0, after - before)
        ok = after >= total
        if ok:
            _save_state(total, after)
        return {
            "ok": ok, "skipped": False, "opened": opened, "total": total,
            "before": before, "after": after, "accounts": acc,
            "cdp_port": port,
            "reason": "" if ok else "open_incomplete",
            "msg": ("已打开 %d/%d 个账号（本次新开 %d 个）" % (after, total, opened))
                   if ok else
                   ("只打开 %d/%d 个账号，管理器可能还在加载页面，"
                    "稍后再点一次测试连接即可补齐" % (after, total)),
        }
    except Exception as e:
        return _fail(port, before, 0, "exception", "自动打开账号异常：%s" % e)
    finally:
        if ws is not None:
            ws.close()


if __name__ == "__main__":
    _port = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else _CDP_FIRST
    _r = open_all(cdp_port=_port)
    print(_r["msg"])
    print(json.dumps({k: v for k, v in _r.items() if k != "accounts"},
                     ensure_ascii=False))
    sys.exit(0 if _r["ok"] else 1)

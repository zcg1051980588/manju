# -*- coding: utf-8 -*-
"""
豆包15s 视频插件
================

把字字动画分镜的视频生成任务分发给本机“豆包管理器 V2.0”：
  分镜点“生成视频” → 插件启动/复用本地桥接服务 → 桥接通过 CDP 自动化
  操控管理器内的豆包账号 webview（填提示词/传首帧/点发送/等豆包确认/取视频）
  → 成品视频自动下载回项目目录并按软件命名规范返回。
  注意：按需求已移除“选模型 / 选比例 / 选时长 / 点生成视频按钮”的自动点击，
  模型/比例/时长一律沿用豆包页面当前默认值，由用户在管理器里手动确认生成。

插件不直接操作管理器，全部通过桥接服务（bridge/server.py，标准库实现）
的 HTTP API 完成；桥接既可在宿主进程内以守护线程跑（默认），也可独立运行。
"""

import importlib.util
import json
import socket
import os
import shutil
import sys
import threading
import time
import urllib.request
import urllib.error
import webbrowser
from pathlib import Path

_PLUGIN_FILE = __file__
_PLUGIN_DIR = Path(__file__).resolve().parent
_BRIDGE_SERVER = _PLUGIN_DIR / "bridge" / "server.py"

# 让插件在任何目录深度都能找到 plugin_utils（宿主也会注入 sys.path，双保险）
for _p in (
    _PLUGIN_DIR.parent.parent,          # plugins/
    _PLUGIN_DIR.parent.parent.parent,  # 兜底
):
    if str(_p) not in sys.path:
        sys.path.append(str(_p))

try:
    from plugin_utils import load_plugin_config
except Exception:
    load_plugin_config = None

PLUGIN_NAME = "豆包15s"
PLUGIN_VERSION = "1.1.0"

# 桥接服务身份标识：视频插件专用桥接（端口默认 39230）。
# 图片插件是另一个独立桥接（默认 39231）。两个插件共用同一个豆包管理器，
# 端口一旦撞车，先起来的那个占住端口，另一个把任务发过去就会全部失败
# （典型症状：图片能生成、视频不行）。health 回传此标识用于识别是否串台。
SERVICE_ID = "doubao-video-bridge"

DEFAULT_PARAMS = {
    "bridge_host": "127.0.0.1",
    "bridge_port": 39230,  # 视频专用；图片插件用 39231，两者不可相同
    "manager_exe": "",  # 客户版：首次使用请在插件设置页填写 豆包管理器.exe 的完整路径
    "cdp_port": 39233,
    "download_dir": "",                # 留空 = 自动读取管理器素材库目录
    "default_duration": "15",          # 秒；保留作任务元信息，但桥接已不再自动选时长
    "default_aspect": "自动",           # 保留作任务元信息，但桥接已不再自动选比例
    # 保留作任务元信息，但桥接已不再自动点开模型下拉选择（沿用页面当前模型）
    "model_name": "Seedance 2.0 Fast",
    "duration_follow_scene": False,    # 时长交由页面默认，关闭时长跟随分镜
    "default_account": "",             # 账号关键字（账号1/账号2/昵称），空 = 任意空闲账号
    "max_concurrency": 0,              # 最大并发账号数，0 = 自动（打开几个账号就并发几个）
    # 每个任务最多上传几张参考图 / 几个参考音频到豆包。
    # 豆包（Seedance 2.0）单次任务最多 9 张参考图 + 3 个参考音频，这是硬上限；
    # 设置页可在 1~9 / 1~3 之间调小，超出部分一律截断，避免豆包提示"附件过多"。
    # 2026-11-13：原先参考图写死 4，分镜关联图多于 4 张会被静默丢弃；同时
    # 参考音频压根没有解析，字字动画「参考项」里的音频从来没发到豆包账号。
    "max_reference_images": 9,
    "max_reference_audios": 3,
    "task_timeout_sec": 1800,
    "safety_confirm_wait_sec": 100,    # 发送后等待豆包生成确认消息的秒数
    "auto_confirm_generation": True,   # 未检测到生成确认消息时是否自动发送"确认生成视频"
    "confirm_generation_text": "确认，使用Seedance 2.0 Fast来生成15秒视频",  # 自动确认时发送的文本（固定 Seedance 2.0 Fast 生成 15 秒）
    # ★ 2026-11-14：参考项含参考音频时强制二次确认，两轮都用这句固定提示词。
    "audio_second_confirm_enabled": True,
    "audio_second_confirm_text": "确认，使用seedance 2.0 fast来生成15秒视频",
    # ★ 2026-11-14 全面检查修复：设置页有这两个输入框，但此前未进入
    #   DEFAULT_PARAMS / config_overrides / _PUSH_CONFIG_KEYS，用户改了值
    #   永远不会下发到桥接（服务端一直用 config.json 里固定的 20 / 3）。
    "second_confirm_wait_sec": 20,
    "max_confirm_replies": 3,
    "modify_prompt_text": "改写提示词，保持原文和核心不变",  # 版权拒绝申诉时先于 copyright_appeal_text 发送：要求豆包改写提示词
    "confirm_with_images": True,      # 发确认文本时重新带上参考图（豆包附件不跨轮继承）
    "min_wait_sec": 60,               # 提交后最短等待时间（秒），之后进入实时监控轮询回收
    "poll_interval_sec": 3,           # 实时监控轮询间隔（秒）
    "auto_start_manager": True,
    "auto_start_bridge": True,
}

# 豆包单次任务的参考项硬上限：9 张图 + 3 个音频。
# 插件默认值、用户设置、桥接 API 三处都按这个上限收敛：旧配置里写 30 或 0
# （旧版把 0 当"不限制"）也不会再把超额附件发给豆包，否则页面会直接报附件过多。
HARD_MAX_REFERENCE_IMAGES = 9
HARD_MAX_REFERENCE_AUDIOS = 3
DEFAULT_MAX_REFERENCE_IMAGES = HARD_MAX_REFERENCE_IMAGES
DEFAULT_MAX_REFERENCE_AUDIOS = HARD_MAX_REFERENCE_AUDIOS


def _ref_limit(params, key, hard_max):
    """读取参考项上限，统一收敛到 [1, hard_max]；0 / 非法 / 超上限回落到硬上限。"""
    try:
        value = int(params.get(key, hard_max))
    except (TypeError, ValueError):
        return hard_max
    return value if 1 <= value <= hard_max else hard_max


def _ref_image_limit(params):
    return _ref_limit(params, "max_reference_images", HARD_MAX_REFERENCE_IMAGES)


def _ref_audio_limit(params):
    return _ref_limit(params, "max_reference_audios", HARD_MAX_REFERENCE_AUDIOS)


_STATUS_TEXT = {
    "queued": "任务排队中",
    "starting_manager": "启动豆包管理器",
    "connecting": "连接管理器",
    "preparing_page": "准备豆包页面",
    "filling_form": "网页自动填写中",
    "submitting": "提交生成 / 等待确认",
    "generating": "豆包生成中",
    "downloading": "取回视频中",
    "done": "完成",
    "error": "失败",
    "needs_calibration": "需要标定网页选择器",
}

_bridge_started = False
_bridge_lock = threading.Lock()

# 宿主存活心跳：字字动画一旦关闭，这个 daemon 线程随宿主进程一起消失；
# 桥接侧超过 host_offline_timeout_sec 秒收不到心跳（且宿主进程已退出）就判定
# 「软件端已关闭」→ 自动取消全部任务并立起派发闸门。
_HOST_HEARTBEAT_SEC = 5
_host_hb_started = False
_host_hb_lock = threading.Lock()


def _start_host_heartbeat():
    """启动宿主存活心跳（幂等，全程吞异常，绝不影响主流程）。"""
    global _host_hb_started
    with _host_hb_lock:
        if _host_hb_started:
            return
        _host_hb_started = True

    def _loop():
        while True:
            try:
                p = get_params()
                _http("POST", _base(p) + "/api/host/heartbeat",
                      {"host_pid": os.getpid()}, timeout=3)
            except Exception:
                # 桥接可能尚未就绪 / 正在重启 / 端口被占：下一轮自动重试
                pass
            time.sleep(_HOST_HEARTBEAT_SEC)

    threading.Thread(target=_loop, daemon=True,
                     name="dbm-host-heartbeat").start()


# ---------------------------------------------------------------------------
# 参数
# ---------------------------------------------------------------------------

def get_info():
    return {
        "name": PLUGIN_NAME,
        "description": "把视频任务分发给豆包管理器并自动取回成品视频",
        "version": PLUGIN_VERSION,
    }


def get_models():
    return [{"id": "doubao-manager-seedance", "name": "豆包管理器-Seedance", "type": "video"}]


def get_params():
    params = dict(DEFAULT_PARAMS)
    if load_plugin_config:
        try:
            params.update(load_plugin_config(str(_PLUGIN_FILE)) or {})
        except Exception:
            pass
    return params


# ---------------------------------------------------------------------------
# HTTP 小工具
# ---------------------------------------------------------------------------

# 本地 127.0.0.1 请求必须绕开系统代理：全局代理会把本地请求也转发出去，
# 表现为 /api/health 变慢甚至 502 Bad Gateway。
_LOCAL_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _port_listening(host, port, timeout=0.05):
    """端口预检：没监听就直接判未就绪，避免 urllib 白等约 2 秒（WinError 10061）。"""
    s = socket.socket()
    s.settimeout(timeout)
    try:
        return s.connect_ex((str(host), int(port))) == 0
    except Exception:
        return False
    finally:
        s.close()


def _http(method, url, payload=None, timeout=15):
    data = None
    headers = {
        "Content-Type": "application/json",
        # ★ 宿主存活标识：桥接据此判断字字动画是否还在运行。
        #   任务控制台（浏览器页面）的请求不带这个头，不会被误判成宿主在线。
        "X-Doubao-Host": str(os.getpid()),
    }
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with _LOCAL_OPENER.open(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _base(params):
    return f"http://{params.get('bridge_host', '127.0.0.1')}:{int(params.get('bridge_port', 39230))}"


def _health(params, timeout=3):
    """探测桥接健康状态。

    只有端口上跑的确实是视频桥接才算健康。若返回里的 service 不是自己人，
    说明端口被别的服务（最常见：图片插件桥接）占了，必须判为未就绪，
    否则视频任务会被发到图片桥接上，表现就是"视频一直失败"。
    """
    if not _port_listening(params.get("bridge_host", "127.0.0.1"),
                           int(params.get("bridge_port") or 0)):
        return None
    try:
        r = _http("GET", _base(params) + "/api/health", timeout=timeout)
    except Exception:
        return None
    if not isinstance(r, dict) or not r.get("ok"):
        return None
    svc = r.get("service")
    if svc and svc != SERVICE_ID:
        print("[doubao_manager_video] 端口 %s 上跑的是「%s」，不是视频桥接，判为不可用"
              % (params.get("bridge_port"), svc), file=sys.stderr, flush=True)
        return None
    return r


def _cancel_bridge_task(params, tid, reason):
    """把字字动画侧的失败同步给桥接：取消对应任务，避免它被再次分发/自动重试。

    字字动画里某个分镜一旦判失败就不会再等结果，但桥接侧同一个任务可能还在排队、
    正在生成，或者已经被 handle_stage_error 自动重新排队等待重试。不同步取消的话，
    这些任务会继续占用账号额度反复生成，而产出的视频又没人回收，纯粹浪费。

    取消请求本身失败（桥接已挂/网络抖动）绝不能影响宿主原有的报错，因此全程吞异常。
    """
    if not tid:
        return False
    url = _base(params) + "/api/tasks/%s/cancel" % tid
    try:
        _http("POST", url, {"reason": str(reason)[:200]}, timeout=8)
        print("[doubao_manager] 已同步取消桥接任务 %s（%s）" % (tid, reason),
              file=sys.stderr, flush=True)
        return True
    except Exception as e:
        # 404/400 表示任务已完成或早已取消，属于预期情况，不算错误
        print("[doubao_manager] 同步取消桥接任务失败 %s: %s" % (tid, e),
              file=sys.stderr, flush=True)
        return False


# ---------------------------------------------------------------------------
# 桥接服务启停（宿主进程内守护线程）
# ---------------------------------------------------------------------------

def _start_bridge_in_process(params):
    global _bridge_started
    with _bridge_lock:
        if _bridge_started:
            return
        if not _BRIDGE_SERVER.exists():
            raise RuntimeError(f"PLUGIN_ERROR:::找不到桥接服务文件 {_BRIDGE_SERVER}")
        spec = importlib.util.spec_from_file_location(
            "doubao_manager_bridge_server", str(_BRIDGE_SERVER))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        mod.start_bridge(config_overrides={
            "bridge_host": params.get("bridge_host", "127.0.0.1"),
            "bridge_port": int(params.get("bridge_port", 39230)),
            "cdp_port": int(params.get("cdp_port", 39233)),
            "manager_exe": params.get("manager_exe", ""),
            "download_dir": params.get("download_dir", ""),
            "auto_start_manager": bool(params.get("auto_start_manager", True)),
            "default_duration": str(params.get("default_duration", "10")),
            "default_aspect": str(params.get("default_aspect", "自动")),
            "model_name": str(params.get("model_name", "Seedance 2.0 Fast")),
            "max_concurrency": int(params.get("max_concurrency", 0) or 0),
            "max_reference_images": _ref_image_limit(params),
            "max_reference_audios": _ref_audio_limit(params),
            "task_timeout_sec": int(params.get("task_timeout_sec", 1800)),
            "safety_confirm_wait_sec": int(params.get("safety_confirm_wait_sec", 100) or 100),
            "auto_confirm_generation": bool(params.get("auto_confirm_generation", True)),
            "confirm_generation_text": str(params.get("confirm_generation_text", "确认，使用Seedance 2.0 Fast来生成15秒视频")),
            "audio_second_confirm_enabled": bool(params.get("audio_second_confirm_enabled", True)),
            "audio_second_confirm_text": str(params.get("audio_second_confirm_text", "确认，使用seedance 2.0 fast来生成15秒视频")),
            "second_confirm_wait_sec": int(params.get("second_confirm_wait_sec", 20) or 20),
            "max_confirm_replies": int(params.get("max_confirm_replies", 3) or 3),
            "modify_prompt_text": str(params.get("modify_prompt_text", "改写提示词，保持原文和核心不变")),
            "copyright_appeal_text": str(params.get("copyright_appeal_text", "根据参考图，继续使用Seedance 2.0 Fast来生成15秒视频")),
            "confirm_with_images": bool(params.get("confirm_with_images", True)),
            "parallel_submit": bool(params.get("parallel_submit", True)),
            "auto_raise_manager_window": bool(params.get("auto_raise_manager_window", True)),
            # ★ 2026-11-13：不再让插件把旧的「错峰 2 秒」推给桥接。
            #   用户要求点击生成视频立即派发、不要分批次；错峰与否由桥接
            #   config.json 的 dispatch_stagger_enabled 单一控制（默认关闭）。
            "force_page_visible": bool(params.get("force_page_visible", True)),
            "auto_repair_degraded_page": bool(params.get("auto_repair_degraded_page", True)),
            # 默认 False：2026-09-19 晚并发实测，会话页整页加载在多账号同时跑时
            # 几乎必然半加载，且"换会话重试"会占住全局导航锁把其余账号全部堵死。
            "prefer_conversation_page": bool(params.get("prefer_conversation_page", False)),
            # 强制管理器里所有 webview 参与渲染。关闭 = 只有当前 active 的那个账号
            # 能进视频模式（rAF 为 0 的页面挂载不了 React UI），并发会退化成串行。
            "force_render_all_webviews": bool(params.get("force_render_all_webviews", True)),
        })
        _bridge_started = True


# 任务控制台设置的「每日额度 / 强制冷却」由 /api/health 回传给插件。
# 桥接 config.json 是唯一真相源；插件只读、绝不回推，避免宿主每次生成时
# 拿 DEFAULT_PARAMS 里的旧值把控制台刚保存的设置覆盖掉。
# 只在值变化时打一条日志，避免每个分镜都刷屏；设置页「测试连接」也会展示。
_BRIDGE_SETTINGS_SNAPSHOT = {}


def _note_bridge_settings(health):
    """插件侧确认「控制台改了额度」：读回并缓存，变化时输出可见日志。"""
    global _BRIDGE_SETTINGS_SNAPSHOT
    if not isinstance(health, dict):
        return _BRIDGE_SETTINGS_SNAPSHOT
    limits = health.get("daily_limits") or {}
    if not limits:
        # 桥接仍是旧版本时没有这个字段，静默跳过，不影响生成
        return _BRIDGE_SETTINGS_SNAPSHOT
    snap = {
        "fast": limits.get("Seedance 2.0 Fast"),
        "mini": limits.get("Seedance 2.0 Mini"),
        "cooldown_count": health.get("cooldown_count", 0),
        "cooldown_accounts": list(health.get("cooldown_accounts") or []),
        "immediate_dispatch": bool(health.get("immediate_dispatch", True)),
    }
    if snap != _BRIDGE_SETTINGS_SNAPSHOT:
        _BRIDGE_SETTINGS_SNAPSHOT = snap
        names = "、".join(str(x) for x in snap["cooldown_accounts"] if x)
        print("[doubao_manager_video] 已读取任务控制台设置：Fast %s 次/天、Mini %s 次/天"
              "（分开计数 · 任一满即全账号停派）；强制冷却 %s 个账号%s；派发模式 %s"
              % (snap["fast"], snap["mini"], snap["cooldown_count"],
                 ("（" + names + "）") if names else "",
                 "即时派发（无批次）" if snap["immediate_dispatch"] else "错峰分批"),
              file=sys.stderr, flush=True)
    return _BRIDGE_SETTINGS_SNAPSHOT


# 需要推送给桥接服务的配置项。桥接可能早已在跑（独立进程或上次调用留的），
# 只在首次启动时传一次配置的话，用户在设置页改的东西永远不生效。
# 注意：min_wait_sec / poll_interval_sec 由「任务控制台 → 轮询监控设置」管理，
# 保存在桥接的 config.json 里。宿主 DEFAULT_PARAMS 里这两个是固定值 60/3，
# 若继续在每次 _ensure_bridge() 时推给桥接，会把控制台保存的值静默覆盖回旧值，
# 表现为「设置保存了却不生效」。这两个键只保留控制台单一真相源。
# ★ daily_seedance_limit / daily_model_limits 同理：由控制台两个 1~10 下拉框管理，
#   绝不能放进下面的 _PUSH_CONFIG_KEYS，否则「控制台选了 7 次、插件一生成又变回 3 次」。
# max_concurrency 仍由插件设置页管理（控制台不再暴露重复输入）。
_PUSH_CONFIG_KEYS = (
    "manager_exe", "download_dir", "cdp_port", "auto_start_manager", "default_duration",
    "default_aspect", "model_name", "max_concurrency",
    "max_reference_images", "max_reference_audios",
    "task_timeout_sec", "quota_recheck_sec",
    "safety_confirm_wait_sec", "auto_confirm_generation",
    "confirm_generation_text", "modify_prompt_text", "copyright_appeal_text",
    "confirm_with_images",
    # ★ 2026-11-14：含参考音频的二次确认规则由插件设置页管理，需推给桥接生效。
    "audio_second_confirm_enabled", "audio_second_confirm_text",
    "second_confirm_wait_sec", "max_confirm_replies",
    "return_delay_sec", "orphan_timeout_sec", "fast_detect_max_wait_sec",
    "reload_after_sec", "dir_fallback_enabled", "dir_fallback_after_sec",
    "min_collect_sec", "parallel_submit", "auto_raise_manager_window",
    "force_page_visible", "auto_repair_degraded_page",
    "prefer_conversation_page", "force_render_all_webviews",
)
# ★ 2026-11-13：dispatch_stagger_sec / dispatch_stagger_enabled 已从上面移除。
#   老设置文件里可能残留 dispatch_stagger_sec=2，若继续推送会把桥接
#   config.json 写回"错峰 2 秒"，配合旧逻辑又变成分批次派发。现在桥接侧
#   由 dispatch_stagger_enabled 总开关（默认 False）统一控制，插件只读不写。


def _push_config(params):
    """把最新设置推给已在运行的桥接服务。失败不影响主流程。"""
    try:
        payload = {k: params[k] for k in _PUSH_CONFIG_KEYS
                   if k in params and params[k] not in (None, "")}
        if payload:
            _http("POST", _base(params) + "/api/config", payload, timeout=8)
    except Exception:
        pass


def _ensure_bridge(params):
    """确保桥接服务可用，并把最新设置同步给它；返回 health 信息。"""
    health = _health(params)
    if health and health.get("ok"):
        _push_config(params)
        _start_host_heartbeat()
        _note_bridge_settings(health)
        return health
    if not params.get("auto_start_bridge", True):
        raise RuntimeError("PLUGIN_ERROR:::豆包桥接服务未运行，且设置为不自动启动。"
                           "可手动运行 bridge/server.py 或在设置中开启自动启动。")
    _start_bridge_in_process(params)
    # 等待端口起来
    for _ in range(40):
        health = _health(params, timeout=2)
        if health and health.get("ok"):
            _push_config(params)
            _start_host_heartbeat()
            _note_bridge_settings(health)
            return health
        time.sleep(0.5)
    raise RuntimeError("PLUGIN_ERROR:::桥接服务启动超时，请检查插件设置中的端口是否被占用")


# ---------------------------------------------------------------------------
# 豆包可选时长档位（秒，升序）。管理器已支持 15s / 30s，不再写死"三档"；
# 这个列表只用于「时长跟随分镜」时向上就近取档。页面实际提供哪些档位由注入脚本
# dbm._durTiers() 动态发现，页面没有的档位会自动就近落到真实存在的档。
_DURATION_TIERS = (4, 10, 15, 30)


def _safe_seconds(v):
    """把 "10" / "10s" / "10秒" 归一化成字符串秒数；非法返回 None。"""
    try:
        n = int(str(v).strip().rstrip("sS秒 "))
    except Exception:
        return None
    return str(n) if 1 <= n <= 600 else None


def _pick_duration(context, params):
    # 默认固定使用设置里的时长，不被分镜时长覆盖
    fixed = _safe_seconds(params.get("default_duration", "10")) or "10"
    if not params.get("duration_follow_scene", False):
        return fixed
    raw = context.get("scene_duration") or context.get("audio_duration") or 0
    try:
        secs = float(raw)
    except Exception:
        secs = 0
    if secs <= 0:
        return fixed
    # 向上就近取档（含管理器新增的 15s / 30s）；超出最大档则取最大档
    for cand in _DURATION_TIERS:
        if secs <= cand:
            return str(cand)
    return str(_DURATION_TIERS[-1])


_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}


def _clean_context_path(value):
    """把宿主 context 里的路径片段归一化成本地路径字符串。

    宿主（字字动画）跨进程传参时可能给：
      - file:/// URI，且中文路径经过 URL 编码（Vidu 插件用 unquote 兼容）
      - local-file:/// 或 local-file:// URI：宿主前端 NVe()/Mi() 把本地文件
        转成可显示 URI 时用的方案（encodeURI，保留 : 和 /）
      - /__local_file__/<逐段 encodeURIComponent>：宿主前端 FOt() 为真时
        的另一套本地文件前缀，必须逐段解码才能还原盘符
      - 首尾带引号的字符串
      - 末尾带 ?xxx 查询串
    旧实现只做了 file:/// 的 text[8:] 截取，URL 编码的中文路径、
    local-file:/// 与 /__local_file__/ 前缀都会让 isfile() 失败，
    表现为「参考项里明明有图/音频，插件却说未检测到」。
    图片与音频两个迭代器共用本函数，所以这里是整条参考项链路的入口。
    """
    if value is None or isinstance(value, bool):
        return ""
    try:
        text = os.fspath(value)
    except TypeError:
        try:
            text = str(value)
        except Exception:
            return ""
    text = text.strip().strip('"').strip("'").strip()
    from urllib.parse import unquote
    # 顺序很重要：local-file:/// 比 local-file:// 长，必须先匹配。
    # 与宿主前端 NVe() 完全一致：四种前缀都只做 decodeURI(slice(n))，
    # 不额外补前导斜杠（补了会让本地路径以反斜杠开头，Windows 上必然找不到）。
    # 每条只解码一次，避免把 %2F 二次解成路径分隔符。
    for prefix, cut in (("local-file:///", 14), ("local-file://", 13),
                        ("file:///", 8), ("file://", 7)):
        if text.startswith(prefix):
            text = unquote(text[cut:])
            break
    else:
        if text.startswith("/__local_file__/"):
            text = unquote(text[len("/__local_file__/"):])
    return text.split("?", 1)[0]


def _object_as_dict(value):
    """宿主可能把「参考项」条目传成自定义对象而不是 dict。

    同宿主的 Vidu 插件用 vars() / getattr 兼容这种形态，这里对齐，
    否则对象形态的参考音频会被整个跳过。
    """
    if isinstance(value, dict):
        return value
    try:
        data = vars(value)
        if isinstance(data, dict) and data:
            return data
    except Exception:
        pass
    collected = {}
    for attr in ("audio_path", "audioPath", "audio_file", "audioFile",
                 "path", "image_path", "file_path", "filepath", "filePath",
                 "local_path", "localPath", "src", "source", "url", "file",
                 "name", "label", "type", "media_type", "mediaType"):
        try:
            v = getattr(value, attr)
        except Exception:
            continue
        if not callable(v):
            collected[attr] = v
    return collected


def _iter_context_images(value, label="参考图"):
    """递归遍历 context 里的图片字段，产出 (角色名, 本地绝对路径)。

    兼容宿主可能传入的各种结构：
      - 字符串 / PathLike（支持 file:/// URI）
      - dict：path/file_path/local_path/image_path/image_url/url/src 等键，
              或直接以名称为键的嵌套 dict（如 reference_images["首帧"]、参考图片MAP）
      - list / tuple
    """
    if value is None:
        return
    if isinstance(value, (str, os.PathLike)):
        text = _clean_context_path(value)
        if text and os.path.splitext(text)[1].lower() in _IMAGE_EXTS \
                and os.path.isfile(text):
            yield label, os.path.abspath(text)
        return
    if not isinstance(value, (dict, list, tuple)):
        obj = _object_as_dict(value)
        if obj:
            yield from _iter_context_images(obj, label)
        return
    if isinstance(value, dict):
        for key in ("path", "file_path", "local_path", "image_path",
                    "image_url", "url", "src"):
            if key in value:
                sub_label = str(value.get("name") or value.get("label") or label)
                found = list(_iter_context_images(value[key], sub_label))
                if found:
                    yield from found
                    return
        for key, item in value.items():
            yield from _iter_context_images(item, str(key))
        return
    if isinstance(value, (list, tuple)):
        for idx, item in enumerate(value, 1):
            yield from _iter_context_images(item, f"{label}{idx}")


def _collect_task_images(context, max_images=None):
    """按优先级收集本任务要上传给豆包的参考图（首帧 → 尾帧 → 关联参考图），去重、限量。

    max_images <= 0（或 None）表示不限制；宿主 context 里的「参考图片MAP」
    会显式优先遍历，保证分镜关联的参考图不会被遗漏或受 dict 顺序影响。
    """
    ordered = []
    seen = set()

    def add(value, label):
        for role, path in _iter_context_images(value, label):
            key = os.path.normcase(os.path.realpath(path))
            if key in seen:
                continue
            seen.add(key)
            ordered.append((role, path))

    # 宿主前端同时兼容 snake_case 与 camelCase（K9t(): reference_items /
    # referenceItems，条目内 media_type / mediaType / type），这里两侧都收。
    raw_ref = context.get("reference_images")
    if raw_ref is None:
        raw_ref = context.get("referenceImages", {})
    if isinstance(raw_ref, str):
        try:
            raw_ref = json.loads(raw_ref)
        except Exception:
            raw_ref = {}
    ref_map = raw_ref if isinstance(raw_ref, dict) else {}

    # 1. 首帧：显式字段优先，其次 reference_images["首帧"]
    for key in ("first_frame_path", "first_frame_image",
                "start_frame_path", "start_frame_image"):
        add(context.get(key), "首帧")
    add(ref_map.get("首帧"), "首帧")
    # 2. 尾帧：显式字段优先，其次 reference_images["尾帧"]
    for key in ("end_frame_path", "last_frame_path",
                "end_frame_image", "last_frame_image"):
        add(context.get(key), "尾帧")
    add(ref_map.get("尾帧"), "尾帧")
    # 3. 分镜「关联的参考图」：宿主放在 reference_images["参考图片MAP"] 里
    #    （与 qiling / video-3.x 插件的字段约定一致）。显式优先遍历：
    #    _iter_context_images 碰到 dict 上的 path/url 元数据键会提前 return，
    #    只靠整体递归有可能把 MAP 里的关联参考图整批漏掉。
    ref_asset_map = ref_map.get("参考图片MAP") if isinstance(ref_map, dict) else None
    add(ref_asset_map, "参考图")
    # 4. 其余参考图：reference_images 整体递归补漏 + 其它同义字段（seen 去重）
    add(raw_ref, "参考图")
    for key in ("reference_image_paths", "selected_reference_images",
                "selected_reference_image_paths", "ref_image_paths",
                "ref_images", "image_references",
                "reference_items", "referenceItems",
                "selected_references", "selectedReferences", "references",
                "reference_assets", "referenceAssets",
                "reference_media", "referenceMedia",
                "media_items", "mediaItems",
                "character_images", "character_image_paths",
                "scene_images", "scene_image_paths"):
        add(context.get(key), "参考图")

    import sys as _sys
    limit = DEFAULT_MAX_REFERENCE_IMAGES if max_images is None else max_images
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = DEFAULT_MAX_REFERENCE_IMAGES
    picked = ordered if limit <= 0 else ordered[:limit]
    # 诊断日志：候选数 > 实际数时，一眼看出是「宿主只给了几张」还是「被上限截了」
    print(f"[doubao_manager] 参考图候选 {len(ordered)} 张，上限 "
          f"{'不限' if limit <= 0 else limit} 张，实际取 {len(picked)} 张",
          file=_sys.stderr, flush=True)
    return picked


# 与豆包对话框 input[type=file] 的真实 accept 严格对齐（CDP 实测）：
# .mp3,.wav,.m4a,.wma,.aac,.ogg,.amr,.flac,.aiff,.ac3
# 旧白名单多放了 .mpga / .opus，豆包根本不接受这两个格式，放行后页面不渲染
# 附件卡，桥接会一直判「附件不匹配」直到超时；绝不能比页面 accept 更宽。
_AUDIO_EXTS = {
    ".mp3", ".wav", ".m4a", ".wma", ".aac", ".ogg", ".amr",
    ".flac", ".aiff", ".ac3",
}


def _iter_context_audios(value, label="参考音频"):
    """递归遍历 context，产出 (来源标签, 本地音频绝对路径)。

    兼容宿主（字字动画「参考项」）可能传入的各种结构：
      - 字符串 / PathLike（支持 file:/// URI）
      - dict：audio_path / path / file_path / local_path / src / url / file 等键，
              或「参考音频MAP」这类以名称 / 索引为键的嵌套 dict
      - list / tuple（参考项里图片与音频混排）
    只认 _AUDIO_EXTS 扩展名且本地确实存在的文件，避免把时长数字、
    提示词文本或图片误当成参考音频。
    """
    if value is None:
        return
    if isinstance(value, (str, os.PathLike)):
        text = _clean_context_path(value)
        if text and os.path.splitext(text)[1].lower() in _AUDIO_EXTS \
                and os.path.isfile(text):
            yield label, os.path.abspath(text)
        return
    # 宿主有时把参考项条目传成自定义对象（有 audio_path 等属性），不是 dict。
    if not isinstance(value, (dict, list, tuple)):
        obj = _object_as_dict(value)
        if obj:
            yield from _iter_context_audios(obj, label)
        return
    if isinstance(value, dict):
        for key in ("audio_path", "audioPath", "audio_file", "audioFile",
                    "software_audio_path", "path", "file_path", "filePath",
                    "local_path", "localPath", "src", "source", "url", "file"):
            if key in value:
                sub_label = str(value.get("name") or value.get("label") or label)
                found = list(_iter_context_audios(value[key], sub_label))
                if found:
                    yield from found
                    return
        for key, item in value.items():
            yield from _iter_context_audios(item, str(key))
        return
    if isinstance(value, (list, tuple)):
        for idx, item in enumerate(value, 1):
            yield from _iter_context_audios(item, f"{label}{idx}")


def _collect_task_audios(context, max_audios=None):
    """收集本任务要上传到豆包的参考音频，按来源优先级去重、限量（最多 3 个）。

    宿主把音频放在 reference_audios / reference_audio / reference_items 里
    （与同宿主的 Vidu 插件字段约定一致），不同版本还可能用「参考音频MAP」
    等中文键。这里三层扫描：显式音频字段 → 参考项混合列表 → 键名兜底，
    保证「参考项」里的音频不会被静默丢掉。
    """
    ordered = []
    seen = set()

    def add(value, label):
        for role, path in _iter_context_audios(value, label):
            key = os.path.normcase(os.path.realpath(path))
            if key in seen:
                continue
            seen.add(key)
            ordered.append((role, path))

    # 1. 显式参考音频字段（不含 audio_path / software_audio_path：
    #    那是宿主的配音音轨/BGM，不是「参考项」音频，见第 4 步兜底）
    for key in ("reference_audios", "referenceAudios",
                "reference_audio", "referenceAudio",
                "reference_audio_paths", "reference_audio_path",
                "reference_audios_map", "参考音频",
                "audios", "audio_paths",
                "selected_reference_audios",
                "ref_audios", "audio_references"):
        add(context.get(key), key)

    # 2. 参考项混合列表 / 参考素材字典：图片与音频混排，靠扩展名过滤
    raw_ref = context.get("reference_images")
    if raw_ref is None:
        raw_ref = context.get("referenceImages", {})
    if isinstance(raw_ref, str):
        try:
            raw_ref = json.loads(raw_ref)
        except Exception:
            raw_ref = {}
    if isinstance(raw_ref, dict):
        for key in ("参考音频MAP", "参考音频", "音频MAP", "音频"):
            add(raw_ref.get(key), f"reference_images.{key}")
        add(raw_ref, "reference_images")
    for key in ("reference_items", "referenceItems",
                "selected_references", "selectedReferences",
                "references", "reference_assets", "referenceAssets",
                "reference_media", "referenceMedia",
                "media_items", "mediaItems", "assets"):
        add(context.get(key), key)

    # 3. 键名兜底：宿主换了字段名，但键名里仍带 audio/音频/声音/voice/bgm/音乐
    for key, value in context.items():
        lk = str(key).lower()
        if not any(word in lk for word in
                   ("audio", "音频", "声音", "voice", "bgm", "音乐", "sound")):
            continue
        if lk in ("audio_duration", "software_audio_duration", "scene_duration",
                  "audio_path", "software_audio_path"):
            continue  # 时长是数字；音轨路径不是参考项，留到第 4 步兜底
        add(value, str(key))

    # 4. 最低优先级：宿主音轨字段。这些通常是整段配音 / BGM，不是「参考项」
    #    里的参考音频；只有当上面三层一个参考音频都没找到时才用它兜底，
    #    避免配音挤占 3 个名额、把真正的参考音频截断掉。
    if not ordered:
        for key in ("software_audio_path", "audio_path"):
            add(context.get(key), key)

    limit = HARD_MAX_REFERENCE_AUDIOS if max_audios is None else max_audios
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = HARD_MAX_REFERENCE_AUDIOS
    if limit <= 0 or limit > HARD_MAX_REFERENCE_AUDIOS:
        limit = HARD_MAX_REFERENCE_AUDIOS
    picked = ordered[:limit]
    print(f"[doubao_manager] 参考音频候选 {len(ordered)} 个，上限 {limit} 个，"
          f"实际取 {len(picked)} 个", file=sys.stderr, flush=True)
    return picked


def _build_output_path(context, suffix=".mp4"):
    output_dir = str(context.get("output_dir") or context.get("project_path") or ".").strip()
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    unique_name = str(context.get("unique_name") or "plugin").strip() or "plugin"
    viewer_index = int(context.get("viewer_index") or 0)
    generation_round = int(context.get("generation_round") or 0)
    position = 0
    output_position = context.get("output_position") or []
    if isinstance(output_position, list) and output_position:
        try:
            position = int(output_position[0])
        except Exception:
            position = 0
    return os.path.join(
        output_dir,
        f"{viewer_index:04d}_{unique_name}_{generation_round}_{position}{suffix}")


# ---------------------------------------------------------------------------
# 插件主入口
# ---------------------------------------------------------------------------

def generate(context):
    context = context or {}

    # 幂等跳过：批量分发时，如果字字动画中该分镜本轮已有回传的视频文件，
    # 直接复用、不再向豆包管理器分发（省账号额度，也避免重复生成覆盖）。
    # 文件名含 generation_round，新一轮生成会得到新文件名，不会误跳过。
    progress = context.get("progress_callback")
    try:
        existing = _build_output_path(context, ".mp4")
        if Path(existing).exists() and Path(existing).stat().st_size > 50 * 1024:
            if callable(progress):
                try:
                    progress("分镜已有回传视频，跳过分发", 100)
                except Exception:
                    pass
            print(f"[doubao_manager] 分镜视频已存在，跳过分发: {existing}")
            return [existing]
    except Exception:
        pass

    params = get_params()
    params.update(context.get("plugin_params") or {})

    def report(text, percent=None):
        if callable(progress):
            try:
                progress(text, percent)
            except Exception:
                pass

    report("连接豆包桥接服务…", 2)
    _ensure_bridge(params)
    if _BRIDGE_SETTINGS_SNAPSHOT:
        print("[doubao_manager] 本次按任务控制台额度派发：Fast %s 次 / Mini %s 次"
              "（任一满即整账号停派），强制冷却 %s 个账号"
              % (_BRIDGE_SETTINGS_SNAPSHOT.get("fast"),
                 _BRIDGE_SETTINGS_SNAPSHOT.get("mini"),
                 _BRIDGE_SETTINGS_SNAPSHOT.get("cooldown_count", 0)),
              file=sys.stderr, flush=True)

    # 视频提示词：优先 video_prompt，其次 prompt
    prompt = (context.get("video_prompt") or context.get("prompt") or "").strip()
    if not prompt:
        raise RuntimeError("PLUGIN_ERROR:::当前分镜没有视频提示词，请先生成视频提示词")

    # 参考项：参考图递归解析 context 各种字段（首帧/尾帧/参考图片MAP/角色/场景图），
    # 与 qiling、video_plugin_doubao 的字段约定对齐；首帧优先，去重限量。
    # 参考音频同样从「参考项」里解析（reference_audios / reference_items / 音频MAP），
    # 与图片一起提交给桥接，由桥接通过同一个 file input 一并上传到豆包账号。
    max_imgs = _ref_image_limit(params)
    task_images = _collect_task_images(context, max_imgs)
    max_auds = _ref_audio_limit(params)
    task_audios = _collect_task_audios(context, max_auds)
    first_frame = task_images[0][1] if task_images else ""
    image_paths = [p for _role, p in task_images]
    audio_paths = [p for _role, p in task_audios]
    import sys as _sys
    if task_images:
        for role, p in task_images:
            print(f"[doubao_manager] 参考图[{role}]: {p}", file=_sys.stderr, flush=True)
    else:
        print("[doubao_manager] 未检测到参考图，走纯文生视频", file=_sys.stderr, flush=True)
    if task_audios:
        for role, p in task_audios:
            print(f"[doubao_manager] 参考音频[{role}]: {p}", file=_sys.stderr, flush=True)
    else:
        print("[doubao_manager] 未检测到参考音频", file=_sys.stderr, flush=True)

    duration = _pick_duration(context, params)
    aspect = str(params.get("default_aspect", "自动") or "自动")
    if aspect not in ("自动","3:4","4:3","9:16","16:9","1:1","21:9"):
        aspect = "自动"
    account = str(params.get("default_account", "")).strip()

    img_note = f" · 参考图 {len(image_paths)} 张" if image_paths else ""
    aud_note = f" · 参考音频 {len(audio_paths)} 个" if audio_paths else ""
    report(f"分发任务给豆包管理器（比例 {aspect} · 时长 {duration}s"
           f"{img_note}{aud_note}）…", 5)

    # ★ 2026-11-03：把「这个任务该回传到哪个分镜窗口」一并交给桥接。
    # 桥接成品落盘后会直接复制到 dest，宿主即使判失败 / 超时 / 中途关闭，
    # 视频也已经躺在分镜窗口对应的路径上。
    try:
        _scene_dest = _build_output_path(context, ".mp4")
    except Exception:
        _scene_dest = ""
    _op = context.get("output_position") or []
    try:
        _scene_pos = int(_op[0]) if isinstance(_op, list) and _op else 0
    except (TypeError, ValueError):
        _scene_pos = 0

    def _as_int(v):
        try:
            return int(v or 0)
        except (TypeError, ValueError):
            return 0

    scene = {
        "dest": _scene_dest,
        "output_dir": str(context.get("output_dir") or context.get("project_path") or ""),
        "project_path": str(context.get("project_path") or ""),
        "unique_name": str(context.get("unique_name") or ""),
        "viewer_index": _as_int(context.get("viewer_index")),
        "generation_round": _as_int(context.get("generation_round")),
        "position": _scene_pos,
    }
    try:
        resp = _http("POST", _base(params) + "/api/tasks", {
            "prompt": prompt,
            "negative_prompt": context.get("negative_prompt", ""),
            "duration": duration,
            "aspect": aspect,
            "first_frame": first_frame,
            "images": image_paths,
            # ★ 2026-11-13：字字动画「参考项」里的参考音频，和参考图一起送进
            #   豆包账号（此前完全没解析，音频只体现在提示词文字里）。
            "audios": audio_paths,
            "account": account,
            "scene": scene,
        }, timeout=30)
    except Exception as e:
        raise RuntimeError(f"PLUGIN_ERROR:::提交任务失败：{e}")
    if not resp.get("ok"):
        raise RuntimeError(f"PLUGIN_ERROR:::{resp.get('error', '提交任务失败')}")

    # ★ 2026-11-13：桥接在 /api/tasks 里已同步扫描过"此刻已打开的豆包账号"，
    #   剔除关闭账号 / 无额度账号后立刻唤醒派发。这里把结果落到日志与进度里，
    #   用户能直接看到"只给哪些账号派了单、哪些被跳过"。
    _disp = resp.get("dispatch") or {}
    if _disp and not _disp.get("error"):
        _skip = (len(_disp.get("skipped_offline") or [])
                 + len(_disp.get("skipped_no_quota") or [])
                 + len(_disp.get("skipped_cooldown") or []))
        report(f"已扫描豆包账号：打开 {_disp.get('live_accounts', '-')} 个 · "
               f"可派发 {_disp.get('available_accounts', '-')} 个 · "
               f"跳过 {_skip} 个 · 立即分派", 6)
        print("[doubao_manager_video] 派发前扫描："
              "可派发=%s / 已关闭=%s / 无额度=%s / 冷却=%s / 忙碌=%s"
              % (_disp.get("available"), _disp.get("skipped_offline"),
                 _disp.get("skipped_no_quota"), _disp.get("skipped_cooldown"),
                 _disp.get("skipped_busy")), file=sys.stderr, flush=True)
        if not _disp.get("available_accounts"):
            report("当前没有可派发的账号（未打开 / 忙碌 / 无额度 / 已冷却），任务保持排队", 6)

    tid = resp["task_id"]
    budget = int(params.get("task_timeout_sec", 1800)) + 120
    # 有上限的排队/重试预算；每次真正提交按新的 submit_ts 重新计时。
    started = time.time()
    hard_deadline = started + budget * (max(0, int(params.get("max_gen_retries", 2))) + 3)
    gen_deadline = min(hard_deadline, started + budget)
    last_attempt = None

    def _wait_and_fetch():
        nonlocal gen_deadline, last_attempt
        # 轮询任务
        last_status = ""
        while time.time() < gen_deadline:
            try:
                r = _http("GET", _base(params) + f"/api/tasks/{tid}", timeout=15)
            except Exception:
                time.sleep(3)
                continue
            if not r.get("ok"):
                time.sleep(3)
                continue
            t = r["task"]
            status = t.get("status", "")
            pct = int(t.get("percent") or 0)
            msg = t.get("message") or _STATUS_TEXT.get(status, status)
            if status != last_status or pct % 5 == 0:
                report(f"豆包管理器：{msg}", max(5, min(99, pct)))
                last_status = status

            # 排队不占用生成预算；总截止仍防止离线账号导致无限等待。
            if status == "queued":
                gen_deadline = min(hard_deadline, time.time() + budget)
            try:
                attempt = (int(t.get("gen_retries") or 0), float(t.get("submit_ts") or 0))
                if attempt != last_attempt:
                    last_attempt = attempt
                    gen_deadline = min(hard_deadline, time.time() + budget)
            except (TypeError, ValueError):
                pass

            if status == "done":
                video_path = t.get("video_path", "")
                if not video_path:
                    raise RuntimeError("PLUGIN_ERROR:::任务已完成但桥接未返回视频路径，请查看桥接控制台")
                # 防御性重试：桥接标记 done 后 Electron/浏览器可能短暂清理文件
                max_retries = 3
                for attempt in range(max_retries):
                    if Path(video_path).exists():
                        break
                    if attempt < max_retries - 1:
                        time.sleep(1)
                else:
                    raise RuntimeError("PLUGIN_ERROR:::任务已完成但找不到视频文件，请查看桥接控制台")
                dest = _build_output_path(context, ".mp4")
                # ★ 2026-11-14 回传一致性强化：桥接 _finish_done 会把成品 MD5
                #   写进任务。取回前再核对一次，防止 done 之后成品文件被别的
                #   任务覆盖 / 替换，导致放进分镜的不是当初确认的那条视频。
                _expect_md5 = str(t.get("video_md5") or "").strip()
                if _expect_md5:
                    try:
                        import hashlib as _hashlib
                        _h = _hashlib.md5()
                        with open(video_path, "rb") as _fh:
                            while True:
                                _chunk = _fh.read(1024 * 1024)
                                if not _chunk:
                                    break
                                _h.update(_chunk)
                        if _h.hexdigest() != _expect_md5:
                            raise RuntimeError(
                                "PLUGIN_ERROR:::成品内容在回传前发生变化（MD5 不一致，"
                                "疑似串片），已拒绝把视频放入分镜，请在桥接控制台核对后重新生成")
                    except RuntimeError:
                        raise
                    except Exception:
                        pass  # 读文件异常交给下面的 copy2 正常报错
                shutil.copy2(video_path, dest)
                # 回报桥接：分镜已收到，标记该任务已回传。
                # 桥接侧 _finish_done 也会自动复制一次，两边幂等（同内容不覆盖）。
                try:
                    _http("POST", _base(params) + f"/api/tasks/{tid}/delivered",
                          {"dest": dest}, timeout=5)
                except Exception:
                    pass
                report("视频已取回分镜", 100)
                return [dest]

            if status == "needs_calibration":
                tail = ""
                try:
                    logs = t.get("logs") or []
                    if logs:
                        tail = "\n最近日志：\n" + "\n".join(str(x) for x in logs[-8:])
                except Exception:
                    pass
                raise RuntimeError(
                    "PLUGIN_ERROR:::豆包网页结构需要标定（插件第一步已完成）。"
                    "请打开桥接控制台 http://%s:%s/ 查看任务日志，并联系开发者更新 selectors.json。%s"
                    % (params.get("bridge_host", "127.0.0.1"),
                       params.get("bridge_port", 39230), tail))

            if status == "error":
                raise RuntimeError(f"PLUGIN_ERROR:::{t.get('error') or t.get('message') or '任务失败'}")

            # ★ 2026-11-14 全面检查修复：桥接回传前一致性校验拒绝时写的是
            #   status="failed" 而非 "error"。旧状态机不认这个终态，会白等
            #   整个 task_timeout_sec+120 预算后误报「等待出片超时」，并在
            #   外层撤销时把真实失败原因覆盖成「已取消」。这里立即如实上报。
            if status == "failed":
                _why = (t.get("deliver_consistency_error")
                        or t.get("message") or "成品一致性校验未通过，拒绝回传")
                raise RuntimeError(
                    "PLUGIN_ERROR:::成品未回传（防止串片）：%s。"
                    "请在任务控制台查看该任务日志后重新生成" % _why)

            time.sleep(int(params.get("poll_interval_sec", 3) or 3))

        raise RuntimeError("PLUGIN_ERROR:::等待豆包管理器出片超时，请在桥接控制台查看任务状态")

    # 从"任务已进入桥接队列"这一刻起，字字动画侧的任何失败（报错 / 超时 / 用户中断）
    # 都必须同步给桥接把任务取消掉。否则桥接仍会继续排队重试、继续回收，
    # 白白消耗账号额度，产出的视频也永远不会有人来取。
    try:
        return _wait_and_fetch()
    except BaseException as e:
        # 用 BaseException：用户点"停止"时宿主可能往插件线程里抛 SystemExit 之类的
        # 非 Exception 异常，这时同样要取消桥接任务。
        try:
            reason = f"{type(e).__name__}: {str(e)[:120]}"
        except Exception:
            reason = type(e).__name__
        _cancel_bridge_task(params, tid, f"字字动画侧失败 → {reason}")
        raise


# ---------------------------------------------------------------------------
# UI 动作（iframe 设置页通过 PluginSDK.sendAction 调用）
# ---------------------------------------------------------------------------

def _auto_open_accounts(params):
    """测试连接 / 启动管理器后自动打开全部豆包账号。

    开号模块是插件目录里的 open_all_accounts.py（直连 CDP 调渲染层
    window.openAccount）。失败不阻断测试连接本身，结果交给设置页回显。
    """
    try:
        import importlib.util
        _p = Path(__file__).resolve().parent / "open_all_accounts.py"
        if not _p.exists():
            return {"ok": False, "msg": "找不到开号模块：%s" % _p}
        _spec = importlib.util.spec_from_file_location(
            "dbm_open_all_accounts_ui", str(_p))
        _mod = importlib.util.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        return _mod.open_all(
            cdp_port=int(params.get("cdp_port", 39233) or 39233),
            wait_cdp=30)
    except Exception as e:
        return {"ok": False, "msg": "自动打开账号异常：%s" % e}


# ---------------------------------------------------------------------------
# 测试连接提速：启动管理器 + 全量开号放进后台线程，设置页立即恢复可操作
# ---------------------------------------------------------------------------

_AUTO_OPEN_LOCK = threading.Lock()
_AUTO_OPEN_STATE = {"running": False, "stage": "", "result": None, "ts": 0.0}


def _auto_open_snapshot():
    with _AUTO_OPEN_LOCK:
        return {"running": bool(_AUTO_OPEN_STATE["running"]),
                "stage": _AUTO_OPEN_STATE["stage"],
                "result": _AUTO_OPEN_STATE["result"],
                "age": round(time.time() - float(_AUTO_OPEN_STATE["ts"] or 0), 1)}


def _open_all_module():
    import importlib.util
    _p = Path(__file__).resolve().parent / "open_all_accounts.py"
    _spec = importlib.util.spec_from_file_location("dbm_open_all_shared", str(_p))
    _mod = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_mod)
    return _mod


def _auto_open_quick(params):
    """热态快路径：近期开号成功且账号仍全开时直接返回结果，不启后台。"""
    try:
        mod = _open_all_module()
        st = mod._load_state()
        if not (st and st.get("ok")
                and time.time() - float(st.get("ts") or 0) < 60):
            return None
        port = int(params.get("cdp_port", 39233) or 39233)
        if not mod._cdp_is_manager(port):
            return None
        acc = mod._webview_accounts(port)
        total = int(st.get("total") or 0)
        if total and len(acc) >= total:
            return {"ok": True, "skipped": True, "opened": 0,
                    "before": len(acc), "after": len(acc), "total": total,
                    "accounts": acc, "cdp_port": port, "reason": "",
                    "msg": "账号已全部打开（%d/%d），无需重复打开" % (len(acc), total)}
    except Exception:
        pass
    return None


def _auto_open_async(params, health):
    """后台执行：复用/启动管理器 → 等 CDP → 打开所有账号。返回是否新起了任务。"""
    with _AUTO_OPEN_LOCK:
        if _AUTO_OPEN_STATE["running"]:
            return False
        _AUTO_OPEN_STATE.update(running=True, stage="正在启动豆包管理器",
                                result=None, ts=time.time())

    def _worker():
        result = None
        try:
            # ★ 2026-11-14：不再依赖 ping 时那份可能过期的 health 快照来决定
            # 要不要拉起管理器（启动窗口里它常是 False，会造成重复 Popen 并弹
            # 「程序已经在运行中，请勿重复启动」）。统一交给桥接的
            # /api/manager/launch：端点内有进程级单实例闸门，且幂等可重复调用。
            # health 仅保留调用兼容，不再参与启动判定。
            try:
                launch = _http("POST", _base(params) + "/api/manager/launch",
                               {}, timeout=90) or {}
            except Exception as e:
                launch = {"ok": False, "reason": "launch_endpoint_failed",
                          "error": str(e)}
            if not launch.get("ok"):
                err = str(launch.get("error") or "桥接未返回具体原因")
                reason = str(launch.get("reason") or "manager_not_started")
                result = {"ok": False, "reason": reason,
                          "msg": "管理器未就绪：" + err}
                return
            # 用桥接回传的真实 CDP 端口开号：卡密版写在 DevToolsActivePort，
            # 往往不是设置页里的 39233，拿旧端口会白等 30 秒。
            p2 = dict(params)
            try:
                p2["cdp_port"] = int(launch.get("cdp_port")
                                     or params.get("cdp_port", 39233) or 39233)
            except Exception:
                pass
            with _AUTO_OPEN_LOCK:
                _AUTO_OPEN_STATE["stage"] = "正在打开所有账号"
            result = _auto_open_accounts(p2)
        except Exception as e:
            result = {"ok": False, "msg": "后台任务异常：%s" % e}
        finally:
            with _AUTO_OPEN_LOCK:
                _AUTO_OPEN_STATE["running"] = False
                _AUTO_OPEN_STATE["stage"] = "完成"
                _AUTO_OPEN_STATE["result"] = result

    threading.Thread(target=_worker, daemon=True, name="dbm-auto-open").start()
    return True


def _ping_payload(bridge_state, health, auto, pending):
    return {"ok": True, "data": {
        "bridge": bridge_state,
        "manager_running": health.get("manager_running"),
        "accounts": (auto.get("accounts") or health.get("accounts", [])),
        "download_dir": health.get("download_dir"),
        # 把控制台设置的额度 / 冷却回传给设置页展示，用户不用另开控制台就能确认
        "daily_limits": health.get("daily_limits") or {},
        "cooldown_count": health.get("cooldown_count", 0),
        "cooldown_accounts": health.get("cooldown_accounts") or [],
        "immediate_dispatch": bool(health.get("immediate_dispatch", True)),
        "live_scan": health.get("live_scan") or {},
        "auto_open": auto,
        "pending": pending,
    }}


def handle_action(action, data, context=None):
    data = data or {}
    try:
        if action == "ping":
            params = get_params()
            params.update(data.get("params") or {})
            health = _health(params, timeout=2)
            bridge_state = "running"
            if not (health and health.get("ok")):
                try:
                    _ensure_bridge(params)
                    health = _health(params, timeout=2)
                    bridge_state = "started"
                except Exception as e:
                    return {"ok": False, "error": f"桥接启动失败：{e}"}
            health = health or {}
            # 桥接回传的真实 CDP 端口优先于设置页里填的端口（卡密版会顺延，
            # 并写进 DevToolsActivePort）。只用于本地开号，不回推给桥接配置。
            hparams = dict(params)
            if health.get("cdp_port"):
                hparams["cdp_port"] = health["cdp_port"]
            # 热态快路径：CDP 在线、账号已全开且近期开过号 → 直接给结果
            quick = _auto_open_quick(hparams)
            if quick is not None:
                return _ping_payload(bridge_state, health, quick, False)
            # 冷启动：复用/启动管理器 + 全量开号放进后台，按钮立即恢复
            _auto_open_async(hparams, health)
            st = _auto_open_snapshot()
            return _ping_payload(bridge_state, health, {
                "ok": False, "pending": True, "skipped": False,
                "stage": st["stage"],
                "msg": "已在后台启动管理器并打开所有账号，完成后自动显示结果",
            }, True)

        if action == "auto_open_status":
            return {"ok": True, "data": _auto_open_snapshot()}

        if action == "open_console":
            params = get_params()
            params.update(data.get("params") or {})
            url = f"http://{params.get('bridge_host', '127.0.0.1')}:{int(params.get('bridge_port', 39230))}/"
            try:
                _ensure_bridge(params)
            except Exception:
                pass
            webbrowser.open(url)
            return {"ok": True, "data": {"url": url}}

        if action == "launch_manager":
            params = get_params()
            params.update(data.get("params") or {})
            _ensure_bridge(params)
            try:
                r = _http("POST", _base(params) + "/api/manager/launch", {}, timeout=60)
                auto = _auto_open_accounts(params)
                return {"ok": True, "data": {
                    "manager_running": r.get("manager_running"),
                    "accounts": r.get("accounts", []),
                    "msg": "管理器已就绪" if r.get("manager_running") else "管理器启动中",
                    "auto_open": auto,
                }}
            except Exception as e:
                return {"ok": False, "error": f"启动管理器失败：{e}"}

        if action == "open_all_accounts":
            params = get_params()
            params.update(data.get("params") or {})
            _ensure_bridge(params)
            try:
                r = _http("POST", _base(params) + "/api/accounts/open-all", {}, timeout=90)
                return {"ok": r.get("ok", False), "data": r}
            except Exception as e:
                return {"ok": False, "error": f"批量打开账号失败：{e}"}

        if action == "close_all_accounts":
            params = get_params()
            params.update(data.get("params") or {})
            _ensure_bridge(params)
            try:
                r = _http("POST", _base(params) + "/api/accounts/close-all", {}, timeout=90)
                return {"ok": r.get("ok", False), "data": r}
            except Exception as e:
                return {"ok": False, "error": f"批量关闭账号失败：{e}"}

        if action == "run_selfcheck":
            # 插件内置自检：不依赖外部 bat / 工作脚本目录，报告直接回显到设置页
            import importlib.util
            _sc = Path(__file__).resolve().parent / "selfcheck.py"
            if not _sc.exists():
                return {"ok": False, "error": f"找不到自检模块：{_sc}"}
            _spec = importlib.util.spec_from_file_location(
                "dbm_selfcheck_ui", str(_sc))
            _mod = importlib.util.module_from_spec(_spec)
            _spec.loader.exec_module(_mod)
            _r = _mod.run_check()
            return {"ok": True, "data": {"all_ok": _r["ok"],
                                         "report": _r["report"],
                                         "problems": _r["problems"]}}

        if action == "open_selfcheck_window":
            # 在独立 cmd 窗口运行同目录 bat（等价于用户手动双击）
            _bat = Path(__file__).resolve().parent / "一键自检插件链路.bat"
            if not _bat.exists():
                return {"ok": False, "error": f"找不到自检脚本：{_bat}"}
            os.startfile(str(_bat))
            return {"ok": True, "data": {"path": str(_bat)}}

        return {"ok": False, "error": f"未知动作: {action}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

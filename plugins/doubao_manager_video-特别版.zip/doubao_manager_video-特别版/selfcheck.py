# -*- coding: utf-8 -*-
"""插件内置链路自检（纯标准库，无外部依赖）。

按插件拆开：视频插件只查视频桥接，图片插件只查图片桥接，互不交叉。
两个插件共用同一个豆包管理器（CDP 39233），CDP 身份 / 账号页 / 旧端口残留
属于共用部分，两边都查；但只有视频插件负责把管理器拉起，图片插件不负责、
也不因此判自己故障。

两处复用同一份逻辑：
  1) 设置页「一键自检链路」按钮 -> main.py handle_action('run_selfcheck') -> run_check()
  2) 同目录「一键自检插件链路.bat」-> python selfcheck.py -> 打印报告

本文件由统一模板生成到两个插件目录，
两份只有下面四个常量不同，逻辑完全一致，改逻辑只需改本模板。
本地请求一律绕开系统代理：全局代理会把 127.0.0.1 也转发，返回 502，
导致 CDP 探测误判成「管理器没运行」。
"""
import json
import socket
import sys
import urllib.request

KIND = "video"
BRIDGE_PORT = 39230
BRIDGE_NAME = "视频"
SERVICE_ID = "doubao-video-bridge"

CDP_PORT = 39233
OLD_PORTS = (9222, 9223, 9230, 9231, 9333)

# 2026-11-13：端口以 bridge/config.json 为准。跨电脑适配版可能用 9230/9223，
# 写死 39230/39233 会去探测不存在的端口，还会把客户机在用的端口误判成旧端口残留。
try:
    import os as _os
    _cfg_path = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)),
                              "bridge", "config.json")
    with open(_cfg_path, encoding="utf-8") as _fp:
        _cfg = json.load(_fp)
    BRIDGE_PORT = int(_cfg.get("bridge_port") or BRIDGE_PORT)
    CDP_PORT = int(_cfg.get("cdp_port") or CDP_PORT)
except Exception:
    pass
OLD_PORTS = tuple(p for p in OLD_PORTS if p not in (BRIDGE_PORT, CDP_PORT))

_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def get_json(url, timeout=2.0):
    try:
        with _OPENER.open(url, timeout=timeout) as r:
            return json.load(r)
    except Exception as e:
        return {"__error__": str(e)}


def listening(port):
    s = socket.socket()
    # 本机未监听端口的 connect_ex 不会立刻拒绝，而是走满超时返回 10035，
    # 旧值 0.5s × 5 个旧端口会让自检白等 2.5 秒，故收紧到 0.05s。
    s.settimeout(0.05)
    try:
        return s.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s.close()


def run_check():
    lines, problems = [], []
    lines.append(f"=== {BRIDGE_NAME}插件链路自检 "
                 f"（{BRIDGE_NAME}桥接 {BRIDGE_PORT} -> CDP {CDP_PORT}）===")

    # CDP 端口未监听时先短路，不再发 HTTP：某些机器对未监听端口的
    # urlopen 不会立即拒绝而是走满超时，每次自检要白等 1.2 秒。
    cdp_up = listening(CDP_PORT)
    ver = (get_json(f"http://127.0.0.1:{CDP_PORT}/json/version", timeout=1.2)
           if cdp_up else {"__error__": "CDP 端口未监听"})
    ua = ver.get("User-Agent", "") if "__error__" not in ver else ""
    is_mgr = "豆包管理器" in ua
    lines.append(
        f"[1] 共用 CDP {CDP_PORT}: {'在线' if cdp_up else '未监听'}; "
        f"身份={'豆包管理器 OK' if is_mgr else '不是管理器 / 不可达'}")
    if not is_mgr:
        lines.append("    " + (ua[:120] or str(ver.get("__error__", ""))[:120]))
        hint = ("两个插件共用同一个管理器，任一插件点「测试连接」都会拉起它；"
                "不要手动双击 exe")
        problems.append(f"CDP {CDP_PORT} 不是豆包管理器（{hint}）")

    if is_mgr:
        targets = get_json(f"http://127.0.0.1:{CDP_PORT}/json/list", timeout=1.2)
        tl = targets if isinstance(targets, list) else []
        wv = [t for t in tl if isinstance(t, dict) and t.get("type") == "webview"]
        chat = [t for t in wv if "doubao.com/chat" in (t.get("url") or "")]
        lines.append(f"[2] 共用账号页: webview={len(wv)} doubao/chat={len(chat)}")
        if not chat:
            problems.append("没有已打开的豆包账号页（点一次「测试连接」自动打开全部账号）")
    else:
        # CDP 都不可达时不再查账号页，也不追加一条重复故障项
        lines.append("[2] 共用账号页: CDP 不可用，跳过")

    strays = []
    for p in OLD_PORTS:
        if not listening(p):          # 先快速过滤，避免多次 HTTP 超时叠加
            continue
        v = get_json(f"http://127.0.0.1:{p}/json/version", timeout=0.8)
        u = v.get("User-Agent", "") if "__error__" not in v else ""
        if "豆包管理器" in u:
            strays.append(str(p))
    lines.append(f"[3] 旧端口 {OLD_PORTS}: " +
                 (f"发现管理器占用 {','.join(strays)}（配置可能回退）"
                  if strays else "无管理器残留 OK"))
    if strays:
        problems.append("旧端口上跑着豆包管理器，可能回退到旧配置")

    # [4] 只检查本插件自己的桥接，绝不探测另一个插件的端口
    # 端口未监听时 urlopen 在这台机器上固定耗 ~2 秒才返回 10061，
    # health + config 两次就是 4 秒；先做 0.05 秒的端口预检短路。
    bridge_up = listening(BRIDGE_PORT)
    if bridge_up:
        health = get_json(f"http://127.0.0.1:{BRIDGE_PORT}/api/health", timeout=3)
        cfg = get_json(f"http://127.0.0.1:{BRIDGE_PORT}/api/config", timeout=2)
    else:
        health = {"__error__": "桥接端口未监听"}
        cfg = {}
    conf = cfg.get("config", {}) if "__error__" not in cfg else {}
    if "__error__" in health:
        lines.append(f"[4] {BRIDGE_NAME}桥接 {BRIDGE_PORT}: 不可达 "
                     f"{str(health['__error__'])[:90]}")
        problems.append(f"{BRIDGE_NAME}桥接未运行"
                        f"（在{BRIDGE_NAME}插件设置页点一次「测试连接」即可拉起）")
    else:
        svc = health.get("service")
        wc = health.get("worker_count") or 0
        lines.append(
            f"[4] {BRIDGE_NAME}桥接 {BRIDGE_PORT}: service={svc} "
            f"manager_running={health.get('manager_running')} "
            f"worker_count={wc} cdp_port={conf.get('cdp_port')}")
        if svc and svc != SERVICE_ID:
            problems.append(
                f"端口 {BRIDGE_PORT} 上跑的是「{svc}」，不是{SERVICE_ID}，"
                f"检查两个插件的桥接端口是否写反了")
        if conf.get("cdp_port") not in (None, CDP_PORT):
            problems.append(f"{BRIDGE_NAME}桥接 cdp_port={conf.get('cdp_port')}，"
                            f"应为 {CDP_PORT}")
        if KIND == "video":
            vd = get_json(f"http://127.0.0.1:{BRIDGE_PORT}/api/accounts", timeout=3)
            if "__error__" in vd:
                problems.append("视频桥接 /api/accounts 不可达")
            else:
                n = vd.get("raw_count") or 0
                lines.append(f"    /api/accounts raw_count={n} "
                             f"workers={len(vd.get('workers', []))}")
                if not n:
                    problems.append(f"视频桥接读不到账号（检查 cdp_port 是否为 {CDP_PORT}）")
        else:
            bg = conf.get("background_only_when_active", True)
            if wc == 0 and bg:
                lines.append("    worker_count=0 为空闲态：无任务时不占用豆包页面，"
                             "提交图片任务后自动加载，非故障")
            # 图片桥接 /api/health 的 manager_running 实际是「账号页数 > 0」：
            # 管理器在线但账号页还没打开时它为 False，不能据此判故障。
            if not health.get("manager_running") and is_mgr:
                lines.append("    manager_running=False 表示账号页还没打开；"
                             "点一次「测试连接」即可打开全部账号，非故障")
            elif not health.get("manager_running"):
                problems.append("图片桥接读不到管理器（两个插件共用同一个管理器，"
                                "点一次「测试连接」即可拉起并打开账号）")

    lines.append(f"说明: 本自检只覆盖{BRIDGE_NAME}插件链路；"
                 f"另一个插件请用它的「一键自检链路」按钮")
    lines.append("-" * 52)
    if problems:
        lines.append(f"结论: {BRIDGE_NAME}链路仍有待处理项")
        for i, p in enumerate(problems, 1):
            lines.append(f"  {i}. {p}")
    else:
        lines.append(f"结论: {BRIDGE_NAME}链路正常"
                     f"（{BRIDGE_NAME}桥接 {BRIDGE_PORT} -> CDP {CDP_PORT}）")
    return {"ok": not problems, "report": "\n".join(lines), "problems": problems}


if __name__ == "__main__":
    r = run_check()
    print(r["report"])
    sys.exit(0 if r["ok"] else 1)

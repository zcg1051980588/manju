@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo   Doubao Manager / VIDEO Plugin Link Check
echo   Ports: video bridge 39230  /  shared manager CDP 39233
echo   Scope : VIDEO plugin ONLY. The IMAGE plugin has its own check.
echo ============================================================
where python >nul 2>nul
if %errorlevel%==0 (
  python selfcheck.py
) else (
  py -3 selfcheck.py
)
echo.
echo   Any numbered items under the result are issues to fix.
echo   Press any key to close.
pause >nul

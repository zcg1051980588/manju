(() => {
  const SEL = __DBM_SEL_PLACEHOLDER__;
  const dbm = window.__dbm || {};
  dbm.SEL = SEL;
  // ============ 下载通道截获============
  // 管理器的"无水印下载"无论由 hover 还是 click 触发，最终都要在页面里通过
  // <a download>.click() / window.open / fetch / XHR 之一拿到无水印地址。
  // hook 这些通道后，即使合成鼠标事件无法触发其 UI，只要其脚本运行就能截获 URL。
  dbm.__caps = dbm.__caps || [];
  if (!window.__dbmCapHooked) {
    window.__dbmCapHooked = true;
    const cap = (u, via) => {
      try {
        if (!u) return;
        u = String(u);
        if (!/^https?:|^blob:/.test(u)) return;
        dbm.__caps.push({ url: u.slice(0, 2000), via: via, ts: Date.now() });
        if (dbm.__caps.length > 200) dbm.__caps.splice(0, dbm.__caps.length - 200);
      } catch (e) {}
    };
    try {
      const aClick = HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click = function () {
        cap(this.href || this.getAttribute("href") || "", "a.click");
        return aClick.apply(this, arguments);
      };
    } catch (e) {}
    try {
      if (window.open) {
        const _open = window.open;
        window.open = function (u) { cap(u, "window.open"); return _open.apply(this, arguments); };
      }
    } catch (e) {}
    try {
      if (window.fetch) {
        const _fetch = window.fetch;
        window.fetch = function (input, init) {
          try { cap(typeof input === "string" ? input : (input && input.url), "fetch"); } catch (e) {}
          return _fetch.apply(this, arguments);
        };
      }
    } catch (e) {}
    try {
      const _xopen = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function (m, u) {
        cap(u, "xhr");
        return _xopen.apply(this, arguments);
      };
    } catch (e) {}
  }
  // 读取某时间戳之后截获到的、不在 baseline 中的 http 视频地址（Python 轮询调用）
  // baseline: JS 数组，包含点击前的页面视频URL基线；传空数组表示不过滤
  dbm.capsSince = (sinceMs, baseline) => {
    const since = sinceMs || 0;
    const exclude = new Set((baseline || []).map(u => String(u)));
    return dbm.__caps.filter(c => c.ts >= since && !exclude.has(c.url)
      && /^https?:/.test(c.url));
  };
  dbm.sleep = ms => new Promise(r => setTimeout(r, ms));
  // 后台/未激活 webview 下 Chromium 停止排版与绘制，所有元素 getBoundingClientRect()
  // 都返回 0，导致 dbm.vis 全 false —— 这正是"第二个账号报需要标定"的直接原因
  // （页面其实正常，只是没被激活）。检测到整页零尺寸时自动降级为宽松判定：
  // 只排除 display:none / visibility:hidden，不再看尺寸。
  dbm.__zeroLayout = () => {
    try {
      const b = document.body;
      if (!b) return true;
      const r = b.getBoundingClientRect();
      return r.width < 2 || r.height < 2;
    } catch (e) { return false; }
  };
  dbm.vis = el => {
    if (!el) return false;
    const s = getComputedStyle(el);
    if (!s || s.display === 'none' || s.visibility === 'hidden') return false;
    if (dbm.__zeroLayout()) return true;   // 后台标签页：跳过尺寸/透明度判定
    const r = el.getBoundingClientRect();
    return r.width > 2 && r.height > 2 && s.opacity !== '0';
  };
  // 页面可见性探针：判断本 webview 是否真的是管理器里的活动标签页
  dbm.pageProbe = () => {
    let bodyW = 0, bodyH = 0;
    try {
      const r = document.body ? document.body.getBoundingClientRect() : null;
      bodyW = r ? Math.round(r.width) : 0;
      bodyH = r ? Math.round(r.height) : 0;
    } catch (e) {}
    return {
      url: location.href,
      title: document.title,
      ready: document.readyState,
      hidden: (typeof document.__dbmRealHidden === 'function')
        ? !!document.__dbmRealHidden() : !!document.hidden,
      visState: (typeof document.__dbmRealVis === 'function')
        ? (document.__dbmRealVis() || "") : (document.visibilityState || ""),
      visForced: !!document.__dbmForceVisible,
      innerW: window.innerWidth || 0, innerH: window.innerHeight || 0,
      bodyW: bodyW, bodyH: bodyH, zeroLayout: dbm.__zeroLayout(),
      nodes: document.querySelectorAll("*").length,
      hasDoubao: /doubao\.com/.test(location.href),
    };
  };
  dbm.q = sel => Array.from(document.querySelectorAll(sel));
  dbm.findAny = sels => {
    for (const s of sels) {
      const el = dbm.q(s).find(dbm.vis);
      if (el) return { el, s };
    }
    return { el: null, s: null };
  };
  dbm.findByText = (tags, text) => {
    for (const t of tags) {
      const el = dbm.q(t).find(e => dbm.vis(e) && (e.innerText || '').includes(text));
      if (el) return el;
    }
    return null;
  };
  // 真实指针事件序列（Radix 等组件不认合成 click）
  dbm.realClick = (el) => {
    if (!el) return false;
    const opts = { bubbles: true, cancelable: true, view: window, button: 0, composed: true };
    el.scrollIntoView({ block: "center", inline: "center" });
    const r = el.getBoundingClientRect();
    const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
    const p = (Type, Ev) => {
      try { el.dispatchEvent(new PointerEvent(Type, Object.assign({ clientX: cx, clientY: cy }, opts))); } catch (e) {}
      el.dispatchEvent(new MouseEvent(Ev, Object.assign({ clientX: cx, clientY: cy }, opts)));
    };
    p("pointerover", "mouseover"); p("pointerenter", "mouseenter");
    p("pointermove", "mousemove"); p("pointerdown", "mousedown");
    p("pointerup", "mouseup"); p("pointerout", "mouseout");
    el.dispatchEvent(new MouseEvent("click", Object.assign({ clientX: cx, clientY: cy }, opts)));
    return true;
  };
  dbm.getEditor = () => {
    const sels = SEL.prompt_input || [
      ".tiptap.ProseMirror", "div[contenteditable='true'][role='textbox']",
      "div[contenteditable='true']", "textarea", "[role='textbox']"
    ];
    const { el } = dbm.findAny(sels);
    return el;
  };
  dbm.focusEditor = () => {
    const el = dbm.getEditor();
    if (!el) return { ok: false, reason: "no_prompt_input" };
    el.scrollIntoView({ block: "center" });
    el.focus();
    return { ok: true, tag: el.tagName, ce: !!el.isContentEditable,
             active: document.activeElement === el || el.contains(document.activeElement) };
  };
  dbm.editorText = () => {
    const el = dbm.getEditor();
    return el ? (el.innerText || el.value || "") : "";
  };
  // 输入文本（execCommand 对 TipTap/ProseMirror 可靠；CDP Input 事件在 Electron webview 中不生效）
  dbm.setPrompt = (text) => {
    const el = dbm.getEditor();
    if (!el) return { ok: false, reason: "no_prompt_input" };
    el.scrollIntoView({ block: "center" });
    el.focus();
    const cur = el.innerText || el.value || "";
    if (cur.trim().length > 0) {
      try { document.execCommand("selectAll", false); document.execCommand("delete", false); } catch (e) {}
    }
    const ok = document.execCommand("insertText", false, text);
    // ★ 2026-09-24：记下"这话是我们自己说的"。
    //   事故：确认文本被改成"…先将提示词内容修改为不涉及版权、不侵权、不违规的
    //   提示词…"，里面自带"涉及版权/不侵权/不违规"，generationFailed() 把它当成
    //   豆包的拒绝话术 → 我们自己发的消息触发了自己判自己失败。
    //   所有由我们填入编辑器的文本（提示词 / 确认文本）都会经过 setPrompt，
    //   在这里登记后，判失败时就能精确跳过，而不是靠猜哪条气泡是助手的
    //   （实测用户/助手气泡的 className 无法区分）。
    try {
      dbm.__mine = dbm.__mine || [];
      const s = String(text == null ? "" : text).trim();
      if (s) dbm.__mine.push(s.slice(0, 40));
      if (dbm.__mine.length > 12) dbm.__mine = dbm.__mine.slice(-12);
    } catch (e) {}
    return { ok: ok, len: (el.innerText || "").length };
  };
  // Enter 键回退（合成 KeyboardEvent 派发到编辑器）
  dbm.pressEnter = () => {
    const el = dbm.getEditor();
    if (!el) return false;
    el.focus();
    const opts = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent("keydown", opts));
    el.dispatchEvent(new KeyboardEvent("keypress", opts));
    el.dispatchEvent(new KeyboardEvent("keyup", opts));
    return true;
  };
  // 比例 + 时长：点开“自动 · Ns”Radix 下拉（弹层上半比例 7 个按钮：自动/3:4/4:3/9:16/16:9/1:1/21:9；
  // 下半时长档位改为动态发现，已支持管理器新增的 15s / 30s）
  dbm.pickAspectDuration = async (aspect, sec) => {
    const ASPECTS = ["自动","3:4","4:3","9:16","16:9","1:1","21:9"];
    // 动态读取页面真实提供的时长档位（如 4s/10s/15s/30s）。此前写死 ["4s","10s","15s"]，
    // 豆包/管理器一加新档位就选不中；现在新增档位也无需改插件。
    dbm._durTiers = () => {
      const out = [];
      const re = /^\s*(\d+)\s*(s|秒)(\s|$|[^0-9a-zA-Z])/i;
      const nodes = Array.from(document.querySelectorAll("button, [role='option'], [role='menuitem'], li, div, span"));
      nodes.forEach(e => {
        if (!dbm.vis(e)) return;
        const m = re.exec((e.innerText || "").trim());
        if (m) out.push(parseInt(m[1], 10));
      });
      // 去重排序（同一档位可能被渲染成多个节点）
      return Array.from(new Set(out)).sort((a, b) => a - b);
    };
    const trigger = Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && /\d+\s*s/.test(e.innerText || "") && (e.innerText || "").trim().length <= 20);
    if (!trigger) return { ok: false, reason: "no_trigger" };
    const before = (trigger.innerText || "").replace(/\\s+/g, " ").trim();
    // 判定当前是否已选中
    const secWant = String(sec || "10").replace(/s$/, "").replace(/秒$/, "") + "s";
    const aspWant = aspect || "自动";
    const alreadySec = new RegExp("(^|[^0-9])" + secWant.replace(/s$/,"") + "\\s*s($|[^a-z])", "i").test(before);
    const alreadyAsp = aspWant === "自动" ? /^自动/.test(before) : before.includes(aspWant);
    if (alreadyAsp && alreadySec) return { ok: true, label: "already " + before };
    dbm.realClick(trigger);
    await dbm.sleep(1300);
    // 判断弹层是否仍打开（点比例按钮后，若该比例已是当前或触发自动关闭，弹层会消失）
    const popoverVisible = () => Array.from(document.querySelectorAll("[role='menu'],[role='listbox'],[data-radix-popper-content-wrapper]"))
      .some(el => dbm.vis(el));
    // 比例按钮：在弹层里找文字严格等于 aspWant 的 button
    const findBtn = (label) => Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && (e.innerText||"").trim() === label);
    let aspOk = false, durOk = false, aspLabel = "", durLabel = "";
    if (!ASPECTS.includes(aspWant)) {
      aspLabel = aspWant + "(invalid→自动)";
    } else {
      const ab = findBtn(aspWant);
      if (ab) { dbm.realClick(ab); await dbm.sleep(450); aspOk = true; aspLabel = aspWant; }
    }
    // 时长：按页面真实存在的档位选择；目标档不存在则就近落档（管理器新增 15s / 30s 自动生效）
    const tiers = dbm._durTiers();
    const wantN = parseInt(String(sec).replace(/[s秒]/g, ""), 10);
    let targetN = NaN;
    if (!isNaN(wantN)) {
      if (tiers.includes(wantN)) {
        targetN = wantN;
      } else if (tiers.length) {
        targetN = tiers.slice().sort((a, b) => Math.abs(a - wantN) - Math.abs(b - wantN))[0];
      } else {
        targetN = wantN;   // 发现不到档位列表时退回直接点击目标
      }
    }
    const fbSuffix = (!isNaN(wantN) && targetN !== wantN) ? ("(req " + wantN + "s)") : "";
    if (!popoverVisible()) {
      const nowTxt = trigger ? (trigger.innerText||"").replace(/\\s+/g," ").trim() : "";
      if (!isNaN(targetN) && new RegExp("(^|[^0-9])" + targetN + "\\s*s($|[^a-z])", "i").test(nowTxt)) {
        durOk = true; durLabel = targetN + "s(popover_closed)" + fbSuffix;
      }
    } else if (!isNaN(targetN)) {
      // 时长弹层可能因点比例而关闭：先确保弹层仍开，否则重新点开 trigger 再选
      if (!popoverVisible()) {
        dbm.realClick(trigger); await dbm.sleep(1300);
      }
      const cands = Array.from(document.querySelectorAll("button, [role='option'], [role='menuitem'], li, div, span")).filter(dbm.vis);
      // 优先按「用户要的档位 wantN」直接找选项点击，不依赖 tiers 发现是否完整
      const durExactN = new RegExp("^\s*" + wantN + "\s*(s|秒)\s*$", "i");
      const durPreN   = new RegExp("^\s*" + wantN + "\s*(s|秒)(\s|$|[^0-9a-zA-Z])", "i");
      let db_ = cands.find(e => durExactN.test((e.innerText || "").trim()))
              || cands.find(e => durPreN.test((e.innerText || "").trim()));
      let clickN = wantN;
      if (!db_ && !isNaN(targetN)) {
        // 页面确实没有该档位：按就近落档（targetN）找
        const durExactT = new RegExp("^\s*" + targetN + "\s*(s|秒)\s*$", "i");
        const durPreT   = new RegExp("^\s*" + targetN + "\s*(s|秒)(\s|$|[^0-9a-zA-Z])", "i");
        db_ = cands.find(e => durExactT.test((e.innerText || "").trim()))
             || cands.find(e => durPreT.test((e.innerText || "").trim()))
             || findBtn(targetN + "s") || findBtn(targetN + "秒");
        clickN = targetN;
      }
      if (db_) { dbm.realClick(db_); await dbm.sleep(450); durOk = true; durLabel = clickN + "s" + fbSuffix; }
    }
    await dbm.sleep(500);
    const after = trigger && trigger.innerText ? trigger.innerText.replace(/\s+/g, " ").trim() : before;
    dbm.esc();
    // 最终验证：after 需包含 aspWant；时长只要落在「目标档」或「已就近落到的档」都算成功，
    // 否则页面没有目标档时，即便已成功点击最近的可用档也会被误判为失败。
    const aspMatch = (aspWant === "自动" ? /^自动/.test(after) : after.includes(aspWant));
    const secRx = (n) => new RegExp("(^|[^0-9])" + n + "\\s*s($|[^a-z])", "i");
    const durMatch = secRx(secWant.replace(/s$/, "")) || (!isNaN(targetN) && secRx(targetN));
    const finalOk = !!(aspMatch && durMatch);
    return { ok: finalOk, asp: aspLabel, dur: durLabel, before, after };
  };
  // 兼容旧名（外部插件若直接调用此方法）
  dbm.pickDuration = (sec) => dbm.pickAspectDuration("自动", sec);
  // 关闭可能残留的弹层（时长下拉等），避免遮挡发送按钮
  dbm.esc = () => {
    document.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true }));
    return true;
  };
  // 模型选择：点开“模型 Seedance x.x”Radix 菜单，点目标模型项；带“升级”标签的判定为锁定
  dbm.ensureModel = async (name) => {
    const trigger = Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && /模型/.test(e.innerText || "") && /Seedance/i.test(e.innerText || ""));
    if (!trigger) return { ok: false, reason: "no_model_trigger" };
    const cur = (trigger.innerText || "").replace(/\s+/g, " ").trim();
    if (cur.includes(name)) return { ok: true, label: "already " + cur.slice(0, 40) };
    dbm.realClick(trigger);
    await dbm.sleep(1200);
    const items = Array.from(document.querySelectorAll("[role='menuitem']")).filter(dbm.vis);
    const item = items.find(e => {
      const first = ((e.innerText || "").split("\n")[0] || "").trim();
      return first === name || first.startsWith(name);
    });
    if (!item) {
      dbm.esc();
      return { ok: false, reason: "model_not_found",
               items: items.map(i => ((i.innerText || "").split("\n")[0] || "").trim()).slice(0, 8) };
    }
    // ★ 2026-10-09 优化：不再仅凭菜单项里的"升级"文字角标预判锁定。
    //   "升级"是会员模型的常驻推广角标，即使账号实际可用该模型也会带着；旧逻辑会把它
    //   误判为"无权限"，导致 30 秒（需 Seedance 2.5）在能用的账号上也永远跑不起来。
    //   改为：直接尝试点击该模型项，再回看模型触发按钮文案是否真的变成目标模型——
    //   变了=可用（带"升级"角标也能用），没变=真锁（可能弹出了升级层）→ 判锁定并关弹窗。
    dbm.realClick(item);
    await dbm.sleep(900);
    const t2 = Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && /模型/.test(e.innerText || "") && /Seedance/i.test(e.innerText || ""));
    const label2 = (t2 && t2.innerText || "").trim();
    if (label2.includes(name)) {
      return { ok: true, label: label2.slice(0, 40), switched: true };
    }
    // 选择未生效：该账号确实无此模型（或点"升级"弹出了升级层）。关闭可能的弹窗并判锁定。
    dbm.esc();
    await dbm.sleep(200);
    return { ok: false, reason: "model_locked", model: name };
  };
  // 账号是否正忙（页面里有生成中的任务：停止按钮 / 消息流“生成中”文字 / 加载动画）
  dbm.isPageBusy = () => {
    const stop = Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && /停止|暂停生成|stop/i.test(
        (e.getAttribute("aria-label") || "") + " " + (e.innerText || "")));
    if (stop) return { busy: true, reason: "stop_button",
                        text: (stop.getAttribute("aria-label") || stop.innerText || "").trim().slice(0, 30) };
    const ed = dbm.getEditor();
    const edBottom = ed ? ed.getBoundingClientRect().bottom : window.innerHeight;
    const re = /(视频生成中|视频创作中|正在生成|创作中|生成中[.…]|加载中|排队中)/;
    let spinner = null;
    const nodes = document.querySelectorAll("div,span,button");
    for (const e of nodes) {
      if (!dbm.vis(e)) continue;
      const r = e.getBoundingClientRect();
      if (r.bottom > edBottom - 90) continue;   // 输入工具栏区域不算
      const t = (e.innerText || "").trim();
      if (t && t.length <= 24 && re.test(t)) return { busy: true, reason: "text", text: t.slice(0, 30) };
      const cls = String(e.className || "");
      if (!spinner && e.querySelector("svg") && /(animate|spin|loading|pulse)/i.test(cls)) {
        spinner = { reason: "spinner", cls: cls.slice(0, 40) };
      }
    }
    if (spinner) return Object.assign({ busy: true }, spinner);
    return { busy: false };
  };
  // 额度/限流提示（豆包额度耗尽时以消息流错误或 toast 反馈，如“请求超限”）
  dbm.quotaNotice = () => {
    const re = /(请求超限|额度不足|积分不足|余额不足|点数不足|次数已用完|次数用完|今日[^。\n]{0,10}(次数|额度|上限)|已达[^。\n]{0,8}上限|操作过于频繁|升级会员|开通会员|会员[^。\n]{0,6}到期|配额[^。\n]{0,8}(不足|用完)|今日视频生成免费次数[^。\n]{0,6}用完|免费额度已用完|开通订阅畅享更多额度|畅享更多额度|明天再来[^。\n]{0,10}继续)/;
    const hits = [];
    const seen = new Set();
    const scan = (root) => {
      root.querySelectorAll("[role='alert'],[class*='toast'],[class*='Toast'],[class*='notice'],[class*='Notice'],[class*='bubble'],[class*='message'],[class*='reply'],[class*='content'],[class*='markdown']").forEach(e => {
        if (!dbm.vis(e)) return;
        const t = (e.innerText || "").trim().replace(/\s+/g, " ");
        if (t && t.length <= 80 && re.test(t) && !seen.has(t)) { seen.add(t); hits.push(t); }
      });
    };
    scan(document);
    return hits.length ? hits[0].slice(0, 80) : null;
  };
  // 明确额度耗尽文案（强信号，2026-11-03 v3）。
  // 豆包把"免费次数"改版成"免费额度 / 开通订阅畅享更多额度"后，旧版关键词只认
  // "次数"，新文案只能靠一条脆弱正则兜底命中（去掉"今日"二字就漏检），"开通订阅"
  // 更是完全不在识别库里。这里把"额度"系文案全部升级为显式关键词，并保留正则
  // 兜底覆盖文案微调。
  // 命中后 Python 侧会：直接把该账号当日生成计数补到上限（3/3 满额、不可派发）、
  // 写被动封禁标记（次日 00:01 恢复），且绝不把本次任务判成"视频已生成"。
  dbm.quotaExhausted = () => {
    const all = (document.body.innerText || "").replace(/\s+/g, " ");
    // 关键词匹配（按可信度排序，宽松匹配以适应豆包文案微调）
    const keywords = [
      "今日视频生成免费额度已用完",
      "今日视频生成免费次数用完",
      "视频生成免费额度已用完",
      "视频生成免费次数用完",
      "免费额度已用完",
      "免费次数已用完",
      "今日视频生成次数用完",
      "开通订阅畅享更多额度",
      "开通会员畅享更多额度",
      "明天再来找我继续",
      "明天再来继续"
    ];
    for (const kw of keywords) {
      if (all.includes(kw)) return kw;
    }
    // 正则兜底：今日...视频...(次数|额度)...用完 / (免费|视频生成)...额度...用完 /
    //           额度...用完...订阅 / 明天再来...继续
    const re = /今日[^。]{0,20}视频[^。]{0,14}(?:次数|额度)[^。]{0,8}用完|[^。]{0,12}(?:免费|视频生成)[^。]{0,12}额度[^。]{0,8}用完|额度[^。]{0,8}用完[^。]{0,20}订阅|明天再来[^。]{0,15}继续/;
    const m = all.match(re);
    if (m) return m[0].slice(0, 80);
    return null;
  };
  // 发送按钮：填字后出现在编辑器右下角。扫描该区域，向上找真正的可点击元素
  // （<button>/[role=button] 优先；其次 cursor:pointer 的指针覆盖层），
  // 不能直接点命中的图标子 div —— 它与指针覆盖层是兄弟节点，事件不会横向冒泡。
  dbm.findSendTarget = (preferOverlay) => {
    const ed = dbm.getEditor();
    if (!ed) return null;
    const r = ed.getBoundingClientRect();
    const ax = r.right - 22, ay = r.bottom + 16;
    let best = null;
    for (let dx = -72; dx <= 24; dx += 8) {
      for (let dy = -20; dy <= 52; dy += 8) {
        const x = r.right + dx, y = r.bottom + dy;
        const hit = document.elementFromPoint(x, y);
        if (!hit) continue;
        let el = hit, target = null;
        for (let i = 0; i < 7 && el; i++) {
          const t = el.tagName ? el.tagName.toLowerCase() : "";
          const cs = getComputedStyle(el);
          const isBtn = t === "button" || el.getAttribute("role") === "button";
          const ptr = cs.cursor === "pointer";
          if (isBtn || ptr) {
            const rr = el.getBoundingClientRect();
            if (rr.width > 8 && rr.width <= 90 && rr.height > 8 && rr.height <= 90) {
              target = { el: el, isBtn: isBtn, ptr: ptr, x: x, y: y,
                          t: t, cls: String(el.className || "").slice(0, 50),
                          w: Math.round(rr.width), h: Math.round(rr.height) };
              if (isBtn && !preferOverlay) break;  // button 祖先优先
              if (ptr && preferOverlay) break;    // 回退：指针覆盖层
            }
          }
          el = el.parentElement;
        }
        if (target) {
          const score = Math.hypot(x - ax, y - ay)
            + (target.isBtn && !preferOverlay ? -20 : 0)
            + (target.ptr && preferOverlay ? -20 : 0);
          if (!best || score < best.score) best = Object.assign(target, { score: score });
        }
      }
    }
    return best;
  };
  dbm.clickSend = (preferOverlay) => {
    const c = dbm.findSendTarget(!!preferOverlay);
    if (!c) return { ok: false, reason: "no_send_button" };
    if (c.el.disabled || c.el.getAttribute("aria-disabled") === "true"
        || /停止|stop/i.test((c.el.getAttribute("aria-label") || "") + (c.el.innerText || "")))
      return { ok: false, reason: "send_disabled_or_busy" };
    dbm.realClick(c.el);
    return { ok: true, tag: c.t, cls: c.cls, isBtn: c.isBtn, ptr: c.ptr,
              x: Math.round(c.x), y: Math.round(c.y), w: c.w, h: c.h,
              overlay: !!preferOverlay };
  };
  // 提交是否成功：编辑器被清空（消息已进入对话流）
  dbm.isSent = () => !!dbm.getEditor() && ((dbm.editorText() || "").trim().length < 3);
  // best-effort 探测当前登录账号昵称（用于多账号展示/关键字路由，失败返回 null）
  dbm.guessNick = () => {
    const sels = ["[class*='user'] [class*='name']", "[class*='avatar'] [class*='Name']",
                  "aside [class*='name']", "[data-testid*='nick']", "[data-testid*='user']"];
    for (const s of sels) {
      let e = null;
      try { e = document.querySelector(s); } catch (err) {}
      if (e && dbm.vis(e)) {
        const t = (e.innerText || "").trim();
        if (t && t.length >= 2 && t.length <= 12) return t;
      }
    }
    return null;
  };
  dbm.fileInputs = () => dbm.q("input[type=file]").map((e, i) => ({
    i: i, accept: e.accept || "", visible: dbm.vis(e)
  }));
  dbm.pageInfo = () => {
    const videos = dbm.q("video").map(v => v.currentSrc || v.src).filter(Boolean);
    let attach = { count: 0 };
    try { attach = dbm.attachmentState(); } catch (e) {}
    return {
      url: location.href,
      title: document.title,
      video_mode: dbm.isVideoPage(),
      video_controls: dbm.videoControls(),
      attachments: attach,
      textareas: dbm.q("textarea").filter(dbm.vis).length,
      editables: dbm.q("[contenteditable='true']").filter(dbm.vis).length,
      // 原始计数（不做可见性过滤）：后台/未激活 webview 里 vis 可能全 false，
      // 判定"页面到底有没有输入框"必须用 raw，否则会误报 needs_calibration。
      textareas_raw: dbm.q("textarea").length,
      editables_raw: dbm.q("[contenteditable='true']").length,
      zero_layout: dbm.__zeroLayout(),
      file_inputs: dbm.fileInputs(),
      videos,
      buttons: dbm.q("button").filter(dbm.vis).map(b => (b.innerText || "").trim())
        .filter(Boolean).slice(0, 40),
    };
  };
  dbm.pageVideos = () => dbm.q("video")
    .map(v => v.currentSrc || v.src)
    // http(s) 直链与 blob: 媒体地址都算"视频已出现"
    // （豆包部分版本预览流用 blob:，旧逻辑只认 http 会误判为一直没出片而卡死）
    .filter(u => u && /^(https?:|blob:)/.test(u));
  // 视频模式的可靠特征：输入工具栏出现“模型 Seedance …”按钮，或“自动 · Ns”时长档位按钮
  dbm.videoControls = () => {
    const btns = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(dbm.vis)
      .map(e => (e.innerText || "").replace(/\s+/g, " ").trim());
    const hasModel = btns.some(t => /模型/.test(t) && /Seedance/i.test(t));
    const hasDuration = btns.some(t => /·\s*\d+\s*s/.test(t) || /^自动/.test(t) && /\d+\s*s/.test(t));
    return { hasModel, hasDuration,
             modelBtn: btns.find(t => /模型/.test(t) && /Seedance/i.test(t)) || "",
             durBtn: btns.find(t => /·\s*\d+\s*s/.test(t)) || "" };
  };
  dbm.isVideoPage = () => {
    // URL 兜底（管理器直接打开视频创作地址时）
    if (/video/i.test(location.href)) return true;
    const c = dbm.videoControls();
    return !!(c.hasModel || c.hasDuration);
  };
  // 页面是否已加载到可进入视频模式的就绪状态（用于并发时等待后台标签页渲染完成）
  dbm.chatReadyState = () => {
    const controls = dbm.videoControls();
    const isVideo = !!(controls.hasModel || controls.hasDuration);
    // 首页快捷入口"视频生成"按钮（新对话首页）
    // ⚠️ 必须过 dbm.vis()：页面上常残留一个 innerText 为"视频生成"但不可见的节点，
    // 不做可见性过滤就会误报"入口已出现"，于是 _wait_chat_ready 立刻返回、
    // 真正要点击的 ensureVideoMode 却用 vis 过滤找不到 → no_video_entry。
    // 并发时多个页面同时刚加载，这个误判会被放大成"整批都进不了视频模式"。
    const hasVideoEntry = Array.from(document.querySelectorAll('button,[role="button"]'))
      .some(e => {
        if (!dbm.vis(e)) return false;
        const t = (e.innerText || "").trim().replace(/\s+/g, "");
        return t === "视频生成";
      });
    const editor = dbm.getEditor();
    const hasComposer = !!(editor || document.querySelector("textarea,[contenteditable='true']"));
    return {
      readyState: document.readyState,
      isVideo: isVideo,
      hasVideoEntry: hasVideoEntry,
      hasComposer: hasComposer,
      // 就绪 = 已在视频模式，或（首页视频入口出现 或 编辑器出现）
      ready: isVideo || hasVideoEntry || hasComposer
    };
  };
  // 页面健康度：识别"半加载卡死"的账号页（侧边栏渲染了，主内容区没渲染）。
  // 实测特征：正常页面可见按钮约 20 个、有 textarea、"视频生成"入口存在；
  // 卡死的页面只有 3~4 个按钮（豆包 / 创建新项目 / 昵称 / 下载电脑版），textarea=0，
  // 少加载 1 个 script。这种页面 chatReadyState 会误判就绪，必须在这里拦下来。
  dbm.pageHealth = () => {
    const btns = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(dbm.vis);
    const hasEntry = btns.some(e =>
      (e.innerText || "").trim().replace(/\s+/g, "") === "视频生成");
    const textareas = document.querySelectorAll("textarea").length;
    // 卡死判定：页面加载完了、既不在视频模式、又没有"视频生成"入口、也没有输入框
    // ⇒ 主内容区没渲染。
    // ⚠️ 不能用"按钮数 < 8"当主判据：实测有的坏页面侧边栏历史会话就有 10~12 个
    // 可见按钮（账号10 那次就是这样被漏掉，随后一路 no_video_entry）。
    // 决定性的信号是**"视频生成"入口缺失 + 没有 textarea**。
    // 可见的 contenteditable（会话页的输入框形态）：只用于诊断，不参与判定。
    // 实测坏页面被 revealEditor 强行显形后 editables 会变成 1、也能填词，
    // 但"视频生成"入口依然不存在，照样进不了视频模式 —— 所以不能算 usable。
    const editables = Array.from(
      document.querySelectorAll("[contenteditable='true']")).filter(dbm.vis).length;
    const isVideo = (typeof dbm.isVideoPage === "function") ? !!dbm.isVideoPage() : false;
    const complete = document.readyState === "complete";
    const degraded = !!document.body
      && complete
      && !isVideo && !hasEntry && textareas === 0;
    // usable = 页面"真正能操作"（有可见输入框、或有视频生成入口、或已在视频模式）。
    // ⚠️ 绝对不能拿 !degraded 当"页面已修好"：导航过程中 readyState==='interactive'
    //    时 degraded 恒为 false，会把"还在加载"误判成"已修复"。
    //    2026-09-19 日志里那句「页面已修复（按钮 11 个，入口=False）」就是这么来的 ——
    //    判据放水导致修复假成功，后面 ensureVideoMode 立刻又报 no_video_entry。
    const usable = !!document.body && complete
      && (isVideo || hasEntry || textareas > 0);
    return {
      readyState: document.readyState,
      buttons: btns.length,
      hasVideoEntry: hasEntry,
      isVideo: isVideo,
      textareas: textareas,
      editables: editables,
      degraded: degraded,
      usable: usable,
      url: location.href,
    };
  };
  // 视频模式下 composer 会被换成"ghost"：一个 .pointer-events-none.invisible
  // 绝对定位副本里的隐藏 contenteditable。此时 dbm.vis() 判 false，填词必然失败。
  // 这里点一下最近的**可见**祖先容器，把真正的输入区唤醒。
  dbm.revealEditor = () => {
    const cands = Array.from(document.querySelectorAll("textarea, [contenteditable='true']"));
    if (!cands.length) return { ok: false, reason: "no_editor" };
    // 1) 已经有可见的输入框（首页 = textarea，会话页 = .tiptap 的 contenteditable）
    const visOne = cands.find(dbm.vis);
    if (visOne) {
      try { visOne.scrollIntoView({ block: "center" }); visOne.focus(); } catch (e) {}
      return { ok: true, mode: "visible", tag: visOne.tagName,
                cls: String(visOne.className || "").slice(0, 40) };
    }
    // 2) 全都不可见：输入区被祖先的 visibility:hidden / pointer-events:none 盖住了。
    //    ⚠️ 旧实现是"点最近的可见祖先"——实测会点到最外层的空壳容器
    //    （clicked = DIV.min-h-24 w-full，一个 96px 高的空白盒子，点了毫无作用）。
    //    原因：真正该点的 DIV.relative.w-full 高度为 0（它唯一的子元素是 absolute
    //    定位的浮层），会被 dbm.vis() 过滤掉，于是"往上找可见祖先"必然越过它。
    //    改为直接沿祖先链剥掉隐藏样式：inline style 优先级高于 Tailwind 的
    //    .invisible / .pointer-events-none 类，可以把输入区强行显形。
    const el = cands[0];
    const fixed = [];
    let n = el;
    for (let i = 0; i < 10 && n && n !== document.documentElement; i++) {
      const cs = getComputedStyle(n);
      if (cs.visibility === "hidden" || cs.pointerEvents === "none"
          || parseFloat(cs.opacity) < 0.05) {
        n.style.setProperty("visibility", "visible", "important");
        n.style.setProperty("pointer-events", "auto", "important");
        n.style.setProperty("opacity", "1", "important");
        fixed.push(n.tagName + "." + String(n.className || "").slice(0, 30));
      }
      n = n.parentElement;
    }
    try { el.scrollIntoView({ block: "center" }); el.focus(); } catch (e) {}
    const cs2 = getComputedStyle(el);
    const r2 = el.getBoundingClientRect();
    return { ok: dbm.vis(el), mode: "force_unhide", fixed: fixed,
              visAfter: cs2.visibility, peAfter: cs2.pointerEvents,
              rect: r2.width + "x" + r2.height };
  };
  dbm.ensureVideoMode = async () => {
    if (dbm.isVideoPage()) {
      const c = dbm.videoControls();
      return { ok: true, mode: "already", url: location.href, model: c.modelBtn, dur: c.durBtn };
    }
    // 对话模式下输入框工具栏有“视频生成”模式页签
    // 匹配策略：严格相等 → 去空白包含 → aria-label/title 包含
    const entryText = (SEL.video_entry_text || "视频生成").trim();
    for (let attempt = 0; attempt < 3; attempt++) {
      // 1. 严格文本匹配（同样只认按钮类元素，理由见策略 2 的注释）
      let entry = Array.from(document.querySelectorAll("button,[role='button'],a"))
        .find(e => dbm.vis(e) && (e.innerText || "").trim() === entryText);
      // 2. 去空白后包含匹配（按钮可能有图标+文字，innerText 可能有多余空白/换行）
      //    ⚠️ 只认 button/[role=button]/a：早期版本把 div/span 也算进来，页面卡死时
      //    会点到一个"含'视频生成'文字的无关容器"，点了没反应 → 报
      //    video_mode_not_active（看起来像"点了没生效"），把真正的根因（页面半加载）
      //    完全掩盖住。限定成按钮后抓不到就会如实报 no_video_entry。
      if (!entry) {
        entry = Array.from(document.querySelectorAll("button,[role='button'],a"))
          .find(e => {
            if (!dbm.vis(e)) return false;
            const t = (e.innerText || "").trim().replace(/\s+/g, "");
            return t && t.length <= 10 && t.includes(entryText.replace(/\s+/g, ""));
          });
      }
      // 3. aria-label / title 匹配
      if (!entry) {
        entry = Array.from(document.querySelectorAll("button,[role='button'],a"))
          .find(e => {
            if (!dbm.vis(e)) return false;
            const label = (e.getAttribute("aria-label") || e.getAttribute("title") || "").trim();
            return label === entryText || (label && label.includes(entryText));
          });
      }
      if (!entry) {
        const allBtns = Array.from(document.querySelectorAll("button,[role='button']"))
          .filter(dbm.vis).map(b => (b.innerText || "").trim().replace(/\s+/g, " "))
          .filter(Boolean).slice(0, 20);
        return { ok: false, reason: "no_video_entry", url: location.href,
                  entryText: entryText, visibleButtons: allBtns };
      }
      dbm.realClick(entry);
      await dbm.sleep(3000);
      if (dbm.isVideoPage()) {
        const c = dbm.videoControls();
        return { ok: true, mode: "clicked", attempt: attempt + 1,
                  text: (entry.innerText || "").trim().slice(0, 20),
                  model: c.modelBtn, dur: c.durBtn, url: location.href };
      }
      await dbm.sleep(2000);
      if (dbm.isVideoPage()) {
        const c = dbm.videoControls();
        return { ok: true, mode: "clicked_slow", attempt: attempt + 1,
                  text: (entry.innerText || "").trim().slice(0, 20),
                  model: c.modelBtn, dur: c.durBtn, url: location.href };
      }
    }
    // 最终诊断
    const c2 = dbm.videoControls();
    const allBtns2 = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(dbm.vis).map(b => (b.innerText || "").trim().replace(/\s+/g, " "))
      .filter(Boolean).slice(0, 20);
    return { ok: false, reason: "video_mode_not_active", url: location.href,
              videoControls: c2, visibleButtons: allBtns2 };
  };
  // ---- 参考图附件（输入框上方缩略图 chip）----
  // 标定说明：原只认视频创作页的 [class*='thumb-card']。去掉视频模式后，插件会落在
  // 普通对话输入框，缩略图可能使用不同的 class（upload / attachment / preview /
  // image-item / img-item / file-item 等），且 React 上传完成会把 <input type=file> 的
  // .files 清空、并重渲染预览区（实测：上传中 count=4，发送前复检瞬间变 0）。
  // 因此检测改为“三路取最大”，任何一路命中都算数：
  //   1) 标定 chip class（thumb_card 候选数组，见 selectors.json）；
  //   2) composer 区域内“可见缩略图 <img>”数量（不依赖任何 class、也不依赖 file input 是否残留
  //      files——这是去掉视频模式后普通对话输入框最可靠的信号，已实测 4 张图能正确数出 4）；
  //   3) file input 里实际加载的文件数（input.files，仅作补充兜底）。
  dbm.thumbCardSel = () => {
    const base = Array.isArray(SEL.thumb_card) ? SEL.thumb_card
                : (SEL.thumb_card ? [SEL.thumb_card] : []);
    const extra = ["[class*='thumb-card']","[class*='thumbCard']",
                   "[class*='upload']","[class*='Upload']",
                   "[class*='attachment']","[class*='Attachment']",
                   "[class*='preview']","[class*='Preview']",
                   "[class*='image-item']","[class*='imageItem']",
                   "[class*='img-item']","[class*='imgItem']",
                   "[class*='file-item']","[class*='fileItem']",
                   "[class*='pic-item']","[class*='picItem']",
                   "[class*='media-item']","[class*='mediaItem']"];
    const set = new Set([...base, ...extra].filter(Boolean));
    return Array.from(set).join(",");
  };
  dbm.thumbDelSel = () => {
    const base = Array.isArray(SEL.thumb_delete_btn) ? SEL.thumb_delete_btn
                : (SEL.thumb_delete_btn ? [SEL.thumb_delete_btn] : []);
    const extra = ["[class*='delete-btn']","[class*='delete']","[class*='Delete']",
                   "[class*='close']","[class*='Close']","[class*='remove']","[class*='Remove']"];
    const set = new Set([...base, ...extra].filter(Boolean));
    return Array.from(set).join(",");
  };
  // 一个 <img> 是否“像附件缩略图”：可见、尺寸够大（排除图标/按钮）、src 像图片。
  // blob:/data: 是本地选中文件生成的“对象 URL”，是最强信号（聊天记录里的图通常是 http(s) CDN 地址）。
  dbm._thumbImg = (im) => {
    try {
      if (!dbm.vis(im)) return false;
      const w = im.clientWidth || im.naturalWidth || 0;
      const h = im.clientHeight || im.naturalHeight || 0;
      if (w < 36 || h < 36) return false;   // 太小的是图标/按钮，不是附件缩略图
      const src = (im.src || im.currentSrc || "").toLowerCase();
      if (/^blob:/.test(src)) return true;
      // ★ 2026-10-15：data:image/svg+xml 是新版 mdbox 卡片的装饰占位图
      //   （每张附件都有一个 54px svg 底图 + 一张真实图），不能算缩略图，
      //   否则一张附件被数成两张。data: 只接受位图。
      if (/^data:image\/(png|jpe?g|webp|gif|bmp)/.test(src)) return true;
      if (/^https?:/.test(src) && /\.(png|jpe?g|webp|gif|bmp)(\?|#|$)/.test(src)) return true;
      return false;
    } catch (e) { return false; }
  };
  // 一个元素是否“真的是张缩略图容器”：自身/子节点含 <img> 或 <canvas>，或带背景图（部分 UI 用背景图而非 <img>）
  dbm._isThumb = (el) => {
    try {
      if (el.tagName === "IMG" || el.tagName === "CANVAS") return dbm.vis(el) && !!el.src;
      if (el.querySelector && el.querySelector("img,canvas")) return true;
      const s = getComputedStyle(el);
      const bi = (s.backgroundImage || s.webkitBackgroundImage || "");
      if (bi && bi !== "none" && /\.(png|jpe?g|webp|gif|bmp)|data:image|blob:/i.test(bi)) return true;
    } catch (e) {}
    return false;
  };
  dbm.thumbCards = () => {
    const all = Array.from(document.querySelectorAll(dbm.thumbCardSel()))
      .filter(c => dbm.vis(c) && (c.querySelector("img") || c.querySelector("canvas") || dbm._isThumb(c)));
    // 去重：若一个元素包含另一个匹配元素（容器包叶子），只保留最内层叶子，避免容器+叶子重复计数
    return all.filter(c => !all.some(o => o !== c && c.contains(o)));
  };
  // composer 区域：从输入框向上找“最小且含缩略图 img”的祖先（即输入框+附件区所在容器）。
  // 这样只数“当前对话框”的附件，不会把上方聊天记录里的图也算进来；也不依赖任何具体 chip class。
  dbm.composerRegion = () => {
    const inp = dbm.getEditor();
    if (!inp) return null;
    let el = inp;
    for (let i = 0; i < 8 && el; i++) {
      if (Array.from(el.querySelectorAll("img")).some(dbm._thumbImg)) return el;
      el = el.parentElement;
    }
    return inp.parentElement || inp;
  };
  // ★ 2026-10-15：豆包改版（tiptap ProseMirror 新输入框）后，附件预览卡片
  //   container-MzuYIN > [data-testid=mdbox_image] > img.image-Q7dBqW(blob:/CDN)
  //   与编辑器不在同一 DOM 分支——编辑器祖先链向上 8 层到不了附件区，旧
  //   composerRegion 永远数 0；旧 chip class（thumb-card/upload/attachment 等）
  //   也全部失配。结果：文件已塞、卡片已渲染，插件却判"未受理"反复重传 16 次。
  //   新版输入框有稳定锚点 id=input-engine-container（data-testid=chat_input），
  //   附件卡片就在它内部，天然与上方聊天历史隔离。
  dbm.attachRegion = () => {
    return document.querySelector("#input-engine-container")
        || document.querySelector("[data-testid='chat_input']")
        || dbm.composerRegion();
  };
  // 新版附件卡片：mdbox_image 是 imagex 图片组件的 wrapper（一图一节点）
  dbm.mdboxCards = () => {
    const region = dbm.attachRegion();
    if (!region) return [];
    return Array.from(region.querySelectorAll("[data-testid='mdbox_image']"))
      .filter(c => dbm.vis(c));
  };
  // ★ 2026-11-13：豆包「参考项」支持上传参考音频。音频附件不是图片卡，而是
  //   [data-testid=attachment_file_item]（FileAudio 图标 + 文件名 + "Audio · 3KB"
  //   字幕 + 删除 svg），没有 <img>。旧 attachmentState 只数 mdbox_image /
  //   缩略图 img，音频上传后 cardCount 恒为 0，而期望是「图片+音频」总数，
  //   于是永远判"附件不匹配"，任务一直重传到超时。
  //   另外图片卡的删除按钮挂在父级 [data-testid=attachment-image-card]，
  //   旧 clearAttachments 拿内层 mdbox_image 去 querySelector 找不到删除按钮，
  //   残留附件清不掉（实测 removed=0 / left=1）。
  dbm.attachmentFileCards = () => {
    const region = dbm.attachRegion();
    if (!region) return [];
    return Array.from(region.querySelectorAll("[data-testid='attachment_file_item']"))
      .filter(c => dbm.vis(c));
  };
  dbm.attachmentImageCards = () => {
    const region = dbm.attachRegion();
    if (!region) return [];
    return Array.from(region.querySelectorAll("[data-testid='attachment-image-card']"))
      .filter(c => dbm.vis(c));
  };
  // 每个附件只算一张卡：优先用新版稳定 testid（图片卡 / 文件卡，二者互不包含）；
  // 老版 DOM 没有这些 testid 时退回 chip / mdbox_image / composer 容器，
  // 并去掉「容器包叶子」造成的重复计数。
  dbm.attachmentCards = () => {
    const primary = dbm.attachmentImageCards().concat(dbm.attachmentFileCards());
    if (primary.length) return primary;
    const set = new Set();
    try { dbm.thumbCards().forEach(c => set.add(c)); } catch (e) {}
    try { dbm.mdboxCards().forEach(c => set.add(c)); } catch (e) {}
    try { dbm.composerAttachmentCards().forEach(c => set.add(c)); } catch (e) {}
    const all = Array.from(set);
    return all.filter(c => !all.some(o => o !== c && o.contains(c)));
  };
  dbm.composerThumbs = () => {
    const region = dbm.attachRegion();
    if (!region) return [];
    return Array.from(region.querySelectorAll("img")).filter(dbm._thumbImg);
  };
  // composer 区域内“含缩略图 img”的容器（用于清空旧附件，不依赖 chip class）
  dbm.composerAttachmentCards = () => {
    const region = dbm.attachRegion();
    if (!region) return [];
    const conts = Array.from(region.querySelectorAll("*"))
      .filter(el => el.querySelector && el.querySelector("img") && Array.from(el.querySelectorAll("img")).some(dbm._thumbImg));
    return conts.filter(c => !conts.some(o => o !== c && c.contains(o)));
  };
  // 附件失败特征：豆包失败态有时只有图标/红点、没有文字，所以文字和 class 都要看
  dbm._ATTACH_FAIL_RE = /上传失败|发送失败|上传出错|失败|重试|重新上传|已停止|超时/;
  dbm.attachmentState = () => {
    // ★ 2026-11-13：卡片集合 = 图片卡 ∪ 音频/文件卡（每个附件一张，节点去重）。
    //   异常时退回旧版 chip ∪ mdbox_image，保证老页面不受影响。
    let cards = [];
    try { cards = dbm.attachmentCards(); } catch (e) {
      const fallback = new Set(dbm.thumbCards());
      dbm.mdboxCards().forEach(c => fallback.add(c));
      cards = Array.from(fallback);
    }
    const composerImgs = dbm.composerThumbs(); // 输入区域内可见缩略图 img（不依赖 class / file input）
    let uploading = 0, failed = 0, broken = 0;
    const names = [];
    // —— 1) 卡片扫描（保留原失败/上传中/裂图判定）——
    cards.forEach(c => {
      const t = (c.innerText || "").trim();
      let bad = dbm._ATTACH_FAIL_RE.test(t);
      if (!bad) {
        try {
          if (c.querySelector("[class*='error'],[class*='Error'],[class*='fail'],"
            + "[class*='Fail'],[class*='retry'],[class*='Retry'],[class*='warn']")) bad = true;
        } catch (e) {}
      }
      if (bad) failed++;
      if (Array.from(c.querySelectorAll("[class*='animate-spin'],[class*='loading'],[class*='progress'],[class*='spinner']"))
          .some(dbm.vis) || /上传中|正在上传/.test(t)) uploading++;
      const im = c.querySelector("img");
      if (im) {
        if (im.alt) names.push(im.alt);
        try { if (im.complete && !im.naturalWidth) broken++; } catch (e) {}
      }
      // 音频/文件卡没有 <img>：取文件名节点，或图片卡的 aria-label
      const fn = c.querySelector("[data-testid='message_nested_content_file_name']");
      if (fn && (fn.innerText || "").trim()) names.push(fn.innerText.trim());
      const al = c.getAttribute && c.getAttribute("aria-label");
      if (al && al.trim() && names.indexOf(al.trim()) < 0) names.push(al.trim());
    });
    // —— 2) composer img 补扫（失败/裂图/上传中转圈，不依赖 chip class）——
    composerImgs.forEach(im => {
      if (im.alt) names.push(im.alt);
      try { if (im.complete && !im.naturalWidth) broken++; } catch (e) {}
      const host = im.parentElement || im;
      const t = ((im.alt || "") + " " + (host.innerText || "")).trim();
      if (dbm._ATTACH_FAIL_RE.test(t)) failed++;
      if (Array.from(host.querySelectorAll("[class*='animate-spin'],[class*='loading'],[class*='progress'],[class*='spinner']"))
          .some(dbm.vis) || /上传中|正在上传/.test(t)) uploading++;
    });
    // —— 3) file input 兜底：★只统计当前输入框容器内的 input★。
    //    页面"+"菜单 radix 浮层里还有一个隐形死 input（pointer-events-none invisible），
    //    对它 setFileInputFiles 也能塞进 files，但豆包不受理——旧逻辑全文档统计，
    //    死控件残留文件让 fileCount 虚高、也会把它误当候选反复重传。
    let fileCount = 0;
    try {
      const scope = dbm.attachRegion() || document;
      scope.querySelectorAll("input[type=file]").forEach(inp => {
        try {
          const acc = (inp.getAttribute("accept") || "").toLowerCase();
          const isMedia = /\.(png|jpe?g|webp|gif|bmp|mp3|wav|m4a|aac|ogg|flac|amr|aiff|wma|ac3)|image\/|audio\//.test(acc);
          if (!isMedia && !inp.multiple) return;
          if (inp.files && inp.files.length) fileCount += inp.files.length;
        } catch (e) {}
      });
    } catch (e) {}
    const cardCount = cards.length;
    const composerCount = composerImgs.length;
    // 三路取最大：附件卡片 / 渲染层缩略图 img / 活跃 input 文件数。
    const count = Math.max(cardCount, fileCount, composerCount);
    return { count, cardCount, fileCount, composerCount, uploading, failed, broken,
             // 满配 = 9 张参考图 + 3 个参考音频，旧版 slice(0,9) 会把音频文件名截掉
             names: names.slice(0, 12) };
  };
  // ★ 2026-10-12 上传网络层正向证据：fileCount 只是插件塞进 input 的文件数，
  // chip/img 渲染滞后时两者全为 0，旧逻辑会"空真"判成功并盲目点发送 —— 豆包
  // 实际未受理图片，消息永远停在 local_ 会话（submission_not_acknowledged）。
  // 这里扫 performance 资源时间线里的上传类请求：
  //   enough  = 完成的上传请求数 >= 期望张数（逐条/并发上传时直接判满）
  //   settled = 最后一条上传请求完成后已静默 >= 6s（批量/分片上传时确认批次结束）
  // ★ 2026-11-14：参考音频与图片走同一个上传通道（实测 performance 里的
  //  /alice/resource/prepare_upload、Action=ApplyImageUpload、tos.../upload/v1/*.wav
  //  都含 "upload"，原正则已能命中），无需为音频另加规则。
  dbm.uploadNetEvidence = (sinceMs, expected) => {
    try { performance.setResourceTimingBufferSize(4096); } catch (e) {}
    const since = (typeof sinceMs === "number" && sinceMs > 0) ? sinceMs : 0;
    const re = /upload|imagex|bytetos|byteimg|\/tos\/|tosx|imgx|imagex/i;
    const hits = [];
    let lastDone = -1;
    try {
      (performance.getEntriesByType("resource") || []).forEach(e => {
        if (e.startTime < since) return;
        if (!/fetch|xmlhttprequest|beacon/i.test(String(e.initiatorType || ""))) return;
        const u = String(e.name || "");
        if (re.test(u)) {
          hits.push({ url: u.slice(-90), ms: Math.round(e.duration) });
          const done = e.startTime + (e.duration || 0);
          if (done > lastDone) lastDone = done;
        }
      });
    } catch (e) {}
    const now = performance.now();
    const settled = hits.length > 0 && lastDone >= 0 && (now - lastDone) >= 6000;
    const enough = (typeof expected === "number" && expected > 0)
      ? hits.length >= expected : false;
    return { count: hits.length, enough, settled,
              now: Math.round(now), lastDone: Math.round(lastDone),
              samples: hits.slice(0, 3) };
  };
  // 附件卡删除按钮：只认明确的删除/关闭语义，以及「无文本的图标按钮」。
  // 音频卡里另有「总结音频内容」这类带文字的功能按钮，宽泛 fallback 会误点它，
  // 弹出新面板并让清理 Promise 一直挂起。
  dbm._attachmentDelSel = () => (
    dbm.thumbDelSel() + ","
    + "[aria-label*='删除'],[aria-label*='移除'],[title*='删除'],[title*='移除'],"
    + "[aria-label*='remove'],[title*='remove'],[aria-label*='close'],[title*='close'],"
    + "[data-testid*='delete'],[data-testid*='remove']"
  );
  // ★ 2026-11-14：满配 9图+3音频时，旧实现「每轮只点一张卡 + 等 450ms」
  //  实测会卡住 24s 以上并残留 4 张卡，生产侧 evaluate(awaitPromise) 直接
  //  60s 超时让任务失败。改为每轮批量点掉全部删除按钮 + 10 轮上限 + 12s
  //  硬时限，实测 12 个附件 4 轮（约 3s）清零，且保证 Promise 一定 resolve。
  dbm.clearAttachments = async () => {
    let removed = 0;
    const started = Date.now();
    for (let round = 0; round < 10 && Date.now() - started < 12000; round++) {
      const cards = [];
      try { dbm.attachmentCards().forEach(c => { if (cards.indexOf(c) < 0) cards.push(c); }); } catch (e) {}
      // 老版 DOM 没有稳定 testid 时才补扫，避免「外层卡 + 内层 wrapper」重复点击
      if (!cards.length) {
        try { dbm.thumbCards().forEach(c => { if (cards.indexOf(c) < 0) cards.push(c); }); } catch (e) {}
        try { dbm.mdboxCards().forEach(c => { if (cards.indexOf(c) < 0) cards.push(c); }); } catch (e) {}
        try { dbm.composerAttachmentCards().forEach(c => { if (cards.indexOf(c) < 0) cards.push(c); }); } catch (e) {}
      }
      if (!cards.length) break;
      let clicked = 0;
      cards.forEach(c => {
        let del = null;
        try { del = c.querySelector(dbm._attachmentDelSel()); } catch (e) {}
        if (!del) {
          try {
            const bs = Array.from(c.querySelectorAll("button,[role='button']"))
              .filter(b => !(b.innerText || "").trim());
            if (bs.length) del = bs[bs.length - 1];
          } catch (e) {}
        }
        if (!del) return;
        try { if (dbm.realClick(del)) { clicked++; removed++; } } catch (e) {}
      });
      if (!clicked) break;
      await dbm.sleep(500);
    }
    let left = 0;
    try { left = dbm.attachmentCards().length; } catch (e) {
      left = Math.max(dbm.thumbCards().length, dbm.mdboxCards().length,
                      dbm.composerAttachmentCards().length);
    }
    // 卡片删掉后 file input 里可能仍挂着旧 FileList（React 未同步清理），
    // attachmentState 的 count 取 max(卡片, fileCount, img)，残留会让计数虚高，
    // 下一轮上传误判"附件已齐"。清原生 value 与 Python 侧 _reset_upload_input 同理。
    try {
      const scope = dbm.attachRegion() || document;
      scope.querySelectorAll("input[type=file]").forEach(inp => {
        try { inp.value = ""; } catch (e) {}
      });
    } catch (e) {}
    return { removed, left };
  };
  // ===================== 安全确认弹窗 =====================
  // 发送后豆包可能弹出"确认安全/内容安全"对话框，需要点击确认按钮
  dbm.confirmSafetyDialog = () => {
    // 查找模态对话框
    const dialogs = Array.from(document.querySelectorAll(
      "[role='dialog'],[role='alertdialog'],[class*='modal'],[class*='Modal'],[class*='dialog'],[class*='Dialog'],[data-state='open']"
    )).filter(dbm.vis);
    for (const dlg of dialogs) {
      const btns = Array.from(dlg.querySelectorAll("button,[role='button']")).filter(dbm.vis);
      // 确认按钮：文本匹配确认/确定/继续/同意等
      const confirmBtn = btns.find(b => {
        const t = (b.innerText || "").trim();
        return /^(确认|确定|同意|我知道了|继续生成|继续|是|确认生成|确认安全|确认内容|确定生成|OK|Confirm)$/.test(t)
               || /确认|确定|继续|同意/.test(t);
      });
      if (confirmBtn) {
        dbm.realClick(confirmBtn);
        return { ok: true, text: (confirmBtn.innerText || "").trim().slice(0, 20),
                 dialogText: ((dlg.innerText || "").trim()).slice(0, 80) };
      }
    }
    return { ok: false, reason: "no_safety_dialog" };
  };
  // ===================== 新建对话 =====================
  // 在豆包页面创建一个新对话，避免多个任务共用同一对话导致上下文混乱
  // 查找侧边栏"新对话"按钮（文本/aria-label/title 含"新对话"/"新建对话"）
  dbm.startNewConversation = () => {
    // 1. 查找侧边栏中的"新对话"按钮
    const candidates = Array.from(document.querySelectorAll(
      "button,[role='button'],a"
    )).filter(el => {
      if (!dbm.vis(el)) return false;
      const t = (el.innerText || "").trim();
      const label = (el.getAttribute("aria-label") || el.getAttribute("title") || "").trim();
      return t === "新对话" || t === "新建对话" || t === "开始新对话" ||
             /新对话|新建对话|开始新对话/.test(t) ||
             /新对话|新建对话/.test(label);
    });
    if (candidates.length) {
      // 选最靠左上角的一个（侧边栏通常在左侧）
      const btn = candidates.slice().sort((a, b) => {
        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        return (ra.x + ra.y) - (rb.x + rb.y);
      })[0];
      dbm.realClick(btn);
      return { ok: true, method: "click_button", text: (btn.innerText || "").trim().slice(0, 20) };
    }
    // 2. 查找带"+"图标的按钮（有些版本用"+"图标表示新对话）
    const iconBtns = Array.from(document.querySelectorAll(
      "button,[role='button'],a"
    )).filter(el => {
      if (!dbm.vis(el)) return false;
      const cls = String(el.className || "");
      const svg = el.querySelector("svg");
      // 在侧边栏区域（x < 300）的带 svg 的按钮
      const rect = el.getBoundingClientRect();
      if (rect.x > 300) return false;
      return (cls.includes("new") || cls.includes("create") || cls.includes("add")) && svg;
    });
    if (iconBtns.length) {
      dbm.realClick(iconBtns[0]);
      return { ok: true, method: "click_icon_button" };
    }
    // 3. 兜底：通过 URL 跳转创建新对话（doubao.com/chat/ 根路径会创建新对话）
    //    注意：此方法会重载页面，需在调用后重新注入脚本
    return { ok: false, reason: "no_new_chat_button", suggest_navigate: true };
  };
  // 检查页面是否出现生成确认文本（豆包回复"本次使用...生成，预计等待..."）
  dbm.checkGenerationConfirmed = () => {
    // 在消息流中查找确认文本
    const messages = Array.from(document.querySelectorAll(
      "[class*='message'],[class*='bubble'],[class*='content'],[class*='assistant'],[class*='reply']"
    )).filter(dbm.vis);
    for (const msg of messages) {
      const t = (msg.innerText || "").trim();
      if (t.includes("本次使用") && t.includes("预计等待") && t.includes("视频生成好后")) {
        return { ok: true, text: t.slice(0, 150), source: "message" };
      }
    }
    // 兜底：检查整个文档
    const body = (document.body.innerText || "");
    if (body.includes("本次使用") && body.includes("预计等待") && body.includes("视频生成好后")) {
      return { ok: true, text: "found_in_body", source: "body" };
    }
    return { ok: false };
  };
  // 检测豆包是否明确回复"生成失败"（内容审核拒绝 / 生成失败 / 系统繁忙）。
  // 严格只扫消息气泡文本（不用常驻按钮文案，避免误判，教训同 quotaNotice）；
  // Python 端还会要求"页面无 <video> + 连续命中"才采信。
  dbm.generationFailed = () => {
    // ⚠️⚠️ 2026-09-22 实测补充：豆包的拒绝话术**会变**，而且常带空格/斜杠。
    //   本次 9 并发事故里豆包的原话是：
    //     "生成内容中疑似包含侵权 / 违规内容，无法返回该内容，
    //      换个主题再试试，生成额度未扣除。"
    //   而旧表里写的是"内容违规"（词序相反）和"无法**生成**该内容"（动词不同），
    //   **一个都命中不了** → 5 个任务一路空转到 1700s+ 才超时失败。
    //   所以这里 words + 正则双重匹配：正则专门消化话术里的空格 / 全半角斜杠 /
    //   换行，避免下次豆包再改一个字就全线失效。
    const RULES = [
      { kind: "moderation", words: [
        "不符合社区规范", "不符合相关规范", "违反社区规范", "违反内容规范",
        "违反相关规定", "内容涉嫌违规", "内容违规", "审核未通过", "未通过审核",
        "无法生成相关内容", "无法生成该内容", "该内容无法生成", "无法为你生成该内容",
        // ↓ 2026-09-22 实测话术（豆包会把拒绝理由换着说，两类都撞上过）
        "疑似包含侵权", "侵权内容", "违规内容", "无法返回该内容",
        "换个主题再试试", "换个话题再试试", "生成额度未扣除", "涉嫌侵权", "涉嫌违规",
        //   同一批任务里豆包给的第二种理由：版权限制
        "涉及版权限制", "版权限制", "版权受限", "涉及版权",
        "请更换输入内容", "更换输入内容后重试", "请更换内容", "更换内容后重试"
      ]},
      { kind: "failed", words: [
        "视频生成失败", "生成视频失败", "视频生成出错", "生成出错", "生成失败",
        "未能生成视频", "没能生成视频", "生成不成功", "无法为你生成视频",
        "不能生成该视频", "视频没有生成成功", "无法返回该内容"
      ]},
      { kind: "busy", words: [
        "系统繁忙，请稍后", "系统开小差", "服务开小差", "当前使用人数过多",
        "请稍后再试", "请稍后重试", "网络繁忙，请稍后"
      ]}
    ];
    // 正则兜底：话术里的空格 / 全角斜杠 / 换行会让纯子串匹配失效
    const PATTERNS = [
      { kind: "moderation", re: /侵权\s*[／/\|]?\s*违规/ },
      { kind: "moderation", re: /违规\s*[／/\|]?\s*内容/ },
      { kind: "moderation", re: /无法返回该内容/ },
      { kind: "moderation", re: /换个\s*主题|换个\s*话题/ },
      { kind: "moderation", re: /额度\s*未扣除|不\s*扣除\s*额度/ },
      { kind: "moderation", re: /疑似\s*包含/ },
      { kind: "moderation", re: /涉嫌\s*违规|涉嫌\s*侵权/ },
      { kind: "moderation", re: /版权\s*限制|版权\s*受限|涉及\s*版权/ },
      { kind: "moderation", re: /更换\s*输入\s*内容|更换\s*内容|换个\s*内容/ }
    ];
    // "让你改输入"这一类通用拒绝（豆包下一版话术大概率还是这个套路）
    const PATTERNS2 = [
      { kind: "moderation", re: /请\s*更换[^。]{0,10}(内容|输入|素材|描述)/ },
      { kind: "moderation", re: /(内容|素材|描述)[^。]{0,8}后\s*重试/ }
    ];
    const ALL_PATTERNS = PATTERNS.concat(PATTERNS2);
    const messages = Array.from(document.querySelectorAll(
      "[class*='message'],[class*='bubble'],[class*='content'],[class*='assistant'],[class*='reply']"
    )).filter(dbm.vis);
    // ★ 2026-09-24：跳过**我们自己发出去的**消息。
    //   确认文本/提示词由 setPrompt 登记在 dbm.__mine（见 setPrompt 里的注释）。
    //   事故：确认文本被改成"…修改为不涉及版权、不侵权、不违规的提示词…"，
    //   自带"涉及版权/不侵权/不违规" → 我们自己发的消息触发了自己判自己失败。
    //   用户气泡与助手气泡的 className 实测无法区分，所以只能靠这条登记簿。
    const MINE = dbm.__mine || [];
    // ★★ 2026-10-13 修复"版权申诉后仍被旧拒绝文案判死"：
    //   旧逻辑扫**全部**气泡、取第一个命中 —— 版权申诉的两条对话发出去后，
    //   第一轮的旧拒绝文案永久残留在会话里；豆包改写提示词+重新生成要
    //   5~10 分钟，宽限期一过（实测 18:36:16，宽限截止后 4 秒）就被旧文案
    //   再次命中判死，两条申诉等于白发。
    //   现在**只把"豆包最新一条有效回复"当判决**：
    //   - 申诉后豆包只要回了任何新内容（改写确认 / 生成进度 / 新拒绝 /
    //     成片卡片），旧拒绝即告失效，判决以新回复为准；
    //   - 若最新有效回复仍是旧拒绝（豆包迟迟不接茬），照常返回 failed，
    //     由宽限期（copyright_appeal_grace_sec）与回收预算兜底。
    //   细节：
    //   a) 父子去重（同 __collectBeanMessages）：选择器会同时命中消息容器与
    //      其内部节点，文本互为前缀/后缀时只算一条，避免把气泡内碎片当成
    //      "更新的消息"；
    //   b) 判决只认长度 ≥ 8 字的气泡：拒绝话术都是完整句子，而按钮
    //      （「重新生成」）/时间戳类碎片通常 < 8 字 —— 短碎片既不参与判决，
    //      也不遮蔽它前面那条完整消息。
    const MIN_VERDICT = 8;
    // ★★ 2026-10-23 修复"版权拒绝被输入区菜单遮蔽、永不申诉"：
    //   实测页面（会话 38448799092518146，18:10）豆包已回
    //     「生成的视频可能涉及版权限制，请更换输入内容后重试」
    //   但 generationFailed() 仍返回 failed:false —— 原因是选择器
    //   `[class*='content']` 同时命中了输入框下方的模式菜单
    //   `guidance-input-content`（文本「对话 图像生成 视频生成 PPT 生成 帮我写作…」），
    //   它排在消息之后、长度 40 ≥ MIN_VERDICT，于是被当成"最后一条回复"，
    //   真正的版权拒绝被判成"不是最新的消息"而忽略 → 不申诉、不改写、不回复，
    //   任务一路空等到超时（实测 576s 仍在等）。
    //   三条过滤：①排除输入区/菜单区节点 ②排除纯时间戳 ③排除模式菜单文案。
    const inInputArea = (el) => {
      try {
        return !!(el.closest
          && el.closest("#input-engine-container,[data-testid='chat_input'],"
            + "[class*='guidance-input'],[class*='input-engine'],"
            + "[class*='sender'],[class*='Sender'],"
            + "[class*='input-area'],[class*='inputArea'],"
            + "[contenteditable='true'],[contenteditable=true]"));
      } catch (e) { return false; }
    };
    const TS_RE = /^(今天|昨天|前天|\d{1,2}-\d{1,2})\s*\d{1,2}:\d{2}$|^\d{1,2}:\d{2}$/;
    const MENU_RE = /图像生成[\s\S]*视频生成|视频生成[\s\S]*PPT|帮我写作|录音转写/;
    let prevSeen = "";
    let last = "";
    for (const msg of messages) {
      const t = (msg.innerText || "").trim().replace(/\s+/g, " ");
      if (!t || t.length > 600) continue;
      // 父子节点文本重复（容器 vs 内部节点）→ 只算一条
      if (prevSeen && (t === prevSeen || prevSeen.indexOf(t) === 0
                       || t.indexOf(prevSeen) === 0)) continue;
      prevSeen = t;
      // 输入框 / 模式菜单不是对话消息
      if (inInputArea(msg)) continue;
      if (TS_RE.test(t)) continue;
      if (MENU_RE.test(t) && t.length <= 80) continue;
      // 这是我们说的话，不是豆包的判决
      let mineHit = false;
      for (const m of MINE) {
        if (m && (t.indexOf(m) >= 0 || m.indexOf(t.slice(0, 40)) >= 0)) { mineHit = true; break; }
      }
      if (mineHit) continue;
      // 正常流程确认消息不算失败
      if (t.includes("视频生成好后") && t.includes("预计等待")) continue;
      if (t.length < MIN_VERDICT) continue;
      last = t;
    }
    if (!last) return { failed: false };
    for (const rule of RULES) {
      for (const w of rule.words) {
        if (last.includes(w)) {
          return { failed: true, kind: rule.kind, word: w, text: last.slice(0, 150) };
        }
      }
    }
    for (const p of ALL_PATTERNS) {
      if (p.re.test(last)) {
        return { failed: true, kind: p.kind, word: "re:" + String(p.re).slice(0, 24),
                  text: last.slice(0, 150) };
      }
    }
    return { failed: false };
  };
  // 豆包「视频生成参数确认」态（2026-09-22 九并发事故里新发现的第二类卡死）。
  // 现在豆包经常不直接开始生成，而是先铺一屏参数＋分镜表，结尾说
  //     "确认后我再开始生成视频。"
  // 然后**等用户在输入框里回复确认**。我们的确认文本发出去之后，若豆包没接茬
  // （既不开始生成、也不报错），页面就永远停在那一屏 —— 实测 4 个任务就这么
  // 一路空转到 1790s 超时才失败。这里把这种状态显式识别出来，交给 Python 侧
  // 提前判死、换账号重试，不再干等半个钟头。
  //
  // myText：我们自己发出的确认文本（Python 侧传入），用来把它从"尾巴正文"里剔掉。
  dbm.awaitingConfirm = () => {
    // 判据（刻意做得保守，宁可漏判也绝不误杀正在生成的任务）：
    //   ① 会话里最后一条"长消息"（豆包的正式回复通常上百字，而我们的确认文本
    //      只有几十字、UI 文案更短）里含"等你确认"类关键词；
    //   ② 且这条之后没有任何新的长消息 —— 即豆包还没接茬；
    //   ③ 且页面没有 <video>、没有"已开始生成"的确认消息、没有"生成中"字样。
    const KEY = [
      "确认后我再开始生成", "确认后我开始生成", "确认后再开始生成",
      "确认后开始生成", "确认后即可开始生成", "确认之后开始生成",
      "请确认后开始生成", "回复确认后开始", "确认后我将开始生成",
      "确认后才会开始生成", "确认无误后开始生成", "确认后我再生成"
    ];
    const RUNNING = ["正在生成", "生成中", "排队中", "视频生成好后",
                     "正在为你生成", "生成进度"];
    try {
      if (dbm.checkGenerationConfirmed && dbm.checkGenerationConfirmed().ok) {
        return { waiting: false };
      }
    } catch (e) {}
    try {
      const vs = dbm.pageVideos ? dbm.pageVideos() : [];
      if (vs && vs.length) return { waiting: false };
    } catch (e) {}
    const body = (document.body.innerText || "");
    if (!body) return { waiting: false };
    for (const r of RUNNING) {
      if (body.indexOf(r) >= 0) return { waiting: false };
    }
    // 收集所有带文本的消息节点，按 DOM 顺序去重（父子节点文本相同的只算一次）
    const nodes = Array.from(document.querySelectorAll(
      "[class*='message'],[class*='bubble'],[class*='content'],[class*='assistant'],[class*='reply']"
    ));
    const seen = [];
    for (const n of nodes) {
      const t = (n.innerText || "").trim().replace(/\s+/g, " ");
      if (!t || t.length < 8) continue;
      const prev = seen.length ? seen[seen.length - 1] : "";
      // 与上一条完全一样、或是上一条的前缀/后缀（典型的父子节点重复）→ 跳过
      if (prev && (t === prev || prev.indexOf(t) === 0 || t.indexOf(prev) === 0)) continue;
      seen.push(t);
    }
    if (!seen.length) return { waiting: false };
    let lastLong = -1;
    for (let i = seen.length - 1; i >= 0; i--) {
      if (seen[i].length >= 60) { lastLong = i; break; }
    }
    if (lastLong < 0) return { waiting: false };
    let hit = false;
    for (const k of KEY) {
      if (seen[lastLong].indexOf(k) >= 0) { hit = true; break; }
    }
    if (!hit) return { waiting: false };
    return { waiting: true, last: seen[lastLong].slice(-90),
              after: seen.slice(lastLong + 1).map(function(s) { return s.slice(0, 40); }) };
  };
  // ===================== 2026-09-29：四类对话场景识别 =====================
  // 区分豆包常见的三种"抱歉"类拒绝 + 正常的"需要确认"态。
  // 注意：我们自己的确认文本里可能含"版权/侵权/违规"等字眼，因此这些检测
  // 也只扫豆包气泡（跳过 dbm.__mine 登记的自发消息），与 generationFailed 一致。
  //
  // 需求2："抱歉，我无法生成你要求的内容。你可以尝试提出其他需求…"
  //   → 需要回"请根据内容进行修改…"让它改提示词重生成。
  // 需求3："抱歉，由于模型可能带来准确性问题，我无法为你生成相应内容…"
  //   → 需要回"确认，使用seedance 2.0 fast 生成视频"，20s 后若还需二次确认，
  //     再回"字字动画提示 + 参考图"。
  // 需求1/需求4：普通的"需要确认"走既有 checkGenerationConfirmed / 版权申诉逻辑。
  dbm.__collectBeanMessages = () => {
    const MINE = dbm.__mine || [];
    const nodes = Array.from(document.querySelectorAll(
      "[class*='message'],[class*='bubble'],[class*='content'],[class*='assistant'],[class*='reply']"
    )).filter(dbm.vis);
    const out = [];
    for (const n of nodes) {
      const t = (n.innerText || "").trim().replace(/\s+/g, " ");
      if (!t || t.length > 600) continue;
      let mineHit = false;
      for (const m of MINE) {
        if (m && (t.indexOf(m) >= 0 || m.indexOf(t.slice(0, 40)) >= 0)) { mineHit = true; break; }
      }
      if (mineHit) continue;
      out.push(t);
    }
    return out;
  };
  // 需求2：豆包"我无法生成你要求的内容"
  dbm.matchesRejectModify = () => {
    const msgs = dbm.__collectBeanMessages();
    for (const t of msgs) {
      if (t.indexOf("抱歉") >= 0 && t.indexOf("我无法生成你要求的内容") >= 0) {
        return { hit: true, text: t.slice(0, 150) };
      }
    }
    const body = (document.body.innerText || "");
    if (body.indexOf("我无法生成你要求的内容") >= 0) {
      return { hit: true, text: "found_in_body" };
    }
    return { hit: false };
  };
  // 需求3：豆包"由于模型可能带来准确性问题…我无法为你生成相应内容"
  dbm.matchesRejectAccuracy = () => {
    const msgs = dbm.__collectBeanMessages();
    for (const t of msgs) {
      if (t.indexOf("抱歉") >= 0 && t.indexOf("由于模型可能带来准确性问题") >= 0
          && t.indexOf("我无法为你生成相应内容") >= 0) {
        return { hit: true, text: t.slice(0, 150) };
      }
    }
    const body = (document.body.innerText || "");
    if (body.indexOf("由于模型可能带来准确性问题") >= 0
        && body.indexOf("我无法为你生成相应内容") >= 0) {
      return { hit: true, text: "found_in_body" };
    }
    return { hit: false };
  };
  // ===================== 无水印视频下载 =====================
  // 豆包管理器给"无水印下载"按钮注入了专属 class .dbm-doubao-no-watermark-download，
  // 且按钮非 hover 时就已在 DOM 中且可见（实测 opacity:1, visibility:visible）。
  // 直接 querySelector 定位，返回按钮坐标，由 Python 端用 CDP 真实鼠标点击（比 el.click() 可靠）。

  // 元素上所有可能携带"无水印下载"语义的文本（按钮文案/aria/title/class 拼接）
  dbm._btnText = (el) => {
    if (!el) return "";
    return ((el.innerText || el.textContent || "") + " "
      + (el.getAttribute("aria-label") || "") + " "
      + (el.getAttribute("title") || "") + " "
      + String(el.className || "")).replace(/\s+/g, "");
  };
  // 判断元素是否是"无水印下载"入口（模糊包含即可，不再要求文本全等）
  dbm._isNoWatermarkEl = (el) => {
    if (!el) return false;
    const hay = dbm._btnText(el);
    const cls = String(el.className || "");
    if (cls.includes("dbm-doubao-no-watermark-download")) return true;
    if (/no[-_]?watermark/i.test(cls)) return true;
    // "无水印/去水印"都算；"加水印/水印设置"等反向语义词不同，不会误中
    if (hay.includes("无水印") || hay.includes("去水印")) return true;
    return false;
  };
  dbm._clickableSel = () =>
    "button,a,[role='button'],[class*='download'],[class*='Download'],[class*='watermark'],[class*='Watermark']";
  dbm._usableRect = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return null;
    const st = getComputedStyle(el);
    if (st.display === "none" || st.visibility === "hidden") return null;
    return r;
  };
  dbm._scoreNoWm = (el) => {
    const t = dbm._btnText(el);
    const cls = String(el.className || "");
    let s = 0;
    if (cls.includes("dbm-doubao-no-watermark-download")) s += 100;
    if (/no[-_]?watermark/i.test(cls)) s += 40;
    if (t.includes("无水印下载") || t.includes("去水印下载")) s += 20;
    else if (t.includes("无水印") || t.includes("去水印")) s += 10;
    return s;
  };
  // 最后一个 <video> 的几何信息（供 Python 端 CDP hover 唤出悬浮控制条）
  dbm.lastVideoRect = () => {
    // 用穿透式查找：成片可能在 shadow DOM / iframe 里，顶层 querySelectorAll 找不到
    const v = dbm._lastVideoEl ? dbm._lastVideoEl() : (dbm.q("video").slice(-1)[0] || null);
    if (!v) return null;
    const r = v.getBoundingClientRect();
    return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height),
              cx: Math.round(r.x + r.width / 2), cy: Math.round(r.y + r.height / 2),
              // 右下角：豆包/管理器的下载工具条通常出现在视频右下
              rx: Math.round(r.x + r.width * 0.75), by: Math.round(r.y + r.height * 0.82),
              src: (v.currentSrc || v.src || "").slice(0, 80),
              isBlob: /^blob:/.test(v.currentSrc || v.src || "") };
  };
  // ★ 2026-10-23：新版成片卡片在"点播放"之前根本不存在 <video>（只有封面
  //   <img> + 播放图标）。lastVideoRect() 返回 null，Python 端连一次悬停都不做，
  //   hover 唤出的「无水印下载」按钮自然永远找不到 —— 线上表现为无限重试
  //   (reason=button_not_found, videoRect=null)。这里给出统一的悬停目标：
  //   优先最后一个 <video>，没有就退回成片卡片矩形（videoCardRect 已能定位）。
  dbm.hoverRect = () => {
    const v = dbm.lastVideoRect();
    if (v && v.w) return v;
    const c = dbm.videoCardRect ? dbm.videoCardRect() : null;
    if (!c || !c.found) return null;
    return { x: c.x, y: c.y, w: c.w, h: c.h,
              cx: c.cx, cy: c.cy, rx: c.rx, by: c.bry,
              src: "", isBlob: false, byCard: c.by };
  };
  // 点卡片里的播放图标（inline xgplayer），把 <video> 真正挂载出来。
  // ⚠️ 只点小播放图标，绝不点卡片本体 —— 点卡片会打开「创建画布」预览面板，
  //    把聊天页整个盖住，「无水印下载」按钮随之消失。
  //    管理器/浏览器插件的下载按钮注入逻辑依赖页面里存在 <video>，所以这一步
  //    同时也是"唤出无水印按钮"的前提。
  dbm.clickPlayIcon = () => {
    // 1. 先定位最后一个成片卡片，合成 hover 事件强制挂载悬浮层
    //    （播放图标/工具条都是 mouseenter 后才渲染的，未 hover 时 DOM 里根本没有）
    let cards = [];
    try {
      cards = Array.from(document.querySelectorAll(
        '[class*="video-hover-button-group-container"],[class*="block-video"]'))
        .filter(el => dbm._usableRect(el));
    } catch (e) {}
    const card = cards.length ? cards[cards.length - 1] : null;
    if (card) {
      try {
        const cr = card.getBoundingClientRect();
        for (const ty of ["mouseover", "mouseenter", "mousemove"]) {
          card.dispatchEvent(new MouseEvent(ty, { bubbles: true,
            clientX: cr.x + cr.width / 2, clientY: cr.y + cr.height / 2 }));
        }
      } catch (e) {}
    }
    // 2. 收集播放图标候选（只查可用矩形，不做 opacity 过滤——hover 渐入期 opacity 可能为 0）
    let cands = [];
    try {
      document.querySelectorAll('[class*="play-icon"],[class*="playIcon"]')
        .forEach(el => { if (dbm._usableRect(el)) cands.push(el); });
    } catch (e) {}
    if (!cands.length && card) {
      try {
        card.querySelectorAll('[class*="play"],[class*="Play"]')
          .forEach(el => { if (dbm._usableRect(el)) cands.push(el); });
      } catch (e) {}
    }
    // 3. 优先取最后一个卡片内部的图标，避免点到历史消息的播放按钮
    let el = null;
    if (card) {
      for (let i = cands.length - 1; i >= 0; i--) {
        if (card.contains(cands[i])) { el = cands[i]; break; }
      }
    }
    if (!el && cands.length) el = cands[cands.length - 1];
    if (!el) return { ok: false, reason: "no_play_icon",
                       cards: cards.length, cands: cands.length };
    const r = el.getBoundingClientRect();
    try {
      el.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
      el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
      el.click();
    } catch (e) {
      return { ok: false, reason: "click_exc:" + e };
    }
    return { ok: true, x: Math.round(r.x + r.width / 2),
              y: Math.round(r.y + r.height / 2), candCount: cands.length };
  };
  // 内部查找：返回 DOM 元素（供同页面函数取 href），不直接回传 Python（DOM 引用无法序列化）
  dbm._findNoWatermarkRaw = () => {
    const last = dbm._lastVideoEl ? dbm._lastVideoEl() : (dbm.q("video").slice(-1)[0] || null);
    let best = null;
    const consider = (el, bonus) => {
      if (!el || !dbm._isNoWatermarkEl(el)) return;
      const s = dbm._scoreNoWm(el) + bonus + (dbm._usableRect(el) ? 2 : 0);
      if (!best || s > best.s) best = { el: el, s: s };
    };
    // 1) 只在【最后一个视频】容器内向上最多 25 层查找，避免拿到历史视频卡片的旧按钮
    if (last) {
      let node = last;
      for (let i = 0; i < 25 && node; i++) {
        node = node.parentElement;
        if (!node) break;
        node.querySelectorAll(dbm._clickableSel()).forEach(el => consider(el, 0));
        if (best && best.s >= 100) break;
      }
    }
    // 2) 全局兜底（class 专属按钮 / 文本按钮），取分数最高者
    if (!best) {
      Array.from(document.querySelectorAll(dbm._clickableSel())).forEach(el => consider(el, -5));
    }
    // 3) elementFromPoint 在最后一个视频右下区域 11×9 网格采样探测
    //    （按钮是 hover 才渲染的悬浮层、又不在常规 button 标签里时的兜底）
    if (!best && last) {
      const r = last.getBoundingClientRect();
      outer:
      for (let gy = 2; gy >= 0; gy--) {
        for (let gx = 10; gx >= 4; gx--) {
          const px = r.x + r.width * (gx / 10);
          const py = r.y + r.height * (gy / 8);
          let el = document.elementFromPoint(px, py);
          for (let k = 0; k < 5 && el; k++) {
            if (el.querySelectorAll) {
              el.querySelectorAll(dbm._clickableSel()).forEach(c => consider(c, -8));
            }
            if (el.matches && dbm._isNoWatermarkEl(el)) { consider(el, -8); }
            el = el.parentElement;
          }
          if (best) break outer;
        }
      }
    }
    return best;
  };
  // 对外（Python）：只回标量坐标与诊断信息
  dbm.findNoWatermarkButton = () => {
    const found = dbm._findNoWatermarkRaw();
    if (!found || !found.el) return { found: false };
    const el = found.el;
    const r = dbm._usableRect(el) || el.getBoundingClientRect();
    return {
      found: true,
      x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2),
      w: Math.round(r.width), h: Math.round(r.height),
      score: found.s,
      text: (el.innerText || el.textContent || "").trim().slice(0, 20),
      cls: String(el.className || "").slice(0, 80),
      tag: el.tagName,
      by: found.s >= 100 ? "class" : (found.s >= 20 ? "text" : "fuzzy"),
      dpr: window.devicePixelRatio || 1,
      videoRect: dbm.lastVideoRect()
    };
  };
  // DOM 级点击「无水印下载」按钮（2026-11-02）：直接对元素派发事件，
  // 彻底摆脱 Python 侧 CDP 真实鼠标坐标点击对"窗口可见且在屏幕内 + DPI 缩放匹配"的强依赖。
  dbm.clickNoWatermarkButton = () => {
    const found = dbm._findNoWatermarkRaw();
    if (!found || !found.el) return { ok: false, reason: "no_btn" };
    const el = found.el;
    try {
      el.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
      el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
      el.click();
      return { ok: true, tag: el.tagName,
               text: (el.innerText || el.textContent || "").trim().slice(0, 20) };
    } catch (e) {
      return { ok: false, reason: "click_exc:" + e };
    }
  };
  // DOM 级点击豆包原生「重新发送/重试」入口（替代 CDP 坐标点击）
  dbm.clickRetryButton = () => {
    try {
      const els = Array.from(
        document.querySelectorAll("button,[role=button],span,div"))
        .filter(e => /^(重新发送|重试)$/.test((e.innerText || '').trim()) && e.offsetParent);
      if (!els.length) return { ok: false, reason: "no_retry" };
      const t = els[els.length - 1];
      t.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
      t.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      t.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
      t.click();
      return { ok: true, text: (t.innerText || "").trim().slice(0, 20) };
    } catch (e) {
      return { ok: false, reason: "click_exc:" + e };
    }
  };
  // 坐标命中诊断：给定视口坐标，返回 elementFromPoint 命中的元素及其 8 层父链中
  // 是否有无水印按钮、该按钮当前是否处于 :hover。用于判断 CDP 鼠标事件到底有没有
  // 真正落到按钮上（Electron + 系统显示缩放时 CDP 坐标可能与 CSS 像素错位）。
  dbm.probeAt = (x, y) => {
    const out = { x: Math.round(x), y: Math.round(y), dpr: window.devicePixelRatio || 1,
                   hit: false, hover: false, depth: -1, tag: "", cls: "", text: "",
                   btnRect: null };
    let el = null;
    try { el = document.elementFromPoint(x, y); } catch (e) { el = null; }
    if (!el) return out;
    out.tag = el.tagName;
    out.cls = String(el.className || "").slice(0, 80);
    out.text = (el.innerText || el.textContent || "").trim().slice(0, 20);
    let node = el;
    for (let i = 0; i < 8 && node; i++) {
      if (dbm._isNoWatermarkEl && dbm._isNoWatermarkEl(node)) {
        out.hit = true;
        out.depth = i;
        try { out.hover = node.matches(":hover"); } catch (e) {}
        const r = node.getBoundingClientRect();
        out.btnRect = { x: Math.round(r.x), y: Math.round(r.y),
                         w: Math.round(r.width), h: Math.round(r.height) };
        if (!out.text) out.text = (node.innerText || node.textContent || "").trim().slice(0, 20);
        break;
      }
      node = node.parentElement;
    }
    return out;
  };

  dbm.getNoWatermarkUrl = async () => {
    const videos = dbm.q("video");
    if (!videos.length) return { ok: false, reason: "no_video_on_page" };
    const lastVideo = videos[videos.length - 1];
    const vsrc = lastVideo.currentSrc || lastVideo.src || "";
    const vRect = lastVideo.getBoundingClientRect();
    let debug = { videoCount: videos.length,
                  videoSrc: vsrc.slice(0, 80),
                  isBlob: /^blob:/.test(vsrc),
                  vRect: { x: Math.round(vRect.x), y: Math.round(vRect.y),
                            w: Math.round(vRect.width), h: Math.round(vRect.height) } };

    const raw = dbm._findNoWatermarkRaw();
    if (!raw || !raw.el) {
      // 诊断：列出页面所有含"水印/下载"的按钮
      let diag = [];
      Array.from(document.querySelectorAll("button,a,[role='button']")).forEach(el => {
        const t = (el.innerText || el.getAttribute("aria-label") || "").trim();
        if ((t.includes("水印") || t.includes("下载")) && t.length < 30) {
          diag.push({ tag: el.tagName, text: t.slice(0, 20),
                       cls: String(el.className || "").slice(0, 50) });
        }
      });
      debug.downloadLikeButtons = diag.slice(0, 15);
      debug.videoRect = dbm.lastVideoRect();
      return { ok: false, reason: "no_no_watermark_button", debug: debug };
    }

    const btn = raw.el;
    const r = dbm._usableRect(btn) || btn.getBoundingClientRect();
    const x = Math.round(r.x + r.width / 2);
    const y = Math.round(r.y + r.height / 2);
    const btnText = (btn.innerText || btn.textContent || "").trim().slice(0, 20);
    const btnCls = String(btn.className || "").slice(0, 60);
    debug.btn = { tag: btn.tagName, text: btnText, cls: btnCls, score: raw.s,
                   rect: { x: Math.round(r.x), y: Math.round(r.y),
                            w: Math.round(r.width), h: Math.round(r.height) } };

    // 1. 链接形式：直接取 href
    if (btn.tagName === "A" || btn.hasAttribute("href")) {
      const href = btn.href || btn.getAttribute("href") || "";
      if (href.startsWith("http") && !href.startsWith("javascript:")) {
        return { ok: true, url: href, source: "no_watermark_href", text: btnText, debug: debug };
      }
    }
    // 2. data 属性携带 URL
    const dataUrl = btn.getAttribute("data-url") || btn.getAttribute("data-src")
                    || btn.getAttribute("data-href") || btn.getAttribute("data-video-url") || "";
    if (dataUrl && dataUrl.startsWith("http")) {
      return { ok: true, url: dataUrl, source: "no_watermark_data", text: btnText, debug: debug };
    }
    // 3. 返回按钮坐标，由 Python 端先 hover 视频唤出悬浮工具条，再 CDP 真实鼠标点击
    return { ok: true, url: "", source: "need_click", text: btnText, x: x, y: y,
              videoRect: dbm.lastVideoRect(), debug: debug };
  };
  // 扫描页面中所有可见的按钮文本（用于诊断"无水印下载"按钮是否真的存在）
  dbm.scanAllButtons = () => {
    const out = [];
    document.querySelectorAll("button,[role='button'],a").forEach(el => {
      if (!dbm.vis(el)) return;
      const t = (el.innerText || "").trim();
      const label = (el.getAttribute("aria-label") || el.getAttribute("title") || "").trim();
      if (t && t.length < 30) out.push({ tag: el.tagName, text: t, label: label.slice(0, 20) });
    });
    return out.slice(0, 50);
  };

  // ===================== 深度视频检测（穿透 shadow DOM / iframe / source） =====================
  dbm._srcOf = (v) => {
    let s = "";
    try { s = v.currentSrc || v.src || ""; } catch (e) { s = ""; }
    if (!s) {
      try {
        const ss = v.querySelectorAll ? v.querySelectorAll("source") : [];
        for (let i = 0; i < ss.length; i++) {
          const u = ss[i].currentSrc || ss[i].src || "";
          if (u) { s = u; break; }
        }
      } catch (e) {}
    }
    if (!s) {
      try { s = v.getAttribute("data-src") || v.getAttribute("data-url") || ""; } catch (e) {}
    }
    return String(s || "");
  };
  dbm._deepRoots = () => {
    const roots = [{ root: document, where: "doc" }];
    try {
      const all = document.querySelectorAll("*");
      for (let i = 0; i < all.length; i++) {
        const e = all[i];
        try {
          if (e && e.shadowRoot) roots.push({ root: e.shadowRoot, where: "shadow:" + e.tagName });
        } catch (err) {}
      }
    } catch (err) {}
    const pushFrames = (doc, tag) => {
      let frs = [];
      try { frs = doc.querySelectorAll("iframe,frame"); } catch (e) { return; }
      for (let i = 0; i < frs.length; i++) {
        let d = null;
        try { d = frs[i].contentDocument; } catch (e) { d = null; }
        if (d) roots.push({ root: d, where: tag + ":frame" });
      }
    };
    pushFrames(document, "doc");
    return roots;
  };
  dbm._lastVideoEl = () => {
    let last = null;
    const rs = dbm._deepRoots();
    for (let i = 0; i < rs.length; i++) {
      let vs = [];
      try { vs = rs[i].root.querySelectorAll("video"); } catch (e) { continue; }
      for (let j = 0; j < vs.length; j++) last = vs[j];
    }
    return last;
  };
  dbm.deepVideos = () => {
    const out = [];
    const rs = dbm._deepRoots();
    for (let i = 0; i < rs.length; i++) {
      let vs = [];
      try { vs = rs[i].root.querySelectorAll("video"); } catch (e) { continue; }
      for (let j = 0; j < vs.length; j++) {
        const v = vs[j];
        out.push({
          where: rs[i].where,
          src: dbm._srcOf(v),
          w: v.videoWidth || 0,
          h: v.videoHeight || 0,
          dur: (isFinite(v.duration) ? v.duration : 0),
          rs: v.readyState || 0
        });
      }
    }
    return out;
  };
  // 页面资源时间线里的视频请求：既不依赖 <video> DOM，也不依赖 CDP Network 域，
  // 是页面自己记的账，CDP 断连/重连都不丢（页面刷新会清空，故按增量比对）。
  dbm.perfVideos = () => {
    try {
      const es = performance.getEntriesByType("resource") || [];
      const out = [];
      for (let i = 0; i < es.length; i++) {
        const n = String(es[i].name || "");
        const it = String(es[i].initiatorType || "");
        if (/\.(mp4|mov|m4v|webm|mkv)(\?|$)/i.test(n) || it === "video") {
          out.push({ name: n.slice(0, 240), init: it, t: Math.round(es[i].startTime || 0) });
        }
      }
      return out;
    } catch (e) { return []; }
  };
  // 结果卡片 UI 信号：即使 <video> 完全拿不到，只要出现"无水印下载/下载/重新生成"
  // 且页面不再显示"生成中/排队中"，就说明成片已经出来了。
  // 正则在字符串里最后一次出现的位置（没有则 -1）
  dbm._lastIdx = (s, re) => {
    let i = -1, m;
    const r = new RegExp(re.source, "g");
    while ((m = r.exec(s)) !== null) { i = m.index; if (m.index === r.lastIndex) r.lastIndex++; }
    return i;
  };
  // 豆包成片/生成中的文案
  dbm._DONE_RE = /你的视频生成好了|视频已生成|视频生成好了|生成好了|视频已生成完成/;
  dbm._PROG_RE = /预计等待|生成中|排队中|正在生成|生成进度|还需等待|排队等待/;
  // 页面文案状态机：比较"完成文案"与"进行中文案"在 innerText 里的先后位置。
  //
  // ⚠️ 绝不能用"全文是否包含'预计等待'"判断还在生成：豆包那条
  // "本次使用 Seedance 2.0 Fast 生成，预计等待 5 分钟"是**生成前的说明**，
  // 会永久留在对话里。实测线上日志就是被它坑了 —— progress 恒为 true，
  // 所有成片信号被永久屏蔽，片子生成好了也永远判不出来。
  // 对话文本按时间顺序排列，所以"完成文案出现在进行中文案之后"即代表已出片。
  dbm.textState = () => {
    let bt = "";
    try { bt = String((document.body ? document.body.innerText : "") || ""); } catch (e) {}
    const iDone = dbm._lastIdx(bt, dbm._DONE_RE);
    const iProg = dbm._lastIdx(bt, dbm._PROG_RE);
    let state = "none";
    if (iDone >= 0 && iDone > iProg) state = "done";
    else if (iProg >= 0) state = "progress";
    else if (iDone >= 0) state = "done";
    return { state: state, iDone: iDone, iProg: iProg,
             doneText: iDone >= 0 ? bt.substr(iDone, 24) : "" };
  };
  dbm.resultSignal = () => {
    let noWm = false, download = false, regen = false, progress = false, done = false;
    const hits = [];
    // ★★ 2026-11-03 v3 额度闸门（最高优先级，压过一切历史完成文案）：
    //   豆包回复「今日视频生成免费额度已用完。开通订阅畅享更多额度。」时，
    //   对话里往往还残留着上一轮「你的视频生成好了」。textState() 用全文
    //   innerText 找最后一次完成文案，会拿这条历史文案判成 done=true，
    //   于是 _video_evidence 的文案证据认定"已出片" → _mark_seedance_generated()
    //   把这次被拒绝的任务虚增一次生成，凑出「3/3 已满额」。
    //   额度文案是豆包侧的权威拒绝结论，必须优先于所有历史/进度信号：
    //   命中即强制 done=false / progress=false，并打上 quota 标志，Python 侧
    //   _video_evidence / _confirm_hit_concrete 据此一律不放行。
    let qe = null;
    try { qe = dbm.quotaExhausted(); } catch (e) {}
    if (qe) {
      return { noWm: false, download: false, regen: false,
               progress: false, done: false, quota: true,
               quotaText: String(qe).slice(0, 80),
               hits: ["quota:" + String(qe).slice(0, 24)] };
    }
    // ---- 1) 页面文案状态机（最可靠，直接来自豆包自己的回复）----
    let ts = { state: "none" };
    try { ts = dbm.textState(); } catch (e) {}
    if (ts.state === "done") { done = true; hits.push("text:" + (ts.doneText || "done")); }
    else if (ts.state === "progress") { progress = true; hits.push("text:progress"); }
    // ---- 2) 按钮/入口扫描 ----
    const roots = [document];
    try {
      const frs = document.querySelectorAll("iframe,frame");
      for (let i = 0; i < frs.length; i++) {
        try { if (frs[i].contentDocument) roots.push(frs[i].contentDocument); } catch (e) {}
      }
    } catch (e) {}
    const SEL2 = "button,a,[role='button'],[class*='download'],[class*='Download'],"
      + "[class*='watermark'],[class*='Watermark']";
    for (let r = 0; r < roots.length; r++) {
      let els = [];
      try { els = roots[r].querySelectorAll(SEL2); } catch (e) { continue; }
      for (let i = 0; i < els.length; i++) {
        const el = els[i];
        const hay = dbm._btnText(el);
        if (!hay) continue;
        // "下载电脑版/下载客户端"是豆包侧边栏常驻广告位，不是成片入口，必须排除
        if (dbm._isNoWatermarkEl(el)) { noWm = true; hits.push("nowm:" + hay.slice(0, 14)); }
        else if (/下载/.test(hay)
                 && !/加水印|水印设置|下载电脑版|下载客户端|下载豆包|下载[AD][Pp][Pp]/.test(hay)) {
          download = true; hits.push("dl:" + hay.slice(0, 14));
        }
        else if (/重新生成|再次生成|再来一次|重新编辑/.test(hay)) { regen = true; hits.push("regen:" + hay.slice(0, 14)); }
        if (/生成中|排队中|正在生成|还需等待|排队等待/.test(hay)) { progress = true; hits.push("prog:" + hay.slice(0, 14)); }
      }
    }
    return { noWm: noWm, download: download, regen: regen,
             progress: progress, done: done, hits: hits.slice(0, 16) };
  };
  // 把所有可滚动容器（含聊天列表）滚到底：豆包的结果卡片是懒加载的，
  // 不在可视区就只留一张封面 <img>，永远不会有 <video>。
  dbm.scrollToBottom = () => {
    let n = 0;
    try {
      const all = document.querySelectorAll("*");
      for (let i = 0; i < all.length; i++) {
        const e = all[i];
        try {
          if (e.scrollHeight - e.clientHeight > 16 && e.clientHeight > 80) {
            e.scrollTop = e.scrollHeight;
            n++;
          }
        } catch (err) {}
      }
    } catch (err) {}
    try { window.scrollTo(0, (document.body && document.body.scrollHeight) || 999999); } catch (e) {}
    try { window.scrollBy(0, 999999); } catch (e) {}
    return n;
  };
  // 定位成片卡片矩形（供 Python 侧 CDP hover 唤醒 <video> / 唤出悬浮下载条）
  //  1) 任意根里的 <video>
  //  2) 以"你的视频生成好了"为锚点，向上逐层扩大范围找视频卡片
  //  3) 视口里最大的 <img> 兜底
  dbm.videoCardRect = () => {
    const VIDEO_OK = (r) => r.width >= 100 && r.height >= 70;
    const pack = (by, r, extra) => ({
      found: true, by: by,
      x: Math.round(r.x), y: Math.round(r.y),
      w: Math.round(r.width), h: Math.round(r.height),
      cx: Math.round(r.x + r.width / 2), cy: Math.round(r.y + r.height / 2),
      rx: Math.round(r.x + r.width * 0.75), bry: Math.round(r.y + r.height * 0.82),
      extra: extra || ""
    });
    // 1) <video>
    let v = dbm._lastVideoEl ? dbm._lastVideoEl() : null;
    if (v) {
      const r = v.getBoundingClientRect();
      if (VIDEO_OK(r)) return pack("video", r, String(v.currentSrc || v.src || "").slice(0, 60));
    }
    const scan = (root) => {
      let out = null;
      let els = [];
      try {
        els = root.querySelectorAll(
          "video,img,[class*='video'],[class*='Video'],[class*='player'],[class*='Player']");
      } catch (e) { return null; }
      for (let i = 0; i < els.length; i++) {
        const el = els[i];
        const tn = el.tagName;
        const c = String(el.className || "");
        let score = 0;
        if (tn === "VIDEO") score = 100;
        else if (tn === "IMG") score = 30;
        else score = 5;
        if (/video|player/i.test(c)) score += 25;
        if (score < 30) continue;
        const r = el.getBoundingClientRect();
        if (!VIDEO_OK(r)) continue;
        if (!out || score > out.score) out = { score: score, r: r, tag: tn, cls: c.slice(0, 50) };
      }
      return out;
    };
    // 2) 锚点法
    let leaf = null;
    try {
      const all = document.querySelectorAll("*");
      for (let i = 0; i < all.length; i++) {
        const e = all[i];
        if (e.children && e.children.length) continue;
        if (dbm._DONE_RE.test(String(e.textContent || ""))) { leaf = e; break; }
      }
    } catch (e) {}
    let node = leaf;
    for (let k = 0; k < 12 && node; k++) {
      const hit = scan(node);
      if (hit) return pack("anchor:" + hit.tag, hit.r, hit.cls);
      node = node.parentElement;
    }
    // 3) 全局兜底：视口内最大的 img
    let best = null;
    try {
      const imgs = document.querySelectorAll("img");
      for (let i = 0; i < imgs.length; i++) {
        const r = imgs[i].getBoundingClientRect();
        if (!VIDEO_OK(r)) continue;
        if (r.bottom < 0 || r.top > (window.innerHeight || 900)) continue;
        if (!best || r.width * r.height > best.r.width * best.r.height) {
          best = { r: r, cls: String(imgs[i].className || "").slice(0, 50) };
        }
      }
    } catch (e) {}
    if (best) return pack("fallback:img", best.r, best.cls);
    return { found: false, reason: leaf ? "anchor_found_no_card" : "no_anchor" };
  };
  // 主动唤醒成片：滚到底 → 定位卡片 → 返回矩形（由 Python 侧 hover）
  dbm.revealVideo = () => {
    const n = dbm.scrollToBottom();
    const card = dbm.videoCardRect();
    card.scrolled = n;
    card.sig = dbm.resultSignal();
    return card;
  };
  // 一键诊断：超时前后把现场全部 dump 出来，下次再出问题可以直接定位。
  dbm.pageDiag = () => {
    let iframes = 0, shadowHosts = 0, canvas = 0, imgs = 0, videoLike = 0, nodes = 0;
    try {
      const all = document.querySelectorAll("*");
      nodes = all.length;
      for (let i = 0; i < all.length; i++) {
        const e = all[i];
        const tg = e.tagName;
        if (tg === "IFRAME" || tg === "FRAME") iframes++;
        else if (e.shadowRoot) shadowHosts++;
        else if (tg === "CANVAS") canvas++;
        else if (tg === "IMG") imgs++;
        const c = String(e.className || "");
        if (/video/i.test(c)) videoLike++;
      }
    } catch (e) {}
    const dv = dbm.deepVideos();
    let tail = "";
    try {
      const msgs = document.querySelectorAll(
        "[class*='message'],[class*='bubble'],[class*='assistant'],[class*='reply']");
      const last = msgs[msgs.length - 1];
      tail = last ? String(last.innerText || "").trim().slice(-160) : "";
    } catch (e) {}
    let bodyTail = "";
    try { bodyTail = String((document.body ? document.body.innerText : "") || "").trim().slice(-260); } catch (e) {}
    return {
      url: String(location.href).slice(0, 90),
      vis: String(document.visibilityState),
      nodes: nodes,
      plainVideo: dbm.q("video").length,
      deepVideo: dv.length,
      deepSrcs: dv.map(function (v) { return String(v.src || "(empty)").slice(0, 70); }).slice(0, 6),
      deepInfo: dv.map(function (v) { return v.where + "/" + v.w + "x" + v.h + "/rs" + v.rs; }).slice(0, 6),
      iframes: iframes, shadowHosts: shadowHosts, canvas: canvas, imgs: imgs, videoLike: videoLike,
      perf: dbm.perfVideos().slice(-4),
      sig: dbm.resultSignal(),
      tail: tail,
      bodyTail: bodyTail
    };
  };

  // ===================== 无水印直链自解析（官方创作中心主链路，2026-11-03 v2） =====================
  // 深度逆向官方 runtime-resolver 后重写。官方「无水印下载」按钮的真实解析主链路是
  // 【创作中心】：homepage → node_info(分页) → node_lastest_used → 按页面可见封面 /
  // messageId / creationTaskId 对齐出「真实 asset node_id」→ get_download_info →
  // 官方无水印直链。message_node_info 只是官方 F() 里 V() 全部失败后的【最后兜底】。
  // 旧插件把 message_node_info 当主链路、并把 fiber 里的 message/block id 直接喂给
  // get_download_info，恒返回 code=0 无地址 —— 这正是自解析 317 连败 / 0 成功的根因。
  // 本函数完全在页面内用「当前 webview 自己的 Cookie」调 samantha API，因此每个豆包
  // 账号天然拥有独立解析通道，可并发，不依赖管理器 IPC / 全局下载窗口锁。
  dbm.resolveNoWmViaApi = async () => {
    if (!/(^|\.)doubao\.com$/i.test(location.hostname)) return { ok: false, error: "not_doubao" };
    const isNum = (s) => /^\d{8,}$/.test(String(s == null ? "" : s));
    const uniq = (arr, n) => {
      const s = new Set(), o = [];
      for (const v of arr) { const k = String(v); if (k && !s.has(k)) { s.add(k); o.push(k); } if (o.length >= n) break; }
      return o;
    };
    const uniqBy = (arr, key, n) => {
      const s = new Set(), o = [];
      for (const it of arr) { const k = String(it && it[key] || ""); if (k && !s.has(k)) { s.add(k); o.push(it); } if (o.length >= n) break; }
      return o;
    };
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const cleanUrl = (t) => {
      if (typeof t !== "string") return "";
      const e = t.trim().replace(/\\u0026/g, "&").replace(/&amp;/g, "&");
      return /^https?:\/\//i.test(e) ? e : "";
    };
    // 官方 v(t)：复用页面实际请求过的 samantha URL（含可能必需的签名 query），
    // 避免硬编码相对路径丢参数导致接口返回 code!=0 / 空数据。
    const apiUrl = (p) => {
      const e = String(p || "");
      if (/^https?:\/\//i.test(e)) return e;
      try {
        const rs = performance.getEntriesByType?.("resource") || [];
        for (const n of rs.slice().reverse()) {
          const nm = String(n.name || "");
          if (nm.includes(e)) return nm;
        }
        const hit = rs.slice().reverse().find((n) => /\/samantha\//.test(String(n.name || "")));
        if (hit && hit.name) { const u = new URL(hit.name); u.pathname = e; return u.href; }
      } catch (e2) {}
      return e;
    };
    const postJson = async (p, body) => {
      const r = await fetch(apiUrl(p), {
        method: "POST",
        headers: {
          accept: "application/json",
          "content-type": "application/json",
          "agw-js-conv": "str",
          origin: location.origin,
          referer: location.href
        },
        credentials: "include",
        body: JSON.stringify(body || {})
      });
      return await r.json();
    };
    // 官方 U(t)：确认无水印下载流校验（比旧 okUrl 更宽，覆盖全部官方确认流）
    const okUrl = (u) => {
      const e = String(u || "").toLowerCase();
      if (!e) return false;
      try {
        const t = new URL(u, location.href);
        const q = t.searchParams.get("download");
        if (/(^|[.-])videoweb-download\.doubao\.com$/i.test(t.hostname) && q === "true") return true;
        if (/(^|[.-])videoweb\.doubao\.com$/i.test(t.hostname) && q === "true") return true;
        if (t.hostname.includes("doubao.com") && t.pathname.includes("/download") && q === "true") return true;
        // 管理器实测：真实下载直链也落在 vXX-vdl.doubao.com（与预览流同族域名）
        if (/(^|[.-])v\d+-vdl\.doubao\.com$/i.test(t.hostname) && q === "true") return true;
      } catch (e2) {}
      return /download=true/.test(e) && /video_mp4|mime_type=video_mp4/.test(e);
    };
    // 递归扫整份响应找官方直链（响应体结构变化时兜底）
    const findOfficial = (obj, d) => {
      if (!obj || d > 7) return "";
      if (typeof obj === "string") return okUrl(obj) ? obj : "";
      if (typeof obj !== "object") return "";
      if (Array.isArray(obj)) { for (const it of obj) { const r = findOfficial(it, d + 1); if (r) return r; } return ""; }
      try { for (const k in obj) { const r = findOfficial(obj[k], d + 1); if (r) return r; } } catch (e2) {}
      return "";
    };
    // 官方 j(t)：get_download_info → 确认无水印直链（保留响应体做 findOfficial 兜底）
    const downloadInfo = async (nid) => {
      const id = String(nid || "").trim();
      if (!isNum(id)) throw new Error("缺少作品节点ID");
      const j = await postJson("/samantha/aispace/get_download_info", { requests: [{ node_id: id }] });
      const code = (j && typeof j.code !== "undefined") ? j.code : "none";
      const di = ((j.data || {}).download_infos || [])[0] || {};
      let main = String(di.main_url || di.mainUrl || "");
      const backup = String(di.backup_url || di.backupUrl || "");
      if (!main || !okUrl(main)) { const hit = findOfficial(j, 0); if (hit) main = hit; }
      if (!main) throw new Error("接口没有返回下载地址(code=" + code + ")");
      if (!okUrl(main)) throw new Error("接口返回的不是确认无水印下载流");
      return { mainUrl: main, backupUrl: backup, nodeId: id, code: code };
    };
    // 官方 S(t)：封面 URL 归一化 key（按页面可见封面对齐创作中心节点）
    const coverKey = (raw) => {
      const u = cleanUrl(raw);
      if (!u) return "";
      try {
        const t = new URL(u, location.href);
        return decodeURIComponent(t.pathname).replace(/~[^/]*$/, "").toLowerCase();
      } catch (e2) {
        return u.split("?")[0].replace(/~[^/]*$/, "").toLowerCase();
      }
    };
    const visibleCoverKeys = (max) => {
      const lim = max || 30, out = [];
      try {
        const els = Array.from(document.querySelectorAll("img,video,source"));
        for (const o of els) {
          let ss = "";
          try { ss = String(o.srcset || o.srcSet || "").split(",")[0].trim().split(/\s+/)[0]; } catch (e2) {}
          const cands = [o.currentSrc, o.src, o.poster, ss];
          for (const c of cands) {
            const k = coverKey(c);
            if (k && /tos-cn-p-9ecd54|tplv-noop|videoweb/i.test(String(c || ""))) out.push(k);
          }
          if (out.length >= lim) break;
        }
      } catch (e2) {}
      return uniq(out, lim);
    };
    // 官方 C(t)：递归从创作中心响应提取视频节点
    const collectNodes = (t, out, seen, d) => {
      if (d > 10 || !t || typeof t !== "object" || seen.has(t)) return;
      seen.add(t);
      try {
        const r = (t.id != null) ? String(t.id) : "";
        const key = (t.key != null) ? String(t.key) : "";
        const name = (t.name != null) ? String(t.name) : "";
        if (isNum(r) && (key || name || t.node_type || t.nodeType)) {
          const covers = [];
          const nc = t.node_cover || t.nodeCover || {};
          const lv = nc && (nc.list_view || nc.listView);
          const tv = nc && (nc.thumbnail_view || nc.thumbnailView);
          const cu1 = lv && (lv.cover_url || lv.coverUrl);
          const cu2 = tv && (tv.cover_url || tv.coverUrl);
          if (cu1) covers.push(String(cu1));
          if (cu2) covers.push(String(cu2));
          const ct = t.content || {};
          out.push({
            id: r,
            key: key,
            name: name,
            nodeType: Number(t.node_type || t.nodeType || 0),
            messageId: String(ct.message_id_str || ct.message_id || t.message_id_str || t.message_id || ""),
            creationTaskId: String(ct.creation_task_id_str || ct.creation_task_id || t.creation_task_id_str || ""),
            coverKeys: uniq(covers.map(coverKey).filter(Boolean), 8)
          });
        }
      } catch (e2) {}
      try {
        if (Array.isArray(t)) { for (const v of t) collectNodes(v, out, seen, d + 1); }
        else { for (const v of Object.values(t).slice(0, 160)) if (v && typeof v === "object") collectNodes(v, out, seen, d + 1); }
      } catch (e2) {}
    };
    const isVideoNode = (n) => !!n && (6 === n.nodeType || /^v\d/i.test(String(n.key || "")) || /\.mp4$/i.test(String(n.name || "")));
    // 官方 N()：创作中心主链路 homepage → node_info(分页) → node_lastest_used
    const creationCenterNodes = async (diag) => {
      let nodes = [];
      try {
        const hp = await postJson("/samantha/aispace/homepage", {});
        if (!hp || hp.code !== 0) { diag.ccCodes.push("homepage:code=" + (hp && hp.code)); return nodes; }
        diag.ccCodes.push("homepage:0");
        const cats = [];
        collectNodes(hp.data || hp, cats, new WeakSet(), 0);
        let root = cats.find((n) => /我的创作/.test(String(n.name || "")))
          || cats.find((n) => 1 === n.nodeType && n.key === n.id)
          || cats[0];
        if (!root || !root.id) { diag.ccCodes.push("no_creation_root"); }
        else {
          const collected = [];
          let cursor = "";
          for (let page = 0; page < 6; page++) {
            const body = {
              node_id: root.id,
              need_full_path: true,
              sort_param: { need_sort_config: true, sort_order: 1, sort_type: 0 },
              size: 50
            };
            if (cursor) { body.cursor = cursor; body.next_cursor_with_sort = cursor; }
            const r = await postJson("/samantha/aispace/node_info", body);
            const d = (r && r.data) ? r.data : {};
            collectNodes(r.data || r, collected, new WeakSet(), 0);
            diag.ccCodes.push("node_info:" + page + ":" + (r && r.code));
            cursor = String(d.next_cursor || d.nextCursor || "");
            if (!d.has_more || !cursor) break;
            if (collected.some(isVideoNode)) break;
          }
          nodes = uniqBy(collected, "id", 200);
          // node_lastest_used 兜底（node_info 未返回任何视频节点时）
          if (!nodes.some(isVideoNode)) {
            for (const b of [{ nodeType: 6, size: 50 }, { node_type: 6, size: 50 }]) {
              try {
                const r = await postJson("/samantha/aispace/node_lastest_used", b);
                const tmp = [];
                collectNodes(r.data || r, tmp, new WeakSet(), 0);
                const vids = uniqBy(tmp.filter(isVideoNode), "id", 10);
                if (vids.length) { nodes = vids.concat(nodes); diag.ccCodes.push("latest_used:hit"); break; }
                diag.ccCodes.push("latest_used:empty");
              } catch (e2) { diag.ccCodes.push("latest_used:err"); }
            }
          }
        }
      } catch (e2) {
        diag.ccCodes.push("cc_err:" + String((e2 && e2.message) || e2).slice(0, 60));
      }
      return nodes;
    };

    // ---- 1) 采集当前会话页面里的 id 信号（fiber + DOM） ----
    const ids = [], msgIds = [], taskIds = [];
    const idSeen = new Set(), msgSeen = new Set(), taskSeen = new Set();
    const addId = (s) => { const k = String(s == null ? "" : s); if (isNum(k) && !idSeen.has(k)) { idSeen.add(k); ids.push(k); } };
    const addMsg = (s) => { const k = String(s == null ? "" : s); if (k && !msgSeen.has(k)) { msgSeen.add(k); msgIds.push(k); } };
    const addTask = (s) => { const k = String(s == null ? "" : s); if (k && !taskSeen.has(k)) { taskSeen.add(k); taskIds.push(k); } };
    const nodeKey = /(^|_|\b)(node_id|nodeid|node_id_str|nodeidstr|asset_id|assetid|creation_id|creationid|material_id|materialid|video_id|videoid|media_id|mediaid|file_id|fileid|object_id|objectid|target_id|targetid)(_|$|\b)/i;
    const msgKey = /(^|_|\b)(message_id|messageid|message_id_str|messageidstr|msg_id|msgid|reply_id|replyid|section_id|sectionid|conversation_id|conversationid|chat_id|chatid)(_|$|\b)/i;
    const taskKey = /(^|_|\b)(creation_task_id|creationtaskid|creation_task_id_str|task_id|taskid|task_id_str)(_|$|\b)/i;
    const scanIds = (obj, d, seen) => {
      if (!obj || typeof obj !== "object" || d > 9 || seen.has(obj)) return;
      seen.add(obj);
      try {
        const hint = Object.keys(obj).join(",").toLowerCase();
        const maybeNode = /video|creation|material|asset|media|node|content|生成|作品/i.test(hint);
        for (const [k, v] of Object.entries(obj).slice(0, 220)) {
          if (typeof v === "string" || typeof v === "number") {
            const sv = String(v);
            if (nodeKey.test(k) && isNum(sv)) addId(sv);
            if (msgKey.test(k)) addMsg(sv);
            if (taskKey.test(k)) addTask(sv);
            if (k === "id" && isNum(sv) && maybeNode) addId(sv);
            if (k === "key" && /^v\d/i.test(sv) && isNum(String(obj.id || ""))) addId(obj.id);
          } else if (v && typeof v === "object") {
            scanIds(v, d + 1, seen);
          }
        }
      } catch (e2) {}
    };
    const fiberProps = (el) => {
      const props = [];
      let node = el;
      for (let up = 0; node && up < 8; up++) {
        try {
          const fk = Object.keys(node).find((k) => k.indexOf("__reactFiber") === 0 || k.indexOf("__reactProps") === 0);
          if (fk) {
            let f = node[fk];
            for (let d = 0; f && d < 70; d++) {
              const p = f.memoizedProps || f.pendingProps || {};
              if (f.memoizedProps && typeof f.memoizedProps === "object") props.push(f.memoizedProps);
              if (f.pendingProps && typeof f.pendingProps === "object") props.push(f.pendingProps);
              // 显式补采 contentBlock / message / creations（键名不含 node_id 前缀）
              const cb = p.contentBlock || p.block;
              if (cb && typeof cb === "object") {
                addId(cb.id); addId(cb.block_id);
                addMsg(cb.id); addMsg(cb.block_id);
                addTask(cb.creation_task_id); addTask(cb.task_id);
                try {
                  const crs = (cb.content_obj && cb.content_obj.creations) || cb.creations || [];
                  for (const cr of crs.slice(0, 4)) if (cr) {
                    addId(cr.id); addMsg(cr.id);
                    addTask(cr.creation_task_id); addTask(cr.task_id);
                  }
                } catch (e2) {}
              }
              const m = p.message || {};
              addMsg(m.message_id); addMsg(m.reply_id); addMsg(m.section_id);
              addTask(m.creation_task_id); addTask(m.task_id);
              f = f.return;
            }
          }
        } catch (e2) {}
        node = node.parentElement;
      }
      return props;
    };
    let roots = [];
    try {
      const lastV = dbm._lastVideoEl ? dbm._lastVideoEl() : (dbm.q("video").slice(-1)[0] || null);
      if (lastV) { let n = lastV; for (let i = 0; i < 8 && n; i++) { roots.push(n); n = n.parentElement; } }
    } catch (e2) {}
    if (!roots.length) {
      try {
        const cards0 = Array.from(document.querySelectorAll('[class*="video-hover-button-group-container"],[class*="block-video"]'));
        const card0 = cards0[cards0.length - 1];
        if (card0) { let n = card0; for (let i = 0; i < 8 && n; i++) { roots.push(n); n = n.parentElement; } }
      } catch (e2) {}
    }
    const objSeen = new WeakSet();
    for (const r of roots) for (const p of fiberProps(r)) scanIds(p, 0, objSeen);
    // 广扫：全部成片卡片 + 所有 message 容器（管理器按整段会话 message_id 解析）
    try {
      const els = Array.from(document.querySelectorAll(
        '[class*="video-hover-button-group-container"],[class*="block-video"],' +
        '[data-message-id],[class*="message"],[class*="Message"],[class*="chat-item"],[class*="chatItem"]'));
      for (const el of els.slice(0, 80)) for (const p of fiberProps(el)) scanIds(p, 0, objSeen);
    } catch (e2) {}
    const pageCoverKeys = visibleCoverKeys(30);

    // ---- 2) 官方创作中心主链路（每账号独立 Cookie，天然可并发） ----
    const diag = { ccCodes: [], ccTotal: 0, ccMatched: 0 };
    let ccIds = [];
    const ccNodes = await creationCenterNodes(diag);
    diag.ccTotal = ccNodes.length;
    if (ccNodes.length) {
      const msgSet = new Set(msgIds.map(String));
      const taskSet = new Set(taskIds.map(String));
      const coverSet = new Set(pageCoverKeys);
      const matched = ccNodes.filter((n) => {
        const byCover = n.coverKeys && n.coverKeys.some((k) => coverSet.has(k));
        const byMsg = n.messageId && msgSet.has(String(n.messageId));
        const byTask = n.creationTaskId && taskSet.has(String(n.creationTaskId));
        return byCover || byMsg || byTask;
      }).filter(isVideoNode);
      // 官方 M()：按页面可见封面顺序排序，让「当前成片」优先
      const rank = (n) => Math.min.apply(null,
        (n.coverKeys || []).map((k) => pageCoverKeys.indexOf(k)).filter((i) => i >= 0).concat([Number.POSITIVE_INFINITY]));
      const ordered = matched.slice().sort((a, b) => rank(a) - rank(b));
      ccIds = ordered.map((n) => n.id);
      diag.ccMatched = ccIds.length;
      // 兜底：匹配不到时取创作中心最新的 3 个视频节点（刚生成的必在最新之列）
      if (!ccIds.length) ccIds = ccNodes.filter(isVideoNode).slice(0, 3).map((n) => n.id);
      ccIds = uniq(ccIds, 12);
    }

    // ---- 3) message_node_info 兜底（官方 F() 里 V() 失败后才调 A()） ----
    //   body 必须是 number 型 message_ids（旧版传字符串数组，官方接口不认）。
    let msgResolved = [], mniRaw = null;
    const mniCodes = [];
    try {
      const mniIds = msgIds.filter(isNum).slice(0, 40);
      if (mniIds.length) {
        let mni = null;
        for (let t = 0; t < 3; t++) {
          try {
            const resp = await fetch(apiUrl("/samantha/aispace/message_node_info"), {
              method: "POST",
              headers: {
                accept: "application/json",
                "content-type": "application/json",
                "agw-js-conv": "str",
                origin: location.origin,
                referer: location.href
              },
              credentials: "include",
              body: JSON.stringify({ message_ids: mniIds.map((x) => Number(x)), message_ids_str: mniIds })
            });
            mni = await resp.json();
            mniCodes.push(mni && typeof mni.code !== "undefined" ? mni.code : "none");
            if (mni && (mni.code === 0 || mni.code === 200)) break;
          } catch (e2) { mni = null; mniCodes.push("err"); }
          if (t < 2) await sleep(600 * (t + 1));
        }
        mniRaw = mni;
        if (mni) {
          const rSeen = new Set();
          const nodeLikeKey = /(^|_|\b)(node_id|nodeid|asset_id|creation_id|material_id|video_id|videoid|media_id|object_id|target_id)(_|$|\b)/i;
          const idLikeKey = /(^|_|\b)(message_id|messageid|msg_id|section_id|reply_id|conversation_id|task_id|creation_task_id)(_|$|\b)/i;
          const scanNode = (o, d) => {
            if (!o || typeof o !== "object" || d > 12) return;
            for (const k in o) {
              const v = o[k];
              if ((typeof v === "string" || typeof v === "number") && isNum(String(v))) {
                const s = String(v);
                if (!rSeen.has(s) && (nodeLikeKey.test(k) || (typeof v === "number" && !idLikeKey.test(k)))) {
                  rSeen.add(s); msgResolved.push(s);
                }
              }
              if (v && typeof v === "object") scanNode(v, d + 1);
            }
          };
          scanNode(mni.data || mni, 0);
        }
      }
    } catch (e2) {}

    // ---- 4) 候选合并：创作中心(主) > message_node_info(兜底) > fiber(末) ----
    const allIds = uniq(ccIds.concat(msgResolved, ids), 20);
    const resultDiag = {
      ids: allIds.slice(0, 6), msgIds: msgIds.slice(0, 5), msgResolved: msgResolved.slice(0, 5),
      ccIds: ccIds.slice(0, 6), ccTotal: diag.ccTotal, ccMatched: diag.ccMatched,
      ccCodes: diag.ccCodes.slice(0, 8), mniCodes: mniCodes.slice(0, 5),
      mniRaw: mniRaw ? JSON.stringify(mniRaw).slice(0, 500) : ""
    };
    if (!allIds.length) {
      return Object.assign({ ok: false, error: "no_node_id" }, resultDiag);
    }
    let lastErr = "";
    const gdiCodes = [];
    const deadline = Date.now() + 55000;
    for (const nid of allIds) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const r = await downloadInfo(nid);
          gdiCodes.push("ok:" + r.code);
          return Object.assign({
            ok: true, nodeId: nid, url: r.mainUrl.slice(0, 2000), backup: r.backupUrl.slice(0, 2000),
            source: ccIds.indexOf(nid) >= 0 ? "creation_center" : (msgResolved.indexOf(nid) >= 0 ? "message_node_info" : "fiber"),
            gdiCodes: gdiCodes.slice(0, 8)
          }, resultDiag);
        } catch (e2) {
          lastErr = String((e2 && (e2.message || e2)) || "unknown");
          gdiCodes.push(lastErr.slice(0, 40));
        }
        if (attempt < 1) await sleep(400);
        if (Date.now() > deadline) break;
      }
      if (Date.now() > deadline) break;
    }
    return Object.assign({
      ok: false, error: lastErr || "no_video_node", gdiCodes: gdiCodes.slice(0, 8)
    }, resultDiag);
  };
  // ===================== 无水印按钮状态 / 带水印指纹（2026-10-25） =====================
  // 管理器注入按钮文案状态机：无水印下载 → 解析中… → 下载中… / 解析失败（2.6s 后复原）。
  // 「解析失败」= 豆包 get_download_info 暂未签发无水印（限流/未同步创作中心），
  // 此时盲点只会经 resolver u() 兜底再触发一次带水印下载，故插件按状态降频守候。
  dbm.noWatermarkBtnState = () => {
    try {
      const b = document.querySelector(".dbm-doubao-no-watermark-download");
      if (!b) return { found: false };
      const r = b.getBoundingClientRect();
      return { found: true, text: String(b.textContent || "").trim().slice(0, 40),
               disabled: !!b.disabled,
               x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2) };
    } catch (e) { return { found: false, error: String(e) }; }
  };
  // 带水印指纹：最后成片卡片 fiber → creations[].video.download_filehash /
  // video_model.video_list[].file_hash（= 带水印文件 MD5，已与落盘文件实测一致），
  // 以及 download_url（resolver u() 兜底会把它误当"确认无水印"发出下载）。
  // 落盘文件 MD5 命中 hashes 即"带水印预览同体"，绝不能当无水印成品交付。
  dbm.watermarkFingerprints = () => {
    const out = { hashes: [], urls: [] };
    const hSeen = new Set(), uSeen = new Set();
    const addH = (v) => {
      const s = String(v == null ? "" : v).toLowerCase();
      if (/^[0-9a-f]{32}$/.test(s) && !hSeen.has(s)) { hSeen.add(s); out.hashes.push(s); }
    };
    const addU = (v) => {
      const s = String(v == null ? "" : v);
      if (/^https?:\/\//i.test(s) && !uSeen.has(s)) { uSeen.add(s); out.urls.push(s.slice(0, 2000)); }
    };
    const scan = (o, d, seen) => {
      if (!o || typeof o !== "object" || d > 9 || seen.has(o)) return;
      seen.add(o);
      let es;
      try { es = Object.entries(o).slice(0, 240); } catch (e) { return; }
      for (let i = 0; i < es.length; i++) {
        const k = es[i][0], v = es[i][1];
        if (typeof v === "string" || typeof v === "number") {
          if (/download_?filehash/i.test(k)) addH(v);
          else if (/file_?hash/i.test(k)) addH(v);
          else if (/download_?url/i.test(k)) addU(v);
          else if (/^video_model$/i.test(k) && typeof v === "string" && v.length < 400000) {
            try {
              const vm = JSON.parse(v);
              const vl = (vm && vm.video_list) || [];
              for (const it of vl.slice(0, 10)) {
                if (!it) continue;
                addH(it.file_hash); addH(it.fileHash); addH(it.filehash);
                addU(it.main_url); addU(it.mainUrl); addU(it.backup_url); addU(it.backupUrl);
              }
            } catch (e) {}
          }
        } else if (v && typeof v === "object") scan(v, d + 1, seen);
      }
    };
    try {
      const cards = Array.from(document.querySelectorAll(
        '[class*="video-hover-button-group-container"],[class*="block-video"]'));
      const card = cards[cards.length - 1];
      if (!card) return out;
      const fk = Object.keys(card).find((k) => k.indexOf("__reactFiber") === 0);
      let f = fk ? card[fk] : null;
      for (let d = 0; f && d < 45; d++) {
        const p = f.memoizedProps || {};
        if (p.contentBlock && typeof p.contentBlock === "object") {
          scan(p.contentBlock, 0, new Set());
          try { scan(p.message, 0, new Set()); } catch (e) {}
          break;
        }
        f = f.return;
      }
    } catch (e) {}
    return out;
  };

  // -------------------- 「创建画布」面板检测与关闭 --------------------
  dbm.findCanvasPanel = () => {
    try {
      const hasTitle = (e) => {
        const t = (e.textContent || "").trim();
        return t.length > 0 && t.length < 60 && /创建画布|创意画布|新建画布/.test(t);
      };
      // 1) 已知模态容器
      const containers = document.querySelectorAll(
        '[role="dialog"],[class*="modal"],[class*="dialog"],[class*="panel"],'
        + '[class*="drawer"],[class*="overlay"],[class*="mask"],[class*="backdrop"],'
        + '[class*="popup"],[class*="popover"]');
      for (let i = 0; i < containers.length; i++) {
        if (hasTitle(containers[i])) return containers[i];
      }
      // 2) header/标题元素：命中标题则向上爬到对话框容器
      const headers = document.querySelectorAll(
        'header,h1,h2,h3,h4,h5,h6,[class*="header"],[class*="title"],[class*="modal-title"]');
      for (let i = 0; i < headers.length; i++) {
        if (hasTitle(headers[i])) {
          let panel = headers[i];
          while (panel && panel !== document.body) {
            const cls = String(panel.className || "");
            const role = panel.getAttribute && panel.getAttribute("role");
            if (role === "dialog"
                || /modal|dialog|panel|drawer|overlay|mask|backdrop|popup|popover/i.test(cls)) break;
            panel = panel.parentElement;
          }
          if (!panel || panel === document.body) panel = headers[i];
          return panel;
        }
      }
      // 3) 兜底：短文本小元素（用 textContent，避免重排）
      const all = document.querySelectorAll('button,[role="button"],a,div,span');
      for (let i = 0; i < all.length; i++) {
        const el = all[i];
        if (el.children.length > 25) continue;
        const t = (el.textContent || "").trim();
        if (t.length > 0 && t.length < 40 && /创建画布|创意画布|新建画布/.test(t)) return el;
      }
    } catch (e) {}
    return null;
  };
  dbm.findCanvasCloseBtn = (panel) => {
    try {
      const scope = panel || document;
      const nodes = scope.querySelectorAll(
        'button,[role="button"],a,span,div,i,svg,[class*="close"],[class*="dismiss"]');
      for (let i = 0; i < nodes.length; i++) {
        const b = nodes[i];
        const txt = (b.innerText || b.textContent || "").trim();
        const label = ((b.getAttribute && (b.getAttribute("aria-label") || b.getAttribute("title"))) || "").trim().toLowerCase();
        const cls = String(b.className || "").toLowerCase();
        if (/close|dismiss|cancel|关闭|取消/.test(label) || /close|dismiss/.test(cls)) return b;
        if (txt === "×" || txt.toLowerCase() === "x" || txt === "✕"
            || txt === "✖" || txt === "关闭") return b;
      }
    } catch (e) {}
    return null;
  };
  dbm.closeCanvasPanel = () => {
    try {
      const panel = dbm.findCanvasPanel();
      if (!panel) return { closed: false, reason: "no_panel" };
      // 1) 点关闭按钮
      const btn = dbm.findCanvasCloseBtn(panel);
      if (btn) { try { btn.click(); return { closed: true, via: "button" }; } catch (e) {} }
      // 2) Esc 键
      try {
        const ev = new KeyboardEvent("keydown",
          { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true });
        document.dispatchEvent(ev);
        const t = document.querySelector("textarea,input,[contenteditable]");
        if (t) t.dispatchEvent(ev);
        return { closed: true, via: "escape" };
      } catch (e) {}
      // 3) 兜底：隐藏 + 移除节点
      try { panel.style.display = "none"; if (panel.remove) panel.remove();
            return { closed: true, via: "remove" }; } catch (e) {}
      return { closed: false, reason: "no_action" };
    } catch (e) { return { closed: false, error: String(e) }; }
  };
  dbm.__installCanvasGuard = () => {
    if (window.__dbmCanvasGuard) return true;
    window.__dbmCanvasGuard = true;
    let _last = 0;
    const guarded = () => {
      const now = Date.now();
      if (now - _last < 500) return;   // 节流，避免大 DOM 下 MutationObserver 风暴
      _last = now;
      try { dbm.closeCanvasPanel(); } catch (e) {}
    };
    setInterval(guarded, 800);
    try {
      const mo = new MutationObserver(guarded);
      mo.observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) {}
    return true;
  };

  // ★ 2026-11-02：常驻「创建画布」面板看门狗，弹窗即关（DOM 级兜底）
  try { dbm.__installCanvasGuard(); } catch (e) {}
  window.__dbm = dbm;
  return { ok: true };
})()

# -*- coding: utf-8 -*-
"""
豆包管理器桥接服务 (Doubao Manager Bridge)
==========================================

职责：
1. 自动启动 / 复用“豆包管理器.exe”（Electron），启动时附加 CDP 调试端口；
2. 通过 Chrome DevTools Protocol (CDP) 操控管理器内的豆包账号 webview：
   自动填视频提示词、上传首帧、点发送、等待豆包确认、嗅探成品视频地址；
   （按需求已移除“选模型 / 选比例 / 选时长 / 点生成视频按钮”的点击，
    模型/比例/时长一律沿用豆包页面当前默认值，由用户手动确认）
3. 对外暴露本地 HTTP API（127.0.0.1），供字字动画视频插件调用；
4. 下载成品视频到管理器素材库目录，按任务 ID 落盘，任务状态全程可轮询。

桥接主体使用 Python 标准库，参考图优化使用宿主已有 Pillow（缺失时保留原图），
无需额外 pip 安装。既可独立运行（python server.py），也可被插件
以 importlib 方式在宿主进程内以守护线程启动（start_bridge）。

注意：豆包网页的 DOM 选择器集中在 selectors.json，网页改版后只需标定该文件，
不用改代码。/api/debug/pageinfo 用于辅助标定。
"""

import base64
import hashlib
import json
import os
import queue
import re
import shutil
import socket
import ssl
import struct
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.request
import urllib.error
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

BRIDGE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BRIDGE_DIR / "config.json"
TASKS_PATH = BRIDGE_DIR / "tasks.json"
SELECTORS_PATH = BRIDGE_DIR / "selectors.json"
CONSOLE_PATH = BRIDGE_DIR / "web_console.html"
QUOTA_MARKS_PATH = BRIDGE_DIR / "quota_marks.json"
SEEDANCE_QUOTA_PATH = BRIDGE_DIR / "seedance_quota.json"  # 各账号受限额模型每日生成计数
TODAY_LEDGER_PATH = BRIDGE_DIR / "seedance_today_ledger.json"  # 今日已生成流水（账号无关，重启不清零）
DISPATCH_STATE_PATH = BRIDGE_DIR / "dispatch_state.json"  # 轮询游标（跨批次均衡分派）
# 控制台「强制冷却」名单：点了之后桥接不再给该账号派发新任务，直到再次点「解除冷却」。
# 独立于 quota_marks.json（被动封禁，次日 0:01 自动恢复），不会被「重置额度标记」清掉。
COOLDOWN_PATH = BRIDGE_DIR / "cooldown_accounts.json"
# 账号身份表：管理器注入的 UUID <-> 手机号/备注 <-> 历史 CDP target_id。
# 每日额度按 UUID 记账，重启、换账号、换顺序都不会串台。
ACCOUNT_IDENTITY_PATH = BRIDGE_DIR / "account_identities.json"

# 每日生成额度：模型各自独立计数，控制台下拉可选 1~10 次/账号/天。
DAILY_LIMIT_MODELS = ("Seedance 2.0 Fast", "Seedance 2.0 Mini")
DAILY_LIMIT_MIN = 1
DAILY_LIMIT_MAX = 10
# 旧版本 Fast / Mini 共用的计数桶名；升级后自动按任务模型拆到各自的桶。
LEGACY_SHARED_BUCKET = "__seedance_2_0_shared__"
# 宿主（字字动画）存活会话标记。跨进程/跨重启持久化：宿主一关闭，桥接据此
# 把残留任务全部取消，避免下次启动时 _recover() 把它们重新排队重复派发。
HOST_SESSION_PATH = BRIDGE_DIR / "host_session.json"

# 跨进程协调：图片桥/视频桥互斥驱动同一个豆包管理器，避免同时抢 .active 标签页
# （见 _crosslock.py）。任何异常都降级为空操作，保证桥接照常启动。
# 桥接由宿主进程经 importlib 加载，bridge/ 目录不一定在 sys.path 上，
# 这里显式把本目录加进去，确保 _crosslock 可被导入。
if str(BRIDGE_DIR) not in sys.path:
    sys.path.insert(0, str(BRIDGE_DIR))
try:
    from _crosslock import foreground_mutex, launch_mutex
except Exception:
    class _NoopMutex:
        def __enter__(self):
            return self
        def __exit__(self, *a):
            return False
        def acquire(self):
            return True
        def release(self):
            return None
    def foreground_mutex(tag):
        return _NoopMutex()
    def launch_mutex(tag):
        return _NoopMutex()

# 仅限制附件传输，视频服务端生成仍按原账号并发。
_UPLOAD_SLOTS = threading.BoundedSemaphore(2)

# 豆包（Seedance 2.0）单次任务的参考项硬上限：9 张图 + 3 个音频。
# 插件 main.py、本文件的 /api/tasks、任务控制台三处都按这个上限收敛，
# 任何一路传入超额附件都截断，避免豆包页面提示"附件过多"导致整批上传失败。
HARD_MAX_REFERENCE_IMAGES = 9
HARD_MAX_REFERENCE_AUDIOS = 3
# 附件类型：与豆包对话框 input[type=file] 的 accept 对齐。
# 只有图片能进 Pillow 压缩流程；音频原样上传，压缩会直接损坏文件。
IMAGE_ATTACHMENT_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}
# 与豆包对话框 input[type=file] 的真实 accept 严格对齐（CDP 实测）：
# .mp3,.wav,.m4a,.wma,.aac,.ogg,.amr,.flac,.aiff,.ac3
# 放行页面不接受的格式会让附件卡不渲染，桥接一直判「附件不匹配」直到超时。
AUDIO_ATTACHMENT_EXTS = {
    ".mp3", ".wav", ".m4a", ".wma", ".aac", ".ogg", ".amr",
    ".flac", ".aiff", ".ac3",
}


def prepare_upload_images(file_paths, output_dir, config):
    """生成小体积上传副本，保留顺序和原文件；Pillow 使用宿主已有依赖。

    ★ 2026-11-13：附件里现在可能混有参考音频，音频不是图片，绝不能交给
    Pillow 打开（会抛 UnidentifiedImageError 让整批附件准备失败），原样上传即可。
    """
    files = [os.path.abspath(p).replace("\\", "/") for p in file_paths]
    before = sum(Path(p).stat().st_size for p in files)
    if not config.get("upload_optimize_images", True):
        return files, before, before
    try:
        from PIL import Image, ImageOps
    except ImportError:
        return files, before, before
    edge = max(1024, int(config.get("upload_max_edge", 2048)))
    result = []
    for i, name in enumerate(files):
        source = Path(name)
        # 音频 / 其它非图片附件不压缩，保持字节完整
        if source.suffix.lower() not in IMAGE_ATTACHMENT_EXTS:
            result.append(name)
            continue
        if source.stat().st_size <= 1024 * 1024:
            result.append(name)
            continue
        # 每个源文件独立目录，防同名图覆盖，图片编号和顺序保持不变。
        folder = Path(output_dir) / str(i)
        folder.mkdir(parents=True, exist_ok=True)
        dest = folder / (source.stem + ".jpg")
        with Image.open(source) as original:
            if getattr(original, "is_animated", False):
                result.append(name)
                continue
            im = ImageOps.exif_transpose(original)
            im.thumbnail((edge, edge), Image.Resampling.LANCZOS)
            if im.mode in ("RGBA", "LA") or "transparency" in im.info:
                rgba = im.convert("RGBA")
                im = Image.new("RGB", rgba.size, "white")
                im.paste(rgba, mask=rgba.getchannel("A"))
            else:
                im = im.convert("RGB")
            im.save(dest, "JPEG", quality=90, optimize=True)
        result.append(str(dest.resolve()).replace("\\", "/")
                      if dest.stat().st_size < source.stat().st_size else name)
    return result, before, sum(Path(p).stat().st_size for p in result)

DEFAULT_CONFIG = {
    "bridge_host": "127.0.0.1",
    "bridge_port": 39230,
    "cdp_port": 39233,                 # 期望的管理器 CDP 端口（被占用时管理器会顺延，服务会自动读取实际端口）
    "manager_exe": "",  # 客户版：由插件设置页 /api/config 推送
    "download_dir": "",               # 留空则自动读取管理器 settings.json 的 downloadDir
    "auto_start_manager": True,
    "default_duration": "10",         # 秒；常用 4 / 10 / 15 / 30，实际档位以豆包页面为准（页面没有的会自动就近落档）
    "default_aspect": "自动",          # 自动 / 3:4 / 4:3 / 9:16 / 16:9 / 1:1 / 21:9
    "model_name": "Seedance 2.0 Fast",  # 默认模型（弹层可选：2.0 Fast / 2.0 Mini / 2.0 / 2.5，后两者需会员）
    # 备选模型：主模型（如 30 秒所需的 Seedance 2.5）在本账号不可用时，自动改用此模型继续提交
    # （例如 2.5 需会员、账号未开通时，退回 2.0 Fast 试跑，由注入脚本把时长改成 30s）。留空 "" 关闭兜底。
    "model_fallback": "Seedance 2.0 Fast",
    # 每日生成额度（主动计数封顶，区别于被动 quota_marks 报错封禁）：
    # 旧字段 daily_seedance_limit 保留作兼容回退，实际以 daily_model_limits 为准。
    # 2026-11-13 起 Fast / Mini 各自独立计数，由「任务控制台」两个 1~10 下拉框设置，
    # 保存在本 config.json（控制台是唯一真相源；插件 main.py 的 _PUSH_CONFIG_KEYS
    # 刻意不含这两个键，避免宿主每次生成时把控制台保存的值推回旧值）。
    "daily_seedance_limit": 3,
    "daily_model_limits": {"Seedance 2.0 Fast": 3, "Seedance 2.0 Mini": 3},
    "daily_limited_models": ["Seedance 2.0 Fast", "Seedance 2.0 Mini"],
    # ※ 模型与时长的对应（2026-10-09）：Seedance 2.0 Mini / 2.0 Fast 支持 4 / 10 / 15 秒；
    #   30 秒只有 Seedance 2.5 支持。若选了 30 秒但当前模型不给该档，
    #   注入脚本 dbm._durTiers() 会发现页面没有此档位并自动就近落到可用档。
    "quota_recheck_sec": 1800,        # 账号被判额度不足后，多久后允许重试（秒，默认30分钟）
    # 单个任务总超时。豆包生成耗时参考：10~15 秒约 5~8 分钟，30 秒约 15~20 分钟。
    # 实际取值会被 min_timeout_for() 按时长自动放宽（生成耗时 + 600s 固定开销），
    # 配置值若低于该下限则以时长下限为准。
    "task_timeout_sec": 1800,
    "poll_interval_sec": 3,
    "max_concurrency": 0,             # 最大并发账号数；0 = 自动（=已打开的账号页数）
    # 管理器窗口被最小化/完全遮挡时，Chromium 会把**所有** webview（含 active 那个）
    # 判为 document.visibilityState='hidden'，豆包前端随即不渲染"视频生成"入口、
    # 也不推进生成状态轮询 —— 表现为"必须手动点一下账号才开始走流程"，且一直等不到
    # 成片。实测（2026-09-19）：最小化 → 9 个 webview 全 hidden；还原置前 → 全 visible。
    # 开启后：检测到页面 hidden 时自动还原并置前管理器窗口（带全局节流，不抢焦点刷屏）。
    "auto_raise_manager_window": True,
    # 在页面里覆盖 document.visibilityState / hidden，让豆包前端"以为"页面一直可见。
    # ⚠️ 实测在豆包管理器的 Electron webview guest 里**做不到**：document 自带一个
    # configurable:false 的 visibilityState / hidden 访问器，defineProperty 必抛
    # "Cannot redefine property"（2026-09-19 验证）。代码会检测并只提示一次，不刷屏。
    # 保留开关仅为兼容其他环境；真正兜底的是 auto_raise_manager_window（还原窗口）。
    "force_page_visible": True,
    # 并行分发时，第 N 个账号延迟 N×本值 秒再开始填报（0=关闭）。
    # 并发时若所有账号同一瞬间建对话/跳转/加载，页面渲染与 CDP 会互相挤，
    # 实测容易整批卡在"找不到视频生成入口"。错开几秒起步即可化解。
    # ★ 2026-11-13 用户要求「不需要分批次派发，点击生成视频立即响应」：
    #   默认改为 0，且增加 dispatch_stagger_enabled 总开关。老配置里残留的
    #   dispatch_stagger_sec=2 不会被自动启用，必须显式打开下面的开关才生效。
    "dispatch_stagger_sec": 0,
    # 是否需要错峰起步。False（默认）= 所有空闲账号同一时刻立即开工，无批次延迟。
    # 只有在实测出现 CDP 拥堵（一批账号同时报「CDP 未连接」）时才建议打开。
    "dispatch_stagger_enabled": False,
    # 错峰起步的总上限（秒）：一批里第 N 个账号延迟 N×dispatch_stagger_sec，但不超过本值。
    # 9 个分镜同时超时重排队时，20s 太挤会把 CDP 挤爆（实测 5/9 报 CDP 未连接）。
    "dispatch_stagger_max_sec": 45,
    # 账号页面"半加载卡死"自愈：部分 webview 加载时少拉到 1 个 JS chunk，主内容区
    # （composer、"视频生成"入口）不渲染，只剩侧边栏 3~4 个按钮。这种页面会一路报
    # video_mode_not_active 空耗到超时 —— 多账号并行时表现成"只有 1 个账号在走流程"。
    # 开启后会在填报前检测，并重新导航修复（只能用 Page.navigate，Page.reload 会把
    # Electron 的 webview 全部打没）；修不好则本账号 10 分钟内不派单，任务换账号重排。
    "auto_repair_degraded_page": True,
    # 提交前先把页面整页导航到一个"会话页"（/chat/<会话ID>），别停在首页 /chat/。
    #
    # ⚠️⚠️ 默认已改为 False（2026-09-19 晚，并发实测推翻）：
    #   开启时 6 个账号并发，8 个 webview 里 6 个是"导航进会话页后变成半加载"
    #   （按钮 8/21/27/28/28/28、入口=False、输入框=0），而**停在首页的那个是健康的**
    #   （按钮 26、入口=True）。会话页远比首页重，多账号同时整页加载会话页时几乎
    #   必然少拉 JS chunk。更糟的是本开关会让"修页面→再进会话页→又坏"形成死循环，
    #   且每次导航都抢全局 _NAV_LOCK → 一个账号的重试把其余账号全部堵死
    #   （表现：并发时 6 个任务集体卡在 preparing_page）。
    #   原结论（2026-09-19 上午）是在**管理器窗口被最小化**的状态下测出来的，
    #   那时所有页面都是 hidden，样本本身不成立。
    # 若确实遇到"首页点入口就退化"再手动打开本开关，并配合较少的并发数。
    "prefer_conversation_page": False,
    # "进入视频模式"这段的总预算（秒）。重试每轮都要修页面 + 重新进会话页，
    # 两步都抢全局导航锁；没有硬预算时一个账号的低成功率会把整批并发任务拖死
    # （2026-09-19 晚：6 个任务集体卡在 preparing_page 十几分钟）。
    # 到点就放弃、让任务快速失败并重新排队，比无限空转划算。
    "vmode_budget_sec": 180,
    # ★★★ 让管理器里**全部** webview 都参与渲染（2026-09-19 晚定位到的并发头号根因）
    #
    # 管理器 CSS 是 `.browser-stack webview{visibility:hidden}` +
    # `.browser-stack webview.active{visibility:visible}`，非活动 webview 被
    # Chromium 判定为不合成：**requestAnimationFrame 永不触发**（实测同一时刻
    # active 那个 76fps，其余 6 个全部 0fps）。
    #
    # 关键陷阱：guest 内部 `document.visibilityState` 仍然是 "visible"、布局也正常，
    # 所以过去所有"页面是否可见"的检测都**测不出问题**；但 React 挂载类 UI（豆包的
    # "视频模式"）依赖渲染帧，在 0fps 的页面上永远挂不上来 —— 表现为点「视频生成」
    # 后主内容区被卸载、30 秒都恢复不了，最终 no_video_entry。
    #   * 实测（串行，与并发无关）：7 个健康首页同时/依次点入口，只有 1 个成功；
    #   * 实测（强制全渲染后）：7/7 全部成功进入视频模式。
    # 这就是"7 个任务只有 2 个在跑"的真正原因 —— 不是并发限制，是只有一个 webview
    # 在渲染，其余账号的页面根本没法完成模式切换。
    #
    # 修复：在管理器宿主页面给每个 <webview> 加行内 `visibility:visible !important`
    # （行内 !important 才能盖过宿主更高优先级的选择器），非 active 的压到
    # opacity 0.02 并置于底层，用户看到的仍是当前 active 账号，视觉无变化。
    # 页面内用 setInterval 每秒兜底重施（React 重渲染会把 class 改回去）。
    "force_render_all_webviews": True,
    # 多账号并行提交（L2）：实测豆包管理器的非活动 webview 与活动 webview 能力完全一致
    # （visibility:hidden 只加在宿主 DOM 的 <webview> 元素上，CSS 继承不跨文档边界，
    #   guest 内部 computed visibility 恒为 visible、布局正常、可聚焦、合成事件照常派发、
    #   DOM.setFileInputFiles 照常改写 input.files 并触发 input/change）。
    # 所以"必须切到前台才能填表提交"是历史假设，不成立。
    # 开启后：提交阶段不再抢全局 input_lock、不再切管理器 tab，各账号用自己的
    # CDP 连接并发填报提交。关闭 = 完全回到原来的串行行为（唯一回退开关）。
    "parallel_submit": True,
    "max_reference_images": 9,        # 每个任务最多上传到豆包的参考图数量（首帧优先）；硬上限 9
    "max_reference_audios": 3,        # 每个任务最多上传到豆包的参考音频数量；硬上限 3
    "safety_confirm_wait_sec": 100,   # 发送后等待豆包生成确认消息的秒数（超时则发"确认生成视频"）
    "auto_confirm_generation": True,  # 未检测到生成确认消息时是否自动发送确认文本
    "confirm_generation_text": "确认，使用Seedance 2.0 Fast来生成15秒视频",  # 自动确认时发送的文本（仅需求1，固定 Seedance 2.0 Fast 生成 15 秒）
    # ★ 2026-09-29 新增：对话场景的可编辑自定义回复（逻辑见 _negotiate_generation）。
    #   需求2（豆包"我无法生成你要求的内容"→改提示词重生成）已取消，不再自动改写提示词。
    #   首次回复后等待多久再查"二次确认"（需求1/需求3 的 20 秒重查）。
    "second_confirm_wait_sec": 20,
    #   同一任务最多自动回复次数（含二次确认重发），防止无限循环。
    "max_confirm_replies": 3,
    # ★ 2026-11-14 新增（对话场景自动应对）：提交的参考项含参考音频时，
    #   豆包常会在首次确认后再弹一屏「参数确认」，必须完成二次确认才会开始生成。
    #   把「含音频 → 强制二次确认」做成可配置规则，并固定二次确认的提示词，
    #   避免被 _normalize_model_in_text 按当前模型改写（用户要求固定这句话）。
    "audio_second_confirm_enabled": True,
    "audio_second_confirm_text": "确认，使用seedance 2.0 fast来生成15秒视频",
    #   需求3：豆包回"由于模型可能带来准确性问题…我无法为你生成相应内容"时，
    #   直接判失败并在任务结果里说明的原因文本（不再尝试二次确认/重发）。
    "reject_accuracy_reason": "由于模型可能带来准确性问题，豆包判定无法生成该内容，已直接返回失败（如需继续，请调整提示词或更换参考图后手动重新生成）",
    # 发确认文本时是否重新带上参考项：★ 2026-11-14 三轮起默认关闭。
    # 用户明确要求「两轮确认只发文案」，确认句一律不夹带参考图 / 参考音频；
    # 保留开关只为兼容老配置回滚，协商阶段已不再依赖它。
    "confirm_with_images": False,
    # ★ 2026-09-22：发确认文本前的"等豆包说完整句话"上限（秒）与重试轮数。
    #   豆包那条「视频生成参数确认」带一整张分镜表、是流式输出的，输出没结束时
    #   右下角是"停止"按钮、发送点不动 —— 旧代码就在这时候发，8/9 个任务因此
    #   没能把确认发出去，豆包一直等确认，任务空转到 1774s 超时。
    "confirm_idle_wait_sec": 120,
    "confirm_send_retries": 4,
    # ★ 2026-09-24：发完确认后继续盯豆包回应的秒数。豆包的拒绝（"生成的视频可能
    #   涉及版权限制，请更换输入内容后重试"）是**收到我们确认之后**才回的，
    #   旧代码发完就切走 → 这条拒绝要躺到 600 多秒后回收阶段才被发现。
    #   0 = 发完就走（回到旧行为）。正常受理时会立刻 break，不会白等。
    "confirm_reply_wait_sec": 60,
    # 轻量检测阶段是否每轮都查一次"豆包明确拒绝"。关闭就退回 2026-09-24 之前的
    # 行为：只有进了完整回收流程才判死（实测要等 600s+）。
    "fast_detect_fail_check": True,
    # ★ 2026-09-24：豆包回「生成的视频可能涉及版权限制，请更换输入内容后重试」
    #   这类**版权**拒绝时，先自动回一句申诉（copyright_appeal_text）再给它一次
    #   机会，而不是直接判死。申诉后豆包若再次拒绝 → 才按 moderation_no_requeue
    #   直接返回失败（不重排队）。
    "copyright_appeal_enabled": True,
    "modify_prompt_text": "改写提示词，保持原文和核心不变",  # 版权拒绝申诉时先于 copyright_appeal_text 发送：要求豆包改写提示词（保持原文与核心不变）
    "copyright_appeal_text": "根据参考图，继续使用Seedance 2.0 Fast来生成15秒视频",
    "copyright_appeal_max": 1,        # 每个任务最多申诉几次（1 = 只给一次机会）
    "copyright_appeal_all_moderation": False,   # True = 所有审核拒绝都申诉（含涉政/违禁等，多半无效）
    "copyright_appeal_idle_wait_sec": 60,       # 发申诉前等豆包说完的秒数
    "copyright_appeal_retries": 3,              # 申诉发送失败的重试轮数
    "copyright_appeal_grace_sec": 120,          # 申诉后给豆包的宽限秒数：这段时间内不再判死，等它消化
    "return_delay_sec": 360,          # 分镜提交后到回收（下载回传）的间隔秒数：豆包生成约5分钟，留1分钟余量
    "min_wait_sec": 60,               # 提交后最短等待时间（秒），之后开始实时监控轮询回收
    "max_gen_retries": 2,             # 豆包明确生成失败/超时无视频时，自动换账号重试的最大次数（受批次屏障约束，下一批才重发）
    # 内容审核拒绝（kind=moderation）时是否**跳过重排队、直接判失败**。
    # True（2026-09-24 用户要求）：审核拒绝由提示词/参考图本身决定，换账号重试
    # 必然得到同一句拒绝，只会白占额度、把整批拖长。改成 False 可恢复换账号重试。
    "moderation_no_requeue": True,
    # 模型"准确性问题"拒绝（kind=accuracy_reject，即需求3）时是否**跳过重排队、直接判失败**。
    # 该拒绝属内容/准确性判定，与账号无关，重试必然同样失败，故默认直接失败。
    "accuracy_no_requeue": True,
    "orphan_timeout_sec": 300,        # 宿主（字字动画）超过这么久没轮询某任务 → 判定已放弃，自动取消（0=关闭）
    "fast_detect_max_wait_sec": 240,  # 轻量检测等不到视频超过这么久 → 转交完整回收流程兜底（秒）。
                                       # 2026-09-29 由 420 下调：豆包成片通常 3~5 分钟内生成，超过 4 分钟还
                                       # "检不出"基本就是冻结 webview / 网络嗅探漏抓；与其原地空转，不如
                                       # 早点交给 collect_stage（能解冻/重载/扫盘/直抓 src），少白等 3~6 分钟。
    "fast_detect_thaw_after_sec": 150,  # 轻量检测等待超过这么久仍确认不到成片 → 提前转交 collect_stage。
                                        # 比 fast_detect_max_wait_sec 更早触发，针对"管理器看得见、DOM 却检不出"的卡死。
    # 页面始终检测不到 <video> 时，是否去下载目录"捡现成的"成品（同名覆盖的
    # video.mp4、用户手动下载的文件都能被认领）。0 或 false = 关闭。
    # ⚠️ 2026-09-20 用户要求改为 **False**（原为 True）：
    #   这条兜底会在"页面始终检不出 <video>"时，直接把下载目录里最新落盘的
    #   video.mp4 认领成本任务成品并置为 done。但 video.mp4 是豆包的**共享落点**
    #   （每次下载都覆盖同一个文件名），归属只能靠时间窗猜 —— 实测会认领到别的
    #   账号的片子，日志里甚至自己就打印"无归属前缀，请人工核对"。
    #   与其交一个归属不明（且可能是带水印版本）的成品，不如如实失败让用户重跑。
    #   确实需要时可在设置里改回 true，但请先看懂 _claim_dir_video 的风险说明。
    "dir_fallback_enabled": False,
    "dir_fallback_after_sec": 150,    # 至少等这么久才启动该兜底（避开刚提交时的历史文件）
    "reload_after_sec": 900,          # 无视频时多久才允许刷新页面（刷新会打断生成，别太早；0=禁止刷新）
    # ★ 2026-09-22：豆包「视频生成参数确认」态的判死门槛（秒，0=关闭该判定）。
    #   豆包现在经常先回一屏参数＋分镜表并说"确认后我再开始生成视频"，等用户在
    #   输入框回复确认。我们的确认文本发出后若豆包不接茬，页面就一直停在那一屏，
    #   任务会空转到 1800s 超时才失败（实测 4 个任务各浪费约半小时）。
    #   超过本值后若仍在"等确认"状态且连续 2 次采样确认，直接判死换账号。
    "pending_confirm_fail_sec": 300,
    # 回收阶段（collect_stage）至少要拿到这么长的独立等待时间。
    # 回收是在提交后 fast_detect_max_wait_sec（默认 240s）才启动的，若只沿用
    # "提交时刻 + task_timeout_sec" 的总截止，task_timeout_sec=1000 时回收只剩
    # 约 400s，成片还没出来就被判超时。0 = 不额外延长。
    "min_collect_sec": 900,
    # ★ 2026-11-03：单个账号独占「无水印下载解析窗口」的时间片（秒）。
    #   管理器单进程的解析/落盘链路一次只能可靠服务一个账号，必须全局串行；
    #   但串行不能变成排队死等，所以每个账号最多占这么久，到期主动让位。
    #   5 个账号并发时总耗时约为 N × 实际解析耗时（通常 30~90s），远小于此值。
    "nowm_window_slice_sec": 180,
    # ★ 2026-11-03：宿主（字字动画）存活守卫。
    #   宿主进程内插件每 5 秒发一次心跳；超过下面这个秒数没有任何宿主请求，
    #   或宿主进程已不存在，就判定"字字动画已关闭"→ 立即取消所有未完成任务、
    #   立起派发闸门（插件与控制台都无法再提交/派发），并在下次桥接启动时
    #   不再把这些任务重新排队。设为 false 可整体关闭该功能（回退用）。
    "host_guard_enabled": True,
    # 进程身份检测不可用时的心跳超时（秒）；宿主进程明确退出则不受此限，立即判定。
    "host_offline_timeout_sec": 20,
    # 宿主进程仍存活、但长时间没有任何请求的宽限期（秒）。
    # 必须显著大于 20s：Windows 休眠/锁屏会暂停所有线程，唤醒后若按 20s 判离线
    # 会把正在生成的整批任务全部误取消。进程还在就说明软件端还在，不轻易判死。
    "host_idle_timeout_sec": 120,
    # ★ 2026-11-03：自动回传。任务提交时由插件携带 scene.dest（分镜目标视频的
    #   绝对路径），成品一落盘就【自动】复制过去，不再依赖插件侧 generate() 是否
    #   还活着等待返回（宿主超时 / 被取消 / 软件关闭时最容易丢片）。设为 false 可回退。
    "scene_auto_deliver": True,
}


def _canonical_limited_model(name, models=None):
    """把 "seedance 2.0 fast" / 多余空格之类写法归一到配置里的标准模型名。"""
    s = re.sub(r"\s+", " ", str(name or "").strip()).lower()
    for m in (models if models is not None else DAILY_LIMIT_MODELS):
        if s == re.sub(r"\s+", " ", str(m).strip()).lower():
            return str(m)
    return ""


def _coerce_daily_limits(value):
    """控制台两个下拉框 → {模型: 1~10 次}。

    只接受受限额模型，未知键一律忽略；字符串数字、越界值、非法值都收敛到
    1~10 的合法范围，防止手工调 API 把额度写成 0 或 999 导致永不派单/超额派单。
    """
    out = dict(DEFAULT_CONFIG["daily_model_limits"])
    if not isinstance(value, dict):
        return out
    fallback = DEFAULT_CONFIG["daily_seedance_limit"]
    for k, v in value.items():
        canon = _canonical_limited_model(k)
        if not canon:
            continue
        try:
            n = int(float(str(v).strip()))
        except (TypeError, ValueError):
            n = fallback
        out[canon] = max(DAILY_LIMIT_MIN, min(DAILY_LIMIT_MAX, n))
    return out


def daily_limits_snapshot(config):
    """给 /api/health、/api/runtime、插件侧看的当前限额（始终含两个模型）。"""
    raw = (config or {}).get("daily_model_limits") or {}
    out = {}
    fallback = _coerce_daily_limits(raw)
    for m in DAILY_LIMIT_MODELS:
        try:
            n = int(fallback.get(m, DEFAULT_CONFIG["daily_seedance_limit"]))
        except (TypeError, ValueError):
            n = DEFAULT_CONFIG["daily_seedance_limit"]
        out[m] = max(DAILY_LIMIT_MIN, min(DAILY_LIMIT_MAX, n))
    return out


def _coerce_cfg(key, value):
    """按 DEFAULT_CONFIG 里默认值的类型归一化配置项。

    宿主从 UI 传来的数字/布尔经常是字符串（"1800" / "true"），直接塞进 config
    会让 int(...) 之类的取值处拿到字符串，行为与预期不符。这里统一转回原类型。
    """
    if key == "daily_model_limits":
        return _coerce_daily_limits(value)
    default = DEFAULT_CONFIG.get(key)
    if isinstance(default, bool):
        if isinstance(value, str):
            return value.strip().lower() in ("1", "true", "yes", "on")
        return bool(value)
    if isinstance(default, int) and not isinstance(default, bool):
        try:
            return int(float(str(value).strip()))
        except (TypeError, ValueError):
            return default
    if isinstance(default, float):
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            return default
    return value


# 豆包时长档位（秒）。以前这里写死 ("4","10","15")，导致管理器新增的 15s / 30s
# 在提交时被静默打回默认 10 秒——控制台下拉里早就有「30」了，选了却不生效。
# 改为按秒数范围放行：页面实际提供哪些档位由注入脚本 dbm._durTiers() 动态发现，
# 页面没有的档位会自动就近落到最接近的一档；以后豆包再加新档位无需改插件。
DURATION_SECONDS_MIN = 1
DURATION_SECONDS_MAX = 600


def valid_duration(v):
    """判断是否为合法时长（秒数）。支持 "10" / "10s" / "10秒" 三种写法。"""
    try:
        n = int(str(v).strip().rstrip("sS秒 "))
    except Exception:
        return False
    return DURATION_SECONDS_MIN <= n <= DURATION_SECONDS_MAX


# ---------------------------------------------------------------------------
# 按视频时长自适应的等待预算
#
# 豆包各档位的实际生成耗时（2026-10-09 用户提供）：
#     4 秒       约 3 分钟
#     10 / 15 秒 约 5~8 分钟    —— Seedance 2.0 Mini / 2.0 Fast 支持这三档
#     30 秒      约 15~20 分钟  —— 需 Seedance 2.5
# 而插件里所有等待预算最初都是按「3~5 分钟出片」标定的（task_timeout_sec 1200s、
# min_collect_sec 900s、reload_after_sec 900s）。跑 30 秒任务时会在成片出来之前
# 就把任务判超时，甚至触发 Page.navigate 刷新页面把正在进行的生成打断。
# 这里统一按时长估算耗时，并作为各项预算的**下限**自动放宽。
# ---------------------------------------------------------------------------
GEN_ESTIMATE_SEC = {4: 240, 10: 600, 15: 720, 30: 1320}
# 传参考图 + 安全确认来回 + 下载回传 等与时长无关的固定开销
GEN_FIXED_OVERHEAD_SEC = 600


def expected_gen_sec(duration):
    """按时长估算豆包"生成"本身的耗时（秒）。未知/更大档位按最大档保守外推。"""
    try:
        n = int(str(duration).strip().rstrip("sS秒 "))
    except Exception:
        return GEN_ESTIMATE_SEC[max(GEN_ESTIMATE_SEC)]
    if n <= 0:
        return GEN_ESTIMATE_SEC[max(GEN_ESTIMATE_SEC)]
    for tier in sorted(GEN_ESTIMATE_SEC):
        if n <= tier:
            return GEN_ESTIMATE_SEC[tier]
    return GEN_ESTIMATE_SEC[max(GEN_ESTIMATE_SEC)] * 2


def min_timeout_for(duration):
    """单个任务总超时的下限：该时长的生成耗时 + 固定开销。"""
    return expected_gen_sec(duration) + GEN_FIXED_OVERHEAD_SEC


VALID_ASPECTS = ("自动", "3:4", "4:3", "9:16", "16:9", "1:1", "21:9")
VIDEO_EXTS = (".mp4", ".mov", ".webm", ".avi", ".mkv")  # 素材捕获支持的视频扩展名

# ---------------------------------------------------------------------------
# 通用工具
# ---------------------------------------------------------------------------

def now_str():
    return time.strftime("%Y-%m-%d %H:%M:%S")


# 下载目录里的成品文件"认领表"：{归一化路径: 认领它的任务 id}
# 所有账号共用同一个下载目录，多账号并发时每个 worker 都在扫同一个目录。
# 若只按"最新修改时间"挑文件，A 账号很可能把 B 账号刚下载好的视频当成自己的
# 成果取走 → 分镜拿到完全错误的视频，而且两边都不会报错。这里用全局认领表
# 保证一个文件只归属一个任务。
_CLAIMED_DL_FILES = {}          # {归一化路径: (认领它的任务 id, 认领时刻)}
_CLAIMED_DL_LOCK = threading.Lock()
# 认领有效期。任务失败/取消时不一定走得到释放逻辑，若认领永久有效，浏览器下次
# 再存成同名文件（豆包常固定存成 video.mp4）时会被这条僵尸记录挡住，导致后续
# 任务永远扫不到自己的文件。给一个远长于单次生成耗时的 TTL 即可自动失效。
_CLAIM_TTL_SEC = 1800.0


def claim_download_file(path, tid):
    """尝试把下载目录里的某个文件认领给任务 tid。已被别认领则返回 False。"""
    if not path:
        return False
    key = str(path).replace("/", "\\").lower()
    now = time.time()
    with _CLAIMED_DL_LOCK:
        rec = _CLAIMED_DL_FILES.get(key)
        if rec:
            owner, ts = rec
            if owner != tid and (now - ts) < _CLAIM_TTL_SEC:
                return False
        _CLAIMED_DL_FILES[key] = (tid, now)
        # 顺带清理过期项，避免表随任务数无限增长
        if len(_CLAIMED_DL_FILES) > 256:
            for k, v in list(_CLAIMED_DL_FILES.items()):
                if (now - v[1]) >= _CLAIM_TTL_SEC:
                    _CLAIMED_DL_FILES.pop(k, None)
        return True


def release_download_file(path):
    if not path:
        return
    key = str(path).replace("/", "\\").lower()
    with _CLAIMED_DL_LOCK:
        _CLAIMED_DL_FILES.pop(key, None)


# 已经作为成品回传给某个任务的文件：改名成"账号名+时间"后，这些文件对其他任务
# 来说同样是"新出现的大 mp4"，而且前缀还可能同属一个账号（同账号先后两单），
# 光靠账号名匹配挡不住。认领表有 30 分钟 TTL，过了仍会被误认领，所以这里单独
# 记一份"已交付"清单，永久排除。
#
# ★ 2026-11-14 回传一致性强化：旧清单只按「路径 -> tid」，两个漏洞：
#   ① 同一份视频被复制/改名到新路径后保护失效 → 两个分镜可能回传同一个视频；
#   ② 豆包固定落盘 video.mp4（同名覆盖），旧记录会永久挡住本任务的新成品（丢片）。
#   现在升级为 v2：路径记录带 size/mtime 元信息（可识别覆盖），另建
#   「内容 MD5 -> 归属任务」索引，无论文件叫什么、在哪个目录都能认出它已归谁。
#   v1 旧文件在加载时自动迁移，历史保护不丢失。
_DELIVERED_PATH = BRIDGE_DIR / "delivered.json"
_DELIVERED_VIDEOS = {}       # v1 兼容镜像：{path_key: tid}（控制台 delivered_count 用）
_DELIVERED_META = {}         # {path_key: {"tid","size","mtime","md5"}}
_DELIVERED_CONTENT = {}      # {md5: {"tid","path","size","at"}}
_DELIVERED_LOCK = threading.Lock()
_DELIVERED_FORMAT_VERSION = 2


def _delivered_key(path):
    return str(path or "").replace("/", "\\").lower()


def _delivered_stat(path):
    try:
        st = Path(path).stat()
        return int(st.st_size), float(st.st_mtime)
    except Exception:
        return 0, 0.0


def _load_delivered():
    """启动时加载已交付清单（2026-11-02）；兼容 v1 纯 path->tid 与 v2 结构。"""
    global _DELIVERED_VIDEOS
    _migrated = False
    try:
        p = _DELIVERED_PATH
        if not (p and Path(p).exists()):
            return
        with open(p, "r", encoding="utf-8") as _f:
            _data = json.load(_f)
        if not isinstance(_data, dict):
            return
        if int(_data.get("v") or 1) >= 2:
            _meta = _data.get("paths") or {}
            _content = _data.get("content") or {}
            if isinstance(_meta, dict):
                for k, v in _meta.items():
                    if isinstance(v, dict):
                        _DELIVERED_META[str(k)] = {
                            "tid": str(v.get("tid") or ""),
                            "size": int(v.get("size") or 0),
                            "mtime": float(v.get("mtime") or 0),
                            "md5": str(v.get("md5") or ""),
                        }
                    else:
                        _DELIVERED_META[str(k)] = {
                            "tid": str(v), "size": 0, "mtime": 0.0, "md5": ""}
            if isinstance(_content, dict):
                for k, v in _content.items():
                    if isinstance(v, dict):
                        _DELIVERED_CONTENT[str(k)] = dict(v)
        else:
            # v1：只有路径 -> tid，无元信息。
            # ★ 2026-11-14 全面检查修复：旧迁移把 size/mtime 全填 0，导致
            #   is_video_delivered 的「同名覆盖」比对（size>0 才比）被整段跳过，
            #   历史 video.mp4 记录会永久挡住本任务的新成品 —— 正是 v2 声称
            #   已修复的丢片问题。这里只做 stat（不读内容、不算 MD5），让覆盖
            #   可被识别；文件已删则保留 0 值，语义仍是「曾交付过」。
            for k, v in _data.items():
                _sz, _mt = _delivered_stat(str(k))
                _DELIVERED_META[str(k)] = {
                    "tid": str(v), "size": _sz, "mtime": _mt, "md5": ""}
            _migrated = True
        _DELIVERED_VIDEOS = {
            k: str(v.get("tid") or "") for k, v in _DELIVERED_META.items()}
        if _migrated:
            # 迁移后立刻写回 v2，避免每次启动重复迁移，也让结构真正落盘
            _save_delivered()
    except Exception as e:
        logging.warning("[doubao-bridge] 加载 delivered.json 失败，本次启动保护清单为空：%s", e)


def _save_delivered():
    """把已交付清单落盘（仅成功交付时调用，频率低）。"""
    try:
        p = _DELIVERED_PATH
        if not p:
            return
        _tmp = str(p) + ".tmp"
        _payload = {"v": _DELIVERED_FORMAT_VERSION,
                    "paths": _DELIVERED_META,
                    "content": _DELIVERED_CONTENT}
        with open(_tmp, "w", encoding="utf-8") as _f:
            json.dump(_payload, _f, ensure_ascii=False)
        os.replace(_tmp, str(p))
    except Exception:
        pass


_load_delivered()


def mark_video_delivered(path, tid):
    """标记该文件已作为 tid 的成品回传；同时登记内容 MD5 归属（防串片）。"""
    if not path:
        return
    key = _delivered_key(path)
    size, mtime = _delivered_stat(path)
    md5 = ""
    try:
        if size > 0:
            md5 = _file_md5(path)
    except Exception:
        md5 = ""
    with _DELIVERED_LOCK:
        _DELIVERED_META[key] = {"tid": str(tid), "size": size,
                                "mtime": mtime, "md5": md5}
        _DELIVERED_VIDEOS[key] = str(tid)
        if md5:
            # 先到先得：同一内容先归 A，B 再 mark 也不会篡改归属，
            # 回传前 content_delivered_by_other 就能把 B 拦下来。
            _DELIVERED_CONTENT.setdefault(md5, {
                "tid": str(tid), "path": str(path), "size": size,
                "at": time.time()})
        if len(_DELIVERED_META) > 512:
            for k in list(_DELIVERED_META)[:256]:
                _DELIVERED_META.pop(k, None)
                _DELIVERED_VIDEOS.pop(k, None)
        if len(_DELIVERED_CONTENT) > 512:
            for k in list(_DELIVERED_CONTENT)[:256]:
                _DELIVERED_CONTENT.pop(k, None)
    try:
        _save_delivered()
    except Exception:
        pass


def _unmark_video_delivered(path, tid):
    """回滚一次「已交付」登记（2026-11-14 全面检查修复）。

    6 条落盘链路都在调用 _finish_done 之前先 mark_video_delivered；
    若随后的一致性校验拒绝回传，必须把这些登记撤销，否则被拒文件会
    永久占据路径记录与内容 MD5 归属，后续正常任务会被连环误拒。
    """
    if not path:
        return
    key = _delivered_key(path)
    with _DELIVERED_LOCK:
        meta = dict(_DELIVERED_META.get(key) or {})
        md5 = str(meta.get("md5") or "")
        owner = str(meta.get("tid") or "")
        if owner and owner != str(tid):
            # 这条记录本来属于别的任务，不能动
            return
        _DELIVERED_META.pop(key, None)
        _DELIVERED_VIDEOS.pop(key, None)
        if md5:
            rec = _DELIVERED_CONTENT.get(md5) or {}
            if str(rec.get("tid") or "") == str(tid):
                _DELIVERED_CONTENT.pop(md5, None)
    try:
        _save_delivered()
    except Exception:
        pass


def is_video_delivered(path, tid=""):
    """该文件是否已作为成品交付过（可指定"是否由本任务交付"）。

    2026-11-14：带 size/mtime 元信息的记录会比对当前文件；若同名文件已被
    覆盖写入（豆包固定落盘 video.mp4），旧记录不再误挡本任务的新成品。
    内容级归属由 _video_consistency_check 在回传前做最终兜底。
    """
    if not path:
        return False
    key = _delivered_key(path)
    with _DELIVERED_LOCK:
        meta = dict(_DELIVERED_META.get(key) or {})
        owner = _DELIVERED_VIDEOS.get(key)
    if not meta and owner is None:
        return False
    owner = str(meta.get("tid") or owner or "")
    if int(meta.get("size") or 0) > 0:
        size, mtime = _delivered_stat(path)
        if size and (size != int(meta["size"]) or
                     abs(mtime - float(meta.get("mtime") or 0)) > 2):
            return False
    return True if not tid else owner != str(tid)


def content_delivered_by_other(md5, tid):
    """该内容指纹是否已归属别的任务；返回对方 tid（空串表示没有冲突）。"""
    if not md5:
        return ""
    with _DELIVERED_LOCK:
        rec = _DELIVERED_CONTENT.get(md5)
    if not rec:
        return ""
    owner = str(rec.get("tid") or "")
    return owner if owner and owner != str(tid) else ""


# 下载目录里的 dbm_<任务id>.mp4 是"某个任务私有的保护副本"：把下载目录里的原始
# 文件 copy2 成这个名字，防止 Electron 后续把它清理掉。所有任务共用同一个下载
# 目录，A 任务刚生成的 dbm_A.mp4 对 B 任务来说就是一个"新出现的大文件"，如果
# 不拦住，B 会把它当成自己的成品取走 → 分镜拿到别的账号/别的分镜的视频，而且
# 两边都不报错。这里统一判定：名字是 dbm_*.mp4 但不属于本任务的，一律跳过。
def is_foreign_dbm_file(path, tid):
    try:
        name = str(Path(str(path)).name).lower()
    except Exception:
        return False
    if not (name.startswith("dbm_") and name.endswith(".mp4")):
        return False
    return name != ("dbm_%s.mp4" % str(tid).lower())


# ---------------------------------------------------------------------------
# 成品命名：<账号名>_<YYYYmmdd_HHMMSS>.mp4
#
# 以前统一叫 dbm_<任务id>.mp4，两个问题：
#   1) 下载目录里一堆任务 id，人根本分不清哪个片子是哪个账号下的；
#   2) 所有账号共用一个下载目录，只能靠"谁新认领谁"猜归属 → 串片。
# 改成"账号名 + 落盘时间"后，归属一眼可辨，认领规则也能写成**硬匹配**：
# 文件名带别账号前缀的一律跳过，本账号前缀的可直接认领。
# ---------------------------------------------------------------------------
_ACCT_VIDEO_RE = re.compile(
    r"^(?P<acct>.+)_(?P<ts>\d{8}_\d{6})(?:_(?P<seq>\d+))?\.mp4$")
_INVALID_NAME_CHARS = re.compile(r"[\\/:*?\"<>|\s]+")


def safe_account_name(name):
    """把账号名洗成可安全用于文件名的片段（去空白与 Windows 非法字符）。"""
    s = _INVALID_NAME_CHARS.sub("_", str(name or "").strip())
    return s.strip("._") or "account"


_NICK_UI_WORDS = ("最近修改", "刚刚", "分钟前", "小时前", "天前", "新建对话",
                  "历史记录", "智能纪要", "下载", "分享", "复制", "登录",
                  "注册", "全部", "取消", "设置", "编辑", "更多")


def valid_nickname(nick):
    """把豆包页面误抓的 UI 文案挡在「账号身份」之外。

    2026-11-14 实测：guessNick() 的选择器会命中侧栏「最近修改: 刚刚」，
    两个不同账号因此共用同一个昵称 key，每日额度被合并计数；重启后昵称
    抓不到又退回每次都变的 CDP target_id，历史额度彻底查不到。
    昵称只用于展示/路由/额度主键，宁可为空走 target_id，也不能收脏值。
    """
    s = str(nick or "").strip()
    if not (2 <= len(s) <= 20):
        return ""
    if any(w in s for w in _NICK_UI_WORDS):
        return ""
    if not re.search(r"[\w\u4e00-\u9fff]", s):
        return ""
    return s


# ---------------------------------------------------------------------------
# 稳定账号身份（2026-11-14）
#
# 旧版拿「昵称 / CDP target_id」当每日额度主键，实测今天 3 次生成被重复记到
# 8 个不同的 target_id key（每次重启全变），控制台于是把 A 账号的 2 次显示成
# B 账号的 1 次。管理器给每个账号窗口预注入了 __DBM_ACCOUNT_ID__（UUID），
# 主窗口 .account-card[data-id] 与 <webview data-account-id> 都是同一个值，
# 跟随账号资料持久化：窗口重开、重启、账号顺序调整、换一批账号都不会变。
# 这里每次巡检动态读取，按 UUID 登记，不写死任何手机号或顺序。
# ---------------------------------------------------------------------------
_STABLE_UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
ACCOUNT_IDENTITY_TTL = 25.0
_ACCOUNT_IDENTITY_LOCK = threading.Lock()
_ACCOUNT_IDENTITY_CACHE = {"ts": 0.0, "by_target": {}}

_MANAGER_IDENTITY_JS = r"""(function(){
  var out={names:{},webviews:[]};
  var cards=document.querySelectorAll('.account-card[data-id]');
  for(var i=0;i<cards.length;i++){
    var c=cards[i], id=c.getAttribute('data-id')||'';
    var info=c.querySelector('.account-info');
    var txt=info?(info.innerText||'').trim().split('\n')[0]:'';
    if(id) out.names[id]=txt.slice(0,40);
  }
  var wvs=document.querySelectorAll('webview[data-account-id]');
  for(var j=0;j<wvs.length;j++){
    var w=wvs[j], u='';
    try{ u = w.getURL ? (w.getURL()||'') : (w.src||''); }catch(e){ u=w.src||''; }
    out.webviews.push({id:(w.getAttribute('data-account-id')||''),
                       url:String(u).split('?')[0].split('#')[0]});
  }
  return JSON.stringify(out);
})()"""


def stable_account_key(uuid_str):
    """管理器账号 UUID -> 每日额度主键；非法值返回空串。"""
    s = str(uuid_str or "").strip().lower()
    return "uuid:" + s if _STABLE_UUID_RE.match(s) else ""


def is_stable_account_key(key):
    s = str(key or "")
    return s.startswith("uuid:") and bool(_STABLE_UUID_RE.match(s[5:]))


def load_account_identities():
    """读身份表；任何损坏都降级为空表，不影响桥接启动。"""
    try:
        d = load_json(ACCOUNT_IDENTITY_PATH, {}) or {}
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("version", 1)
    if not isinstance(d.get("accounts"), dict):
        d["accounts"] = {}
    if not isinstance(d.get("targets"), dict):
        d["targets"] = {}
    return d


def save_account_identities(d):
    try:
        d["updated_at"] = now_str()
        save_json(ACCOUNT_IDENTITY_PATH, d)
    except Exception as e:
        print(f"[bridge] 账号身份表落盘失败: {e}")


def identity_for_target(target_id, store=None):
    """按 CDP target_id 反查稳定身份（含历史 target，重启后仍可解析）。"""
    d = store if isinstance(store, dict) else load_account_identities()
    uid = str((d.get("targets") or {}).get(str(target_id or "")) or "")
    if not uid:
        return {}
    rec = (d.get("accounts") or {}).get(uid) or {}
    return {"uuid": uid, "name": str(rec.get("name") or ""),
            "key": stable_account_key(uid)}


def account_identity_snapshot():
    """只读缓存：{target_id: {uuid, name, key}}，绝不触发网络请求。"""
    with _ACCOUNT_IDENTITY_LOCK:
        return {k: dict(v) for k, v in _ACCOUNT_IDENTITY_CACHE["by_target"].items()}


def refresh_account_identities(bridge=None, force=False, timeout=3.0):
    """动态探测当前所有账号窗口的稳定身份，并累积进身份表。

    - 主窗口一次 JS 拿 uuid -> 手机号/备注；每个豆包 webview 一次纯读 JS
      拿 __DBM_ACCOUNT_ID__；TTL 25 秒内复用缓存，不拖慢 3 秒巡检。
    - 新账号打开、换一批账号、账号顺序变化都自动登记，无需配置或写死名单。
    - 探测失败一律保留上一次结果，不影响派发主链路。
    """
    now = time.time()
    with _ACCOUNT_IDENTITY_LOCK:
        ts = _ACCOUNT_IDENTITY_CACHE["ts"]
        cached = {k: dict(v) for k, v in _ACCOUNT_IDENTITY_CACHE["by_target"].items()}
    if not force and ts and now - ts < ACCOUNT_IDENTITY_TTL and cached:
        return cached
    with _ACCOUNT_IDENTITY_LOCK:
        if _ACCOUNT_IDENTITY_CACHE.get("scanning"):
            return cached
        _ACCOUNT_IDENTITY_CACHE["scanning"] = True
    try:
        port = _dbk_resolve_cdp_port(bridge)
        try:
            targets = http_get_json(
                "http://127.0.0.1:%d/json/list" % port, timeout=5) or []
        except Exception:
            targets = []
        if not isinstance(targets, list) or not targets:
            return cached
        pages = [t for t in targets if isinstance(t, dict)
                 and t.get("type") == "page" and "豆包管理器" in str(t.get("title") or "")]
        views = [t for t in targets if isinstance(t, dict)
                 and t.get("type") in ("page", "webview")
                 and "doubao.com" in str(t.get("url") or "")]
        names, by_url = {}, {}
        if pages:
            ws = None
            try:
                ws = WSClient(pages[0].get("webSocketDebuggerUrl", ""), timeout=5)
                ws.send("Runtime.enable")
                r = ws.send("Runtime.evaluate", {
                    "expression": _MANAGER_IDENTITY_JS,
                    "returnByValue": True, "awaitPromise": True})
                raw = (r.get("result") or {}).get("value") or ""
                obj = json.loads(raw) if raw else {}
                if isinstance(obj, dict):
                    names = obj.get("names") or {}
                    for item in (obj.get("webviews") or []):
                        if isinstance(item, dict) and item.get("id") and item.get("url"):
                            by_url[str(item["url"])] = str(item["id"])
            except Exception:
                pass
            finally:
                try:
                    if ws: ws.close()
                except Exception:
                    pass
        store = load_account_identities()
        live = {}
        for t in views:
            tid = str(t.get("id") or "")
            ws_url = str(t.get("webSocketDebuggerUrl") or "")
            if not tid or not ws_url:
                continue
            uid = ""
            ws = None
            try:
                ws = WSClient(ws_url, timeout=timeout)
                ws.send("Runtime.enable")
                r = ws.send("Runtime.evaluate", {
                    "expression": "(window.__DBM_ACCOUNT_ID__ || '')",
                    "returnByValue": True})
                uid = str((r.get("result") or {}).get("value") or "").strip().lower()
            except Exception:
                uid = ""
            finally:
                try:
                    if ws: ws.close()
                except Exception:
                    pass
            if not _STABLE_UUID_RE.match(uid):
                # 只在明确的会话页 URL 上用主窗口顺序兜底，避免多个 /chat/ 首页互串
                url = str(t.get("url") or "").split("?")[0].split("#")[0]
                if re.search(r"/chat/\d+", url):
                    uid = str(by_url.get(url) or "").strip().lower()
            if not _STABLE_UUID_RE.match(uid):
                continue
            name = str(names.get(uid) or "").strip()
            rec = store["accounts"].get(uid)
            if not isinstance(rec, dict):
                rec = {"name": name, "phone": "", "targets": [], "first_seen": now_str()}
                store["accounts"][uid] = rec
            if name and rec.get("name") != name:
                rec["name"] = name
            if name:
                m = re.search(r"1[3-9]\d{9}", name)
                if m:
                    rec["phone"] = m.group(0)
            rec["last_seen"] = now_str()
            tl = rec.get("targets")
            if not isinstance(tl, list):
                tl = []
            if tid not in tl:
                tl.append(tid)
            rec["targets"] = tl[-12:]
            store["targets"][tid] = uid
            live[tid] = {"uuid": uid, "name": rec.get("name") or "",
                         "key": stable_account_key(uid)}
        # 历史 target 也放进内存映射：账号暂时没打开时仍能解析账本里的旧 key
        for hist_tid, uid in list((store.get("targets") or {}).items()):
            if hist_tid in live:
                continue
            rec = (store.get("accounts") or {}).get(uid) or {}
            live[hist_tid] = {"uuid": uid, "name": rec.get("name") or "",
                              "key": stable_account_key(uid)}
        if len(store["targets"]) > 300:
            keep = {k: v for k, v in list(store["targets"].items())[-240:]}
            store["targets"] = keep
        save_account_identities(store)
        with _ACCOUNT_IDENTITY_LOCK:
            _ACCOUNT_IDENTITY_CACHE["ts"] = time.time()
            _ACCOUNT_IDENTITY_CACHE["by_target"] = live
        return live
    finally:
        with _ACCOUNT_IDENTITY_LOCK:
            _ACCOUNT_IDENTITY_CACHE["scanning"] = False


def task_generated_today(task, day):
    """该任务是否属于 day（YYYY-MM-DD）当天「豆包侧已真实生成视频」的一次消费。

    只认终态 done/delivered + 成品证据；error/未提交/未下载的不算，
    避免把失败任务误计进额度。created_at 以 day 开头即覆盖 00:00:00–23:59:59，
    tid 前缀作旧数据兜底。
    """
    if not isinstance(task, dict):
        return False
    ts = str(task.get("created_at") or "")
    tid = str(task.get("id") or "")
    if not (ts.startswith(day) or tid.startswith(day.replace("-", ""))):
        return False
    if str(task.get("status") or "") not in ("done", "delivered"):
        return False
    if any(task.get(k) for k in ("video_path", "video_md5", "video_url")):
        return True
    for line in (task.get("logs") or [])[-40:]:
        if "无水印视频已保存" in str(line):
            return True
    return False


def account_download_dir(base_dl, account_label, date_str=None):
    """按「日期 + 账号名」派生独立下载子目录，避免多账号共用同一下载目录互相覆盖。

    base_dl 为空时回退 detect_download_dir()。返回的目录形如：
        <base>/<日期>_<账号名>_<场景名>/
    每个账号每天的成品只落进自己的子目录，回收时也只扫自己的子目录，
    从物理层面彻底隔离多账号并发下载写同一 video.mp4 的串片/覆盖问题。
    """
    if not base_dl:
        base_dl = detect_download_dir()
    if not base_dl:
        return ""
    if date_str is None:
        date_str = time.strftime("%Y-%m-%d")
    sub = "%s_%s" % (date_str, safe_account_name(account_label))
    return str(Path(base_dl) / sub)


def parse_account_video_name(name):
    """解析 <账号名>_<YYYYmmdd_HHMMSS>[_n].mp4，返回账号名；格式不符返回 None。"""
    try:
        m = _ACCT_VIDEO_RE.match(str(name or ""))
    except Exception:
        return None
    return m.group("acct") if m else None


def is_foreign_video_file(path, tid, account_name=""):
    """下载目录里的文件是否"确定属于别人"（本任务必须跳过）。

    两条硬规则，任一命中即判外来：
      1. dbm_<任务id>.mp4        —— 别的任务的保护副本；
      2. <账号名>_<时间>.mp4 且账号名不是本账号 —— 别的账号的成品。
    其余（豆包落盘的 video.mp4、豆包_创作原视频_*.mp4 等原始下载）不算外来，
    交给"认领表 + 修改时间窗口"去仲裁。
    """
    try:
        name = str(Path(str(path)).name)
    except Exception:
        return False
    low = name.lower()
    if low.startswith("dbm_") and low.endswith(".mp4"):
        return low != ("dbm_%s.mp4" % str(tid).lower())
    owner = parse_account_video_name(name)
    if owner and account_name:
        return owner.lower() != safe_account_name(account_name).lower()
    return False


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    tmp = str(path) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, str(path))


# ---------------------------------------------------------------------------
# 宿主（字字动画）存活守卫 —— 2026-11-03
#
# 需求：字字动画软件端关闭后，插件与任务控制台里残留的任务必须全部取消，
#       不允许桥接在下次启动时把它们重新排队、也不允许控制台继续派发。
#
# 信号来源：main.py 给所有插件侧 HTTP 请求带 X-Doubao-Host: <宿主PID>，并额外
#   起一个 5 秒心跳。宿主进程一退出，心跳与轮询同时消失；桥接侧据此判定离线。
#   控制台（浏览器页面）的请求不带这个头，绝不会被误当成宿主在线。
#
# 双保险：除了心跳超时，还直接查宿主进程是否存在 + 进程创建时间（FILETIME），
#   这样「宿主崩溃后几秒内就重启」也能识别（旧 PID 已退出 / PID 被复用），
#   而宿主崩溃来不及写离线标记时，下次桥接启动靠持久化会话同样能清理残留。
# ---------------------------------------------------------------------------

def process_identity(pid):
    """返回 (alive, creation_ft)。alive=None 表示无法判定（此时不得据此误杀任务）。

    绝不能用 os.kill(pid, 0)：Windows 上 Python 的 os.kill 对 signal=0 会走
    TerminateProcess，直接把目标进程杀掉。这里用 OpenProcess（只读权限）+
    GetProcessTimes 取创建时间，用来识别 PID 被复用导致的漏判。
    """
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return (None, 0)
    if pid <= 0:
        return (None, 0)
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return (True, 0)
        except OSError:
            return (False, 0)
        except Exception:
            return (None, 0)
    try:
        import ctypes
        from ctypes import wintypes

        class _FILETIME(ctypes.Structure):
            _fields_ = [("dwLowDateTime", wintypes.DWORD),
                        ("dwHighDateTime", wintypes.DWORD)]

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k32.OpenProcess.restype = wintypes.HANDLE
        k32.GetProcessTimes.argtypes = [wintypes.HANDLE,
                                        ctypes.POINTER(_FILETIME),
                                        ctypes.POINTER(_FILETIME),
                                        ctypes.POINTER(_FILETIME),
                                        ctypes.POINTER(_FILETIME)]
        k32.GetProcessTimes.restype = wintypes.BOOL
        k32.CloseHandle.argtypes = [wintypes.HANDLE]
        # PROCESS_QUERY_LIMITED_INFORMATION：只读，不需要管理员权限
        h = k32.OpenProcess(0x1000, False, pid)
        if not h:
            err = ctypes.get_last_error()
            # 87 = ERROR_INVALID_PARAMETER，Windows 上表示这个 PID 根本不存在
            if err == 87:
                return (False, 0)
            return (None, 0)
        try:
            c, e, kt, ut = _FILETIME(), _FILETIME(), _FILETIME(), _FILETIME()
            if not k32.GetProcessTimes(h, ctypes.byref(c), ctypes.byref(e),
                                       ctypes.byref(kt), ctypes.byref(ut)):
                return (True, 0)
            creation = (int(c.dwHighDateTime) << 32) | int(c.dwLowDateTime)
            return (True, creation)
        finally:
            k32.CloseHandle(h)
    except Exception:
        return (None, 0)


class HostGuard:
    """宿主存活会话的持久化状态机（跨桥接重启有效）。"""

    def __init__(self):
        self._lock = threading.RLock()
        raw = load_json(HOST_SESSION_PATH, {})
        self.data = raw if isinstance(raw, dict) else {}
        cfg = load_json(CONFIG_PATH, {}) or {}
        self._enabled = bool(cfg.get("host_guard_enabled", True))
        try:
            self._timeout = float(cfg.get("host_offline_timeout_sec", 20) or 20)
        except (TypeError, ValueError):
            self._timeout = 20.0
        try:
            self._idle_timeout = float(cfg.get("host_idle_timeout_sec", 120) or 120)
        except (TypeError, ValueError):
            self._idle_timeout = 120.0
        self._last_write = 0.0

    @property
    def enabled(self):
        return self._enabled

    @property
    def timeout(self):
        return self._timeout

    @property
    def idle_timeout(self):
        return self._idle_timeout

    def set_enabled(self, value):
        self._enabled = bool(value)

    def set_timeout(self, value):
        try:
            self._timeout = max(5.0, float(value))
        except (TypeError, ValueError):
            pass

    def set_idle_timeout(self, value):
        try:
            self._idle_timeout = max(self._timeout + 5.0, float(value))
        except (TypeError, ValueError):
            pass

    def has_session(self):
        with self._lock:
            return bool(self.data.get("host_pid")) and bool(self.data.get("last_seen"))

    def _persist(self, force=False):
        now = time.time()
        if not force and now - self._last_write < 2.0:
            return
        try:
            save_json(HOST_SESSION_PATH, dict(self.data))
            self._last_write = now
        except Exception as e:
            print(f"[doubao-bridge] 宿主会话落盘失败: {e}")

    def note(self, pid):
        """宿主侧任何 HTTP 请求都会调用：刷新存活时间戳，必要时切换/恢复会话。"""
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            return
        if pid <= 0:
            return
        now = time.time()
        with self._lock:
            changed = False
            if self.data.get("host_pid") != pid:
                _alive, creation = process_identity(pid)
                self.data["host_pid"] = pid
                self.data["host_start"] = int(creation or 0)
                self.data["session_start"] = now
                changed = True
                print(f"[doubao-bridge] 宿主会话建立: pid={pid}")
            if self.data.get("offline"):
                # 收到心跳 = 宿主还活着（或已重新启动），解除派发闸门。
                # 已取消的旧任务不会被复活：它们是终态，_recover() 会跳过。
                self.data["offline"] = False
                self.data["reason"] = ""
                changed = True
                print("[doubao-bridge] 字字动画重新上线，解除派发闸门，恢复接收新任务")
            self.data["last_seen"] = now
            self._persist(force=changed)

    def _offline_reason(self, now):
        """返回离线原因字符串；None = 在线或无法判定（不得误杀）。

        判定优先级：
          1) 宿主进程明确已退出 / PID 被复用 → 立即离线（最可靠信号）；
          2) 宿主进程仍存活 → 只有长时间完全无请求才离线，避免休眠唤醒后
             把正在生成的整批任务误取消（Windows 休眠会暂停所有线程）；
          3) 进程身份无法判定（权限/平台限制）→ 退回短心跳超时兜底。
        """
        if not self._enabled:
            return None
        with self._lock:
            if not (self.data.get("host_pid") and self.data.get("last_seen")):
                # 从未收到过宿主心跳（例如手动独立运行 bridge/server.py 调试）：
                # 保持原行为，不取消任何任务。
                return None
            if self.data.get("offline"):
                return "宿主会话已标记离线"
            last = float(self.data.get("last_seen") or 0)
            pid = int(self.data.get("host_pid") or 0)
            start = int(self.data.get("host_start") or 0)
        idle = now - last
        pid_state = None
        if pid > 0:
            alive, creation = process_identity(pid)
            if alive is False:
                return "字字动画进程已退出"
            if alive is True and start and creation and creation != start:
                return "字字动画进程已重启（PID 复用）"
            pid_state = alive
        if pid_state is True:
            # 进程还在（宿主线程可能因休眠/锁屏暂停），给足宽限期，不误杀在途任务
            if idle > self._idle_timeout:
                return f"字字动画进程仍在但已 {int(idle)} 秒无响应"
            return None
        # 进程身份无法判定：退回心跳超时兜底
        if idle > self._timeout:
            return f"字字动画已 {int(idle)} 秒无心跳"
        return None

    def is_offline(self):
        return self._offline_reason(time.time()) is not None

    def session_ended(self):
        """给 TaskStore._recover() 用：上一宿主会话是否已经结束。"""
        return self._offline_reason(time.time()) is not None

    def marked_offline(self):
        """是否已显式打上离线标记（用于避免看门狗重复执行全量取消）。"""
        with self._lock:
            return bool(self.data.get("offline"))

    def mark_offline(self, reason):
        with self._lock:
            self.data["offline"] = True
            self.data["offline_since"] = time.time()
            self.data["reason"] = str(reason or "字字动画已关闭")
            self._persist(force=True)

    def set_cancel_count(self, n):
        with self._lock:
            self.data["last_cancel_count"] = int(n or 0)
            self.data["last_cancel_at"] = now_str()
            self._persist(force=True)

    def info(self):
        now = time.time()
        reason = self._offline_reason(now)
        with self._lock:
            last = float(self.data.get("last_seen") or 0)
            return {
                "enabled": self._enabled,
                "online": reason is None,
                "reason": reason or "",
                "host_pid": int(self.data.get("host_pid") or 0),
                "last_seen_sec": (int(now - last) if last else -1),
                "offline_since": self.data.get("offline_since") or 0,
                "last_cancel_count": int(self.data.get("last_cancel_count") or 0),
                "last_cancel_at": self.data.get("last_cancel_at") or "",
                "timeout_sec": self._timeout,
                "idle_timeout_sec": self._idle_timeout,
            }


HOST_GUARD = HostGuard()


def cancel_all_tasks(reason):
    """取消桥接侧所有未完成任务（含释放占用账号、移出编排器 inflight）。"""
    if STATE is None:
        return 0
    n = 0
    for t in list(STATE.store.list()):
        try:
            r = STATE.scheduler.cancel_task(t.get("id"), reason)
            if r.get("ok"):
                n += 1
        except Exception as e:
            print(f"[doubao-bridge] 自动取消任务 {t.get('id')} 异常: {e}")
    return n


def http_get_json(url, timeout=5):
    # 本地 CDP / 桥接 API 必须绕开系统代理：全局代理（含 Windows 注册表代理）
    # 会把 127.0.0.1 也转发出去，返回 502，进而被误判成"管理器没运行"。
    # 外网请求仍走原来的代理设置。
    if "://127.0.0.1" in url or "://localhost" in url:
        _opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with _opener.open(url, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _vid_url_key(u):
    """视频 URL 的比对键：域名 + path 前两段。

    2026-09-19 定位的"回传带水印视频"根因就在这里没做区分：
    豆包的**预览流**（页面 <video> 播放的，带水印）和**无水印下载流**是两条
    不同的签名地址，但都会被 CDP 网络层当成 mp4 响应收进 _mp4_candidates。
    旧代码只要时间窗内出现任何 mp4 就当"无水印下载地址"用，于是把带水印
    预览流下回去交给字字动画。

    同一条地址在不同请求里 query 不同（签名/过期参数），所以要忽略 query；
    末尾文件名也可能随转码参数变化，因此只取 path 前两段（豆包的两段 hash）。
    """
    try:
        p = urllib.parse.urlsplit(str(u or ""))
    except Exception:
        return ("", str(u or "").split("?")[0])
    segs = [s for s in (p.path or "").split("/") if s][:2]
    return ((p.netloc or "").lower(), "/".join(segs))


def _vid_url_exact(u):
    """去掉 query 后的完整 URL（用于精确比对）。"""
    return str(u or "").split("?")[0]


# 明确的图片类 URL（含 .jpg~tp 这类 imagex 变体后缀）——hook/嗅探噪声里最常见，
# 命中即绝不能当无水印视频下载地址（2026-10-12：3MB .jpg~tp 被存成 .mp4 的根因之一）
_IMG_URL_RE = re.compile(r"\.(jpe?g|png|webp|gif|bmp|avif|heic)([?~#]|$)", re.I)


def _head_is_mp4(path, min_size=50 * 1024):
    """落盘文件内容签名校验（2026-10-20 新增）。

    管理器/浏览器的"无水印下载"偶发把**封面图**（2.4MB PNG）以 .mp4 文件名
    落到下载目录，靠文件名/体积/稳定性检查全部拦不住——今天实测两张 PNG
    被当无水印成品回传给字字动画。这里统一读文件头：豆包成片统一 mp4 容器，
    前 8 字节必须含 ftyp 签名（bytes[4:8]），否则一律不算成品。
    """
    try:
        p = Path(path)
        if not p.is_file() or p.stat().st_size < min_size:
            return False
        with open(p, "rb") as fh:
            head = fh.read(16)
        return len(head) >= 8 and head[4:8] == b"ftyp"
    except Exception:
        return False


def _file_md5(path):
    """文件 MD5（分块读，几 MB 级文件开销可忽略）。

    与 fiber 里的 download_filehash / file_hash 比对，识别"带水印预览同体"
    （2026-10-25：管理器 resolver 的 u() 兜底会把带水印 download_url 误当
    确认无水印发出下载，落盘文件 MD5 与 download_filehash 完全一致）。
    """
    h = hashlib.md5()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(1024 * 1024)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _video_consistency_check(path, tid, task=None, account_name=""):
    """回传前最终一致性校验（2026-11-14「回传视频必须是该分镜的视频」强化）。

    返回 (ok, reason, md5)。只在有明确证据时拒绝，避免误杀正常成品：
      1) 文件头必须是 mp4（拦封面图 / 损坏文件）；
      2) 落盘时间不得早于本任务「协商完成、真正开始生成」的时刻
         （拦跨任务 / 别的账号窗口刚下的残留文件）；
      3) 内容 MD5 不得已归属别的任务（拦同一视频被两个分镜认领 = 串片）；
      4) 文件名明确归属别的账号 / 别的任务时拒收（拦跨账号串片）。
    旧任务缺 task.submit_ts 等字段时相应检查自动跳过，保证向后兼容；
    校验过程本身出异常也不吞掉成品，交回原有链路继续处理。
    """
    try:
        p = Path(str(path or ""))
        if not p.is_file() or p.stat().st_size <= 50 * 1024:
            return False, "成品文件不存在或体积不合格", ""
        if not _head_is_mp4(p):
            return False, "成品文件头不是 mp4（疑似封面图或损坏文件）", ""
        task = task or {}
        # ★ 2026-11-14 二轮：时间基准改为「协商完成、真正开始生成」的时刻。
        #   旧版用 submit_ts-300s（足足放宽 5 分钟），而带参考音频的任务协商
        #   本身就要 160s+，其它账号窗口在这段时间里刚下的片子完全能通过，
        #   正是用户反馈「二次确认还没发就收到别的账号窗口视频」的帮凶。
        try:
            ready_ts = float(task.get("generation_ready_ts") or 0)
        except (TypeError, ValueError):
            ready_ts = 0.0
        try:
            submit_ts = float(task.get("submit_ts") or 0)
        except (TypeError, ValueError):
            submit_ts = 0.0
        base_ts = ready_ts or submit_ts
        grace = 30.0 if ready_ts > 0 else 60.0
        if base_ts > 0 and p.stat().st_mtime < base_ts - grace:
            return False, "成品落盘时间早于本任务开始生成时刻（疑似跨任务/跨账号残留）", ""
        if account_name and is_foreign_video_file(str(p), tid, account_name):
            return False, "成品文件名归属其它账号或任务（疑似跨账号串片）", ""
        md5 = _file_md5(p)
        other = content_delivered_by_other(md5, tid)
        if other:
            return False, ("成品内容与分镜 %s 已交付的视频完全相同"
                           "（疑似串片 / 重复认领）" % other), md5
        return True, "", md5
    except Exception:
        return True, "", ""


def is_preview_video_url(url, preview_urls):
    """url 是否是页面上正在播放的**带水印预览流**。

    判据（命中任一即视为预览流，绝不能当无水印下载地址）：
      1) 去掉 query 后与某个预览 src 完全相同
      2) 域名 + path 前两段与某个预览 src 相同

    页面 <video> 里播放的一定是带水印预览——豆包对未下载的视频一律带水印，
    只有走"无水印下载"才会给出去水印的版本。这条判据比任何 URL 关键字规则
    都可靠，因为它直接来自页面实际播放的元素。
    """
    if not url or not preview_urls:
        return False
    # ★ 2026-11-03 深度修复：官方「确认无水印下载流」一定带 download=true，
    #   而页面 <video> 播放的带水印预览流一定不带。旧判据 2「域名 + path 前两段
    #   相同」会把 vXX-vdl.doubao.com 家族里的真下载流（与预览流同域、path 前两段
    #   相同）误判为预览流并丢弃——日志实证「忽略 1 条带水印预览流地址：
    #   https://v26-vdl.doubao.com/...」正是被误杀的无水印下载直链。
    #   这里对官方确认下载流直接放行，不再进入预览流匹配；带水印预览流因不含
    #   download=true，原有过滤逻辑完全不受影响。
    try:
        from urllib.parse import urlparse as _up, parse_qs as _pq
        if (_pq(_up(url).query).get("download", [None])[0] or "").lower() == "true":
            return False
    except Exception:
        pass
    ex = _vid_url_exact(url)
    if not ex:
        return False
    if ex in preview_urls:
        return True
    try:
        k = _vid_url_key(url)
    except Exception:
        return False
    for pu in preview_urls:
        if not pu:
            continue
        if _vid_url_exact(pu) == ex:
            return True
        try:
            if _vid_url_key(pu) == k and k[1]:
                return True
        except Exception:
            continue
    return False


def http_download(url, dest_path, cookies=None, timeout=300, cancel_check=None, chunk_size=1024 * 1024):
    """下载到 dest_path。cancel_check 为可调用对象（通常 self.check_cancel），
    每读完一个分块调用一次，若任务已取消会就地抛异常中断下载（2026-11-02 修复：
    原实现用 shutil.copyfileobj 整体阻塞，最长卡 300s 无法响应取消）。"""
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Referer": "https://www.doubao.com/",
    })
    if cookies:
        req.add_header("Cookie", cookies)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp, open(dest_path, "wb") as f:
        while True:
            if cancel_check is not None:
                cancel_check()
            chunk = resp.read(chunk_size)
            if not chunk:
                break
            f.write(chunk)
    return dest_path




def detect_download_dir():
    """优先读管理器 settings.json 里的素材库目录。"""
    ud = find_manager_userdata()
    if ud:
        settings = load_json(ud / "settings.json", {})
        d = settings.get("downloadDir", "")
        if d and Path(d).exists():
            return d
    return str(Path.home() / "Downloads")


# ==========================================================================
# DBK 2026-11-08 断链修复：CDP 身份校验 + 多目录端口发现
#
# 背景：WorkBuddy / WorkBuddyAI 会占用 9222 / 9223 作为自己的 CDP 端口。
# 2026-11-08 二次迁移：三端口已迁到 3923x 冷门段，避开动态端口池；
# 下列身份校验继续保留，防止任何端口上再把别的 Electron 误认成管理器。
# 旧代码只要 /json/version 能返回 JSON 就认为「豆包管理器运行中」，于是把
# WorkBuddyAI 当成管理器，launch_manager() 直接返回，账号永远枚举为 0。
# 同时 DevToolsActivePort 可能是几周前的陈旧文件，端口早已不属于管理器。
# 这里统一按「CDP 里是否真的有豆包管理器主窗口 / doubao 账号页」来认亲。
# ==========================================================================
_DBK_CDP_PROBE_CACHE = {}
_DBK_CDP_RESOLVE_CACHE = {"ts": 0.0, "port": None}


# --------------------------------------------------------------------------
# DBK 2026-11-08 二次加固：端口占用检测 + CDP 顺延
#
# 背景：9222/9223/9230/9231/9333 全落在 Windows 动态端口池（本机 1024~15000），
# 连系统临时出站连接都可能随机占用。迁到 3923x 后概率已极低，再加两道保险：
#   * 桥接 bind 前 preflight：被别的程序占用时直接报出 PID / 进程名，而不是让
#     插件干等 20 秒超时后只说一句含糊的"启动超时"。
#     （桥接端口【不】静默顺延：宿主 main.py 按固定端口拼 URL，偷偷换端口会断链。）
#   * 管理器 CDP 启动前 pick：Chromium 遇到被占的 --remote-debugging-port
#     不会自己换端口，只会静默不开调试口 —— 正是本次断链的同型故障。
#     顺延后的真实端口由 Electron 写进 DevToolsActivePort，动态发现能读回。
# --------------------------------------------------------------------------
_DBK_CDP_FIRST = 39233
_DBK_CDP_SPAN = 8


def _dbk_cdp_port_candidates():
    """CDP 顺延段 39233~39240，与 config.json 的 cdp_port 一起构成候选集。"""
    return list(range(_DBK_CDP_FIRST, _DBK_CDP_FIRST + _DBK_CDP_SPAN))


# --------------------------------------------------------------------------
# 2026-11-14 单实例保护：点「测试连接」不再弹「程序已经在运行中，请勿重复启动」
#
# 实测 13:25 的进程时间线：13:25:37 / 13:25:41 连着 Popen 了两个带
# --remote-debugging-port=39233 的实例，13:25:50 卡密版自解包主进程才起来。
# 管理器带 requestSingleInstanceLock，第二个实例只会弹错误框后退出，
# 既带不起 CDP，还会挡住用户界面。结论：只要系统里已有管理器进程，
# 就绝不 Popen 第二个实例；CDP 没就绪就等着，不要靠重启去"修"。
# --------------------------------------------------------------------------
class ManagerAlreadyRunning(RuntimeError):
    """管理器进程已存在（或刚被拉起仍在启动中），本次跳过重复启动。"""

    def __init__(self, pids=None, note=""):
        self.pids = [int(p) for p in (pids or []) if p]
        self.note = note or ""
        detail = ("PID " + ",".join(str(p) for p in self.pids[:4])) \
            if self.pids else self.note
        super().__init__(
            "豆包管理器已在运行（%s），已跳过重复启动" % (detail or "启动中"))


_DBK_LAUNCH_STATE = {"ts": 0.0, "pid": 0}
_DBK_LAUNCH_COOLDOWN = 20.0
_DBK_PROC_SNAPSHOT = {"ts": 0.0, "pids": None}


def _dbk_launch_in_cooldown():
    """20 秒内刚 Popen 过 → 视为仍在启动中，禁止周期性/并发的第二次 Popen。"""
    try:
        return (time.time() - float(_DBK_LAUNCH_STATE.get("ts") or 0)
                < _DBK_LAUNCH_COOLDOWN)
    except Exception:
        return False


def _dbk_manager_process_pids(force=False, extra_names=()):
    """枚举系统里所有豆包管理器进程 PID。

    用 Win32 Toolhelp 快照（纯标准库、无外部进程、不受中文进程名编码影响，
    单次约 1ms）。Electron 子进程 / 自解包 runtime 副本同名，一并命中即可。
    返回：
      * [pid, ...]  检测到管理器进程
      * []          确认系统里没有管理器进程
      * None        检测本身失败（非 Windows / API 异常）——调用方保守处理
    """
    now = time.time()
    if not force:
        cached = _DBK_PROC_SNAPSHOT.get("pids")
        if cached is not None and now - float(_DBK_PROC_SNAPSHOT.get("ts") or 0) < 1.0:
            return list(cached)
    if os.name != "nt":
        return None
    names = {"豆包管理器.exe"}
    for n in extra_names:
        if n and str(n).lower().endswith(".exe"):
            names.add(str(n))
    try:
        import ctypes
        from ctypes import wintypes

        class PROCESSENTRY32W(ctypes.Structure):
            _fields_ = [
                ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.c_void_p),
                ("th32ModuleID", wintypes.DWORD),
                ("cntThreads", wintypes.DWORD),
                ("th32ParentProcessID", wintypes.DWORD),
                ("pcPriClassBase", ctypes.c_long),
                ("dwFlags", wintypes.DWORD),
                ("szExeFile", wintypes.WCHAR * 260),
            ]

        k32 = ctypes.windll.kernel32
        k32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
        k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        k32.Process32FirstW.argtypes = [wintypes.HANDLE,
                                        ctypes.POINTER(PROCESSENTRY32W)]
        k32.Process32FirstW.restype = wintypes.BOOL
        k32.Process32NextW.argtypes = [wintypes.HANDLE,
                                       ctypes.POINTER(PROCESSENTRY32W)]
        k32.Process32NextW.restype = wintypes.BOOL
        k32.CloseHandle.argtypes = [wintypes.HANDLE]
        snap = k32.CreateToolhelp32Snapshot(0x00000002, 0)  # TH32CS_SNAPPROCESS
        if not snap or snap == ctypes.c_void_p(-1).value:
            return None
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        pids = []
        try:
            ok = k32.Process32FirstW(snap, ctypes.byref(entry))
            while ok:
                name = str(entry.szExeFile or "")
                if name and (name in names or "豆包管理器" in name):
                    pids.append(int(entry.th32ProcessID))
                ok = k32.Process32NextW(snap, ctypes.byref(entry))
        finally:
            k32.CloseHandle(snap)
        _DBK_PROC_SNAPSHOT.update(ts=now, pids=list(pids))
        return pids
    except Exception:
        return None


def _dbk_port_available(host, port):
    """真 bind 一次才算空闲；connect 探测会漏掉只监听 0.0.0.0 的服务。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
        s.bind(("0.0.0.0" if host in ("", "0.0.0.0") else host, int(port)))
        return True
    except OSError:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


def _dbk_port_owner(port):
    """返回 "PID 进程名" 便于定位；纯标准库，拿不到返回空串，绝不影响主流程。"""
    try:
        out = subprocess.check_output(
            ["netstat", "-ano", "-p", "TCP"],
            stderr=subprocess.DEVNULL, timeout=3).decode("utf-8", "ignore")
        pids = set()
        for line in out.splitlines():
            parts = line.split()
            if len(parts) < 5 or parts[0].lower() != "tcp":
                continue
            if parts[3].upper() != "LISTENING":
                continue
            if parts[1].rsplit(":", 1)[-1] == str(port):
                pids.add(parts[4])
        names = []
        for pid in sorted(pids):
            try:
                tl = subprocess.check_output(
                    ["tasklist", "/FI", "PID eq %s" % pid, "/FO", "CSV", "/NH"],
                    stderr=subprocess.DEVNULL, timeout=3).decode("utf-8", "ignore")
                first = tl.strip().splitlines()[0] if tl.strip() else ""
                name = first.split('","')[0].strip('"') if '","' in first else ""
                names.append(("PID %s %s" % (pid, name)).strip())
            except Exception:
                names.append("PID %s" % pid)
        return ", ".join(names)
    except Exception:
        return ""


def _dbk_pick_cdp_port(preferred=None, host="127.0.0.1"):
    """给管理器挑可用 CDP 端口：管理器自己已占用则复用，否则顺延找空闲。"""
    base = int(preferred or DEFAULT_CONFIG.get("cdp_port") or _DBK_CDP_FIRST)
    cands = [base] + [p for p in _dbk_cdp_port_candidates() if p != base]
    for p in cands:
        if _dbk_cdp_probe(p):
            return p
        if _dbk_port_available(host, p):
            return p
    raise RuntimeError(
        "CDP 端口段 %d~%d 全被占用（%s）。请关闭占用程序或在插件设置里另填端口。"
        % (_DBK_CDP_FIRST, _DBK_CDP_FIRST + _DBK_CDP_SPAN - 1,
           _dbk_port_owner(base)))


def _dbk_preflight_bridge_port(host, port, service_id):
    """bind 前体检；被无关程序占用时抛带 PID / 进程名的清晰异常。"""
    port = int(port)
    if _dbk_port_available(host, port):
        return
    owner = _dbk_port_owner(port) or "未知进程"
    try:
        _opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with _opener.open(
                "http://127.0.0.1:%d/api/health" % port, timeout=1.5) as r:
            info = json.loads(r.read().decode("utf-8", "ignore") or "{}")
        if str(info.get("service") or "") == service_id:
            raise RuntimeError(
                "桥接端口 %d 上已有同款 %s 在运行，直接复用即可，不要重复启动。"
                % (port, service_id))
    except RuntimeError:
        raise
    except Exception:
        pass
    raise RuntimeError(
        "桥接端口 %d 已被其它程序占用（%s）。请关闭占用程序，或在插件设置里把"
        "桥接端口改成 %d / %d，并同步两个插件与设置区配置。"
        % (port, owner, port + 4, port + 5))


def _dbk_cdp_probe(port, timeout=1.2):
    """返回该端口是否属于豆包管理器。带 1.5 秒缓存，避免高频 HTTP 探测。"""
    try:
        port = int(port)
    except Exception:
        return False
    if port <= 0 or port > 65535:
        return False
    now = time.time()
    hit = _DBK_CDP_PROBE_CACHE.get(port)
    if hit and now - hit[0] < 1.5:
        return hit[1]
    ok = False
    try:
        targets = http_get_json(
            "http://127.0.0.1:%d/json/list" % port, timeout=timeout) or []
        if isinstance(targets, list):
            for t in targets:
                if not isinstance(t, dict):
                    continue
                title = str(t.get("title") or "")
                url = str(t.get("url") or "").lower()
                if ("豆包管理器" in title or "doubao.com" in url
                        or "dola" in url):
                    ok = True
                    break
    except Exception:
        targets = []
    if not ok:
        # 部分版本主窗口标题为空，用 /json/version 的 UA 兜底
        try:
            v = http_get_json(
                "http://127.0.0.1:%d/json/version" % port, timeout=timeout) or {}
            ua = str(v.get("User-Agent") or "")
            ok = "豆包管理器" in ua
        except Exception:
            pass
    _DBK_CDP_PROBE_CACHE[port] = (now, ok)
    return ok


def _dbk_userdata_candidates():
    """管理器 userData 候选目录（按优先级）。"""
    out = []
    appdata = os.environ.get("APPDATA", "")
    if appdata:
        out.append(Path(appdata) / "DoubaoAccountManager")   # 历史 Junction -> Data
        out.append(Path(appdata) / "豆包管理器")               # 新版本默认名
    try:
        exe = str(DEFAULT_CONFIG.get("manager_exe") or "")
        if exe:
            p = Path(exe)
            base = p if p.is_dir() else p.parent
            out.append(base / "Data")
            out.append(base / "userdata")
            out.append(base.parent / "userdata")
    except Exception:
        pass
    seen, result = set(), []
    for d in out:
        try:
            key = str(d).lower()
            if key in seen:
                continue
            seen.add(key)
            if d.exists():
                result.append(d)
        except Exception:
            pass
    return result


def find_manager_userdata():
    """优先返回带有效 DevToolsActivePort 的目录；否则返回第一个含 settings.json 的目录。"""
    cands = _dbk_userdata_candidates()
    for d in cands:
        f = d / "DevToolsActivePort"
        try:
            line = f.read_text(encoding="utf-8").splitlines()[0].strip()
            if _dbk_cdp_probe(int(line)):
                return d
        except Exception:
            pass
    for d in cands:
        if (d / "settings.json").exists() or (d / "accounts.json").exists():
            return d
    return cands[0] if cands else None


def read_cdp_port_from_userdata():
    """只返回「确实属于豆包管理器」的端口；陈旧/被别的 Electron 占用的一律丢弃。"""
    for d in _dbk_userdata_candidates():
        f = d / "DevToolsActivePort"
        try:
            line = f.read_text(encoding="utf-8").splitlines()[0].strip()
            port = int(line)
        except Exception:
            continue
        if _dbk_cdp_probe(port):
            return port
    return None


def _dbk_resolve_cdp_port(bridge=None, ttl=2.0):
    """统一解析 CDP 端口：缓存 > 桥接记录 > 配置 > DevToolsActivePort > 顺延段扫描。"""
    now = time.time()
    cached = _DBK_CDP_RESOLVE_CACHE["port"]
    if cached and now - _DBK_CDP_RESOLVE_CACHE["ts"] < ttl:
        return cached
    cands = []
    if bridge is not None:
        cands.append(getattr(bridge, "_cdp_port", None))
        cands.append(getattr(bridge, "cdp_port", None))  # 图片桥接把端口存在这里
        cfg = getattr(bridge, "config", None) or {}
        try:
            cands.append(cfg.get("cdp_port"))
        except Exception:
            pass
    cands.append(read_cdp_port_from_userdata())
    cands.append(DEFAULT_CONFIG.get("cdp_port"))
    cands.extend(_dbk_cdp_port_candidates())
    seen, first = set(), None
    for p in cands:
        try:
            p = int(p)
        except Exception:
            continue
        if p <= 0 or p > 65535 or p in seen:
            continue
        seen.add(p)
        if first is None:
            first = p
        if _dbk_cdp_probe(p):
            _DBK_CDP_RESOLVE_CACHE.update(ts=now, port=p)
            return p
    fallback = first or _DBK_CDP_FIRST
    _DBK_CDP_RESOLVE_CACHE.update(ts=now, port=fallback)
    return fallback



# ---------------------------------------------------------------------------
# 系统代理健康检测
#
# 豆包管理器里的账号页是 Electron <webview>，默认沿用 Windows 系统代理（WinINet）。
# 一旦系统代理开着（典型：Clash/Mihomo 的 127.0.0.1:7897）而代理软件没启动，
# 所有账号页请求 doubao.com 都会 -130:ERR_PROXY_CONNECTION_FAILED，
# 管理器表现为「账号加载失败 / 账号打不开」，桥接侧则表现为「账号全部不在线、
# 网页结构需要标定」。豆包是国产站点根本不需要代理，所以这里既能提前识别，
# 也能在启动管理器时直接绕开死代理。
# ---------------------------------------------------------------------------

def system_proxy_settings():
    """读取当前用户的 Windows 系统代理设置。

    返回 {enabled, server, override, auto}；非 Windows 或读取失败时降级读环境变量。
    """
    info = {"enabled": False, "server": "", "override": "", "auto": ""}
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")

        def _get(name):
            try:
                return winreg.QueryValueEx(key, name)[0]
            except Exception:
                return ""

        info["enabled"] = bool(_get("ProxyEnable"))
        info["server"] = str(_get("ProxyServer") or "")
        info["override"] = str(_get("ProxyOverride") or "")
        info["auto"] = str(_get("AutoConfigURL") or "")
    except Exception:
        pass
    if not info["server"]:
        for k in ("https_proxy", "HTTPS_PROXY", "http_proxy", "HTTP_PROXY"):
            v = os.environ.get(k, "")
            if v:
                info["server"] = v
                info["enabled"] = True
                break
    return info


def _split_proxy_server(server):
    """'127.0.0.1:7897' / 'http=1.2.3.4:8080;https=...' / 'http://host:port' → (host, port)"""
    s = (server or "").strip()
    if not s:
        return "", 0
    if "=" in s and "://" not in s:          # http=host:port;https=host:port
        s = s.split(";")[0].split("=", 1)[-1]
    if "://" in s:
        s = s.split("://", 1)[1]
    s = s.rstrip("/")
    if ":" not in s:
        return s, 0
    host, _, port = s.rpartition(":")
    try:
        return host.strip("[]"), int(port)
    except ValueError:
        return host.strip("[]"), 0


def _tcp_ok(host, port, timeout=1.5):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def proxy_reachable(server, timeout=1.5):
    """代理地址是否真的在监听。

    返回 True / False / None：
      None = 无法判定（环境本身在拦本地连接，例如沙箱/防火墙），此时不做任何处置。
    判定方法：先探代理端口；探不通时再探一个"确定在监听"的本地对照端口
    （管理器 CDP 端口）——对照端口也连不上，说明是环境在拦，不能据此说代理死了。
    """
    host, port = _split_proxy_server(server)
    if not host or not port:
        return None
    if _tcp_ok(host, port, timeout):
        return True
    try:
        ctrl = read_cdp_port_from_userdata() or 0
    except Exception:
        ctrl = 0
    if ctrl and ctrl != port and not _tcp_ok("127.0.0.1", ctrl, timeout):
        return None
    return False


def env_diagnostics():
    """环境自检：返回问题清单，每项 {level, code, message, fix}。

    目前覆盖：
      · proxy_unreachable —— 系统代理开着但端口没人监听（账号加载失败头号原因）
    """
    issues = []
    sp = system_proxy_settings()
    if sp["enabled"] and sp["server"]:
        if proxy_reachable(sp["server"]) is False:
            issues.append({
                "level": "error",
                "code": "proxy_unreachable",
                "message": (
                    f"系统代理 {sp['server']} 没有程序在监听，豆包管理器里所有账号页"
                    f"都会 -130:ERR_PROXY_CONNECTION_FAILED，表现为「账号加载失败」"),
                "fix": ("启动代理软件（Clash / Mihomo 等），或到 Windows「设置 → 网络和 Internet"
                        " → 代理」关掉「使用代理服务器」；豆包是国产站点，直连即可"),
            })
    return issues


def proxy_bypass_args():
    """系统代理确认不可达时，给 Electron 追加的启动参数（让管理器直连、不走死代理）。

    只有 proxy_reachable() 明确返回 False 才绕行；None（无法判定）时不动，
    避免误伤真正需要代理的环境。
    """
    sp = system_proxy_settings()
    if sp["enabled"] and sp["server"] and proxy_reachable(sp["server"]) is False:
        return ["--no-proxy-server"], sp["server"]
    return [], sp["server"]


# ---------------------------------------------------------------------------
# 管理器窗口还原（解决"窗口最小化导致所有 webview 变 hidden"）
# ---------------------------------------------------------------------------

_RAISE_TS = 0.0                 # 上次还原窗口的时间戳（全局节流，避免抢焦点刷屏）
_RAISE_LOCK = threading.Lock()

# 「强制全部 webview 参与渲染」的全局节流时间戳。
# 页内已有 setInterval 每秒自行兜底，这里只是防止管理器页面重载后失效，
# 所以间隔可以放宽；但绝不能只做一次——管理器刷新/重建 tab 会把注入冲掉。
_RENDERALL_TS = 0.0
_RENDERALL_LOCK = threading.Lock()

# 页面修复导航的串行锁。
# 2026-09-19 实测：半加载卡死的页面必须靠 Page.navigate 重新加载来修复，而多个
# webview 同时导航会互相抢带宽/渲染资源，是坏页面的主要来源（6 个并行时大量失败，
# 单发 6 秒成功、3 并发 6 秒 3/3 成功）。所以这里强制串行：同一时刻只允许一个
# 账号页面处于"重新导航"状态，其余排队等。代价是修复变慢，但成功率大幅提升，
# 总耗时反而更短（不用反复重试）。
#
# ⚠️ 但串行绝不能变成"排队死等"（2026-09-19 晚的并发卡死事故）：
#    一个账号的"修页面→进会话页→又坏→再修"循环会长时间占着这把锁，
#    其余账号全部阻塞在 acquire() 上，6 个任务集体卡在 preparing_page 不动，
#    从外面看就是"并发时全部卡住"。
#    所以持锁一律用 _nav_lock() 带超时获取：拿不到就放弃这次导航，回去走别的退路，
#    绝不无限期排队。
_NAV_LOCK = threading.Lock()

# 导航锁的排队上限（秒）。超过就直接放弃这次导航，避免整批任务被一个账号拖死。
_NAV_LOCK_WAIT = 20.0


# ---------------------------------------------------------------------------
# ★ 2026-11-03 根因修复：「无水印下载解析窗口」全局串行锁
# ---------------------------------------------------------------------------
# 事故现场：一次并发 5 个分镜，豆包侧 5 个视频全部生成完成，但只有 1 个回传到
# 字字动画。tasks.json 与下载目录实物显示：只有账号3 落盘了 video.mp4，其余 4 个
# 账号的「日期_账号名」目录全空；日志里这 4 个账号的按钮在
#   「无水印下载」→「解析中…」→「下载失败」 之间无限循环，
#   页面内 get_download_info 恒返回 code=0 / 接口没有返回下载地址。
#
# 根因：豆包管理器是**单进程 + 多 webview**，「无水印下载」按钮内部要走
#   message_id → message_node_info → get_download_info → 签发直链 → 下载落盘
# 这一整条异步链路。它一次只能可靠服务一个账号。而编排器的
# _run_collect_stage 只对**同一账号**的回收加锁（w._collect_lock），
# **跨账号完全并行**：5 个 worker 同时点按钮、同时发 get_download_info，
# 于是只有最先跑完的那一个能落盘，其余全部被挤成解析失败。
# 之后的 90s 看门狗又把 download_clicked/fg_attempts 无限重置，让这 4 个任务
# 永远挂在 generating 里反复重试、既不成功也不报错——这就是"修了很多次还出现"
# 的原因：历次补丁都在治回传阶段的症状（串片/水印/去重/目录/超时），从没串行化
# 这条解析链路。
#
# 修法：与上面 _NAV_LOCK 同一思路，用一个进程级互斥锁把「触发解析 → 等待落盘」
# 整段串行化。抢不到窗口的账号本轮**不做任何下载动作**（不点按钮、不发
# get_download_info），只保活排队；持锁者按时间片（默认 180s）独占，到期主动
# 让位，避免一个卡死的账号把其余 4 个全拖死。
_NOWM_WINDOW_LOCK = threading.Lock()
_NOWM_WINDOW_GUARD = threading.Lock()      # 只保护下面的 owner 字典读写
_NOWM_WINDOW_OWNER = {"tid": "", "worker": "", "until": 0.0}


def _nav_lock(timeout=None):
    """带超时地获取 _NAV_LOCK。

    返回 True=已持有（调用方必须在 finally 里 _NAV_LOCK.release()）；
    False=排队超时，本次导航应放弃（不是错误，走别的退路即可）。
    """
    return _NAV_LOCK.acquire(timeout=(_NAV_LOCK_WAIT if timeout is None else timeout))


def find_manager_hwnd(title_kw="豆包管理器"):
    """找豆包管理器主窗口句柄。找不到返回 0。

    ⚠️ 必须按窗口类名 Chrome_WidgetWin_1 过滤：桌面上往往还开着一个同名文件夹
    「豆包管理器-V2.0-完整便携版」（CabinetWClass，资源管理器窗口）。若按面积排序，
    管理器一最小化面积就变小，会被那个文件夹窗口顶掉，结果还原的是文件夹、页面
    仍然是 hidden。最小化的窗口 IsWindowVisible() 仍为 True，能正常命中。
    """
    try:
        import ctypes
        import ctypes.wintypes as wt
    except Exception:
        return 0
    try:
        u = ctypes.windll.user32
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
        exact, fallback = [], []

        def _cb(h, _l):
            try:
                n = u.GetWindowTextLengthW(h)
                if not n or not u.IsWindowVisible(h):
                    return True
                buf = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(h, buf, n + 1)
                if title_kw not in buf.value:
                    return True
                cls = ctypes.create_unicode_buffer(256)
                u.GetClassNameW(h, cls, 256)
                r = wt.RECT()
                u.GetWindowRect(h, ctypes.byref(r))
                area = abs(int(r.right) - int(r.left)) * abs(int(r.bottom) - int(r.top))
                hw = int(h) & 0xFFFFFFFF
                if cls.value == "Chrome_WidgetWin_1":
                    exact.append((area, hw))
                else:
                    fallback.append((area, hw))
            except Exception:
                pass
            return True

        u.EnumWindows(EnumWindowsProc(_cb), 0)
        if exact:
            return max(exact)[1]
        return max(fallback)[1] if fallback else 0
    except Exception:
        return 0


def raise_manager_window(title_kw="豆包管理器"):
    """把豆包管理器窗口还原（取消最小化）并置前。

    返回 (ok: bool, detail: str)。非 Windows 或找不到窗口时返回 False。
    """
    try:
        import ctypes
    except Exception:
        return False, "非 Windows 平台"
    try:
        hwnd = find_manager_hwnd(title_kw)
        if not hwnd:
            return False, f"未找到标题含「{title_kw}」的窗口"
        u = ctypes.windll.user32
        u.ShowWindow(hwnd, 9)          # SW_RESTORE：最小化时也还原
        u.SetForegroundWindow(hwnd)
        return True, f"hwnd={hwnd}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


# ---------------------------------------------------------------------------
# 极简 WebSocket 客户端（仅用于 CDP，标准库实现）
# ---------------------------------------------------------------------------

class WSClient:
    def __init__(self, ws_url, timeout=20):
        self.ws_url = ws_url
        m = re.match(r"ws://([^:/]+)(?::(\d+))?(/.*)", ws_url)
        if not m:
            raise ValueError(f"非法 ws 地址: {ws_url}")
        self.host = m.group(1)
        self.port = int(m.group(2) or 80)
        self.path = m.group(3)
        self.sock = socket.create_connection((self.host, self.port), timeout=timeout)
        self.sock.settimeout(None)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        handshake = (
            f"GET {self.path} HTTP/1.1\r\n"
            f"Host: {self.host}:{self.port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(handshake.encode("ascii"))
        # 读取握手响应
        resp = b""
        while b"\r\n\r\n" not in resp:
            chunk = self.sock.recv(1024)
            if not chunk:
                raise ConnectionError("WebSocket 握手失败：连接被关闭")
            resp += chunk
        if b"101" not in resp.split(b"\r\n", 1)[0]:
            raise ConnectionError(f"WebSocket 握手被拒: {resp[:120]!r}")
        self._id = 0
        self._id_lock = threading.Lock()
        # 发送锁：同一个 CDP 会话可能被两个线程同时使用（例如编排器线程做实时检测、
        # 回收线程做下载；或调度线程同步额度状态）。注入脚本这类大 payload 的
        # sendall 会分多次写，不加锁可能被另一线程的帧插进来，把 WS 流写坏。
        self._send_lock = threading.Lock()
        self._results = {}
        self._events = queue.Queue()
        self._closed = False
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()

    def _recvn(self, n):
        data = b""
        while len(data) < n:
            chunk = self.sock.recv(n - len(data))
            if not chunk:
                raise ConnectionError("WebSocket 连接已关闭")
            data += chunk
        return data

    def _read_loop(self):
        # 按 WebSocket 规范正确拼装消息：用 FIN 位判断一条消息是否结束，
        # 跨多个帧（opcode=0x0 续帧）的内容累加后，在最后一帧（FIN=1）才做 JSON 解析与分发。
        # 旧实现忽略 FIN 位、续帧只累加不分发，会把超过单帧的大 CDP 响应（pageInfo /
        # pageVideos / 大段 DOM）静默丢弃 → evaluate 卡超时 → 误判"视频还没生成"。
        frag = b""
        frag_op = 0
        while not self._closed:
            try:
                head = self._recvn(2)
            except Exception:
                self._closed = True
                self._events.put({"__ws_closed__": True})
                return
            b1, b2 = head[0], head[1]
            fin = (b1 & 0x80) != 0
            opcode = b1 & 0x0F
            length = b2 & 0x7F
            try:
                if length == 126:
                    length = struct.unpack(">H", self._recvn(2))[0]
                elif length == 127:
                    length = struct.unpack(">Q", self._recvn(8))[0]
                payload = self._recvn(length) if length else b""
            except Exception:
                # 连接被对端/close() 关闭后 socket 已失效，静默退出，不要刷异常栈
                self._closed = True
                self._events.put({"__ws_closed__": True})
                return
            if opcode == 0x9:  # ping → pong
                self._send_frame(0xA, payload)
                continue
            if opcode == 0x8:  # close
                self._closed = True
                self._events.put({"__ws_closed__": True})
                return
            if opcode == 0x0:  # 续帧：仅追加到缓冲
                frag += payload
            else:              # 0x1 文本 / 0x2 二进制：一条消息开始
                frag = payload
                frag_op = opcode
            if not fin:
                continue
            data = frag
            frag = b""
            if frag_op in (0x1, 0x2):     # 仅文本/二进制帧是 JSON 消息
                try:
                    msg = json.loads(data.decode("utf-8", errors="ignore"))
                except Exception:
                    continue
                if "id" in msg:
                    self._results[msg["id"]] = msg
                else:
                    self._events.put(msg)
            frag_op = 0

    def _send_frame(self, opcode, payload: bytes):
        header = bytes([0x80 | opcode])
        mask_bit = 0x80
        n = len(payload)
        if n < 126:
            header += bytes([mask_bit | n])
        elif n < 65536:
            header += bytes([mask_bit | 126]) + struct.pack(">H", n)
        else:
            header += bytes([mask_bit | 127]) + struct.pack(">Q", n)
        mask = os.urandom(4)
        header += mask
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        with self._send_lock:
            self.sock.sendall(header + masked)

    def send(self, method, params=None, timeout=60):
        with self._id_lock:
            self._id += 1
            mid = self._id
        msg = {"id": mid, "method": method, "params": params or {}}
        self._send_frame(0x1, json.dumps(msg).encode("utf-8"))
        deadline = time.time() + timeout
        while time.time() < deadline:
            if mid in self._results:
                r = self._results.pop(mid)
                if "error" in r:
                    raise RuntimeError(f"CDP {method} 错误: {r['error']}")
                return r.get("result", {})
            time.sleep(0.05)
        raise TimeoutError(f"CDP 调用超时: {method}")

    def events(self, max_wait=0.2):
        """取出当前缓冲的所有事件（非阻塞，最多等 max_wait 秒）。"""
        out = []
        deadline = time.time() + max_wait
        while True:
            try:
                timeout = max(0.01, deadline - time.time())
                out.append(self._events.get(timeout=timeout))
            except queue.Empty:
                break
            if time.time() >= deadline:
                break
        return out

    def close(self):
        self._closed = True
        try:
            self.sock.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# 管理器进程 + CDP 目标管理
# ---------------------------------------------------------------------------

class ManagerBridge:
    def __init__(self, config):
        self.config = config
        self._proc = None
        self._cdp_port = None
        self._ws = None            # 当前任务占用的 CDP 连接
        self._ws_target = None
        self._mp4_candidates = []  # 嗅探到的视频地址
        self._downloads = {}       # guid -> {name, state}（浏览器下载事件）
        self._lock = threading.Lock()
        # 账号序号缓存：{url_path: slot}，从豆包管理器主窗口 webview 元素顺序获取
        self._slot_map = {}          # normalized_url -> 账号序号
        self._slot_map_ts = 0.0      # 缓存更新时间
        self._slot_map_ttl = 15.0    # 缓存有效期（秒）

    # ---------- 进程 ----------

    def manager_running(self):
        # DBK: 必须验证 CDP 身份。端口可达 != 豆包管理器在运行。
        # 注意：进程存在但 CDP 还没就绪，不等于可以再启动一个实例。卡密版
        # 自解包约需 13 秒且带单实例锁，重拉只会弹「请勿重复启动」。
        # 「有没有进程」由 launch_manager() 里的 _dbk_manager_process_pids() 判定。
        port = _dbk_resolve_cdp_port(self)
        ok = _dbk_cdp_probe(port)
        if ok:
            self._cdp_port = port
        return ok

    def launch_manager(self):
        exe = self.config.get("manager_exe", "")
        if not exe:
            raise FileNotFoundError(
                "未配置豆包管理器路径，请在插件设置中填写 豆包管理器.exe 路径")
        # 设置里填的是【安装目录】而不是 exe 文件（很常见）。直接 Popen 一个目录
        # 在 Windows 上会得到 [WinError 5] 拒绝访问，表现为"自动启动管理器失败"
        # 反复刷屏、桥接只能等你手动打开管理器。这里自动补上主程序文件名。
        if Path(exe).is_dir():
            found = None
            try:
                exes = sorted(Path(exe).glob("*.exe"))
            except Exception:
                exes = []
            for f in exes:
                if "管理器" in f.stem:
                    found = f
                    break
            if found is None:
                skip = {"elevate", "uninstall", "unins000", "setup", "update"}
                for f in exes:
                    if f.stem.lower() not in skip:
                        found = f
                        break
            if found is None:
                raise FileNotFoundError(
                    f"豆包管理器目录里找不到可执行文件：{exe}")
            exe = str(found)
        if not Path(exe).exists():
            raise FileNotFoundError(
                f"找不到豆包管理器：{exe}，请在插件设置中填写正确的 豆包管理器.exe 路径")
        _xp = launch_mutex("video")
        _xp.acquire()
        try:
            if self.manager_running():
                return True
            # ★ 单实例硬闸门：管理器进程已存在时绝不 Popen 第二个实例。
            # 第二个实例会被管理器自己的单实例锁拦下并弹出错误框，且带不起 CDP。
            # 检测失败（None）时也不盲目重拉，交给冷却窗口兜住。
            _pids = _dbk_manager_process_pids(
                force=True, extra_names=(Path(exe).name,))
            if _pids:
                raise ManagerAlreadyRunning(_pids)
            if _dbk_launch_in_cooldown():
                raise ManagerAlreadyRunning(
                    [], note="进程检测不可用或刚拉起过，仍在启动中")
            # 启动前先挑一个真正空闲、且身份正确的 CDP 端口；Chromium 遇到被占
            # 端口不会顺延，只会静默不开调试口。顺延结果同步写回 config，Electron
            # 也会把它写进 DevToolsActivePort 供两套桥接动态发现。
            cdp = _dbk_pick_cdp_port(self.config.get("cdp_port"))
            if cdp != int(self.config.get("cdp_port") or 0):
                print(f"[doubao-bridge] CDP 端口 {self.config.get('cdp_port')} 不可用，"
                      f"自动顺延到 {cdp}")
            self.config["cdp_port"] = cdp
            self._cdp_port = cdp
            args = [
                exe,
                f"--remote-debugging-port={cdp}",
                "--remote-allow-origins=*",
            ]
            # 系统代理开着但端口没人监听时（Clash/Mihomo 没启动），Electron webview
            # 加载 doubao.com 必然 -130:ERR_PROXY_CONNECTION_FAILED，表现就是
            # "账号加载失败"。豆包是国产站点、无需代理，这里让管理器直接绕开系统代理。
            try:
                _bypass, _pxy = proxy_bypass_args()
                if _bypass:
                    args.extend(_bypass)
                    print(f"[doubao-bridge] 系统代理 {_pxy} 不可达，"
                          f"已用 --no-proxy-server 启动管理器（豆包直连）")
            except Exception:
                pass
            self._proc = subprocess.Popen(
                args,
                cwd=str(Path(exe).parent),
                creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                | getattr(subprocess, "CREATE_NO_WINDOW", 0),
                close_fds=True,
            )
            # 登记本次启动：_cycle(2s) / tick(3s) / HTTP 三处并发调用时，
            # 冷却窗口内一律不再 Popen，避免同一秒内连起两个实例。
            _DBK_LAUNCH_STATE.update(ts=time.time(),
                                     pid=int(self._proc.pid or 0))
            _DBK_PROC_SNAPSHOT.update(ts=0.0, pids=None)
            return True
        finally:
            _xp.release()

    def wait_cdp_ready(self, timeout=40):
        """等待管理器 CDP 端点可用，返回实际端口。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            port = _dbk_resolve_cdp_port(self)
            if _dbk_cdp_probe(port):
                self._cdp_port = port
                return port
            time.sleep(0.2)
        raise TimeoutError(
            "管理器调试端口未就绪。若你是手动打开的豆包管理器，请先完全关闭它再重试"
            "（桥接会自动以调试模式重启管理器，不影响账号登录状态）")

    # ---------- 目标 ----------

    def list_targets(self):
        # 多个 worker 各自持有 bridge 实例：优先读 DevToolsActivePort 实际端口，
        # 避免管理器调试端口顺延（专用端口被占）时连错
        port = _dbk_resolve_cdp_port(self)
        try:
            targets = http_get_json(f"http://127.0.0.1:{port}/json/list", timeout=5)
        except Exception:
            return []
        result = []
        for t in targets:
            if t.get("type") not in ("page", "webview"):
                continue
            result.append({
                "id": t.get("id"),
                "type": t.get("type"),
                "title": (t.get("title") or "").strip(),
                "url": t.get("url", ""),
                "ws": t.get("webSocketDebuggerUrl", ""),
            })
        return result

    def _normalize_url(self, url):
        """URL 规范化：取 path 部分（去掉 query/fragment/trailing slash），用于匹配 webview src 与 CDP target。"""
        if not url:
            return ""
        try:
            from urllib.parse import urlparse
            p = urlparse(url)
            path = p.path.rstrip("/")
            return (p.netloc + path) if path else p.netloc
        except Exception:
            return url.split("?")[0].split("#")[0].rstrip("/")

    def get_account_slot_map(self, force_refresh=False):
        """从豆包管理器主窗口读取账号序号映射。

        管理器主窗口里 <webview> 元素的顺序 = 账号管理页的账号顺序。
        返回 {normalized_url: slot}，slot 从 1 开始。结果缓存 15 秒。
        """
        now = time.time()
        if not force_refresh and self._slot_map and (now - self._slot_map_ts) < self._slot_map_ttl:
            return self._slot_map
        port = _dbk_resolve_cdp_port(self)
        try:
            targets = http_get_json(f"http://127.0.0.1:{port}/json/list", timeout=5) or []
        except Exception:
            targets = []
        manager = None
        for t in targets:
            if t.get("type") == "page" and "豆包管理器" in (t.get("title") or ""):
                manager = t
                break
        if not manager:
            return self._slot_map
        try:
            ws = WSClient(manager.get("webSocketDebuggerUrl", ""), timeout=5)
        except Exception:
            return self._slot_map
        try:
            ws.send("Runtime.enable")
            # ⚠️ 关键修正：必须用 webview.getURL()（当前地址）而不是 .src（初始地址）。
            # 豆包账号页在插件操作后会导航到 /chat/<会话id>，而 <webview>.src 是
            # 初始 src、不会随导航更新，于是 slot_map 的键停留在 "www.doubao.com"，
            # 与 CDP target 的 "www.doubao.com/chat/xxx" 永远匹配不上 → slot 全部为 0，
            # 只能按 CDP target 顺序兜底分配，而这个顺序会随 target 增删变化，
            # 直接导致"分发时叫账号3、完成日志却写账号1"的序号漂移。
            r = ws.send("Runtime.evaluate", {
                "expression": "(function(){var wvs=document.querySelectorAll('webview');"
                              "var arr=[];for(var i=0;i<wvs.length;i++){var u='';"
                              "try{if(wvs[i].getURL){u=wvs[i].getURL()||'';}}catch(e){u='';}"
                              "if(!u){u=(wvs[i].src||'');}"
                              "arr.push(String(u).split('?')[0].split('#')[0]);}"
                              "return JSON.stringify(arr);})()",
                "awaitPromise": True, "returnByValue": True,
            })
            val = r.get("result", {}).get("value", "")
            urls = json.loads(val) if val else []
        except Exception:
            urls = []
        finally:
            try: ws.close()
            except Exception: pass
        slot_map = {}
        for idx, u in enumerate(urls):
            slot_map[self._normalize_url(u)] = idx + 1
        self._slot_map = slot_map
        self._slot_map_ts = now
        return slot_map

    def list_accounts(self):
        """已打开的豆包账号 webview，附带与豆包管理器一致的账号序号 slot。"""
        accounts = []
        slot_map = self.get_account_slot_map()
        targets = self.list_targets()
        # 稳定身份：管理器 UUID 与账号手机号/备注，换账号或换顺序都能对上
        idents = refresh_account_identities(self)
        for t in targets:
            if "doubao.com" in t["url"] or "dola" in t["url"].lower():
                norm = self._normalize_url(t["url"])
                # 优先用主窗口 webview 序号；匹配不到则按 CDP target 顺序兜底
                t["slot"] = slot_map.get(norm, 0)
                info = idents.get(str(t.get("id") or "")) or {}
                t["uuid"] = info.get("uuid", "")
                t["account_name"] = info.get("name", "")
                t["stable_key"] = info.get("key", "")
                accounts.append(t)
        # 兜底：对 slot=0 的账号，按其在 targets 中的出现顺序分配连续序号
        zero_slots = [a for a in accounts if a["slot"] == 0]
        if zero_slots:
            used = {a["slot"] for a in accounts if a["slot"] > 0}
            next_slot = 1
            for a in zero_slots:
                while next_slot in used:
                    next_slot += 1
                a["slot"] = next_slot
                next_slot += 1
        return accounts

    # ---- 派发前的"轻量实时扫描"（2026-11-13）--------------------------------
    def live_accounts(self, timeout=2):
        """扫描豆包管理器里**当前此刻已打开**的豆包账号 target。

        与 list_accounts() 的区别：只读一次 CDP /json/list（一个 HTTP GET，
        不打开 WebSocket、不读主窗口 slot_map、不做 JS 求值），可以在用户点击
        "生成视频"的那一下同步执行而不拖慢派发。

        返回：list[dict]（成功，空列表=确实一个账号都没打开）；
              None（CDP 扫描失败，结果**未知**，调用方必须保留上一次名单，
                   不能把空结果误当成"账号全关了"）。
        """
        port = _dbk_resolve_cdp_port(self)
        try:
            targets = http_get_json(f"http://127.0.0.1:{port}/json/list", timeout=timeout)
        except Exception:
            return None
        if not isinstance(targets, list):
            return None
        out = []
        idents = account_identity_snapshot()
        for t in targets:
            if not isinstance(t, dict) or t.get("type") not in ("page", "webview"):
                continue
            url = t.get("url") or ""
            if "doubao.com" not in url and "dola" not in url.lower():
                continue
            tid = t.get("id")
            if not tid:
                continue
            info = idents.get(str(tid)) or {}
            out.append({
                "id": tid,
                "type": t.get("type"),
                "title": (t.get("title") or "").strip(),
                "url": url,
                "ws": t.get("webSocketDebuggerUrl", ""),
                "slot": 0,
                "uuid": info.get("uuid", ""),
                "account_name": info.get("name", ""),
                "stable_key": info.get("key", ""),
            })
        return out

    def live_account_ids(self, timeout=2):
        """live_accounts() 的 id 集合版本；扫描失败同样返回 None。"""
        accounts = self.live_accounts(timeout=timeout)
        if accounts is None:
            return None
        return {a["id"] for a in accounts}

    def _manager_page_target(self):
        """找到豆包管理器主窗口 page target（与豆包 webview 区分）。"""
        port = _dbk_resolve_cdp_port(self)
        try:
            targets = http_get_json(f"http://127.0.0.1:{port}/json/list", timeout=5) or []
        except Exception:
            return None
        for t in targets:
            if t.get("type") == "page" and "豆包管理器" in (t.get("title") or ""):
                return t
        return None

    def activate_manager_tab(self, token, timeout=25):
        """在豆包管理器窗口点击 token 对应账号的 tab，把该账号 webview 激活为活动标签。

        管理器是浏览器式多 tab：只有 .active 的 webview 才 visibility:visible 并接收
        真实键盘/鼠标输入，非活动标签页填提示词会失败。worker 先用 sessionStorage 写入
        唯一 token，这里通过 <webview>.executeJavaScript 逐页匹配 token，找到后点击对应
        button.browser-tab 激活。
        """
        mgr = self._manager_page_target()
        if not mgr:
            return {"ok": False, "reason": "manager_page_not_found"}
        ws = None
        try:
            ws = WSClient(mgr.get("webSocketDebuggerUrl", ""), timeout=timeout)
            ws.send("Runtime.enable")
            # 管理器 CSS：`.browser-stack webview { visibility: hidden }` +
            # `.browser-stack webview.active { visibility: visible }`。非活动 webview 被
            # Chromium 判为隐藏（不绘制/不跑 rAF/定时器降频），豆包 SPA 常不挂载编辑器
            # → 误报"需要标定"。旧实现还假设 webview[] 与 browser-tab[] 下标对齐，
            # 错位就点错 tab 且没有兜底。这里三级递进：已是前台 → 遍历点 tab（每次用
            # token 校验）→ 直接改 DOM 强制置为 active。
            js = (
                "(async function(){\n"
                "  var TOK = " + json.dumps(token) + ";\n"
                "  try {\n"
                "    var wvs = Array.from(document.querySelectorAll('webview'));\n"
                "    var tabs = Array.from(document.querySelectorAll('button.browser-tab'));\n"
                "    function clsOf(w){ var c = w.className; if (c && typeof c.baseVal === 'string') c = c.baseVal; return String(c||''); }\n"
                "    function isVis(w){ try { var s = getComputedStyle(w); return !!s && s.visibility !== 'hidden' && s.display !== 'none'; } catch(e){ return true; } }\n"
                "    async function tokenOf(w){ try { return await w.executeJavaScript('sessionStorage.getItem(\"__dbm_token\")'); } catch(e){ return null; } }\n"
                "    function activeIdx(){ for (var k=0;k<wvs.length;k++){ if (clsOf(wvs[k]).indexOf('active')>=0 && isVis(wvs[k])) return k; } return -1; }\n"
                "    var targetIdx = -1;\n"
                "    for (var i=0;i<wvs.length;i++){ if (await tokenOf(wvs[i]) === TOK) { targetIdx = i; break; } }\n"
                "    if (targetIdx < 0) return {ok:false, reason:'token_not_found', nWv:wvs.length, nTab:tabs.length};\n"
                "    if (activeIdx() === targetIdx) return {ok:true, index:targetIdx, wasAlreadyActive:true, method:'already'};\n"
                "    var order = [targetIdx];\n"
                "    for (var c=0;c<tabs.length;c++){ if (c!==targetIdx) order.push(c); }\n"
                "    for (var oi=0;oi<order.length;oi++){\n"
                "      var idx = order[oi];\n"
                "      if (tabs[idx]) { try { tabs[idx].click(); } catch(e){} }\n"
                "      await new Promise(function(r){ setTimeout(r,600); });\n"
                "      var ai = activeIdx();\n"
                "      if (ai >= 0 && await tokenOf(wvs[ai]) === TOK)\n"
                "        return {ok:true, index:targetIdx, wasAlreadyActive:false, method:'click', clicked:idx};\n"
                "    }\n"
                "    try {\n"
                "      for (var k=0;k<wvs.length;k++){\n"
                "        if (k === targetIdx){ wvs[k].classList.add('active'); wvs[k].style.visibility = 'visible'; }\n"
                "        else { wvs[k].classList.remove('active'); wvs[k].style.visibility = ''; }\n"
                "      }\n"
                "      for (var c2=0;c2<tabs.length;c2++){\n"
                "        if (c2 === targetIdx) tabs[c2].classList.add('active'); else tabs[c2].classList.remove('active');\n"
                "      }\n"
                "    } catch(e){ return {ok:false, reason:'force_exc:'+(e&&e.message), index:targetIdx}; }\n"
                "    await new Promise(function(r){ setTimeout(r,400); });\n"
                "    if (isVis(wvs[targetIdx]) && await tokenOf(wvs[targetIdx]) === TOK)\n"
                "      return {ok:true, index:targetIdx, wasAlreadyActive:false, method:'force'};\n"
                "    return {ok:false, reason:'activate_failed', index:targetIdx, nWv:wvs.length, nTab:tabs.length};\n"
                "  } catch(e){ return {ok:false, reason:'exc:'+(e&&e.message)}; }\n"
                "})()"
            )
            r = ws.send("Runtime.evaluate",
                        {"expression": js, "awaitPromise": True, "returnByValue": True},
                        timeout=timeout)
            # WSClient.send 已解包外层 result，evaluate 结构为 {result:{type,value}}
            return r.get("result", {}).get("value") or {"ok": False, "reason": "no_value"}
        except Exception as e:
            return {"ok": False, "reason": f"ws_error:{e}"}
        finally:
            if ws is not None:
                try:
                    ws.close()
                except Exception:
                    pass

    def force_render_all_webviews(self, timeout=20):
        """让管理器里**全部** webview 都参与合成（rAF 正常触发）。

        ★ 2026-09-19 晚定位：并发时"只有 1~2 个账号能进视频模式"的真正根因。
        管理器用 `.browser-stack webview{visibility:hidden}` +
        `.browser-stack webview.active{visibility:visible}` 只显示一个账号，
        其余 webview 被 Chromium 判为不合成 → **requestAnimationFrame 恒为 0fps**
        （实测：active 那个 76fps，其余 6 个 0fps）。

        guest 内部 `document.visibilityState` 仍是 visible、布局也正常，所以任何
        "页面可见性"检测都发现不了；但 React 挂载类 UI（豆包的"视频模式"）需要渲染
        帧，0fps 页面上永远挂不上来 → 点「视频生成」后主内容区被卸载且不再恢复 →
        `no_video_entry`。实测强制全渲染后 7/7 成功开启视频模式（此前 1/7）。

        做法：行内 `visibility:visible !important`（宿主选择器优先级更高，必须用行内
        !important 才盖得住）；非 active 的压到 opacity 0.02 并置于底层，用户看到的
        仍是当前 active 账号，视觉无变化。页内 setInterval 每秒兜底重施。

        返回 {"ok":bool, ...}。幂等，重复调用只会刷新一次。
        """
        mgr = self._manager_page_target()
        if not mgr:
            return {"ok": False, "reason": "manager_page_not_found"}
        ws = None
        try:
            ws = WSClient(mgr.get("webSocketDebuggerUrl", ""), timeout=timeout)
            ws.send("Runtime.enable")
            js = (
                "(function(){\n"
                "  function isActive(w){ var c = w.className;"
                " if (c && typeof c.baseVal === 'string') c = c.baseVal;"
                " return String(c||'').indexOf('active') >= 0; }\n"
                "  function apply(){\n"
                "    var wvs = document.querySelectorAll('webview');\n"
                "    for (var i=0;i<wvs.length;i++){\n"
                "      var w = wvs[i];\n"
                "      try{\n"
                "        // 行内 !important：宿主用的是更高优先级的选择器，\n"
                "        // 单纯注入 <style> 盖不住（实测注入样式表后 computed 仍为 hidden）。\n"
                "        w.style.setProperty('visibility','visible','important');\n"
                "        if (isActive(w)){\n"
                "          w.style.setProperty('opacity','1','important');\n"
                "          w.style.setProperty('z-index','99','important');\n"
                "        } else {\n"
                "          // 0.02 而不是 0：完全透明的元素可能被 Chromium 判定为不必绘制。\n"
                "          w.style.setProperty('opacity','0.02','important');\n"
                "          w.style.setProperty('z-index','0','important');\n"
                "        }\n"
                "      }catch(e){}\n"
                "    }\n"
                "    return wvs.length;\n"
                "  }\n"
                "  // React 重渲染会改回 class/内联样式，页内定时兜底\n"
                "  if (window.__dbmAllVisTimer) clearInterval(window.__dbmAllVisTimer);\n"
                "  var n = apply();\n"
                "  window.__dbmAllVisTimer = setInterval(apply, 1000);\n"
                "  var vis = Array.from(document.querySelectorAll('webview'))\n"
                "              .map(function(w){ return getComputedStyle(w).visibility; });\n"
                "  return {ok:true, n:n, visibility:vis};\n"
                "})()"
            )
            r = ws.send("Runtime.evaluate",
                        {"expression": js, "awaitPromise": True, "returnByValue": True},
                        timeout=timeout)
            return r.get("result", {}).get("value") or {"ok": False, "reason": "no_value"}
        except Exception as e:
            return {"ok": False, "reason": f"ws_error:{e}"}
        finally:
            if ws is not None:
                try:
                    ws.close()
                except Exception:
                    pass

    def open_all_accounts(self, timeout=60):
        """打开全部账号：交给插件根目录的 open_all_accounts.py 直连 CDP。

        旧实现靠点击界面文字为「打开」的按钮，但当前管理器渲染层没有该按钮，
        实测始终返回 opened=0。新实现走渲染层全局 window.openAccount(data-id)，
        幂等，已经打开的账号不会重复建标签。
        """
        try:
            import importlib.util
            _p = Path(__file__).resolve().parents[1] / "open_all_accounts.py"
            if not _p.exists():
                return {"ok": False, "reason": "missing_open_all_module:%s" % _p}
            _spec = importlib.util.spec_from_file_location(
                "dbm_open_all_accounts_bridge", str(_p))
            _mod = importlib.util.module_from_spec(_spec)
            _spec.loader.exec_module(_mod)
            r = _mod.open_all(
                cdp_port=int(self.config.get("cdp_port", 39233) or 39233),
                wait_cdp=12)
            # 兼容任务控制台旧字段 opened / total / note
            return {"ok": bool(r.get("ok")), "opened": r.get("opened", 0),
                    "total": r.get("total", 0), "after": r.get("after", 0),
                    "note": r.get("msg", ""), "reason": r.get("reason", "")}
        except Exception as e:
            return {"ok": False, "reason": "exc:%s" % e}
    def close_all_accounts(self, timeout=60):
        """关闭管理器中所有已打开的豆包账号 webview 标签。

        通过 CDP 注入 JS，逐个点击每个浏览器标签页的关闭按钮。
        """
        mgr = self._manager_page_target()
        if not mgr:
            return {"ok": False, "reason": "manager_page_not_found"}
        ws = None
        try:
            ws = WSClient(mgr.get("webSocketDebuggerUrl", ""), timeout=timeout)
            ws.send("Runtime.enable")
            js = (
                "(async function(){\n"
                "  try {\n"
                "    var wvs = Array.from(document.querySelectorAll('webview'));\n"
                "    var tabs = Array.from(document.querySelectorAll('button.browser-tab'));\n"
                "    var closed = 0;\n"
                "    // 从后往前关闭，避免索引变化影响后续操作\n"
                "    for (var i=tabs.length-1;i>=0;i--){\n"
                "      try { tabs[i].click(); closed++; await new Promise(function(r){setTimeout(r,500);}); }\n"
                "      catch(e){}\n"
                "    }\n"
                "    // 兜底：查找带关闭图标（×）的按钮\n"
                "    var closeBtns = Array.from(document.querySelectorAll('button[class*=close], button[class*=dismiss], [class*=close-btn]'));\n"
                "    for (var btn of closeBtns) {\n"
                "      var rect = btn.getBoundingClientRect();\n"
                "      if (rect.width > 0 && rect.height > 0) {\n"
                "        try { btn.click(); closed++; await new Promise(function(r){setTimeout(r,500);}); }\n"
                "        catch(e){}\n"
                "      }\n"
                "    }\n"
                "    return {ok:true, closed:closed, note:'关闭了 ' + closed + ' 个标签'};\n"
                "  } catch(e){ return {ok:false, reason:'exc:'+(e&&e.message)}; }\n"
                "})()"
            )
            r = ws.send("Runtime.evaluate",
                        {"expression": js, "awaitPromise": True, "returnByValue": True},
                        timeout=timeout)
            return r.get("result", {}).get("value") or {"ok": False, "reason": "no_value"}
        except Exception as e:
            return {"ok": False, "reason": f"ws_error:{e}"}
        finally:
            if ws is not None:
                try:
                    ws.close()
                except Exception:
                    pass

    def pick_target(self, account=""):
        accounts = self.list_accounts()
        if not accounts:
            return None
        if account:
            for t in accounts:
                if account in t["title"] or account in t["url"]:
                    return t
        # 默认优先视频创作页，其次任意豆包页（后续会自动点进视频模式）
        for t in accounts:
            if "video" in t["url"].lower():
                return t
        return accounts[0]

    # ---------- CDP 高阶操作 ----------

    def attach(self, target, download_dir=None):
        self.detach()
        ws = WSClient(target["ws"])
        ws.send("Runtime.enable")
        ws.send("Page.enable")
        ws.send("Network.enable")
        ws.send("DOM.enable")
        try:
            # 拦截原生文件选择框：任何触发文件对话框的操作都不会弹出系统窗口，
            # 避免 modal 对话框卡死页面；文件统一走 DOM.setFileInputFiles
            ws.send("Page.setInterceptFileChooserDialog", {"enabled": True})
        except Exception:
            pass
        try:
            ws.send("Page.bringToFront")  # 让后台/失焦的 webview 重新获得输入焦点
        except Exception:
            pass
        try:
            # 关键：管理器窗口在后台时 document.hasFocus()=false，Input.insertText 会被丢弃；
            # 用 CDP 焦点模拟让页面保持“已聚焦”，无需把管理器窗口抢到前台
            ws.send("Emulation.setFocusEmulationEnabled", {"enabled": True})
        except Exception:
            pass
        try:
            # 多账号并发关键：webview 处于后台标签页时 Chromium 会冻结/节流
            # （定时器、渲染、网络都被限制），导致页面加载极慢、自动化时序全乱。
            # 强制页面保持 active 生命周期，即使不是当前活动标签也正常渲染。
            ws.send("Page.setWebLifecycleState", {"state": "active"})
        except Exception:
            pass
        try:
            # 关键：点「无水印下载」时禁止弹"另存为"系统对话框（无人确认会永久挂起），
            # 自动落到配置的下载目录，回收端靠"新增 mp4 文件"检测成品。
            # 关键：点「无水印下载」时禁止弹"另存为"系统对话框（无人确认会永久挂起），
            # 自动落到配置的下载目录，回收端靠"新增 mp4 文件"检测成品。
            # download_dir 为空时回退到配置/自动探测的基础下载目录。
            dl_dir = download_dir or self.config.get("download_dir") or detect_download_dir()
            Path(dl_dir).mkdir(parents=True, exist_ok=True)
            ws.send("Page.setDownloadBehavior", {
                "behavior": "allow",
                "downloadPath": str(dl_dir).replace("/", "\\"),
                "eventsEnabled": True,
            })
        except Exception:
            pass
        self._ws = ws
        self._ws_target = target
        self._mp4_candidates = []
        self._downloads = {}        # guid -> {name, state}（浏览器下载事件）
        # 页面 <video> 正在播放的 src —— 一定是带水印预览流。
        # 2026-09-19 实测：最近 12 个任务里"网络嗅探到的下载地址"100% 都是这个，
        # 说明旧代码一直在把带水印预览流当无水印成品下载回传。
        self._preview_urls = set()
        # url -> {"attachment": bool, "mime": str}：Content-Disposition: attachment
        # 才是真正的"下载"响应，普通的 video/mp4 多半只是预览播放。
        self._mp4_meta = {}
        return ws

    def detach(self):
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass
        self._ws = None
        self._ws_target = None

    def drain_network_events(self):
        """收集网络事件里的视频地址与浏览器下载事件。"""
        if not self._ws:
            return
        for ev in self._ws.events():
            if ev.get("__ws_closed__"):
                raise ConnectionError("与管理器的调试连接断开")
            method = ev.get("method")
            params = ev.get("params") or {}
            if method == "Network.responseReceived":
                resp = params.get("response") or {}
                url = resp.get("url", "")
                mime = (resp.get("mimeType") or "").lower()
                headers = {str(k).lower(): str(v) for k, v in
                           (resp.get("headers") or {}).items()}
                cd = headers.get("content-disposition", "").lower()
                low = url.lower()
                # 无水印下载链接常是不带 .mp4 后缀的签名地址，靠 mime /
                # Content-Disposition attachment 兜底识别。
                # ⚠️ 这里只做宽采集：收进来的既有"无水印下载流"，也有页面 <video>
                #    的**带水印预览流**（2026-09-19 根因）。排除工作由使用方负责：
                #    必须先用 is_preview_video_url() 过滤掉 bridge._preview_urls
                #    里的地址，否则会把带水印预览当成品下载回传。
                is_video = (
                    ".mp4" in low or ".mov" in low
                    or mime.startswith("video/")
                    or ("attachment" in cd and (".mp4" in cd or "video" in cd
                                                or mime.startswith("video/")))
                )
                if url.startswith("http") and is_video:
                    if url not in [u for u, _ in self._mp4_candidates]:
                        self._mp4_candidates.append((url, time.time()))
                    # 记下这条响应到底是"下载"还是"预览播放"：
                    # Content-Disposition 带 attachment 才是真的下载动作；
                    # 只有 video/mp4 的通常是页面 <video> 的预览流（带水印）。
                    try:
                        meta = getattr(self, "_mp4_meta", None)
                        if meta is None:
                            meta = self._mp4_meta = {}
                        meta[url] = {"attachment": ("attachment" in cd),
                                     "mime": mime}
                    except Exception:
                        pass
            elif method == "Page.downloadWillBegin":
                guid = params.get("guid") or ""
                if guid:
                    self._downloads.setdefault(guid, {})
                    self._downloads[guid].update({
                        "name": params.get("suggestedFilename", ""),
                        "state": "inProgress",
                        "ts": time.time(),
                    })
            elif method == "Page.downloadProgress":
                guid = params.get("guid") or ""
                if guid:
                    d = self._downloads.setdefault(guid, {})
                    d["state"] = params.get("state", d.get("state", ""))
                    d["ts"] = time.time()

    def evaluate(self, expression, timeout=60):
        if not self._ws:
            raise RuntimeError("CDP 未连接")
        res = self._ws.send("Runtime.evaluate", {
            "expression": expression,
            "awaitPromise": True,
            "returnByValue": True,
            "timeout": timeout * 1000,
        }, timeout=timeout + 10)
        if "exceptionDetails" in res:
            detail = res["exceptionDetails"]
            raise RuntimeError(f"页面脚本异常: {detail.get('text')} {detail.get('exception', {}).get('description', '')[:300]}")
        return res.get("result", {}).get("value")

    def insert_text(self, text):
        """CDP 真实输入文本（TipTap/ProseMirror 等富文本编辑器可正确响应 beforeinput）。"""
        self._ws.send("Input.insertText", {"text": text})

    def mouse_move(self, x, y):
        """CDP 真实鼠标移动到指定坐标（触发 hover 态）。"""
        self._ws.send("Input.dispatchMouseEvent", {
            "type": "mouseMoved", "x": x, "y": y,
            "buttons": 0,
        })

    def mouse_move_path(self, x0, y0, x1, y1, steps=8, gap=0.025):
        """沿直线分多步移动鼠标（模拟真人轨迹）。

        hover 才触发的悬浮控件依赖连续的 mousemove/mouseover/mouseenter 事件链，
        单次瞬移有时不触发管理器的 hover 判定；分步移动保证事件链完整。
        """
        x0, y0, x1, y1 = float(x0), float(y0), float(x1), float(y1)
        for i in range(1, steps + 1):
            t = i / steps
            # 轻微非线性，更像真人
            t = t * t * (3 - 2 * t)
            self._ws.send("Input.dispatchMouseEvent", {
                "type": "mouseMoved",
                "x": round(x0 + (x1 - x0) * t, 1),
                "y": round(y0 + (y1 - y0) * t, 1),
                "buttons": 0,
            })
            time.sleep(gap)

    def mouse_click(self, x, y, button="left"):
        """CDP 真实鼠标点击（move → press → release），比 el.click() 更可靠触发 React 事件。"""
        self._ws.send("Input.dispatchMouseEvent", {
            "type": "mouseMoved", "x": x, "y": y, "button": button, "buttons": 0,
        })
        time.sleep(0.05)
        self._ws.send("Input.dispatchMouseEvent", {
            "type": "mousePressed", "x": x, "y": y, "button": button,
            "buttons": 1, "clickCount": 1,
        })
        time.sleep(0.05)
        self._ws.send("Input.dispatchMouseEvent", {
            "type": "mouseReleased", "x": x, "y": y, "button": button,
            "buttons": 0, "clickCount": 1,
        })

    def press_key(self, key, code, vk, modifiers=0):
        """发送真实按键（modifiers: 2=Ctrl）。"""
        for evt in ("keyDown", "keyUp"):
            self._ws.send("Input.dispatchKeyEvent", {
                "type": evt, "key": key, "code": code,
                "windowsVirtualKeyCode": vk, "modifiers": modifiers,
            })

    def select_all_and_delete(self):
        self.press_key("a", "KeyA", 65, modifiers=2)
        time.sleep(0.15)
        self.press_key("Delete", "Delete", 46)
        time.sleep(0.2)

    def press_enter(self):
        self._ws.send("Input.dispatchKeyEvent", {
            "type": "keyDown", "key": "Enter", "code": "Enter",
            "windowsVirtualKeyCode": 13, "nativeVirtualKeyCode": 13,
        })
        self._ws.send("Input.dispatchKeyEvent", {
            "type": "keyUp", "key": "Enter", "code": "Enter",
            "windowsVirtualKeyCode": 13, "nativeVirtualKeyCode": 13,
        })

    def _input_aliveness(self, nid):
        """判断 file input 是否"活"：(alive, in_editor)。

        alive=0  明确未连接 DOM 或被 disabled —— 死控件，调用方应排除；
        alive=1  正常，或无法判断（CDP 异常时保守保留候选，避免全过滤后无控件可用）；
        in_editor=True 控件位于聊天编辑器容器（form/contenteditable/composer 等）内。
        头像框、隐藏浮层、旧编辑器残留的 input 即使 accept=image/* 也会排在后面。
        """
        try:
            res = self._ws.send("DOM.resolveNode", {"nodeId": nid}, timeout=8)
            obj = res["object"]["objectId"]
        except Exception:
            return 1, False
        try:
            r = self._ws.send("Runtime.callFunctionOn", {
                "objectId": obj,
                "functionDeclaration": (
                    "function(){"
                    "if(!this.isConnected) return [0,false];"
                    "if(this.disabled) return [0,false];"
                    # 死控件：藏在已关闭的 radix 弹出层里（2026-10-15 实测豆包"+"菜单
                    # 的 input 祖先链含 pointer-events-none invisible h-0 w-0，
                    # setFileInputFiles 能成功但 React 永不受理）
                    "var d=this,dead=0;"
                    "for(var k=0;k<8&&d;k++){var dc=String(d.className||'');"
                    "if(dc.indexOf('pointer-events-none')>=0&&dc.indexOf('invisible')>=0){dead=1;break;}"
                    "d=d.parentElement;}"
                    "if(dead) return [0,false];"
                    "var ed=this.closest&&this.closest("
                    "\"#input-engine-container,[data-testid='chat_input'],"
                    "[class*='guidance-input'],[class*='input-engine'],"
                    "form,[contenteditable=true],[contenteditable='true'],"
                    "[class*='composer'],[class*='Composer'],[class*='editor'],[class*='Editor'],"
                    "[class*='chat-input'],[class*='ChatInput'],[class*='input-area'],"
                    "[class*='inputArea'],[class*='sender'],[class*='Sender']\");"
                    "return [1,!!ed];}"),
                "returnByValue": True,
            }, timeout=8)
            v = r.get("result", {}).get("value")
            if isinstance(v, list) and v:
                return int(v[0]) and 1, bool(v[1])
            return 1, False
        except Exception:
            return 1, False
        finally:
            try:
                self._ws.send("Runtime.releaseObject", {"objectId": obj}, timeout=5)
            except Exception:
                pass

    def _find_image_input_candidates(self):
        """遍历页面（含 shadow DOM）所有 input[type=file]，按“最可能是图片上传控件”排序返回候选 nodeId 列表。

        与 _find_image_input_node（只返回最佳一个）不同，这里返回【候选列表】，
        调用方会逐个尝试，任一控件能成功出缩略图即用。这样在豆包不同对话模式
        （视频生成模式、普通对话、深色浮层等）下都能找到正确的图片上传入口，
        不会因为选错控件（如视频上传框/头像上传框）导致 setFileInputFiles 白搭或塞错文件。

        评分优先级（列表从前到后）：
          1) accept 含图片且带 multiple —— 参考图要一次塞多张，必须多选
          2) accept 含图片（任意）
          3) 退化到未声明 accept 的 file input（明确仅接受视频的控件直接排除）
        豆包改版后 accept 常写成 image/* 或 image/png,image/jpeg，只认扩展名会漏掉；
        而页面上可能同时存在视频上传框、头像上传框等，选错控件会导致塞错文件。
        """
        ws = self._ws
        try:
            doc = ws.send("DOM.getDocument", {"depth": -1, "pierce": True})
            root = doc["root"]["nodeId"]
            q = ws.send("DOM.querySelectorAll", {"nodeId": root, "selector": "input[type=file]"})
        except Exception:
            return []
        node_ids = q.get("nodeIds", [])
        if not node_ids:
            return []
        img_multi, img_only, fallback = [], [], []
        for nid in node_ids:
            try:
                attrs = ws.send("DOM.getAttributes", {"nodeId": nid})
            except Exception:
                continue
            pairs = attrs.get("attributes", [])
            accept = ""
            multiple = False
            for i in range(0, len(pairs) - 1, 2):
                if pairs[i] == "accept":
                    accept = (pairs[i + 1] or "").lower()
                elif pairs[i] == "multiple":
                    multiple = True
            # 扩展名判定直接复用与页面 accept 对齐的白名单，避免「仅音频控件」
            # 换了 accept 写法（如只列 .wma/.amr/.aiff/.ac3）就被漏掉。
            is_image = (any(ext in accept for ext in IMAGE_ATTACHMENT_EXTS)
                        or "image/" in accept)
            is_audio = (any(ext in accept for ext in AUDIO_ATTACHMENT_EXTS)
                        or "audio/" in accept)
            is_video = any(x in accept for x in (".mp4", ".mov", ".webm", "video/", "video/*"))
            if is_video and not (is_image or is_audio):
                continue  # 明确仅视频的控件，排除
            # 死控件（未连接 DOM / disabled）直接排除；编辑器容器内的候选加权优先
            alive, in_editor = self._input_aliveness(nid)
            if not alive:
                continue
            rec = (nid, 1 if in_editor else 0)
            if (is_image or is_audio) and multiple:
                img_multi.append(rec)
            elif (is_image or is_audio):
                img_only.append(rec)
            elif not accept:
                fallback.append(rec)
        # 排序：图片+多选 > 仅图片 > 未限定文件类型；组内编辑器容器内的优先（稳定排序）
        def _ordered(recs):
            return [n for n, _ in sorted(recs, key=lambda r: -r[1])]
        return _ordered(img_multi) + _ordered(img_only) + _ordered(fallback)

    def _find_image_input_node(self):
        """兼容旧调用（及离线测试）：返回最佳候选，没有则返回 None。"""
        cands = self._find_image_input_candidates()
        return cands[0] if cands else None

    def upload_images(self, file_paths, progress=None, check_cancel=None):
        """限制上传并发并准备副本；等待槽位和传输期间都响应取消。

        file_paths 里可以混有参考音频，进度/错误文案统一按「附件 / 参考项」描述。
        """
        report = progress or (lambda msg: None)
        check = check_cancel or (lambda: None)
        check()
        if not file_paths or any(not p or not Path(p).is_file() for p in file_paths):
            return False, "参考项文件缺失，停止提交以免附件序号错位"
        report(f"等待附件上传通道（最多 2 个账号同时上传，{len(file_paths)} 个）")
        while not _UPLOAD_SLOTS.acquire(timeout=0.5):
            check()
        try:
            check()
            with tempfile.TemporaryDirectory(prefix="dbm-upload-") as tmp:
                try:
                    files, before, after = prepare_upload_images(file_paths, tmp, self.config)
                except Exception as exc:
                    return False, f"准备参考项上传副本失败：{exc}"
                report(f"附件上传体积：{before / 1048576:.2f} MB → {after / 1048576:.2f} MB"
                       "（原图未修改）")
                return self._upload_images(files, report, check)
        finally:
            _UPLOAD_SLOTS.release()

    def _reset_upload_input(self, node):
        # 删除 chip 不会清掉 FileList；同一批文件再次选择不触发 change。
        # 实测 CDP 设置 files=[] 仍无法可靠重置同文件选择；必须清原生 value。
        resolved = self._ws.send("DOM.resolveNode", {"nodeId": node}, timeout=15)
        obj = resolved["object"]["objectId"]
        try:
            result = self._ws.send("Runtime.callFunctionOn", {
                "objectId": obj,
                "functionDeclaration": "function(){this.value='';return this.files.length;}",
                "returnByValue": True,
            }, timeout=15)
            if result.get("exceptionDetails") or result.get("result", {}).get("value") != 0:
                raise RuntimeError("原生文件控件未能清空，不能可靠重试相同文件")
        finally:
            self._ws.send("Runtime.releaseObject", {"objectId": obj}, timeout=5)

    def _upload_images(self, file_paths, report, check):
        """上传全部参考项（参考图 + 参考音频）；仅在附件完整且上传结束后返回成功。"""
        ws = self._ws
        files = [os.path.abspath(p).replace("\\", "/") for p in file_paths if p and os.path.isfile(p)]
        if not files or len(files) != len(file_paths):
            return False, "参考项文件缺失，停止提交以免附件序号错位"

        def _env_hint():
            """上传失败时补一句环境原因，省得用户只看到"上传失败"四个字却不知为何。"""
            try:
                for it in env_diagnostics():
                    return f"；可能原因：{it['message']}（处理：{it['fix']}）"
            except Exception:
                pass
            return ""

        def _state():
            try:
                return self.evaluate("window.__dbm.attachmentState()") or {}
            except Exception as exc:
                return {"error": str(exc)[:200]}

        def _sleep(seconds):
            check()
            time.sleep(seconds)
            check()

        def _clear():
            # 清掉输入框里残留的附件（上一个任务/手动操作留下的 chip），避免旧图混入
            try:
                # clearAttachments 内部有 12s 硬时限；这里再给 25s 上限兜底，
                # 避免页面脚本异常时 awaitPromise 一直挂到默认 60s，把整批
                # 附件上传拖成超时失败（满配 9图+3音频时实测会卡住）。
                cleared = self.evaluate("window.__dbm.clearAttachments()", timeout=25) or {}
                if cleared.get("removed"):
                    _sleep(min(1.5, 0.4 * int(cleared.get("removed") or 1)))
                if cleared.get("left"):
                    raise RuntimeError(f"无法清空旧附件：仍有 {cleared['left']} 个")
            except TaskCancelled:
                raise
            except Exception:
                raise
            # 清空所有 file input 的残留文件，防止 fileCount 虚高导致 count 永远 ≠ 期望数。
            # React 上传成功后会清 input.files，但失败/中断的上传会残留；页面上常存在
            # 多个 file input（图片框/头像框/文档框），其他控件残留的文件会让
            # attachmentState 的 fileCount 虚高，count = max(chip, fileCount, img) 被拉高，
            # 出现 "7/3 张" 这种 false-positive → appeared 误判 → stable-wait 永远 == 不上。
            try:
                for nid in self._find_image_input_candidates():
                    try:
                        self._reset_upload_input(nid)
                    except Exception:
                        pass
            except TaskCancelled:
                raise
            except Exception:
                pass
            # 等附件区重渲染稳定，避免 setFileInputFiles 打到被 React 重建掉的旧 <input>
            _sleep(1.0)

        def _try_once():
            _clear()
            # 上传网络证据的时间基线（页面 performance 时钟）：此刻还没塞文件，
            # 之后出现的上传类请求必然由本次塞入触发。
            page_since_ms = 0
            try:
                page_since_ms = float(self.evaluate("performance.now()") or 0)
            except Exception:
                page_since_ms = 0.0
            self._attach_silent_secs = 0
            # 反复重试：React 重建 <input> 会让首轮 setFileInputFiles 静默丢失（chip 0 张）。
            # 每轮都重新查控件 + 重新塞文件，直到出现足量 chip 或次数耗尽。
            appeared = False
            last = {}
            # 候选列表：优先用多候选（逐个尝试），空了再退化到旧的单控件接口（兼容测试/特殊环境）。
            # 去掉视频模式后，上传入口在不同对话模式下可能不同，逐控件兜底能显著提高成功率。
            candidates = self._find_image_input_candidates()
            if not candidates:
                n = self._find_image_input_node()
                candidates = [n] if n else []
            if not candidates:
                return False, last, "页面上没找到附件上传控件（请确认豆包对话框有图片/音频参考项入口）"
            tried = set()
            for attempt in range(8):
                node = next((c for c in candidates if c not in tried), None)
                if node is None:
                    tried = set()           # 全部试过仍失败：重置后再来一轮（React 可能重建了新控件）
                    node = candidates[0]
                tried.add(node)
                try:
                    check()
                    self._reset_upload_input(node)
                    ws.send("DOM.setFileInputFiles", {"nodeId": node, "files": files}, timeout=15)
                except TaskCancelled:
                    raise
                except Exception as e:
                    last = {"count": 0, "error": str(e)}
                    report(f"设置上传文件失败（第 {attempt + 1} 次，控件 {node}）：{e}")
                    _sleep(1.0)
                    continue
                # ★ 2026-10-15：短窗口验证该控件是否真的被豆包受理。
                # fileCount 增长只代表文件被塞进了 input.files —— 页面上常存在多个
                # 图片类 input（头像框/隐藏浮层/旧编辑器残留），对"死控件"
                # setFileInputFiles 也能成功设置 files，但 React 不派上传请求。
                # 旧逻辑仅凭 fileCount 就判 appeared：第一个候选若是死控件，既不会
                # 换下一个候选，又要白等 45s 才失败（实测 10-15 00:40 多账号事故：
                # file=2 chip=0 img=0、网络 count=0，两轮都死在同一个控件上）。
                # 真受理信号（7s 内出现其一）：渲染层缩略图出现，或网络层已有
                # 上传类请求发出（请求发出即证明 React 的 onChange 已受理）。
                probe_to = time.time() + 7
                while time.time() < probe_to:
                    _sleep(0.7)
                    last = _state()
                    if last.get("failed"):
                        return False, last, f"附件上传失败（页面提示失败 {last.get('failed')} 个）"
                    _visual = max(int(last.get("cardCount", 0)),
                                  int(last.get("composerCount", 0)))
                    if _visual >= len(files):
                        appeared = True
                        break
                    try:
                        _net0 = self.evaluate(
                            "window.__dbm && window.__dbm.uploadNetEvidence ? "
                            "window.__dbm.uploadNetEvidence("
                            + str(int(page_since_ms)) + ", " + str(len(files)) + ") : null") or {}
                    except Exception:
                        _net0 = {}
                    if _net0.get("count"):
                        appeared = True
                        break
                if appeared:
                    break
                # 该控件 7s 内既无缩略图也无上传请求 = 死控件。
                # 必须清空刚塞进去的残留文件，否则 fileCount 虚高会污染后续候选的
                # 计数判定；然后立即换下一个上传控件，不再白等。
                try:
                    self._reset_upload_input(node)
                except Exception:
                    pass
                report(f"控件 {node} 未被豆包受理（7s 内无缩略图、无上传请求），"
                       f"换下一个上传控件（第 {attempt + 1}/{len(candidates)} 个）")
                _sleep(0.3)

            if not appeared:
                return False, last, ("豆包未受理附件（逐个尝试了页面上全部上传控件，"
                                     "7s 内均无缩略图、无上传网络请求）——"
                                     "等图片上传完成前绝不点发送，"
                                     f"页面状态: {json.dumps(last, ensure_ascii=False)[:120]}")

            # 慢上传继续等；不能用本地缩略图冒充服务器上传完成。
            # 2026-11-13：参考图上限从 4 放开到 9 后，固定 180 秒（按 4 张估的）
            # 会让多图还没传完就判超时；预算随张数线性增加，封顶 600 秒。
            _base_upload_to = max(30, float(self.config.get("upload_timeout_sec", 180)))
            _upload_to = min(600, _base_upload_to + max(0, len(files) - 4) * 12)
            deadline = time.time() + _upload_to
            stable = 0
            next_report = 0
            while time.time() < deadline:
                _sleep(1)
                last = _state()
                if time.time() >= next_report:
                    report(f"附件进度：{last.get('count', 0)}/{len(files)} 个，"
                           f"上传中 {last.get('uploading', 0)}，失败 {last.get('failed', 0)}"
                           + f"（chip={last.get('cardCount', 0)} file={last.get('fileCount', 0)} img={last.get('composerCount', 0)}）"
                           + (f"；页面读取异常：{last['error']}" if last.get('error') else ""))
                    next_report = time.time() + 15
                if last.get("failed"):
                    return False, last, f"附件上传失败（页面提示失败 {last.get('failed')} 个）"
                if last.get("broken"):
                    return False, last, f"附件上传失败（{last.get('broken')} 个附件卡未加载）"
                # 成功判定以渲染层为准：chip 或 composer img 数 == 期望且无上传中。
                # file input 残留文件不算成功信号——React 未处理时 files 会一直挂在
                # input 上，用 fileCount 判成功会把"文件塞进去了但页面没渲染"误判成已上传。
                # 但渲染层全为 0 时（React 上传完会清 input.files 并保留 chip）退回 file
                # input，cap 到期望数后判等，兼容页面渲染方式变化导致 chip/img 均扫不到的边角。
                # 再退一步用 count（cap），兼容旧 JS / 测试桩只返回 count 的情况。
                # ★ 2026-10-12 渲染层零证据时必须再拿出豆包侧网络层上传请求：
                #   实测 23:07 任务 chip=0 file=4 img=0、上传中 0 失败 0 全是"空真"
                #   （扫描对象根本不存在），判成功后点发送，消息永远停在 local_
                #   会话（submission_not_acknowledged）。fileCount 只是插件塞进去
                #   的文件数，不代表豆包受理；没有上传网络请求就不许点发送。
                _visual = max(int(last.get("cardCount", 0)), int(last.get("composerCount", 0)))
                _file_cnt = min(int(last.get("fileCount", 0)), len(files))
                if _visual > 0:
                    _effective = _visual
                elif _file_cnt > 0:
                    _effective = _file_cnt
                else:
                    _effective = min(int(last.get("count", 0)), len(files))
                if _effective == len(files) and not last.get("uploading"):
                    _net_tag = ""
                    if _visual <= 0:
                        _net = self.evaluate(
                            "window.__dbm && window.__dbm.uploadNetEvidence ? "
                            "window.__dbm.uploadNetEvidence("
                            + str(int(page_since_ms)) + ", " + str(len(files)) + ") : null") or {}
                        # 受理 = 至少 1 条上传请求完成，且满足其一：
                        #   enough  = 完成条数 >= 图片张数（逐条/并发上传直接判满）
                        #   settled = 最后一条上传请求完成后已静默 6s（批次结束）
                        _uptake = bool(_net.get("count")) and (
                            _net.get("enough") or _net.get("settled"))
                        if not _uptake:
                            stable = 0
                            _silent_for = getattr(self, "_attach_silent_secs", 0) + 1
                            self._attach_silent_secs = _silent_for
                            if _silent_for >= 45:
                                self._attach_silent_secs = 0
                                return False, last, (
                                    "豆包未受理附件（渲染层无附件卡、网络层无上传请求或上传未完成）——"
                                    "等图片上传完成前绝不点发送，已提前终止本轮上传，"
                                    f"网络证据: {json.dumps(_net, ensure_ascii=False)[:120]}，"
                                    f"页面状态: {json.dumps(last, ensure_ascii=False)[:120]}")
                            continue
                        _net_tag = (f"（豆包上传请求 x{_net.get('count')}"
                                    + ("，全部完成" if _net.get("enough")
                                       else "，上传批次已静默") + "）")
                    self._attach_silent_secs = 0
                    stable += 1
                    if stable >= 2:
                        names = last.get("names") or []
                        return True, last, f"已上传 {_effective} 个参考项{_net_tag}: {', '.join(names)[:140]}"
                else:
                    stable = 0
                    self._attach_silent_secs = 0
            return False, last, (f"附件上传后未确认（期望 {len(files)} 个，"
                                 f"页面检测到 count={last.get('count', 0)}（chip={last.get('cardCount', 0)}"
                                 f" file={last.get('fileCount', 0)} img={last.get('composerCount', 0)}），"
                                 f"上传中 {last.get('uploading', 0)} 个，"
                                 f"失败 {last.get('failed', 0)} 个）")

        ok, _last, detail = _try_once()
        if ok:
            return True, detail
        # 整轮重来一次：豆包偶发（代理抖动 / 接口 5xx / 页面重建 input）会把一整批图判失败，
        # 清空 chip 重塞往往能救回来；两次都失败才真报错。
        report(f"首轮上传未完成，重置文件控件后重试：{detail}")
        check()
        ok2, _last2, detail2 = _try_once()
        if ok2:
            return True, detail2 + "（第 1 轮失败，重试后成功）"
        return False, detail2 + _env_hint()

    def get_cookies_header(self):
        try:
            res = self._ws.send("Network.getAllCookies")
            cookies = res.get("cookies", [])
            return "; ".join(f"{c['name']}={c['value']}" for c in cookies)
        except Exception:
            return ""


# ---------------------------------------------------------------------------
# 页面自动化脚本（注入豆包页面执行；选择器来自 selectors.json）
# ---------------------------------------------------------------------------

def js_quote(s):
    return json.dumps(str(s), ensure_ascii=False)


# 深度检测扩展脚本：作为普通字符串拼接进注入脚本，避免 f-string 大括号转义出错。
# 背景：豆包成片并不一定以 document 顶层 <video src=...> 的形式存在，实测存在
#   · shadow DOM / 同源 iframe 内的播放器
#   · <video><source src=...></video>（v.src 为空）
#   · MediaSource / srcObject（v.src 为空）
#   · 只渲染封面，点击播放后才创建 <video>
# 旧的 pageVideos() 只查顶层 <video>.src，以上情况全部漏判，于是出现
# "豆包管理器里看得到成片、插件却一直报 0 个视频直到超时"。
_EXTRA_DETECT_JS = r"""
  // ===================== 深度视频检测（穿透 shadow DOM / iframe / source） =====================
  dbm._srcOf = (v) => {
    let s = "";
    try { s = v.currentSrc || v.src || ""; } catch (e) { s = ""; }
    if (!s) {
      try {
        const ss = v.querySelectorAll ? v.querySelectorAll("source") : [];
        for (let i = 0; i < ss.length; i++) {
          const u = ss[i].currentSrc || ss[i].src || "";
          if (u) { s = u; break; }
        }
      } catch (e) {}
    }
    if (!s) {
      try { s = v.getAttribute("data-src") || v.getAttribute("data-url") || ""; } catch (e) {}
    }
    return String(s || "");
  };
  dbm._deepRoots = () => {
    const roots = [{ root: document, where: "doc" }];
    try {
      const all = document.querySelectorAll("*");
      for (let i = 0; i < all.length; i++) {
        const e = all[i];
        try {
          if (e && e.shadowRoot) roots.push({ root: e.shadowRoot, where: "shadow:" + e.tagName });
        } catch (err) {}
      }
    } catch (err) {}
    const pushFrames = (doc, tag) => {
      let frs = [];
      try { frs = doc.querySelectorAll("iframe,frame"); } catch (e) { return; }
      for (let i = 0; i < frs.length; i++) {
        let d = null;
        try { d = frs[i].contentDocument; } catch (e) { d = null; }
        if (d) roots.push({ root: d, where: tag + ":frame" });
      }
    };
    pushFrames(document, "doc");
    return roots;
  };
  dbm._lastVideoEl = () => {
    let last = null;
    const rs = dbm._deepRoots();
    for (let i = 0; i < rs.length; i++) {
      let vs = [];
      try { vs = rs[i].root.querySelectorAll("video"); } catch (e) { continue; }
      for (let j = 0; j < vs.length; j++) last = vs[j];
    }
    return last;
  };
  dbm.deepVideos = () => {
    const out = [];
    const rs = dbm._deepRoots();
    for (let i = 0; i < rs.length; i++) {
      let vs = [];
      try { vs = rs[i].root.querySelectorAll("video"); } catch (e) { continue; }
      for (let j = 0; j < vs.length; j++) {
        const v = vs[j];
        out.push({
          where: rs[i].where,
          src: dbm._srcOf(v),
          w: v.videoWidth || 0,
          h: v.videoHeight || 0,
          dur: (isFinite(v.duration) ? v.duration : 0),
          rs: v.readyState || 0
        });
      }
    }
    return out;
  };
  // 页面资源时间线里的视频请求：既不依赖 <video> DOM，也不依赖 CDP Network 域，
  // 是页面自己记的账，CDP 断连/重连都不丢（页面刷新会清空，故按增量比对）。
  dbm.perfVideos = () => {
    try {
      const es = performance.getEntriesByType("resource") || [];
      const out = [];
      for (let i = 0; i < es.length; i++) {
        const n = String(es[i].name || "");
        const it = String(es[i].initiatorType || "");
        if (/\.(mp4|mov|m4v|webm|mkv)(\?|$)/i.test(n) || it === "video") {
          out.push({ name: n.slice(0, 240), init: it, t: Math.round(es[i].startTime || 0) });
        }
      }
      return out;
    } catch (e) { return []; }
  };
  // 结果卡片 UI 信号：即使 <video> 完全拿不到，只要出现"无水印下载/下载/重新生成"
  // 且页面不再显示"生成中/排队中"，就说明成片已经出来了。
  // 正则在字符串里最后一次出现的位置（没有则 -1）
  dbm._lastIdx = (s, re) => {
    let i = -1, m;
    const r = new RegExp(re.source, "g");
    while ((m = r.exec(s)) !== null) { i = m.index; if (m.index === r.lastIndex) r.lastIndex++; }
    return i;
  };
  // 豆包成片/生成中的文案
  dbm._DONE_RE = /你的视频生成好了|视频已生成|视频生成好了|生成好了|视频已生成完成/;
  dbm._PROG_RE = /预计等待|生成中|排队中|正在生成|生成进度|还需等待|排队等待/;
  // 页面文案状态机：比较"完成文案"与"进行中文案"在 innerText 里的先后位置。
  //
  // ⚠️ 绝不能用"全文是否包含'预计等待'"判断还在生成：豆包那条
  // "本次使用 Seedance 2.0 Fast 生成，预计等待 5 分钟"是**生成前的说明**，
  // 会永久留在对话里。实测线上日志就是被它坑了 —— progress 恒为 true，
  // 所有成片信号被永久屏蔽，片子生成好了也永远判不出来。
  // 对话文本按时间顺序排列，所以"完成文案出现在进行中文案之后"即代表已出片。
  dbm.textState = () => {
    let bt = "";
    try { bt = String((document.body ? document.body.innerText : "") || ""); } catch (e) {}
    const iDone = dbm._lastIdx(bt, dbm._DONE_RE);
    const iProg = dbm._lastIdx(bt, dbm._PROG_RE);
    let state = "none";
    if (iDone >= 0 && iDone > iProg) state = "done";
    else if (iProg >= 0) state = "progress";
    else if (iDone >= 0) state = "done";
    return { state: state, iDone: iDone, iProg: iProg,
             doneText: iDone >= 0 ? bt.substr(iDone, 24) : "" };
  };
  dbm.resultSignal = () => {
    let noWm = false, download = false, regen = false, progress = false, done = false;
    const hits = [];
    // ★★ 2026-11-03 v3 额度闸门（最高优先级，压过一切历史完成文案）：
    //   豆包回复「今日视频生成免费额度已用完。开通订阅畅享更多额度。」时，
    //   对话里往往还残留着上一轮「你的视频生成好了」。textState() 用全文
    //   innerText 找最后一次完成文案，会拿这条历史文案判成 done=true，
    //   于是 _video_evidence 的文案证据认定"已出片" → _mark_seedance_generated()
    //   把这次被拒绝的任务虚增一次生成，凑出「3/3 已满额」。
    //   额度文案是豆包侧的权威拒绝结论，必须优先于所有历史/进度信号：
    //   命中即强制 done=false / progress=false，并打上 quota 标志，Python 侧
    //   _video_evidence / _confirm_hit_concrete 据此一律不放行。
    let qe = null;
    try { qe = dbm.quotaExhausted(); } catch (e) {}
    if (qe) {
      return { noWm: false, download: false, regen: false,
               progress: false, done: false, quota: true,
               quotaText: String(qe).slice(0, 80),
               hits: ["quota:" + String(qe).slice(0, 24)] };
    }
    // ---- 1) 页面文案状态机（最可靠，直接来自豆包自己的回复）----
    let ts = { state: "none" };
    try { ts = dbm.textState(); } catch (e) {}
    if (ts.state === "done") { done = true; hits.push("text:" + (ts.doneText || "done")); }
    else if (ts.state === "progress") { progress = true; hits.push("text:progress"); }
    // ---- 2) 按钮/入口扫描 ----
    const roots = [document];
    try {
      const frs = document.querySelectorAll("iframe,frame");
      for (let i = 0; i < frs.length; i++) {
        try { if (frs[i].contentDocument) roots.push(frs[i].contentDocument); } catch (e) {}
      }
    } catch (e) {}
    const SEL2 = "button,a,[role='button'],[class*='download'],[class*='Download'],"
      + "[class*='watermark'],[class*='Watermark']";
    for (let r = 0; r < roots.length; r++) {
      let els = [];
      try { els = roots[r].querySelectorAll(SEL2); } catch (e) { continue; }
      for (let i = 0; i < els.length; i++) {
        const el = els[i];
        const hay = dbm._btnText(el);
        if (!hay) continue;
        // "下载电脑版/下载客户端"是豆包侧边栏常驻广告位，不是成片入口，必须排除
        if (dbm._isNoWatermarkEl(el)) { noWm = true; hits.push("nowm:" + hay.slice(0, 14)); }
        else if (/下载/.test(hay)
                 && !/加水印|水印设置|下载电脑版|下载客户端|下载豆包|下载[AD][Pp][Pp]/.test(hay)) {
          download = true; hits.push("dl:" + hay.slice(0, 14));
        }
        else if (/重新生成|再次生成|再来一次|重新编辑/.test(hay)) { regen = true; hits.push("regen:" + hay.slice(0, 14)); }
        if (/生成中|排队中|正在生成|还需等待|排队等待/.test(hay)) { progress = true; hits.push("prog:" + hay.slice(0, 14)); }
      }
    }
    return { noWm: noWm, download: download, regen: regen,
             progress: progress, done: done, hits: hits.slice(0, 16) };
  };
  // 把所有可滚动容器（含聊天列表）滚到底：豆包的结果卡片是懒加载的，
  // 不在可视区就只留一张封面 <img>，永远不会有 <video>。
  dbm.scrollToBottom = () => {
    let n = 0;
    try {
      const all = document.querySelectorAll("*");
      for (let i = 0; i < all.length; i++) {
        const e = all[i];
        try {
          if (e.scrollHeight - e.clientHeight > 16 && e.clientHeight > 80) {
            e.scrollTop = e.scrollHeight;
            n++;
          }
        } catch (err) {}
      }
    } catch (err) {}
    try { window.scrollTo(0, (document.body && document.body.scrollHeight) || 999999); } catch (e) {}
    try { window.scrollBy(0, 999999); } catch (e) {}
    return n;
  };
  // 定位成片卡片矩形（供 Python 侧 CDP hover 唤醒 <video> / 唤出悬浮下载条）
  //  1) 任意根里的 <video>
  //  2) 以"你的视频生成好了"为锚点，向上逐层扩大范围找视频卡片
  //  3) 视口里最大的 <img> 兜底
  dbm.videoCardRect = () => {
    const VIDEO_OK = (r) => r.width >= 100 && r.height >= 70;
    const pack = (by, r, extra) => ({
      found: true, by: by,
      x: Math.round(r.x), y: Math.round(r.y),
      w: Math.round(r.width), h: Math.round(r.height),
      cx: Math.round(r.x + r.width / 2), cy: Math.round(r.y + r.height / 2),
      rx: Math.round(r.x + r.width * 0.75), bry: Math.round(r.y + r.height * 0.82),
      extra: extra || ""
    });
    // 1) <video>
    let v = dbm._lastVideoEl ? dbm._lastVideoEl() : null;
    if (v) {
      const r = v.getBoundingClientRect();
      if (VIDEO_OK(r)) return pack("video", r, String(v.currentSrc || v.src || "").slice(0, 60));
    }
    const scan = (root) => {
      let out = null;
      let els = [];
      try {
        els = root.querySelectorAll(
          "video,img,[class*='video'],[class*='Video'],[class*='player'],[class*='Player']");
      } catch (e) { return null; }
      for (let i = 0; i < els.length; i++) {
        const el = els[i];
        const tn = el.tagName;
        const c = String(el.className || "");
        let score = 0;
        if (tn === "VIDEO") score = 100;
        else if (tn === "IMG") score = 30;
        else score = 5;
        if (/video|player/i.test(c)) score += 25;
        if (score < 30) continue;
        const r = el.getBoundingClientRect();
        if (!VIDEO_OK(r)) continue;
        if (!out || score > out.score) out = { score: score, r: r, tag: tn, cls: c.slice(0, 50) };
      }
      return out;
    };
    // 2) 锚点法
    let leaf = null;
    try {
      const all = document.querySelectorAll("*");
      for (let i = 0; i < all.length; i++) {
        const e = all[i];
        if (e.children && e.children.length) continue;
        if (dbm._DONE_RE.test(String(e.textContent || ""))) { leaf = e; break; }
      }
    } catch (e) {}
    let node = leaf;
    for (let k = 0; k < 12 && node; k++) {
      const hit = scan(node);
      if (hit) return pack("anchor:" + hit.tag, hit.r, hit.cls);
      node = node.parentElement;
    }
    // 3) 全局兜底：视口内最大的 img
    let best = null;
    try {
      const imgs = document.querySelectorAll("img");
      for (let i = 0; i < imgs.length; i++) {
        const r = imgs[i].getBoundingClientRect();
        if (!VIDEO_OK(r)) continue;
        if (r.bottom < 0 || r.top > (window.innerHeight || 900)) continue;
        if (!best || r.width * r.height > best.r.width * best.r.height) {
          best = { r: r, cls: String(imgs[i].className || "").slice(0, 50) };
        }
      }
    } catch (e) {}
    if (best) return pack("fallback:img", best.r, best.cls);
    return { found: false, reason: leaf ? "anchor_found_no_card" : "no_anchor" };
  };
  // 主动唤醒成片：滚到底 → 定位卡片 → 返回矩形（由 Python 侧 hover）
  dbm.revealVideo = () => {
    const n = dbm.scrollToBottom();
    const card = dbm.videoCardRect();
    card.scrolled = n;
    card.sig = dbm.resultSignal();
    return card;
  };
  // 一键诊断：超时前后把现场全部 dump 出来，下次再出问题可以直接定位。
  dbm.pageDiag = () => {
    let iframes = 0, shadowHosts = 0, canvas = 0, imgs = 0, videoLike = 0, nodes = 0;
    try {
      const all = document.querySelectorAll("*");
      nodes = all.length;
      for (let i = 0; i < all.length; i++) {
        const e = all[i];
        const tg = e.tagName;
        if (tg === "IFRAME" || tg === "FRAME") iframes++;
        else if (e.shadowRoot) shadowHosts++;
        else if (tg === "CANVAS") canvas++;
        else if (tg === "IMG") imgs++;
        const c = String(e.className || "");
        if (/video/i.test(c)) videoLike++;
      }
    } catch (e) {}
    const dv = dbm.deepVideos();
    let tail = "";
    try {
      const msgs = document.querySelectorAll(
        "[class*='message'],[class*='bubble'],[class*='assistant'],[class*='reply']");
      const last = msgs[msgs.length - 1];
      tail = last ? String(last.innerText || "").trim().slice(-160) : "";
    } catch (e) {}
    let bodyTail = "";
    try { bodyTail = String((document.body ? document.body.innerText : "") || "").trim().slice(-260); } catch (e) {}
    return {
      url: String(location.href).slice(0, 90),
      vis: String(document.visibilityState),
      nodes: nodes,
      plainVideo: dbm.q("video").length,
      deepVideo: dv.length,
      deepSrcs: dv.map(function (v) { return String(v.src || "(empty)").slice(0, 70); }).slice(0, 6),
      deepInfo: dv.map(function (v) { return v.where + "/" + v.w + "x" + v.h + "/rs" + v.rs; }).slice(0, 6),
      iframes: iframes, shadowHosts: shadowHosts, canvas: canvas, imgs: imgs, videoLike: videoLike,
      perf: dbm.perfVideos().slice(-4),
      sig: dbm.resultSignal(),
      tail: tail,
      bodyTail: bodyTail
    };
  };
"""

# 无水印直链自解析脚本（2026-10-12）：管理器注入的「无水印下载」按钮点击后
# 走 sendToHost("manager:no-watermark-download") 交给管理器渲染层/主进程下载，
# 插件侧既看不到它的 fetch，也拿不到它的下载产物 —— 线上实测悬停/点击 24 轮
# 无一产出（视频早已生成，管理器按钮的 IPC 链路对插件不可达）。
# 这里按管理器 runtime-resolver（解密后）的解析链路在插件内复刻一份兜底：
#   最后视频卡片的 React fiber props 提取 node_id →
#   POST /samantha/aispace/get_download_info {requests:[{node_id}]} →
#   取 main_url，且必须通过"确认无水印"校验（download=true + video_mp4）。
# 普通字符串拼接（非 f-string），避免大段 JS 大括号转义出错。
_NO_WM_RESOLVER_JS = r"""
  // ===================== 无水印直链自解析（官方创作中心主链路，2026-11-03 v2） =====================
  // 深度逆向官方 runtime-resolver 后重写。官方「无水印下载」按钮的真实解析主链路是
  // 【创作中心】：homepage → node_info(分页) → node_lastest_used → 按页面可见封面 /
  // messageId / creationTaskId 对齐出「真实 asset node_id」→ get_download_info →
  // 官方无水印直链。message_node_info 只是官方 F() 里 V() 全部失败后的【最后兜底】。
  // 旧插件把 message_node_info 当主链路、并把 fiber 里的 message/block id 直接喂给
  // get_download_info，恒返回 code=0 无地址 —— 这正是自解析 317 连败 / 0 成功的根因。
  // 本函数完全在页面内用「当前 webview 自己的 Cookie」调 samantha API，因此每个豆包
  // 账号天然拥有独立解析通道，可并发，不依赖管理器 IPC / 全局下载窗口锁。
  dbm.resolveNoWmViaApi = async () => {
    if (!/(^|\.)doubao\.com$/i.test(location.hostname)) return { ok: false, error: "not_doubao" };
    const isNum = (s) => /^\d{8,}$/.test(String(s == null ? "" : s));
    const uniq = (arr, n) => {
      const s = new Set(), o = [];
      for (const v of arr) { const k = String(v); if (k && !s.has(k)) { s.add(k); o.push(k); } if (o.length >= n) break; }
      return o;
    };
    const uniqBy = (arr, key, n) => {
      const s = new Set(), o = [];
      for (const it of arr) { const k = String(it && it[key] || ""); if (k && !s.has(k)) { s.add(k); o.push(it); } if (o.length >= n) break; }
      return o;
    };
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const cleanUrl = (t) => {
      if (typeof t !== "string") return "";
      const e = t.trim().replace(/\\u0026/g, "&").replace(/&amp;/g, "&");
      return /^https?:\/\//i.test(e) ? e : "";
    };
    // 官方 v(t)：复用页面实际请求过的 samantha URL（含可能必需的签名 query），
    // 避免硬编码相对路径丢参数导致接口返回 code!=0 / 空数据。
    const apiUrl = (p) => {
      const e = String(p || "");
      if (/^https?:\/\//i.test(e)) return e;
      try {
        const rs = performance.getEntriesByType?.("resource") || [];
        for (const n of rs.slice().reverse()) {
          const nm = String(n.name || "");
          if (nm.includes(e)) return nm;
        }
        const hit = rs.slice().reverse().find((n) => /\/samantha\//.test(String(n.name || "")));
        if (hit && hit.name) { const u = new URL(hit.name); u.pathname = e; return u.href; }
      } catch (e2) {}
      return e;
    };
    const postJson = async (p, body) => {
      const r = await fetch(apiUrl(p), {
        method: "POST",
        headers: {
          accept: "application/json",
          "content-type": "application/json",
          "agw-js-conv": "str",
          origin: location.origin,
          referer: location.href
        },
        credentials: "include",
        body: JSON.stringify(body || {})
      });
      return await r.json();
    };
    // 官方 U(t)：确认无水印下载流校验（比旧 okUrl 更宽，覆盖全部官方确认流）
    const okUrl = (u) => {
      const e = String(u || "").toLowerCase();
      if (!e) return false;
      try {
        const t = new URL(u, location.href);
        const q = t.searchParams.get("download");
        if (/(^|[.-])videoweb-download\.doubao\.com$/i.test(t.hostname) && q === "true") return true;
        if (/(^|[.-])videoweb\.doubao\.com$/i.test(t.hostname) && q === "true") return true;
        if (t.hostname.includes("doubao.com") && t.pathname.includes("/download") && q === "true") return true;
        // 管理器实测：真实下载直链也落在 vXX-vdl.doubao.com（与预览流同族域名）
        if (/(^|[.-])v\d+-vdl\.doubao\.com$/i.test(t.hostname) && q === "true") return true;
      } catch (e2) {}
      return /download=true/.test(e) && /video_mp4|mime_type=video_mp4/.test(e);
    };
    // 递归扫整份响应找官方直链（响应体结构变化时兜底）
    const findOfficial = (obj, d) => {
      if (!obj || d > 7) return "";
      if (typeof obj === "string") return okUrl(obj) ? obj : "";
      if (typeof obj !== "object") return "";
      if (Array.isArray(obj)) { for (const it of obj) { const r = findOfficial(it, d + 1); if (r) return r; } return ""; }
      try { for (const k in obj) { const r = findOfficial(obj[k], d + 1); if (r) return r; } } catch (e2) {}
      return "";
    };
    // 官方 j(t)：get_download_info → 确认无水印直链（保留响应体做 findOfficial 兜底）
    const downloadInfo = async (nid) => {
      const id = String(nid || "").trim();
      if (!isNum(id)) throw new Error("缺少作品节点ID");
      const j = await postJson("/samantha/aispace/get_download_info", { requests: [{ node_id: id }] });
      const code = (j && typeof j.code !== "undefined") ? j.code : "none";
      const di = ((j.data || {}).download_infos || [])[0] || {};
      let main = String(di.main_url || di.mainUrl || "");
      const backup = String(di.backup_url || di.backupUrl || "");
      if (!main || !okUrl(main)) { const hit = findOfficial(j, 0); if (hit) main = hit; }
      if (!main) throw new Error("接口没有返回下载地址(code=" + code + ")");
      if (!okUrl(main)) throw new Error("接口返回的不是确认无水印下载流");
      return { mainUrl: main, backupUrl: backup, nodeId: id, code: code };
    };
    // 官方 S(t)：封面 URL 归一化 key（按页面可见封面对齐创作中心节点）
    const coverKey = (raw) => {
      const u = cleanUrl(raw);
      if (!u) return "";
      try {
        const t = new URL(u, location.href);
        return decodeURIComponent(t.pathname).replace(/~[^/]*$/, "").toLowerCase();
      } catch (e2) {
        return u.split("?")[0].replace(/~[^/]*$/, "").toLowerCase();
      }
    };
    const visibleCoverKeys = (max) => {
      const lim = max || 30, out = [];
      try {
        const els = Array.from(document.querySelectorAll("img,video,source"));
        for (const o of els) {
          let ss = "";
          try { ss = String(o.srcset || o.srcSet || "").split(",")[0].trim().split(/\s+/)[0]; } catch (e2) {}
          const cands = [o.currentSrc, o.src, o.poster, ss];
          for (const c of cands) {
            const k = coverKey(c);
            if (k && /tos-cn-p-9ecd54|tplv-noop|videoweb/i.test(String(c || ""))) out.push(k);
          }
          if (out.length >= lim) break;
        }
      } catch (e2) {}
      return uniq(out, lim);
    };
    // 官方 C(t)：递归从创作中心响应提取视频节点
    const collectNodes = (t, out, seen, d) => {
      if (d > 10 || !t || typeof t !== "object" || seen.has(t)) return;
      seen.add(t);
      try {
        const r = (t.id != null) ? String(t.id) : "";
        const key = (t.key != null) ? String(t.key) : "";
        const name = (t.name != null) ? String(t.name) : "";
        if (isNum(r) && (key || name || t.node_type || t.nodeType)) {
          const covers = [];
          const nc = t.node_cover || t.nodeCover || {};
          const lv = nc && (nc.list_view || nc.listView);
          const tv = nc && (nc.thumbnail_view || nc.thumbnailView);
          const cu1 = lv && (lv.cover_url || lv.coverUrl);
          const cu2 = tv && (tv.cover_url || tv.coverUrl);
          if (cu1) covers.push(String(cu1));
          if (cu2) covers.push(String(cu2));
          const ct = t.content || {};
          out.push({
            id: r,
            key: key,
            name: name,
            nodeType: Number(t.node_type || t.nodeType || 0),
            messageId: String(ct.message_id_str || ct.message_id || t.message_id_str || t.message_id || ""),
            creationTaskId: String(ct.creation_task_id_str || ct.creation_task_id || t.creation_task_id_str || ""),
            coverKeys: uniq(covers.map(coverKey).filter(Boolean), 8)
          });
        }
      } catch (e2) {}
      try {
        if (Array.isArray(t)) { for (const v of t) collectNodes(v, out, seen, d + 1); }
        else { for (const v of Object.values(t).slice(0, 160)) if (v && typeof v === "object") collectNodes(v, out, seen, d + 1); }
      } catch (e2) {}
    };
    const isVideoNode = (n) => !!n && (6 === n.nodeType || /^v\d/i.test(String(n.key || "")) || /\.mp4$/i.test(String(n.name || "")));
    // 官方 N()：创作中心主链路 homepage → node_info(分页) → node_lastest_used
    const creationCenterNodes = async (diag) => {
      let nodes = [];
      try {
        const hp = await postJson("/samantha/aispace/homepage", {});
        if (!hp || hp.code !== 0) { diag.ccCodes.push("homepage:code=" + (hp && hp.code)); return nodes; }
        diag.ccCodes.push("homepage:0");
        const cats = [];
        collectNodes(hp.data || hp, cats, new WeakSet(), 0);
        let root = cats.find((n) => /我的创作/.test(String(n.name || "")))
          || cats.find((n) => 1 === n.nodeType && n.key === n.id)
          || cats[0];
        if (!root || !root.id) { diag.ccCodes.push("no_creation_root"); }
        else {
          const collected = [];
          let cursor = "";
          for (let page = 0; page < 6; page++) {
            const body = {
              node_id: root.id,
              need_full_path: true,
              sort_param: { need_sort_config: true, sort_order: 1, sort_type: 0 },
              size: 50
            };
            if (cursor) { body.cursor = cursor; body.next_cursor_with_sort = cursor; }
            const r = await postJson("/samantha/aispace/node_info", body);
            const d = (r && r.data) ? r.data : {};
            collectNodes(r.data || r, collected, new WeakSet(), 0);
            diag.ccCodes.push("node_info:" + page + ":" + (r && r.code));
            cursor = String(d.next_cursor || d.nextCursor || "");
            if (!d.has_more || !cursor) break;
            if (collected.some(isVideoNode)) break;
          }
          nodes = uniqBy(collected, "id", 200);
          // node_lastest_used 兜底（node_info 未返回任何视频节点时）
          if (!nodes.some(isVideoNode)) {
            for (const b of [{ nodeType: 6, size: 50 }, { node_type: 6, size: 50 }]) {
              try {
                const r = await postJson("/samantha/aispace/node_lastest_used", b);
                const tmp = [];
                collectNodes(r.data || r, tmp, new WeakSet(), 0);
                const vids = uniqBy(tmp.filter(isVideoNode), "id", 10);
                if (vids.length) { nodes = vids.concat(nodes); diag.ccCodes.push("latest_used:hit"); break; }
                diag.ccCodes.push("latest_used:empty");
              } catch (e2) { diag.ccCodes.push("latest_used:err"); }
            }
          }
        }
      } catch (e2) {
        diag.ccCodes.push("cc_err:" + String((e2 && e2.message) || e2).slice(0, 60));
      }
      return nodes;
    };

    // ---- 1) 采集当前会话页面里的 id 信号（fiber + DOM） ----
    const ids = [], msgIds = [], taskIds = [];
    const idSeen = new Set(), msgSeen = new Set(), taskSeen = new Set();
    const addId = (s) => { const k = String(s == null ? "" : s); if (isNum(k) && !idSeen.has(k)) { idSeen.add(k); ids.push(k); } };
    const addMsg = (s) => { const k = String(s == null ? "" : s); if (k && !msgSeen.has(k)) { msgSeen.add(k); msgIds.push(k); } };
    const addTask = (s) => { const k = String(s == null ? "" : s); if (k && !taskSeen.has(k)) { taskSeen.add(k); taskIds.push(k); } };
    const nodeKey = /(^|_|\b)(node_id|nodeid|node_id_str|nodeidstr|asset_id|assetid|creation_id|creationid|material_id|materialid|video_id|videoid|media_id|mediaid|file_id|fileid|object_id|objectid|target_id|targetid)(_|$|\b)/i;
    const msgKey = /(^|_|\b)(message_id|messageid|message_id_str|messageidstr|msg_id|msgid|reply_id|replyid|section_id|sectionid|conversation_id|conversationid|chat_id|chatid)(_|$|\b)/i;
    const taskKey = /(^|_|\b)(creation_task_id|creationtaskid|creation_task_id_str|task_id|taskid|task_id_str)(_|$|\b)/i;
    const scanIds = (obj, d, seen) => {
      if (!obj || typeof obj !== "object" || d > 9 || seen.has(obj)) return;
      seen.add(obj);
      try {
        const hint = Object.keys(obj).join(",").toLowerCase();
        const maybeNode = /video|creation|material|asset|media|node|content|生成|作品/i.test(hint);
        for (const [k, v] of Object.entries(obj).slice(0, 220)) {
          if (typeof v === "string" || typeof v === "number") {
            const sv = String(v);
            if (nodeKey.test(k) && isNum(sv)) addId(sv);
            if (msgKey.test(k)) addMsg(sv);
            if (taskKey.test(k)) addTask(sv);
            if (k === "id" && isNum(sv) && maybeNode) addId(sv);
            if (k === "key" && /^v\d/i.test(sv) && isNum(String(obj.id || ""))) addId(obj.id);
          } else if (v && typeof v === "object") {
            scanIds(v, d + 1, seen);
          }
        }
      } catch (e2) {}
    };
    const fiberProps = (el) => {
      const props = [];
      let node = el;
      for (let up = 0; node && up < 8; up++) {
        try {
          const fk = Object.keys(node).find((k) => k.indexOf("__reactFiber") === 0 || k.indexOf("__reactProps") === 0);
          if (fk) {
            let f = node[fk];
            for (let d = 0; f && d < 70; d++) {
              const p = f.memoizedProps || f.pendingProps || {};
              if (f.memoizedProps && typeof f.memoizedProps === "object") props.push(f.memoizedProps);
              if (f.pendingProps && typeof f.pendingProps === "object") props.push(f.pendingProps);
              // 显式补采 contentBlock / message / creations（键名不含 node_id 前缀）
              const cb = p.contentBlock || p.block;
              if (cb && typeof cb === "object") {
                addId(cb.id); addId(cb.block_id);
                addMsg(cb.id); addMsg(cb.block_id);
                addTask(cb.creation_task_id); addTask(cb.task_id);
                try {
                  const crs = (cb.content_obj && cb.content_obj.creations) || cb.creations || [];
                  for (const cr of crs.slice(0, 4)) if (cr) {
                    addId(cr.id); addMsg(cr.id);
                    addTask(cr.creation_task_id); addTask(cr.task_id);
                  }
                } catch (e2) {}
              }
              const m = p.message || {};
              addMsg(m.message_id); addMsg(m.reply_id); addMsg(m.section_id);
              addTask(m.creation_task_id); addTask(m.task_id);
              f = f.return;
            }
          }
        } catch (e2) {}
        node = node.parentElement;
      }
      return props;
    };
    let roots = [];
    try {
      const lastV = dbm._lastVideoEl ? dbm._lastVideoEl() : (dbm.q("video").slice(-1)[0] || null);
      if (lastV) { let n = lastV; for (let i = 0; i < 8 && n; i++) { roots.push(n); n = n.parentElement; } }
    } catch (e2) {}
    if (!roots.length) {
      try {
        const cards0 = Array.from(document.querySelectorAll('[class*="video-hover-button-group-container"],[class*="block-video"]'));
        const card0 = cards0[cards0.length - 1];
        if (card0) { let n = card0; for (let i = 0; i < 8 && n; i++) { roots.push(n); n = n.parentElement; } }
      } catch (e2) {}
    }
    const objSeen = new WeakSet();
    for (const r of roots) for (const p of fiberProps(r)) scanIds(p, 0, objSeen);
    // 广扫：全部成片卡片 + 所有 message 容器（管理器按整段会话 message_id 解析）
    try {
      const els = Array.from(document.querySelectorAll(
        '[class*="video-hover-button-group-container"],[class*="block-video"],' +
        '[data-message-id],[class*="message"],[class*="Message"],[class*="chat-item"],[class*="chatItem"]'));
      for (const el of els.slice(0, 80)) for (const p of fiberProps(el)) scanIds(p, 0, objSeen);
    } catch (e2) {}
    const pageCoverKeys = visibleCoverKeys(30);

    // ---- 2) 官方创作中心主链路（每账号独立 Cookie，天然可并发） ----
    const diag = { ccCodes: [], ccTotal: 0, ccMatched: 0 };
    let ccIds = [];
    const ccNodes = await creationCenterNodes(diag);
    diag.ccTotal = ccNodes.length;
    if (ccNodes.length) {
      const msgSet = new Set(msgIds.map(String));
      const taskSet = new Set(taskIds.map(String));
      const coverSet = new Set(pageCoverKeys);
      const matched = ccNodes.filter((n) => {
        const byCover = n.coverKeys && n.coverKeys.some((k) => coverSet.has(k));
        const byMsg = n.messageId && msgSet.has(String(n.messageId));
        const byTask = n.creationTaskId && taskSet.has(String(n.creationTaskId));
        return byCover || byMsg || byTask;
      }).filter(isVideoNode);
      // 官方 M()：按页面可见封面顺序排序，让「当前成片」优先
      const rank = (n) => Math.min.apply(null,
        (n.coverKeys || []).map((k) => pageCoverKeys.indexOf(k)).filter((i) => i >= 0).concat([Number.POSITIVE_INFINITY]));
      const ordered = matched.slice().sort((a, b) => rank(a) - rank(b));
      ccIds = ordered.map((n) => n.id);
      diag.ccMatched = ccIds.length;
      // 兜底：匹配不到时取创作中心最新的 3 个视频节点（刚生成的必在最新之列）
      if (!ccIds.length) ccIds = ccNodes.filter(isVideoNode).slice(0, 3).map((n) => n.id);
      ccIds = uniq(ccIds, 12);
    }

    // ---- 3) message_node_info 兜底（官方 F() 里 V() 失败后才调 A()） ----
    //   body 必须是 number 型 message_ids（旧版传字符串数组，官方接口不认）。
    let msgResolved = [], mniRaw = null;
    const mniCodes = [];
    try {
      const mniIds = msgIds.filter(isNum).slice(0, 40);
      if (mniIds.length) {
        let mni = null;
        for (let t = 0; t < 3; t++) {
          try {
            const resp = await fetch(apiUrl("/samantha/aispace/message_node_info"), {
              method: "POST",
              headers: {
                accept: "application/json",
                "content-type": "application/json",
                "agw-js-conv": "str",
                origin: location.origin,
                referer: location.href
              },
              credentials: "include",
              body: JSON.stringify({ message_ids: mniIds.map((x) => Number(x)), message_ids_str: mniIds })
            });
            mni = await resp.json();
            mniCodes.push(mni && typeof mni.code !== "undefined" ? mni.code : "none");
            if (mni && (mni.code === 0 || mni.code === 200)) break;
          } catch (e2) { mni = null; mniCodes.push("err"); }
          if (t < 2) await sleep(600 * (t + 1));
        }
        mniRaw = mni;
        if (mni) {
          const rSeen = new Set();
          const nodeLikeKey = /(^|_|\b)(node_id|nodeid|asset_id|creation_id|material_id|video_id|videoid|media_id|object_id|target_id)(_|$|\b)/i;
          const idLikeKey = /(^|_|\b)(message_id|messageid|msg_id|section_id|reply_id|conversation_id|task_id|creation_task_id)(_|$|\b)/i;
          const scanNode = (o, d) => {
            if (!o || typeof o !== "object" || d > 12) return;
            for (const k in o) {
              const v = o[k];
              if ((typeof v === "string" || typeof v === "number") && isNum(String(v))) {
                const s = String(v);
                if (!rSeen.has(s) && (nodeLikeKey.test(k) || (typeof v === "number" && !idLikeKey.test(k)))) {
                  rSeen.add(s); msgResolved.push(s);
                }
              }
              if (v && typeof v === "object") scanNode(v, d + 1);
            }
          };
          scanNode(mni.data || mni, 0);
        }
      }
    } catch (e2) {}

    // ---- 4) 候选合并：创作中心(主) > message_node_info(兜底) > fiber(末) ----
    const allIds = uniq(ccIds.concat(msgResolved, ids), 20);
    const resultDiag = {
      ids: allIds.slice(0, 6), msgIds: msgIds.slice(0, 5), msgResolved: msgResolved.slice(0, 5),
      ccIds: ccIds.slice(0, 6), ccTotal: diag.ccTotal, ccMatched: diag.ccMatched,
      ccCodes: diag.ccCodes.slice(0, 8), mniCodes: mniCodes.slice(0, 5),
      mniRaw: mniRaw ? JSON.stringify(mniRaw).slice(0, 500) : ""
    };
    if (!allIds.length) {
      return Object.assign({ ok: false, error: "no_node_id" }, resultDiag);
    }
    let lastErr = "";
    const gdiCodes = [];
    const deadline = Date.now() + 55000;
    for (const nid of allIds) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const r = await downloadInfo(nid);
          gdiCodes.push("ok:" + r.code);
          return Object.assign({
            ok: true, nodeId: nid, url: r.mainUrl.slice(0, 2000), backup: r.backupUrl.slice(0, 2000),
            source: ccIds.indexOf(nid) >= 0 ? "creation_center" : (msgResolved.indexOf(nid) >= 0 ? "message_node_info" : "fiber"),
            gdiCodes: gdiCodes.slice(0, 8)
          }, resultDiag);
        } catch (e2) {
          lastErr = String((e2 && (e2.message || e2)) || "unknown");
          gdiCodes.push(lastErr.slice(0, 40));
        }
        if (attempt < 1) await sleep(400);
        if (Date.now() > deadline) break;
      }
      if (Date.now() > deadline) break;
    }
    return Object.assign({
      ok: false, error: lastErr || "no_video_node", gdiCodes: gdiCodes.slice(0, 8)
    }, resultDiag);
  };
  // ===================== 无水印按钮状态 / 带水印指纹（2026-10-25） =====================
  // 管理器注入按钮文案状态机：无水印下载 → 解析中… → 下载中… / 解析失败（2.6s 后复原）。
  // 「解析失败」= 豆包 get_download_info 暂未签发无水印（限流/未同步创作中心），
  // 此时盲点只会经 resolver u() 兜底再触发一次带水印下载，故插件按状态降频守候。
  dbm.noWatermarkBtnState = () => {
    try {
      const b = document.querySelector(".dbm-doubao-no-watermark-download");
      if (!b) return { found: false };
      const r = b.getBoundingClientRect();
      return { found: true, text: String(b.textContent || "").trim().slice(0, 40),
               disabled: !!b.disabled,
               x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2) };
    } catch (e) { return { found: false, error: String(e) }; }
  };
  // 带水印指纹：最后成片卡片 fiber → creations[].video.download_filehash /
  // video_model.video_list[].file_hash（= 带水印文件 MD5，已与落盘文件实测一致），
  // 以及 download_url（resolver u() 兜底会把它误当"确认无水印"发出下载）。
  // 落盘文件 MD5 命中 hashes 即"带水印预览同体"，绝不能当无水印成品交付。
  dbm.watermarkFingerprints = () => {
    const out = { hashes: [], urls: [] };
    const hSeen = new Set(), uSeen = new Set();
    const addH = (v) => {
      const s = String(v == null ? "" : v).toLowerCase();
      if (/^[0-9a-f]{32}$/.test(s) && !hSeen.has(s)) { hSeen.add(s); out.hashes.push(s); }
    };
    const addU = (v) => {
      const s = String(v == null ? "" : v);
      if (/^https?:\/\//i.test(s) && !uSeen.has(s)) { uSeen.add(s); out.urls.push(s.slice(0, 2000)); }
    };
    const scan = (o, d, seen) => {
      if (!o || typeof o !== "object" || d > 9 || seen.has(o)) return;
      seen.add(o);
      let es;
      try { es = Object.entries(o).slice(0, 240); } catch (e) { return; }
      for (let i = 0; i < es.length; i++) {
        const k = es[i][0], v = es[i][1];
        if (typeof v === "string" || typeof v === "number") {
          if (/download_?filehash/i.test(k)) addH(v);
          else if (/file_?hash/i.test(k)) addH(v);
          else if (/download_?url/i.test(k)) addU(v);
          else if (/^video_model$/i.test(k) && typeof v === "string" && v.length < 400000) {
            try {
              const vm = JSON.parse(v);
              const vl = (vm && vm.video_list) || [];
              for (const it of vl.slice(0, 10)) {
                if (!it) continue;
                addH(it.file_hash); addH(it.fileHash); addH(it.filehash);
                addU(it.main_url); addU(it.mainUrl); addU(it.backup_url); addU(it.backupUrl);
              }
            } catch (e) {}
          }
        } else if (v && typeof v === "object") scan(v, d + 1, seen);
      }
    };
    try {
      const cards = Array.from(document.querySelectorAll(
        '[class*="video-hover-button-group-container"],[class*="block-video"]'));
      const card = cards[cards.length - 1];
      if (!card) return out;
      const fk = Object.keys(card).find((k) => k.indexOf("__reactFiber") === 0);
      let f = fk ? card[fk] : null;
      for (let d = 0; f && d < 45; d++) {
        const p = f.memoizedProps || {};
        if (p.contentBlock && typeof p.contentBlock === "object") {
          scan(p.contentBlock, 0, new Set());
          try { scan(p.message, 0, new Set()); } catch (e) {}
          break;
        }
        f = f.return;
      }
    } catch (e) {}
    return out;
  };
"""


# ===================== 「创建画布」面板 DOM 级自动关闭（2026-11-02） =====================
# 豆包生成视频后偶发自动弹出右侧「创建画布」预览面板，盖住聊天页，
# 导致「无水印下载」按钮消失、悬停/点击全部落空。这里在页面内常驻一个看门狗：
# 一旦检测到该面板就自动关闭（点关闭按钮 → 失败则 Esc → 再失败则移除节点）。
# 不用 innerText（会触发整页重排，卡死大 DOM），改用 textContent + 分层定位。
_CANVAS_CLOSE_JS = r"""
  // -------------------- 「创建画布」面板检测与关闭 --------------------
  dbm.findCanvasPanel = () => {
    try {
      const hasTitle = (e) => {
        const t = (e.textContent || "").trim();
        return t.length > 0 && t.length < 60 && /创建画布|创意画布|新建画布/.test(t);
      };
      // 1) 已知模态容器
      const containers = document.querySelectorAll(
        '[role="dialog"],[class*="modal"],[class*="dialog"],[class*="panel"],'
        + '[class*="drawer"],[class*="overlay"],[class*="mask"],[class*="backdrop"],'
        + '[class*="popup"],[class*="popover"]');
      for (let i = 0; i < containers.length; i++) {
        if (hasTitle(containers[i])) return containers[i];
      }
      // 2) header/标题元素：命中标题则向上爬到对话框容器
      const headers = document.querySelectorAll(
        'header,h1,h2,h3,h4,h5,h6,[class*="header"],[class*="title"],[class*="modal-title"]');
      for (let i = 0; i < headers.length; i++) {
        if (hasTitle(headers[i])) {
          let panel = headers[i];
          while (panel && panel !== document.body) {
            const cls = String(panel.className || "");
            const role = panel.getAttribute && panel.getAttribute("role");
            if (role === "dialog"
                || /modal|dialog|panel|drawer|overlay|mask|backdrop|popup|popover/i.test(cls)) break;
            panel = panel.parentElement;
          }
          if (!panel || panel === document.body) panel = headers[i];
          return panel;
        }
      }
      // 3) 兜底：短文本小元素（用 textContent，避免重排）
      const all = document.querySelectorAll('button,[role="button"],a,div,span');
      for (let i = 0; i < all.length; i++) {
        const el = all[i];
        if (el.children.length > 25) continue;
        const t = (el.textContent || "").trim();
        if (t.length > 0 && t.length < 40 && /创建画布|创意画布|新建画布/.test(t)) return el;
      }
    } catch (e) {}
    return null;
  };
  dbm.findCanvasCloseBtn = (panel) => {
    try {
      const scope = panel || document;
      const nodes = scope.querySelectorAll(
        'button,[role="button"],a,span,div,i,svg,[class*="close"],[class*="dismiss"]');
      for (let i = 0; i < nodes.length; i++) {
        const b = nodes[i];
        const txt = (b.innerText || b.textContent || "").trim();
        const label = ((b.getAttribute && (b.getAttribute("aria-label") || b.getAttribute("title"))) || "").trim().toLowerCase();
        const cls = String(b.className || "").toLowerCase();
        if (/close|dismiss|cancel|关闭|取消/.test(label) || /close|dismiss/.test(cls)) return b;
        if (txt === "×" || txt.toLowerCase() === "x" || txt === "✕"
            || txt === "✖" || txt === "关闭") return b;
      }
    } catch (e) {}
    return null;
  };
  dbm.closeCanvasPanel = () => {
    try {
      const panel = dbm.findCanvasPanel();
      if (!panel) return { closed: false, reason: "no_panel" };
      // 1) 点关闭按钮
      const btn = dbm.findCanvasCloseBtn(panel);
      if (btn) { try { btn.click(); return { closed: true, via: "button" }; } catch (e) {} }
      // 2) Esc 键
      try {
        const ev = new KeyboardEvent("keydown",
          { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true });
        document.dispatchEvent(ev);
        const t = document.querySelector("textarea,input,[contenteditable]");
        if (t) t.dispatchEvent(ev);
        return { closed: true, via: "escape" };
      } catch (e) {}
      // 3) 兜底：隐藏 + 移除节点
      try { panel.style.display = "none"; if (panel.remove) panel.remove();
            return { closed: true, via: "remove" }; } catch (e) {}
      return { closed: false, reason: "no_action" };
    } catch (e) { return { closed: false, error: String(e) }; }
  };
  dbm.__installCanvasGuard = () => {
    if (window.__dbmCanvasGuard) return true;
    window.__dbmCanvasGuard = true;
    let _last = 0;
    const guarded = () => {
      const now = Date.now();
      if (now - _last < 500) return;   // 节流，避免大 DOM 下 MutationObserver 风暴
      _last = now;
      try { dbm.closeCanvasPanel(); } catch (e) {}
    };
    setInterval(guarded, 800);
    try {
      const mo = new MutationObserver(guarded);
      mo.observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) {}
    return true;
  };
"""


_INJECT_JS_CACHE = {}


def build_inject_js_cached(selectors):
    """build_inject_js 的缓存版。

    ★ 2026-09-19 晚并发优化：生成的脚本约 **64KB**，而旧代码在
      `_wait_chat_ready` / collect_loop / `_fast_detect_video` 里**每轮循环无条件
      重新生成并注入一次**（约 1.5s 一轮）。7 个账号并发时等于每秒往各个 webview
      灌 ~300KB JS，CDP 传输 + V8 编译全部挤在渲染线程上，直接把豆包的页面加载
      挤成"半加载"（现场：首页明明已就绪、6 秒后却只剩侧边栏按钮）。
      这段脚本只依赖 selectors，完全可以缓存复用。
    """
    try:
        key = json.dumps(selectors or {}, sort_keys=True, ensure_ascii=False)
    except Exception:
        key = repr(selectors)
    js = _INJECT_JS_CACHE.get(key)
    if js is None:
        js = build_inject_js(selectors)
        _INJECT_JS_CACHE[key] = js
    return js


# ============ 2026-11-02：独立注入模板加载（P2-b 抽离 + P0-2 语法校验）============
_PAGE_INJECT_TPL = None
_PAGE_INJECT_CHECKED = False


def _node_check_page_inject(tpl):
    """best-effort 语法校验：用 node --check 验证模板（占位符替换为 {}）。
    无 node 或异常时仅告警，不阻断注入。"""
    try:
        import logging, subprocess, tempfile, os
        js = tpl.replace("__DBM_SEL_PLACEHOLDER__", "{}")
        tf = tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False)
        try:
            tf.write(js)
        finally:
            tf.close()
        try:
            r = subprocess.run(["node", "--check", tf.name],
                               capture_output=True, text=True, timeout=30)
            if r.returncode != 0:
                logging.warning("[doubao-bridge] page_inject.template.js 语法校验失败：%s",
                                (r.stderr or r.stdout).strip())
        finally:
            try:
                os.unlink(tf.name)
            except Exception:
                pass
    except Exception as e:
        try:
            import logging
            logging.warning("[doubao-bridge] page_inject.template.js node --check 跳过：%s", e)
        except Exception:
            pass


def _load_page_inject_template():
    """加载 bridge/page_inject.template.js（含 __DBM_SEL_PLACEHOLDER__ 占位符）。
    优先于内联 f-string 注入体，便于维护与语法校验；缺失/异常时返回 None 走回退。"""
    global _PAGE_INJECT_TPL, _PAGE_INJECT_CHECKED
    if _PAGE_INJECT_CHECKED:
        return _PAGE_INJECT_TPL
    _PAGE_INJECT_CHECKED = True
    try:
        import os, logging
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "page_inject.template.js")
        if not os.path.isfile(p):
            return None
        with open(p, "r", encoding="utf-8") as _f:
            tpl = _f.read()
        if "__DBM_SEL_PLACEHOLDER__" not in tpl:
            return None
        _node_check_page_inject(tpl)
        _PAGE_INJECT_TPL = tpl
        return tpl
    except Exception as e:
        try:
            import logging
            logging.warning("[doubao-bridge] 加载 page_inject.template.js 失败，回退内联：%s", e)
        except Exception:
            pass
        return None


# ★ 2026-11-14：右侧「智能纪要 / 画布」分屏面板防护补丁。
# 放在 build_inject_js() 收口处统一追加：模板文件 / 内联兜底两条路径都会带上，
# 双路径仍逐字节一致，且无需改动 page_inject.template.js 与内联 f-string 的花括号。
_MINUTES_GUARD_JS = r"""  // ★ 2026-11-14：带参考音频时豆包会自动打开右侧「智能纪要 / 画布」分屏
  //   （URL 带 layout=zen_split&pluginId=write-artifact-preview）。面板里的
  //   「下载 / 编辑 / 复制」按钮会被误判成成片入口（实测 nodes 1367→2208、
  //   hits 全是 dl:下载icon），进而把别的账号窗口的历史视频回传；附件清理
  //   的全局兜底也会把聊天历史里的音频「智能纪要」卡当成待删附件误点。
  //   四层防护：① 识别纪要节点 ② 所有 realClick 跳过纪要节点
  //   ③ 清理附件严格限定输入框区域 ④ 分屏面板常驻自动关闭并清理 URL。
  dbm._isMinutesNode = (el) => {
    try {
      if (!el) return false;
      const txt = (el.textContent || el.innerText || "").trim();
      if (txt && txt.length <= 160
          && /智能纪要|音频纪要|生成纪要|查看原始记录/.test(txt)) return true;
      const sig = (String(el.className || "") + " "
        + ((el.getAttribute && el.getAttribute("data-testid")) || "") + " "
        + ((el.getAttribute && el.getAttribute("aria-label")) || "")).toLowerCase();
      if (/smart[-_]?minutes|audio[-_]?summary|meeting[-_]?minutes|note[-_]?detail/.test(sig)) return true;
      let n = el.parentElement;
      for (let i = 0; i < 3 && n; i++) {
        const nt = (n.textContent || "").trim();
        if (nt && nt.length <= 160 && /智能纪要/.test(nt)) return true;
        n = n.parentElement;
      }
    } catch (e) {}
    return false;
  };
  // 最上层拦截：任何 realClick（发送/确认/清理/视频模式入口）都不碰纪要节点
  const _dbmRealClick = dbm.realClick;
  dbm.realClick = (el) => {
    try { if (dbm._isMinutesNode(el)) return false; } catch (e) {}
    return _dbmRealClick ? _dbmRealClick(el) : false;
  };
  // clickPlayIcon / 无水印按钮候选都走 _usableRect，纪要节点一律不可用
  const _dbmUsableRect = dbm._usableRect;
  dbm._usableRect = (el) => {
    try { if (dbm._isMinutesNode(el)) return null; } catch (e) {}
    return _dbmUsableRect ? _dbmUsableRect(el) : null;
  };
  // 全局缩略图扫描不再把聊天历史里的音频纪要卡算成附件
  const _dbmThumbCards = dbm.thumbCards;
  dbm.thumbCards = () => {
    try {
      return (_dbmThumbCards ? _dbmThumbCards() : [])
        .filter(c => !dbm._isMinutesNode(c));
    } catch (e) { return []; }
  };
  // 附件清理：只在输入区内删，且只认明确删除语义的图标按钮
  dbm.clearAttachments = async () => {
    let removed = 0;
    const started = Date.now();
    const region = dbm.attachRegion() || null;
    const inScope = (c) => !!c && (!region || region === c || region.contains(c));
    for (let round = 0; round < 10 && Date.now() - started < 12000; round++) {
      const cards = [];
      const push = (c) => {
        if (inScope(c) && !dbm._isMinutesNode(c) && cards.indexOf(c) < 0) cards.push(c);
      };
      try { dbm.attachmentCards().forEach(push); } catch (e) {}
      if (!cards.length) {
        try { dbm.thumbCards().forEach(push); } catch (e) {}
        try { dbm.mdboxCards().forEach(push); } catch (e) {}
        try { dbm.composerAttachmentCards().forEach(push); } catch (e) {}
      }
      if (!cards.length) break;
      let clicked = 0;
      cards.forEach(c => {
        let del = null;
        try { del = c.querySelector(dbm._attachmentDelSel()); } catch (e) {}
        if (del && dbm._isMinutesNode(del)) del = null;
        if (!del) {
          try {
            const bs = Array.from(c.querySelectorAll("button,[role='button']"))
              .filter(b => !(b.innerText || "").trim())
              .filter(b => !dbm._isMinutesNode(b))
              .filter(b => {
                const s = (String(b.className || "") + " "
                  + (b.getAttribute("aria-label") || "") + " "
                  + (b.getAttribute("title") || "")).toLowerCase();
                return /delete|remove|close|dismiss|删除|移除|关闭|clear/i.test(s);
              });
            if (bs.length) del = bs[bs.length - 1];
          } catch (e) {}
        }
        if (!del) return;
        try { if (dbm.realClick(del)) { clicked++; removed++; } } catch (e) {}
      });
      if (!clicked) break;
      await dbm.sleep(500);
    }
    let left = 0;
    try {
      left = dbm.attachmentCards()
        .filter(c => inScope(c) && !dbm._isMinutesNode(c)).length;
    } catch (e) { left = 0; }
    try {
      (region || document).querySelectorAll("input[type=file]").forEach(inp => {
        try { inp.value = ""; } catch (e) {}
      });
    } catch (e) {}
    return { removed, left };
  };
  // 右侧「智能纪要 / 画布」docked 面板（2026-11-14 CDP 实测结构）：
  //   <aside data-testid="samantha_layout_right_side" data-container-name="right">
  //     <div data-testid="canvas_panel_container" class="container-outer--docked-...">
  //       ... <div data-testid="canvas_close_btn">  ← 真关闭按钮（无 close 类名/aria-label）
  //   旧版靠「标题选择器 + close 语义按钮」定位不到它，改发 Escape 却返回
  //   {closed:true, via:"escape"} 假成功（实测 afterClose: open=true / aside 仍在）。
  //   新策略：豆包自己的 testid 精确定位 → 真实点击关闭 → 隐藏 aside 兜底，
  //   并让 dbm.vis 忽略被隐藏面板里的按钮，杜绝「下载」被误判成成片入口。
  dbm.findMinutesPanel = () => {
    try {
      const vw = window.innerWidth || 1280;
      const okRect = (e) => {
        try {
          const r = e && e.getBoundingClientRect ? e.getBoundingClientRect() : null;
          if (!r || r.width < 240 || r.height < 160 || r.x < vw * 0.35) return false;
          const s = getComputedStyle(e);
          return !!s && s.display !== "none" && s.visibility !== "hidden";
        } catch (err) { return false; }
      };
      const isMinutes = (e) => /智能纪要|纪要|原始记录|画布|doc_editor/
        .test((e.innerText || e.textContent || "").trim().slice(0, 500));
      // 1) 豆包布局节点（不依赖标题标签，CDP 实测最稳）
      const cands = Array.from(document.querySelectorAll(
        'aside[data-testid="samantha_layout_right_side"],'
        + '[data-container-name="right"],'
        + '[data-testid="canvas_panel_container"],'
        + '[class*="container-outer--docked"]'));
      for (let i = 0; i < cands.length; i++) {
        if (okRect(cands[i]) && isMinutes(cands[i])) return cands[i];
      }
      // 2) 右侧大容器 + 纪要文本（豆包改版兜底）
      const big = Array.from(document.querySelectorAll("aside,section,div"))
        .filter(e => okRect(e) && isMinutes(e));
      if (big.length) return big[big.length - 1];
      // 3) 旧标题路径（zen_split 老版页面）
      const heads = Array.from(document.querySelectorAll(
        "h1,h2,h3,h4,[class*='title'],[class*='header'],[data-testid*='title']"));
      for (let i = 0; i < heads.length; i++) {
        const h = heads[i];
        const t = (h.textContent || "").trim();
        if (!t || t.length > 80 || !/智能纪要|纪要|画布/.test(t)) continue;
        let p = h;
        for (let k = 0; k < 8 && p && p !== document.body; k++) {
          if (okRect(p)) return p;
          p = p.parentElement;
        }
      }
    } catch (e) {}
    return null;
  };
  dbm.minutesPanelOpen = () => !!dbm.findMinutesPanel();
  dbm._minutesCloseBtn = (panel) => {
    try {
      const scope = panel || document;
      return scope.querySelector(
        '[data-testid="canvas_close_btn"],[data-selector*="canvas_close"],'
        + '[class*="canvas_close_btn"],[class*="canvas-close"]')
        || document.querySelector('[data-testid="canvas_close_btn"]');
    } catch (e) { return null; }
  };
  dbm.closeMinutesPanel = () => {
    // URL 上的分屏参数清掉，否则重新 attach / 注入后面板还会被还原
    try {
      if (/layout=zen_split|write-artifact-preview|canvas_impayload/.test(location.search)) {
        const u = new URL(location.href);
        ["layout", "pluginId", "canvas_impayload", "canvasId"].forEach(k => u.searchParams.delete(k));
        history.replaceState(history.state, "", u.pathname + (u.search ? u.search : "") + u.hash);
      }
    } catch (e) {}
    const panel = dbm.findMinutesPanel();
    if (!panel) {
      // React 重新显示曾被压住的 aside 时继续压住，不再重复点关闭按钮
      const prev = dbm.__minutesAside;
      if (prev && prev.isConnected) {
        try {
          prev.style.setProperty("display", "none", "important");
          prev.style.setProperty("visibility", "hidden", "important");
          prev.style.setProperty("pointer-events", "none", "important");
        } catch (e) {}
        return { closed: true, via: "keep_hidden" };
      }
      return { closed: true, via: "already_closed" };
    }
    dbm.__minutesAside = panel;
    // 1) 点豆包原生关闭按钮，让它自己更新布局状态
    let via = "hide";
    const btn = dbm._minutesCloseBtn(panel);
    if (btn) {
      via = "button+hide";
      // _dbmRealClick 是未包装的原始点击（包装层会跳过纪要节点），
      // 真实指针事件 + DOM click 双保险，React 合成事件都能收到。
      try { if (_dbmRealClick) _dbmRealClick(btn); } catch (e) {}
      try { btn.click(); } catch (e) {}
    } else {
      // 2) 无 testid 时按几何找右上角 16~48px 的 X 按钮（无 close 类名也能中）
      try {
        const vw = window.innerWidth || 1280;
        const xs = Array.from(document.querySelectorAll("div,button,span"))
          .filter(e => {
            const r = e.getBoundingClientRect ? e.getBoundingClientRect() : null;
            return r && r.width >= 16 && r.width <= 48 && r.height >= 16
              && r.height <= 48 && r.x > vw * 0.70 && r.y < 60
              && !e.querySelector("div,button,span");
          })
          .filter(e => {
            const s = (String(e.className || "") + " "
              + (e.getAttribute("data-testid") || "") + " "
              + (e.getAttribute("aria-label") || "")).toLowerCase();
            if (/close|dismiss|关闭|收起/.test(s)) return true;
            const path = e.querySelector ? e.querySelector("svg path") : null;
            const d = path ? (path.getAttribute("d") || "") : "";
            return /^M19\.4801 4\.51824/.test(d.trim());  // 豆包 X 图标
          });
        if (xs.length) {
          const b = xs[xs.length - 1];
          try { b.click(); } catch (e) {}
          via = "x+hide";
        }
      } catch (e) {}
      // 3) Esc 只是补一刀，不再拿它当「已关闭」的证据
      try {
        const ev = new KeyboardEvent("keydown", { key: "Escape", code: "Escape",
          keyCode: 27, which: 27, bubbles: true, cancelable: true });
        document.dispatchEvent(ev);
      } catch (e) {}
    }
    // 4) 隐藏兜底：视觉立刻关闭 + 隔离面板里的「下载」按钮。
    //    只打标记不 remove，避免 React 卸载时找不到节点报错。
    try {
      panel.setAttribute("data-dbm-minutes-hidden", "1");
      panel.style.setProperty("display", "none", "important");
      panel.style.setProperty("visibility", "hidden", "important");
      panel.style.setProperty("pointer-events", "none", "important");
    } catch (e) {}
    return { closed: true, via: via };
  };
  // 被隐藏面板里的按钮一律视为不可见：CSS display 不继承，dbm.vis 只看元素
  // 自身 computedStyle，后台标签页还会跳过尺寸判定，必须在这里显式拦住。
  if (!dbm.__visWrappedForMinutes) {
    dbm.__visWrappedForMinutes = true;
    const _dbmVis = dbm.vis;
    dbm.vis = (el) => {
      try {
        if (el && el.closest && el.closest('[data-dbm-minutes-hidden="1"]')) return false;
      } catch (e) {}
      return _dbmVis ? _dbmVis(el) : false;
    };
  }
  dbm.__installMinutesGuard = () => {
    if (window.__dbmMinutesGuard) return true;
    window.__dbmMinutesGuard = true;
    let _last = 0;
    const guarded = () => {
      const now = Date.now();
      if (now - _last < 500) return;
      _last = now;
      try { dbm.closeMinutesPanel(); } catch (e) {}
    };
    setInterval(guarded, 800);
    try {
      const mo = new MutationObserver(guarded);
      mo.observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) {}
    return true;
  };
  try { dbm.__installMinutesGuard(); } catch (e) {}
"""


def build_inject_js(selectors):
    sel_json = json.dumps(selectors, ensure_ascii=False)
    body = f"""
(() => {{
  const SEL = {sel_json};
  const dbm = window.__dbm || {{}};
  dbm.SEL = SEL;
  // ============ 下载通道截获============
  // 管理器的"无水印下载"无论由 hover 还是 click 触发，最终都要在页面里通过
  // <a download>.click() / window.open / fetch / XHR 之一拿到无水印地址。
  // hook 这些通道后，即使合成鼠标事件无法触发其 UI，只要其脚本运行就能截获 URL。
  dbm.__caps = dbm.__caps || [];
  if (!window.__dbmCapHooked) {{
    window.__dbmCapHooked = true;
    const cap = (u, via) => {{
      try {{
        if (!u) return;
        u = String(u);
        if (!/^https?:|^blob:/.test(u)) return;
        dbm.__caps.push({{ url: u.slice(0, 2000), via: via, ts: Date.now() }});
        if (dbm.__caps.length > 200) dbm.__caps.splice(0, dbm.__caps.length - 200);
      }} catch (e) {{}}
    }};
    try {{
      const aClick = HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click = function () {{
        cap(this.href || this.getAttribute("href") || "", "a.click");
        return aClick.apply(this, arguments);
      }};
    }} catch (e) {{}}
    try {{
      if (window.open) {{
        const _open = window.open;
        window.open = function (u) {{ cap(u, "window.open"); return _open.apply(this, arguments); }};
      }}
    }} catch (e) {{}}
    try {{
      if (window.fetch) {{
        const _fetch = window.fetch;
        window.fetch = function (input, init) {{
          try {{ cap(typeof input === "string" ? input : (input && input.url), "fetch"); }} catch (e) {{}}
          return _fetch.apply(this, arguments);
        }};
      }}
    }} catch (e) {{}}
    try {{
      const _xopen = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function (m, u) {{
        cap(u, "xhr");
        return _xopen.apply(this, arguments);
      }};
    }} catch (e) {{}}
  }}
  // 读取某时间戳之后截获到的、不在 baseline 中的 http 视频地址（Python 轮询调用）
  // baseline: JS 数组，包含点击前的页面视频URL基线；传空数组表示不过滤
  dbm.capsSince = (sinceMs, baseline) => {{
    const since = sinceMs || 0;
    const exclude = new Set((baseline || []).map(u => String(u)));
    return dbm.__caps.filter(c => c.ts >= since && !exclude.has(c.url)
      && /^https?:/.test(c.url));
  }};
  dbm.sleep = ms => new Promise(r => setTimeout(r, ms));
  // 后台/未激活 webview 下 Chromium 停止排版与绘制，所有元素 getBoundingClientRect()
  // 都返回 0，导致 dbm.vis 全 false —— 这正是"第二个账号报需要标定"的直接原因
  // （页面其实正常，只是没被激活）。检测到整页零尺寸时自动降级为宽松判定：
  // 只排除 display:none / visibility:hidden，不再看尺寸。
  dbm.__zeroLayout = () => {{
    try {{
      const b = document.body;
      if (!b) return true;
      const r = b.getBoundingClientRect();
      return r.width < 2 || r.height < 2;
    }} catch (e) {{ return false; }}
  }};
  dbm.vis = el => {{
    if (!el) return false;
    const s = getComputedStyle(el);
    if (!s || s.display === 'none' || s.visibility === 'hidden') return false;
    if (dbm.__zeroLayout()) return true;   // 后台标签页：跳过尺寸/透明度判定
    const r = el.getBoundingClientRect();
    return r.width > 2 && r.height > 2 && s.opacity !== '0';
  }};
  // 页面可见性探针：判断本 webview 是否真的是管理器里的活动标签页
  dbm.pageProbe = () => {{
    let bodyW = 0, bodyH = 0;
    try {{
      const r = document.body ? document.body.getBoundingClientRect() : null;
      bodyW = r ? Math.round(r.width) : 0;
      bodyH = r ? Math.round(r.height) : 0;
    }} catch (e) {{}}
    return {{
      url: location.href,
      title: document.title,
      ready: document.readyState,
      hidden: (typeof document.__dbmRealHidden === 'function')
        ? !!document.__dbmRealHidden() : !!document.hidden,
      visState: (typeof document.__dbmRealVis === 'function')
        ? (document.__dbmRealVis() || "") : (document.visibilityState || ""),
      visForced: !!document.__dbmForceVisible,
      innerW: window.innerWidth || 0, innerH: window.innerHeight || 0,
      bodyW: bodyW, bodyH: bodyH, zeroLayout: dbm.__zeroLayout(),
      nodes: document.querySelectorAll("*").length,
      hasDoubao: /doubao\\.com/.test(location.href),
    }};
  }};
  dbm.q = sel => Array.from(document.querySelectorAll(sel));
  dbm.findAny = sels => {{
    for (const s of sels) {{
      const el = dbm.q(s).find(dbm.vis);
      if (el) return {{ el, s }};
    }}
    return {{ el: null, s: null }};
  }};
  dbm.findByText = (tags, text) => {{
    for (const t of tags) {{
      const el = dbm.q(t).find(e => dbm.vis(e) && (e.innerText || '').includes(text));
      if (el) return el;
    }}
    return null;
  }};
  // 真实指针事件序列（Radix 等组件不认合成 click）
  dbm.realClick = (el) => {{
    if (!el) return false;
    const opts = {{ bubbles: true, cancelable: true, view: window, button: 0, composed: true }};
    el.scrollIntoView({{ block: "center", inline: "center" }});
    const r = el.getBoundingClientRect();
    const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
    const p = (Type, Ev) => {{
      try {{ el.dispatchEvent(new PointerEvent(Type, Object.assign({{ clientX: cx, clientY: cy }}, opts))); }} catch (e) {{}}
      el.dispatchEvent(new MouseEvent(Ev, Object.assign({{ clientX: cx, clientY: cy }}, opts)));
    }};
    p("pointerover", "mouseover"); p("pointerenter", "mouseenter");
    p("pointermove", "mousemove"); p("pointerdown", "mousedown");
    p("pointerup", "mouseup"); p("pointerout", "mouseout");
    el.dispatchEvent(new MouseEvent("click", Object.assign({{ clientX: cx, clientY: cy }}, opts)));
    return true;
  }};
  dbm.getEditor = () => {{
    const sels = SEL.prompt_input || [
      ".tiptap.ProseMirror", "div[contenteditable='true'][role='textbox']",
      "div[contenteditable='true']", "textarea", "[role='textbox']"
    ];
    const {{ el }} = dbm.findAny(sels);
    return el;
  }};
  dbm.focusEditor = () => {{
    const el = dbm.getEditor();
    if (!el) return {{ ok: false, reason: "no_prompt_input" }};
    el.scrollIntoView({{ block: "center" }});
    el.focus();
    return {{ ok: true, tag: el.tagName, ce: !!el.isContentEditable,
             active: document.activeElement === el || el.contains(document.activeElement) }};
  }};
  dbm.editorText = () => {{
    const el = dbm.getEditor();
    return el ? (el.innerText || el.value || "") : "";
  }};
  // 输入文本（execCommand 对 TipTap/ProseMirror 可靠；CDP Input 事件在 Electron webview 中不生效）
  dbm.setPrompt = (text) => {{
    const el = dbm.getEditor();
    if (!el) return {{ ok: false, reason: "no_prompt_input" }};
    el.scrollIntoView({{ block: "center" }});
    el.focus();
    const cur = el.innerText || el.value || "";
    if (cur.trim().length > 0) {{
      try {{ document.execCommand("selectAll", false); document.execCommand("delete", false); }} catch (e) {{}}
    }}
    const ok = document.execCommand("insertText", false, text);
    // ★ 2026-09-24：记下"这话是我们自己说的"。
    //   事故：确认文本被改成"…先将提示词内容修改为不涉及版权、不侵权、不违规的
    //   提示词…"，里面自带"涉及版权/不侵权/不违规"，generationFailed() 把它当成
    //   豆包的拒绝话术 → 我们自己发的消息触发了自己判自己失败。
    //   所有由我们填入编辑器的文本（提示词 / 确认文本）都会经过 setPrompt，
    //   在这里登记后，判失败时就能精确跳过，而不是靠猜哪条气泡是助手的
    //   （实测用户/助手气泡的 className 无法区分）。
    try {{
      dbm.__mine = dbm.__mine || [];
      const s = String(text == null ? "" : text).trim();
      if (s) dbm.__mine.push(s.slice(0, 40));
      if (dbm.__mine.length > 12) dbm.__mine = dbm.__mine.slice(-12);
    }} catch (e) {{}}
    return {{ ok: ok, len: (el.innerText || "").length }};
  }};
  // Enter 键回退（合成 KeyboardEvent 派发到编辑器）
  dbm.pressEnter = () => {{
    const el = dbm.getEditor();
    if (!el) return false;
    el.focus();
    const opts = {{ key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }};
    el.dispatchEvent(new KeyboardEvent("keydown", opts));
    el.dispatchEvent(new KeyboardEvent("keypress", opts));
    el.dispatchEvent(new KeyboardEvent("keyup", opts));
    return true;
  }};
  // 比例 + 时长：点开“自动 · Ns”Radix 下拉（弹层上半比例 7 个按钮：自动/3:4/4:3/9:16/16:9/1:1/21:9；
  // 下半时长档位改为动态发现，已支持管理器新增的 15s / 30s）
  dbm.pickAspectDuration = async (aspect, sec) => {{
    const ASPECTS = ["自动","3:4","4:3","9:16","16:9","1:1","21:9"];
    // 动态读取页面真实提供的时长档位（如 4s/10s/15s/30s）。此前写死 ["4s","10s","15s"]，
    // 豆包/管理器一加新档位就选不中；现在新增档位也无需改插件。
    dbm._durTiers = () => {{
      const out = [];
      const re = /^\\s*(\\d+)\\s*(s|秒)(\\s|$|[^0-9a-zA-Z])/i;
      const nodes = Array.from(document.querySelectorAll("button, [role='option'], [role='menuitem'], li, div, span"));
      nodes.forEach(e => {{
        if (!dbm.vis(e)) return;
        const m = re.exec((e.innerText || "").trim());
        if (m) out.push(parseInt(m[1], 10));
      }});
      // 去重排序（同一档位可能被渲染成多个节点）
      return Array.from(new Set(out)).sort((a, b) => a - b);
    }};
    const trigger = Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && /\\d+\\s*s/.test(e.innerText || "") && (e.innerText || "").trim().length <= 20);
    if (!trigger) return {{ ok: false, reason: "no_trigger" }};
    const before = (trigger.innerText || "").replace(/\\\\s+/g, " ").trim();
    // 判定当前是否已选中
    const secWant = String(sec || "10").replace(/s$/, "").replace(/秒$/, "") + "s";
    const aspWant = aspect || "自动";
    const alreadySec = new RegExp("(^|[^0-9])" + secWant.replace(/s$/,"") + "\\\\s*s($|[^a-z])", "i").test(before);
    const alreadyAsp = aspWant === "自动" ? /^自动/.test(before) : before.includes(aspWant);
    if (alreadyAsp && alreadySec) return {{ ok: true, label: "already " + before }};
    dbm.realClick(trigger);
    await dbm.sleep(1300);
    // 判断弹层是否仍打开（点比例按钮后，若该比例已是当前或触发自动关闭，弹层会消失）
    const popoverVisible = () => Array.from(document.querySelectorAll("[role='menu'],[role='listbox'],[data-radix-popper-content-wrapper]"))
      .some(el => dbm.vis(el));
    // 比例按钮：在弹层里找文字严格等于 aspWant 的 button
    const findBtn = (label) => Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && (e.innerText||"").trim() === label);
    let aspOk = false, durOk = false, aspLabel = "", durLabel = "";
    if (!ASPECTS.includes(aspWant)) {{
      aspLabel = aspWant + "(invalid→自动)";
    }} else {{
      const ab = findBtn(aspWant);
      if (ab) {{ dbm.realClick(ab); await dbm.sleep(450); aspOk = true; aspLabel = aspWant; }}
    }}
    // 时长：按页面真实存在的档位选择；目标档不存在则就近落档（管理器新增 15s / 30s 自动生效）
    const tiers = dbm._durTiers();
    const wantN = parseInt(String(sec).replace(/[s秒]/g, ""), 10);
    let targetN = NaN;
    if (!isNaN(wantN)) {{
      if (tiers.includes(wantN)) {{
        targetN = wantN;
      }} else if (tiers.length) {{
        targetN = tiers.slice().sort((a, b) => Math.abs(a - wantN) - Math.abs(b - wantN))[0];
      }} else {{
        targetN = wantN;   // 发现不到档位列表时退回直接点击目标
      }}
    }}
    const fbSuffix = (!isNaN(wantN) && targetN !== wantN) ? ("(req " + wantN + "s)") : "";
    if (!popoverVisible()) {{
      const nowTxt = trigger ? (trigger.innerText||"").replace(/\\\\s+/g," ").trim() : "";
      if (!isNaN(targetN) && new RegExp("(^|[^0-9])" + targetN + "\\\\s*s($|[^a-z])", "i").test(nowTxt)) {{
        durOk = true; durLabel = targetN + "s(popover_closed)" + fbSuffix;
      }}
    }} else if (!isNaN(targetN)) {{
      // 时长弹层可能因点比例而关闭：先确保弹层仍开，否则重新点开 trigger 再选
      if (!popoverVisible()) {{
        dbm.realClick(trigger); await dbm.sleep(1300);
      }}
      const cands = Array.from(document.querySelectorAll("button, [role='option'], [role='menuitem'], li, div, span")).filter(dbm.vis);
      // 优先按「用户要的档位 wantN」直接找选项点击，不依赖 tiers 发现是否完整
      const durExactN = new RegExp("^\\s*" + wantN + "\\s*(s|秒)\\s*$", "i");
      const durPreN   = new RegExp("^\\s*" + wantN + "\\s*(s|秒)(\\s|$|[^0-9a-zA-Z])", "i");
      let db_ = cands.find(e => durExactN.test((e.innerText || "").trim()))
              || cands.find(e => durPreN.test((e.innerText || "").trim()));
      let clickN = wantN;
      if (!db_ && !isNaN(targetN)) {{
        // 页面确实没有该档位：按就近落档（targetN）找
        const durExactT = new RegExp("^\\s*" + targetN + "\\s*(s|秒)\\s*$", "i");
        const durPreT   = new RegExp("^\\s*" + targetN + "\\s*(s|秒)(\\s|$|[^0-9a-zA-Z])", "i");
        db_ = cands.find(e => durExactT.test((e.innerText || "").trim()))
             || cands.find(e => durPreT.test((e.innerText || "").trim()))
             || findBtn(targetN + "s") || findBtn(targetN + "秒");
        clickN = targetN;
      }}
      if (db_) {{ dbm.realClick(db_); await dbm.sleep(450); durOk = true; durLabel = clickN + "s" + fbSuffix; }}
    }}
    await dbm.sleep(500);
    const after = trigger && trigger.innerText ? trigger.innerText.replace(/\\s+/g, " ").trim() : before;
    dbm.esc();
    // 最终验证：after 需包含 aspWant；时长只要落在「目标档」或「已就近落到的档」都算成功，
    // 否则页面没有目标档时，即便已成功点击最近的可用档也会被误判为失败。
    const aspMatch = (aspWant === "自动" ? /^自动/.test(after) : after.includes(aspWant));
    const secRx = (n) => new RegExp("(^|[^0-9])" + n + "\\\\s*s($|[^a-z])", "i");
    const durMatch = secRx(secWant.replace(/s$/, "")) || (!isNaN(targetN) && secRx(targetN));
    const finalOk = !!(aspMatch && durMatch);
    return {{ ok: finalOk, asp: aspLabel, dur: durLabel, before, after }};
  }};
  // 兼容旧名（外部插件若直接调用此方法）
  dbm.pickDuration = (sec) => dbm.pickAspectDuration("自动", sec);
  // 关闭可能残留的弹层（时长下拉等），避免遮挡发送按钮
  dbm.esc = () => {{
    document.dispatchEvent(new KeyboardEvent("keydown", {{
      key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true }}));
    return true;
  }};
  // 模型选择：点开“模型 Seedance x.x”Radix 菜单，点目标模型项；带“升级”标签的判定为锁定
  dbm.ensureModel = async (name) => {{
    const trigger = Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && /模型/.test(e.innerText || "") && /Seedance/i.test(e.innerText || ""));
    if (!trigger) return {{ ok: false, reason: "no_model_trigger" }};
    const cur = (trigger.innerText || "").replace(/\\s+/g, " ").trim();
    if (cur.includes(name)) return {{ ok: true, label: "already " + cur.slice(0, 40) }};
    dbm.realClick(trigger);
    await dbm.sleep(1200);
    const items = Array.from(document.querySelectorAll("[role='menuitem']")).filter(dbm.vis);
    const item = items.find(e => {{
      const first = ((e.innerText || "").split("\\n")[0] || "").trim();
      return first === name || first.startsWith(name);
    }});
    if (!item) {{
      dbm.esc();
      return {{ ok: false, reason: "model_not_found",
               items: items.map(i => ((i.innerText || "").split("\\n")[0] || "").trim()).slice(0, 8) }};
    }}
    // ★ 2026-10-09 优化：不再仅凭菜单项里的"升级"文字角标预判锁定。
    //   "升级"是会员模型的常驻推广角标，即使账号实际可用该模型也会带着；旧逻辑会把它
    //   误判为"无权限"，导致 30 秒（需 Seedance 2.5）在能用的账号上也永远跑不起来。
    //   改为：直接尝试点击该模型项，再回看模型触发按钮文案是否真的变成目标模型——
    //   变了=可用（带"升级"角标也能用），没变=真锁（可能弹出了升级层）→ 判锁定并关弹窗。
    dbm.realClick(item);
    await dbm.sleep(900);
    const t2 = Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && /模型/.test(e.innerText || "") && /Seedance/i.test(e.innerText || ""));
    const label2 = (t2 && t2.innerText || "").trim();
    if (label2.includes(name)) {{
      return {{ ok: true, label: label2.slice(0, 40), switched: true }};
    }}
    // 选择未生效：该账号确实无此模型（或点"升级"弹出了升级层）。关闭可能的弹窗并判锁定。
    dbm.esc();
    await dbm.sleep(200);
    return {{ ok: false, reason: "model_locked", model: name }};
  }};
  // 账号是否正忙（页面里有生成中的任务：停止按钮 / 消息流“生成中”文字 / 加载动画）
  dbm.isPageBusy = () => {{
    const stop = Array.from(document.querySelectorAll("button"))
      .find(e => dbm.vis(e) && /停止|暂停生成|stop/i.test(
        (e.getAttribute("aria-label") || "") + " " + (e.innerText || "")));
    if (stop) return {{ busy: true, reason: "stop_button",
                        text: (stop.getAttribute("aria-label") || stop.innerText || "").trim().slice(0, 30) }};
    const ed = dbm.getEditor();
    const edBottom = ed ? ed.getBoundingClientRect().bottom : window.innerHeight;
    const re = /(视频生成中|视频创作中|正在生成|创作中|生成中[.…]|加载中|排队中)/;
    let spinner = null;
    const nodes = document.querySelectorAll("div,span,button");
    for (const e of nodes) {{
      if (!dbm.vis(e)) continue;
      const r = e.getBoundingClientRect();
      if (r.bottom > edBottom - 90) continue;   // 输入工具栏区域不算
      const t = (e.innerText || "").trim();
      if (t && t.length <= 24 && re.test(t)) return {{ busy: true, reason: "text", text: t.slice(0, 30) }};
      const cls = String(e.className || "");
      if (!spinner && e.querySelector("svg") && /(animate|spin|loading|pulse)/i.test(cls)) {{
        spinner = {{ reason: "spinner", cls: cls.slice(0, 40) }};
      }}
    }}
    if (spinner) return Object.assign({{ busy: true }}, spinner);
    return {{ busy: false }};
  }};
  // 额度/限流提示（豆包额度耗尽时以消息流错误或 toast 反馈，如“请求超限”）
  dbm.quotaNotice = () => {{
    const re = /(请求超限|额度不足|积分不足|余额不足|点数不足|次数已用完|次数用完|今日[^。\\n]{{0,10}}(次数|额度|上限)|已达[^。\\n]{{0,8}}上限|操作过于频繁|升级会员|开通会员|会员[^。\\n]{{0,6}}到期|配额[^。\\n]{{0,8}}(不足|用完)|今日视频生成免费次数[^。\\n]{{0,6}}用完|免费额度已用完|开通订阅畅享更多额度|畅享更多额度|明天再来[^。\\n]{{0,10}}继续)/;
    const hits = [];
    const seen = new Set();
    const scan = (root) => {{
      root.querySelectorAll("[role='alert'],[class*='toast'],[class*='Toast'],[class*='notice'],[class*='Notice'],[class*='bubble'],[class*='message'],[class*='reply'],[class*='content'],[class*='markdown']").forEach(e => {{
        if (!dbm.vis(e)) return;
        const t = (e.innerText || "").trim().replace(/\\s+/g, " ");
        if (t && t.length <= 80 && re.test(t) && !seen.has(t)) {{ seen.add(t); hits.push(t); }}
      }});
    }};
    scan(document);
    return hits.length ? hits[0].slice(0, 80) : null;
  }};
  // 明确额度耗尽文案（强信号，2026-11-03 v3）。
  // 豆包把"免费次数"改版成"免费额度 / 开通订阅畅享更多额度"后，旧版关键词只认
  // "次数"，新文案只能靠一条脆弱正则兜底命中（去掉"今日"二字就漏检），"开通订阅"
  // 更是完全不在识别库里。这里把"额度"系文案全部升级为显式关键词，并保留正则
  // 兜底覆盖文案微调。
  // 命中后 Python 侧会：直接把该账号当日生成计数补到上限（3/3 满额、不可派发）、
  // 写被动封禁标记（次日 00:01 恢复），且绝不把本次任务判成"视频已生成"。
  dbm.quotaExhausted = () => {{
    const all = (document.body.innerText || "").replace(/\\s+/g, " ");
    // 关键词匹配（按可信度排序，宽松匹配以适应豆包文案微调）
    const keywords = [
      "今日视频生成免费额度已用完",
      "今日视频生成免费次数用完",
      "视频生成免费额度已用完",
      "视频生成免费次数用完",
      "免费额度已用完",
      "免费次数已用完",
      "今日视频生成次数用完",
      "开通订阅畅享更多额度",
      "开通会员畅享更多额度",
      "明天再来找我继续",
      "明天再来继续"
    ];
    for (const kw of keywords) {{
      if (all.includes(kw)) return kw;
    }}
    // 正则兜底：今日...视频...(次数|额度)...用完 / (免费|视频生成)...额度...用完 /
    //           额度...用完...订阅 / 明天再来...继续
    const re = /今日[^。]{{0,20}}视频[^。]{{0,14}}(?:次数|额度)[^。]{{0,8}}用完|[^。]{{0,12}}(?:免费|视频生成)[^。]{{0,12}}额度[^。]{{0,8}}用完|额度[^。]{{0,8}}用完[^。]{{0,20}}订阅|明天再来[^。]{{0,15}}继续/;
    const m = all.match(re);
    if (m) return m[0].slice(0, 80);
    return null;
  }};
  // 发送按钮：填字后出现在编辑器右下角。扫描该区域，向上找真正的可点击元素
  // （<button>/[role=button] 优先；其次 cursor:pointer 的指针覆盖层），
  // 不能直接点命中的图标子 div —— 它与指针覆盖层是兄弟节点，事件不会横向冒泡。
  dbm.findSendTarget = (preferOverlay) => {{
    const ed = dbm.getEditor();
    if (!ed) return null;
    const r = ed.getBoundingClientRect();
    const ax = r.right - 22, ay = r.bottom + 16;
    let best = null;
    for (let dx = -72; dx <= 24; dx += 8) {{
      for (let dy = -20; dy <= 52; dy += 8) {{
        const x = r.right + dx, y = r.bottom + dy;
        const hit = document.elementFromPoint(x, y);
        if (!hit) continue;
        let el = hit, target = null;
        for (let i = 0; i < 7 && el; i++) {{
          const t = el.tagName ? el.tagName.toLowerCase() : "";
          const cs = getComputedStyle(el);
          const isBtn = t === "button" || el.getAttribute("role") === "button";
          const ptr = cs.cursor === "pointer";
          if (isBtn || ptr) {{
            const rr = el.getBoundingClientRect();
            if (rr.width > 8 && rr.width <= 90 && rr.height > 8 && rr.height <= 90) {{
              target = {{ el: el, isBtn: isBtn, ptr: ptr, x: x, y: y,
                          t: t, cls: String(el.className || "").slice(0, 50),
                          w: Math.round(rr.width), h: Math.round(rr.height) }};
              if (isBtn && !preferOverlay) break;  // button 祖先优先
              if (ptr && preferOverlay) break;    // 回退：指针覆盖层
            }}
          }}
          el = el.parentElement;
        }}
        if (target) {{
          const score = Math.hypot(x - ax, y - ay)
            + (target.isBtn && !preferOverlay ? -20 : 0)
            + (target.ptr && preferOverlay ? -20 : 0);
          if (!best || score < best.score) best = Object.assign(target, {{ score: score }});
        }}
      }}
    }}
    return best;
  }};
  dbm.clickSend = (preferOverlay) => {{
    const c = dbm.findSendTarget(!!preferOverlay);
    if (!c) return {{ ok: false, reason: "no_send_button" }};
    if (c.el.disabled || c.el.getAttribute("aria-disabled") === "true"
        || /停止|stop/i.test((c.el.getAttribute("aria-label") || "") + (c.el.innerText || "")))
      return {{ ok: false, reason: "send_disabled_or_busy" }};
    dbm.realClick(c.el);
    return {{ ok: true, tag: c.t, cls: c.cls, isBtn: c.isBtn, ptr: c.ptr,
              x: Math.round(c.x), y: Math.round(c.y), w: c.w, h: c.h,
              overlay: !!preferOverlay }};
  }};
  // 提交是否成功：编辑器被清空（消息已进入对话流）
  dbm.isSent = () => !!dbm.getEditor() && ((dbm.editorText() || "").trim().length < 3);
  // best-effort 探测当前登录账号昵称（用于多账号展示/关键字路由，失败返回 null）
  dbm.guessNick = () => {{
    const sels = ["[class*='user'] [class*='name']", "[class*='avatar'] [class*='Name']",
                  "aside [class*='name']", "[data-testid*='nick']", "[data-testid*='user']"];
    for (const s of sels) {{
      let e = null;
      try {{ e = document.querySelector(s); }} catch (err) {{}}
      if (e && dbm.vis(e)) {{
        const t = (e.innerText || "").trim();
        if (t && t.length >= 2 && t.length <= 12) return t;
      }}
    }}
    return null;
  }};
  dbm.fileInputs = () => dbm.q("input[type=file]").map((e, i) => ({{
    i: i, accept: e.accept || "", visible: dbm.vis(e)
  }}));
  dbm.pageInfo = () => {{
    const videos = dbm.q("video").map(v => v.currentSrc || v.src).filter(Boolean);
    let attach = {{ count: 0 }};
    try {{ attach = dbm.attachmentState(); }} catch (e) {{}}
    return {{
      url: location.href,
      title: document.title,
      video_mode: dbm.isVideoPage(),
      video_controls: dbm.videoControls(),
      attachments: attach,
      textareas: dbm.q("textarea").filter(dbm.vis).length,
      editables: dbm.q("[contenteditable='true']").filter(dbm.vis).length,
      // 原始计数（不做可见性过滤）：后台/未激活 webview 里 vis 可能全 false，
      // 判定"页面到底有没有输入框"必须用 raw，否则会误报 needs_calibration。
      textareas_raw: dbm.q("textarea").length,
      editables_raw: dbm.q("[contenteditable='true']").length,
      zero_layout: dbm.__zeroLayout(),
      file_inputs: dbm.fileInputs(),
      videos,
      buttons: dbm.q("button").filter(dbm.vis).map(b => (b.innerText || "").trim())
        .filter(Boolean).slice(0, 40),
    }};
  }};
  dbm.pageVideos = () => dbm.q("video")
    .map(v => v.currentSrc || v.src)
    // http(s) 直链与 blob: 媒体地址都算"视频已出现"
    // （豆包部分版本预览流用 blob:，旧逻辑只认 http 会误判为一直没出片而卡死）
    .filter(u => u && /^(https?:|blob:)/.test(u));
  // 视频模式的可靠特征：输入工具栏出现“模型 Seedance …”按钮，或“自动 · Ns”时长档位按钮
  dbm.videoControls = () => {{
    const btns = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(dbm.vis)
      .map(e => (e.innerText || "").replace(/\\s+/g, " ").trim());
    const hasModel = btns.some(t => /模型/.test(t) && /Seedance/i.test(t));
    const hasDuration = btns.some(t => /·\\s*\\d+\\s*s/.test(t) || /^自动/.test(t) && /\\d+\\s*s/.test(t));
    return {{ hasModel, hasDuration,
             modelBtn: btns.find(t => /模型/.test(t) && /Seedance/i.test(t)) || "",
             durBtn: btns.find(t => /·\\s*\\d+\\s*s/.test(t)) || "" }};
  }};
  dbm.isVideoPage = () => {{
    // URL 兜底（管理器直接打开视频创作地址时）
    if (/video/i.test(location.href)) return true;
    const c = dbm.videoControls();
    return !!(c.hasModel || c.hasDuration);
  }};
  // 页面是否已加载到可进入视频模式的就绪状态（用于并发时等待后台标签页渲染完成）
  dbm.chatReadyState = () => {{
    const controls = dbm.videoControls();
    const isVideo = !!(controls.hasModel || controls.hasDuration);
    // 首页快捷入口"视频生成"按钮（新对话首页）
    // ⚠️ 必须过 dbm.vis()：页面上常残留一个 innerText 为"视频生成"但不可见的节点，
    // 不做可见性过滤就会误报"入口已出现"，于是 _wait_chat_ready 立刻返回、
    // 真正要点击的 ensureVideoMode 却用 vis 过滤找不到 → no_video_entry。
    // 并发时多个页面同时刚加载，这个误判会被放大成"整批都进不了视频模式"。
    const hasVideoEntry = Array.from(document.querySelectorAll('button,[role="button"]'))
      .some(e => {{
        if (!dbm.vis(e)) return false;
        const t = (e.innerText || "").trim().replace(/\\s+/g, "");
        return t === "视频生成";
      }});
    const editor = dbm.getEditor();
    const hasComposer = !!(editor || document.querySelector("textarea,[contenteditable='true']"));
    return {{
      readyState: document.readyState,
      isVideo: isVideo,
      hasVideoEntry: hasVideoEntry,
      hasComposer: hasComposer,
      // 就绪 = 已在视频模式，或（首页视频入口出现 或 编辑器出现）
      ready: isVideo || hasVideoEntry || hasComposer
    }};
  }};
  // 页面健康度：识别"半加载卡死"的账号页（侧边栏渲染了，主内容区没渲染）。
  // 实测特征：正常页面可见按钮约 20 个、有 textarea、"视频生成"入口存在；
  // 卡死的页面只有 3~4 个按钮（豆包 / 创建新项目 / 昵称 / 下载电脑版），textarea=0，
  // 少加载 1 个 script。这种页面 chatReadyState 会误判就绪，必须在这里拦下来。
  dbm.pageHealth = () => {{
    const btns = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(dbm.vis);
    const hasEntry = btns.some(e =>
      (e.innerText || "").trim().replace(/\\s+/g, "") === "视频生成");
    const textareas = document.querySelectorAll("textarea").length;
    // 卡死判定：页面加载完了、既不在视频模式、又没有"视频生成"入口、也没有输入框
    // ⇒ 主内容区没渲染。
    // ⚠️ 不能用"按钮数 < 8"当主判据：实测有的坏页面侧边栏历史会话就有 10~12 个
    // 可见按钮（账号10 那次就是这样被漏掉，随后一路 no_video_entry）。
    // 决定性的信号是**"视频生成"入口缺失 + 没有 textarea**。
    // 可见的 contenteditable（会话页的输入框形态）：只用于诊断，不参与判定。
    // 实测坏页面被 revealEditor 强行显形后 editables 会变成 1、也能填词，
    // 但"视频生成"入口依然不存在，照样进不了视频模式 —— 所以不能算 usable。
    const editables = Array.from(
      document.querySelectorAll("[contenteditable='true']")).filter(dbm.vis).length;
    const isVideo = (typeof dbm.isVideoPage === "function") ? !!dbm.isVideoPage() : false;
    const complete = document.readyState === "complete";
    const degraded = !!document.body
      && complete
      && !isVideo && !hasEntry && textareas === 0;
    // usable = 页面"真正能操作"（有可见输入框、或有视频生成入口、或已在视频模式）。
    // ⚠️ 绝对不能拿 !degraded 当"页面已修好"：导航过程中 readyState==='interactive'
    //    时 degraded 恒为 false，会把"还在加载"误判成"已修复"。
    //    2026-09-19 日志里那句「页面已修复（按钮 11 个，入口=False）」就是这么来的 ——
    //    判据放水导致修复假成功，后面 ensureVideoMode 立刻又报 no_video_entry。
    const usable = !!document.body && complete
      && (isVideo || hasEntry || textareas > 0);
    return {{
      readyState: document.readyState,
      buttons: btns.length,
      hasVideoEntry: hasEntry,
      isVideo: isVideo,
      textareas: textareas,
      editables: editables,
      degraded: degraded,
      usable: usable,
      url: location.href,
    }};
  }};
  // 视频模式下 composer 会被换成"ghost"：一个 .pointer-events-none.invisible
  // 绝对定位副本里的隐藏 contenteditable。此时 dbm.vis() 判 false，填词必然失败。
  // 这里点一下最近的**可见**祖先容器，把真正的输入区唤醒。
  dbm.revealEditor = () => {{
    const cands = Array.from(document.querySelectorAll("textarea, [contenteditable='true']"));
    if (!cands.length) return {{ ok: false, reason: "no_editor" }};
    // 1) 已经有可见的输入框（首页 = textarea，会话页 = .tiptap 的 contenteditable）
    const visOne = cands.find(dbm.vis);
    if (visOne) {{
      try {{ visOne.scrollIntoView({{ block: "center" }}); visOne.focus(); }} catch (e) {{}}
      return {{ ok: true, mode: "visible", tag: visOne.tagName,
                cls: String(visOne.className || "").slice(0, 40) }};
    }}
    // 2) 全都不可见：输入区被祖先的 visibility:hidden / pointer-events:none 盖住了。
    //    ⚠️ 旧实现是"点最近的可见祖先"——实测会点到最外层的空壳容器
    //    （clicked = DIV.min-h-24 w-full，一个 96px 高的空白盒子，点了毫无作用）。
    //    原因：真正该点的 DIV.relative.w-full 高度为 0（它唯一的子元素是 absolute
    //    定位的浮层），会被 dbm.vis() 过滤掉，于是"往上找可见祖先"必然越过它。
    //    改为直接沿祖先链剥掉隐藏样式：inline style 优先级高于 Tailwind 的
    //    .invisible / .pointer-events-none 类，可以把输入区强行显形。
    const el = cands[0];
    const fixed = [];
    let n = el;
    for (let i = 0; i < 10 && n && n !== document.documentElement; i++) {{
      const cs = getComputedStyle(n);
      if (cs.visibility === "hidden" || cs.pointerEvents === "none"
          || parseFloat(cs.opacity) < 0.05) {{
        n.style.setProperty("visibility", "visible", "important");
        n.style.setProperty("pointer-events", "auto", "important");
        n.style.setProperty("opacity", "1", "important");
        fixed.push(n.tagName + "." + String(n.className || "").slice(0, 30));
      }}
      n = n.parentElement;
    }}
    try {{ el.scrollIntoView({{ block: "center" }}); el.focus(); }} catch (e) {{}}
    const cs2 = getComputedStyle(el);
    const r2 = el.getBoundingClientRect();
    return {{ ok: dbm.vis(el), mode: "force_unhide", fixed: fixed,
              visAfter: cs2.visibility, peAfter: cs2.pointerEvents,
              rect: r2.width + "x" + r2.height }};
  }};
  dbm.ensureVideoMode = async () => {{
    if (dbm.isVideoPage()) {{
      const c = dbm.videoControls();
      return {{ ok: true, mode: "already", url: location.href, model: c.modelBtn, dur: c.durBtn }};
    }}
    // 对话模式下输入框工具栏有“视频生成”模式页签
    // 匹配策略：严格相等 → 去空白包含 → aria-label/title 包含
    const entryText = (SEL.video_entry_text || "视频生成").trim();
    for (let attempt = 0; attempt < 3; attempt++) {{
      // 1. 严格文本匹配（同样只认按钮类元素，理由见策略 2 的注释）
      let entry = Array.from(document.querySelectorAll("button,[role='button'],a"))
        .find(e => dbm.vis(e) && (e.innerText || "").trim() === entryText);
      // 2. 去空白后包含匹配（按钮可能有图标+文字，innerText 可能有多余空白/换行）
      //    ⚠️ 只认 button/[role=button]/a：早期版本把 div/span 也算进来，页面卡死时
      //    会点到一个"含'视频生成'文字的无关容器"，点了没反应 → 报
      //    video_mode_not_active（看起来像"点了没生效"），把真正的根因（页面半加载）
      //    完全掩盖住。限定成按钮后抓不到就会如实报 no_video_entry。
      if (!entry) {{
        entry = Array.from(document.querySelectorAll("button,[role='button'],a"))
          .find(e => {{
            if (!dbm.vis(e)) return false;
            const t = (e.innerText || "").trim().replace(/\\s+/g, "");
            return t && t.length <= 10 && t.includes(entryText.replace(/\\s+/g, ""));
          }});
      }}
      // 3. aria-label / title 匹配
      if (!entry) {{
        entry = Array.from(document.querySelectorAll("button,[role='button'],a"))
          .find(e => {{
            if (!dbm.vis(e)) return false;
            const label = (e.getAttribute("aria-label") || e.getAttribute("title") || "").trim();
            return label === entryText || (label && label.includes(entryText));
          }});
      }}
      if (!entry) {{
        const allBtns = Array.from(document.querySelectorAll("button,[role='button']"))
          .filter(dbm.vis).map(b => (b.innerText || "").trim().replace(/\\s+/g, " "))
          .filter(Boolean).slice(0, 20);
        return {{ ok: false, reason: "no_video_entry", url: location.href,
                  entryText: entryText, visibleButtons: allBtns }};
      }}
      dbm.realClick(entry);
      await dbm.sleep(3000);
      if (dbm.isVideoPage()) {{
        const c = dbm.videoControls();
        return {{ ok: true, mode: "clicked", attempt: attempt + 1,
                  text: (entry.innerText || "").trim().slice(0, 20),
                  model: c.modelBtn, dur: c.durBtn, url: location.href }};
      }}
      await dbm.sleep(2000);
      if (dbm.isVideoPage()) {{
        const c = dbm.videoControls();
        return {{ ok: true, mode: "clicked_slow", attempt: attempt + 1,
                  text: (entry.innerText || "").trim().slice(0, 20),
                  model: c.modelBtn, dur: c.durBtn, url: location.href }};
      }}
    }}
    // 最终诊断
    const c2 = dbm.videoControls();
    const allBtns2 = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(dbm.vis).map(b => (b.innerText || "").trim().replace(/\\s+/g, " "))
      .filter(Boolean).slice(0, 20);
    return {{ ok: false, reason: "video_mode_not_active", url: location.href,
              videoControls: c2, visibleButtons: allBtns2 }};
  }};
  // ---- 参考图附件（输入框上方缩略图 chip）----
  // 标定说明：原只认视频创作页的 [class*='thumb-card']。去掉视频模式后，插件会落在
  // 普通对话输入框，缩略图可能使用不同的 class（upload / attachment / preview /
  // image-item / img-item / file-item 等），且 React 上传完成会把 <input type=file> 的
  // .files 清空、并重渲染预览区（实测：上传中 count=4，发送前复检瞬间变 0）。
  // 因此检测改为“三路取最大”，任何一路命中都算数：
  //   1) 标定 chip class（thumb_card 候选数组，见 selectors.json）；
  //   2) composer 区域内“可见缩略图 <img>”数量（不依赖任何 class、也不依赖 file input 是否残留
  //      files——这是去掉视频模式后普通对话输入框最可靠的信号，已实测 4 张图能正确数出 4）；
  //   3) file input 里实际加载的文件数（input.files，仅作补充兜底）。
  dbm.thumbCardSel = () => {{
    const base = Array.isArray(SEL.thumb_card) ? SEL.thumb_card
                : (SEL.thumb_card ? [SEL.thumb_card] : []);
    const extra = ["[class*='thumb-card']","[class*='thumbCard']",
                   "[class*='upload']","[class*='Upload']",
                   "[class*='attachment']","[class*='Attachment']",
                   "[class*='preview']","[class*='Preview']",
                   "[class*='image-item']","[class*='imageItem']",
                   "[class*='img-item']","[class*='imgItem']",
                   "[class*='file-item']","[class*='fileItem']",
                   "[class*='pic-item']","[class*='picItem']",
                   "[class*='media-item']","[class*='mediaItem']"];
    const set = new Set([...base, ...extra].filter(Boolean));
    return Array.from(set).join(",");
  }};
  dbm.thumbDelSel = () => {{
    const base = Array.isArray(SEL.thumb_delete_btn) ? SEL.thumb_delete_btn
                : (SEL.thumb_delete_btn ? [SEL.thumb_delete_btn] : []);
    const extra = ["[class*='delete-btn']","[class*='delete']","[class*='Delete']",
                   "[class*='close']","[class*='Close']","[class*='remove']","[class*='Remove']"];
    const set = new Set([...base, ...extra].filter(Boolean));
    return Array.from(set).join(",");
  }};
  // 一个 <img> 是否“像附件缩略图”：可见、尺寸够大（排除图标/按钮）、src 像图片。
  // blob:/data: 是本地选中文件生成的“对象 URL”，是最强信号（聊天记录里的图通常是 http(s) CDN 地址）。
  dbm._thumbImg = (im) => {{
    try {{
      if (!dbm.vis(im)) return false;
      const w = im.clientWidth || im.naturalWidth || 0;
      const h = im.clientHeight || im.naturalHeight || 0;
      if (w < 36 || h < 36) return false;   // 太小的是图标/按钮，不是附件缩略图
      const src = (im.src || im.currentSrc || "").toLowerCase();
      if (/^blob:/.test(src)) return true;
      // ★ 2026-10-15：data:image/svg+xml 是新版 mdbox 卡片的装饰占位图
      //   （每张附件都有一个 54px svg 底图 + 一张真实图），不能算缩略图，
      //   否则一张附件被数成两张。data: 只接受位图。
      if (/^data:image\/(png|jpe?g|webp|gif|bmp)/.test(src)) return true;
      if (/^https?:/.test(src) && /\.(png|jpe?g|webp|gif|bmp)(\?|#|$)/.test(src)) return true;
      return false;
    }} catch (e) {{ return false; }}
  }};
  // 一个元素是否“真的是张缩略图容器”：自身/子节点含 <img> 或 <canvas>，或带背景图（部分 UI 用背景图而非 <img>）
  dbm._isThumb = (el) => {{
    try {{
      if (el.tagName === "IMG" || el.tagName === "CANVAS") return dbm.vis(el) && !!el.src;
      if (el.querySelector && el.querySelector("img,canvas")) return true;
      const s = getComputedStyle(el);
      const bi = (s.backgroundImage || s.webkitBackgroundImage || "");
      if (bi && bi !== "none" && /\.(png|jpe?g|webp|gif|bmp)|data:image|blob:/i.test(bi)) return true;
    }} catch (e) {{}}
    return false;
  }};
  dbm.thumbCards = () => {{
    const all = Array.from(document.querySelectorAll(dbm.thumbCardSel()))
      .filter(c => dbm.vis(c) && (c.querySelector("img") || c.querySelector("canvas") || dbm._isThumb(c)));
    // 去重：若一个元素包含另一个匹配元素（容器包叶子），只保留最内层叶子，避免容器+叶子重复计数
    return all.filter(c => !all.some(o => o !== c && c.contains(o)));
  }};
  // composer 区域：从输入框向上找“最小且含缩略图 img”的祖先（即输入框+附件区所在容器）。
  // 这样只数“当前对话框”的附件，不会把上方聊天记录里的图也算进来；也不依赖任何具体 chip class。
  dbm.composerRegion = () => {{
    const inp = dbm.getEditor();
    if (!inp) return null;
    let el = inp;
    for (let i = 0; i < 8 && el; i++) {{
      if (Array.from(el.querySelectorAll("img")).some(dbm._thumbImg)) return el;
      el = el.parentElement;
    }}
    return inp.parentElement || inp;
  }};
  // ★ 2026-10-15：豆包改版（tiptap ProseMirror 新输入框）后，附件预览卡片
  //   container-MzuYIN > [data-testid=mdbox_image] > img.image-Q7dBqW(blob:/CDN)
  //   与编辑器不在同一 DOM 分支——编辑器祖先链向上 8 层到不了附件区，旧
  //   composerRegion 永远数 0；旧 chip class（thumb-card/upload/attachment 等）
  //   也全部失配。结果：文件已塞、卡片已渲染，插件却判"未受理"反复重传 16 次。
  //   新版输入框有稳定锚点 id=input-engine-container（data-testid=chat_input），
  //   附件卡片就在它内部，天然与上方聊天历史隔离。
  dbm.attachRegion = () => {{
    return document.querySelector("#input-engine-container")
        || document.querySelector("[data-testid='chat_input']")
        || dbm.composerRegion();
  }};
  // 新版附件卡片：mdbox_image 是 imagex 图片组件的 wrapper（一图一节点）
  dbm.mdboxCards = () => {{
    const region = dbm.attachRegion();
    if (!region) return [];
    return Array.from(region.querySelectorAll("[data-testid='mdbox_image']"))
      .filter(c => dbm.vis(c));
  }};
  // ★ 2026-11-13：豆包「参考项」支持上传参考音频。音频附件不是图片卡，而是
  //   [data-testid=attachment_file_item]（FileAudio 图标 + 文件名 + "Audio · 3KB"
  //   字幕 + 删除 svg），没有 <img>。旧 attachmentState 只数 mdbox_image /
  //   缩略图 img，音频上传后 cardCount 恒为 0，而期望是「图片+音频」总数，
  //   于是永远判"附件不匹配"，任务一直重传到超时。
  //   另外图片卡的删除按钮挂在父级 [data-testid=attachment-image-card]，
  //   旧 clearAttachments 拿内层 mdbox_image 去 querySelector 找不到删除按钮，
  //   残留附件清不掉（实测 removed=0 / left=1）。
  dbm.attachmentFileCards = () => {{
    const region = dbm.attachRegion();
    if (!region) return [];
    return Array.from(region.querySelectorAll("[data-testid='attachment_file_item']"))
      .filter(c => dbm.vis(c));
  }};
  dbm.attachmentImageCards = () => {{
    const region = dbm.attachRegion();
    if (!region) return [];
    return Array.from(region.querySelectorAll("[data-testid='attachment-image-card']"))
      .filter(c => dbm.vis(c));
  }};
  // 每个附件只算一张卡：优先用新版稳定 testid（图片卡 / 文件卡，二者互不包含）；
  // 老版 DOM 没有这些 testid 时退回 chip / mdbox_image / composer 容器，
  // 并去掉「容器包叶子」造成的重复计数。
  dbm.attachmentCards = () => {{
    const primary = dbm.attachmentImageCards().concat(dbm.attachmentFileCards());
    if (primary.length) return primary;
    const set = new Set();
    try {{ dbm.thumbCards().forEach(c => set.add(c)); }} catch (e) {{}}
    try {{ dbm.mdboxCards().forEach(c => set.add(c)); }} catch (e) {{}}
    try {{ dbm.composerAttachmentCards().forEach(c => set.add(c)); }} catch (e) {{}}
    const all = Array.from(set);
    return all.filter(c => !all.some(o => o !== c && o.contains(c)));
  }};
  dbm.composerThumbs = () => {{
    const region = dbm.attachRegion();
    if (!region) return [];
    return Array.from(region.querySelectorAll("img")).filter(dbm._thumbImg);
  }};
  // composer 区域内“含缩略图 img”的容器（用于清空旧附件，不依赖 chip class）
  dbm.composerAttachmentCards = () => {{
    const region = dbm.attachRegion();
    if (!region) return [];
    const conts = Array.from(region.querySelectorAll("*"))
      .filter(el => el.querySelector && el.querySelector("img") && Array.from(el.querySelectorAll("img")).some(dbm._thumbImg));
    return conts.filter(c => !conts.some(o => o !== c && c.contains(o)));
  }};
  // 附件失败特征：豆包失败态有时只有图标/红点、没有文字，所以文字和 class 都要看
  dbm._ATTACH_FAIL_RE = /上传失败|发送失败|上传出错|失败|重试|重新上传|已停止|超时/;
  dbm.attachmentState = () => {{
    // ★ 2026-11-13：卡片集合 = 图片卡 ∪ 音频/文件卡（每个附件一张，节点去重）。
    //   异常时退回旧版 chip ∪ mdbox_image，保证老页面不受影响。
    let cards = [];
    try {{ cards = dbm.attachmentCards(); }} catch (e) {{
      const fallback = new Set(dbm.thumbCards());
      dbm.mdboxCards().forEach(c => fallback.add(c));
      cards = Array.from(fallback);
    }}
    const composerImgs = dbm.composerThumbs(); // 输入区域内可见缩略图 img（不依赖 class / file input）
    let uploading = 0, failed = 0, broken = 0;
    const names = [];
    // —— 1) 卡片扫描（保留原失败/上传中/裂图判定）——
    cards.forEach(c => {{
      const t = (c.innerText || "").trim();
      let bad = dbm._ATTACH_FAIL_RE.test(t);
      if (!bad) {{
        try {{
          if (c.querySelector("[class*='error'],[class*='Error'],[class*='fail'],"
            + "[class*='Fail'],[class*='retry'],[class*='Retry'],[class*='warn']")) bad = true;
        }} catch (e) {{}}
      }}
      if (bad) failed++;
      if (Array.from(c.querySelectorAll("[class*='animate-spin'],[class*='loading'],[class*='progress'],[class*='spinner']"))
          .some(dbm.vis) || /上传中|正在上传/.test(t)) uploading++;
      const im = c.querySelector("img");
      if (im) {{
        if (im.alt) names.push(im.alt);
        try {{ if (im.complete && !im.naturalWidth) broken++; }} catch (e) {{}}
      }}
      // 音频/文件卡没有 <img>：取文件名节点，或图片卡的 aria-label
      const fn = c.querySelector("[data-testid='message_nested_content_file_name']");
      if (fn && (fn.innerText || "").trim()) names.push(fn.innerText.trim());
      const al = c.getAttribute && c.getAttribute("aria-label");
      if (al && al.trim() && names.indexOf(al.trim()) < 0) names.push(al.trim());
    }});
    // —— 2) composer img 补扫（失败/裂图/上传中转圈，不依赖 chip class）——
    composerImgs.forEach(im => {{
      if (im.alt) names.push(im.alt);
      try {{ if (im.complete && !im.naturalWidth) broken++; }} catch (e) {{}}
      const host = im.parentElement || im;
      const t = ((im.alt || "") + " " + (host.innerText || "")).trim();
      if (dbm._ATTACH_FAIL_RE.test(t)) failed++;
      if (Array.from(host.querySelectorAll("[class*='animate-spin'],[class*='loading'],[class*='progress'],[class*='spinner']"))
          .some(dbm.vis) || /上传中|正在上传/.test(t)) uploading++;
    }});
    // —— 3) file input 兜底：★只统计当前输入框容器内的 input★。
    //    页面"+"菜单 radix 浮层里还有一个隐形死 input（pointer-events-none invisible），
    //    对它 setFileInputFiles 也能塞进 files，但豆包不受理——旧逻辑全文档统计，
    //    死控件残留文件让 fileCount 虚高、也会把它误当候选反复重传。
    let fileCount = 0;
    try {{
      const scope = dbm.attachRegion() || document;
      scope.querySelectorAll("input[type=file]").forEach(inp => {{
        try {{
          const acc = (inp.getAttribute("accept") || "").toLowerCase();
          const isMedia = /\.(png|jpe?g|webp|gif|bmp|mp3|wav|m4a|aac|ogg|flac|amr|aiff|wma|ac3)|image\/|audio\//.test(acc);
          if (!isMedia && !inp.multiple) return;
          if (inp.files && inp.files.length) fileCount += inp.files.length;
        }} catch (e) {{}}
      }});
    }} catch (e) {{}}
    const cardCount = cards.length;
    const composerCount = composerImgs.length;
    // 三路取最大：附件卡片 / 渲染层缩略图 img / 活跃 input 文件数。
    const count = Math.max(cardCount, fileCount, composerCount);
    return {{ count, cardCount, fileCount, composerCount, uploading, failed, broken,
             // 满配 = 9 张参考图 + 3 个参考音频，旧版 slice(0,9) 会把音频文件名截掉
             names: names.slice(0, 12) }};
  }};
  // ★ 2026-10-12 上传网络层正向证据：fileCount 只是插件塞进 input 的文件数，
  // chip/img 渲染滞后时两者全为 0，旧逻辑会"空真"判成功并盲目点发送 —— 豆包
  // 实际未受理图片，消息永远停在 local_ 会话（submission_not_acknowledged）。
  // 这里扫 performance 资源时间线里的上传类请求：
  //   enough  = 完成的上传请求数 >= 期望张数（逐条/并发上传时直接判满）
  //   settled = 最后一条上传请求完成后已静默 >= 6s（批量/分片上传时确认批次结束）
  // ★ 2026-11-14：参考音频与图片走同一个上传通道（实测 performance 里的
  //  /alice/resource/prepare_upload、Action=ApplyImageUpload、tos.../upload/v1/*.wav
  //  都含 "upload"，原正则已能命中），无需为音频另加规则。
  dbm.uploadNetEvidence = (sinceMs, expected) => {{
    try {{ performance.setResourceTimingBufferSize(4096); }} catch (e) {{}}
    const since = (typeof sinceMs === "number" && sinceMs > 0) ? sinceMs : 0;
    const re = /upload|imagex|bytetos|byteimg|\\/tos\\/|tosx|imgx|imagex/i;
    const hits = [];
    let lastDone = -1;
    try {{
      (performance.getEntriesByType("resource") || []).forEach(e => {{
        if (e.startTime < since) return;
        if (!/fetch|xmlhttprequest|beacon/i.test(String(e.initiatorType || ""))) return;
        const u = String(e.name || "");
        if (re.test(u)) {{
          hits.push({{ url: u.slice(-90), ms: Math.round(e.duration) }});
          const done = e.startTime + (e.duration || 0);
          if (done > lastDone) lastDone = done;
        }}
      }});
    }} catch (e) {{}}
    const now = performance.now();
    const settled = hits.length > 0 && lastDone >= 0 && (now - lastDone) >= 6000;
    const enough = (typeof expected === "number" && expected > 0)
      ? hits.length >= expected : false;
    return {{ count: hits.length, enough, settled,
              now: Math.round(now), lastDone: Math.round(lastDone),
              samples: hits.slice(0, 3) }};
  }};
  // 附件卡删除按钮：只认明确的删除/关闭语义，以及「无文本的图标按钮」。
  // 音频卡里另有「总结音频内容」这类带文字的功能按钮，宽泛 fallback 会误点它，
  // 弹出新面板并让清理 Promise 一直挂起。
  dbm._attachmentDelSel = () => (
    dbm.thumbDelSel() + ","
    + "[aria-label*='删除'],[aria-label*='移除'],[title*='删除'],[title*='移除'],"
    + "[aria-label*='remove'],[title*='remove'],[aria-label*='close'],[title*='close'],"
    + "[data-testid*='delete'],[data-testid*='remove']"
  );
  // ★ 2026-11-14：满配 9图+3音频时，旧实现「每轮只点一张卡 + 等 450ms」
  //  实测会卡住 24s 以上并残留 4 张卡，生产侧 evaluate(awaitPromise) 直接
  //  60s 超时让任务失败。改为每轮批量点掉全部删除按钮 + 10 轮上限 + 12s
  //  硬时限，实测 12 个附件 4 轮（约 3s）清零，且保证 Promise 一定 resolve。
  dbm.clearAttachments = async () => {{
    let removed = 0;
    const started = Date.now();
    for (let round = 0; round < 10 && Date.now() - started < 12000; round++) {{
      const cards = [];
      try {{ dbm.attachmentCards().forEach(c => {{ if (cards.indexOf(c) < 0) cards.push(c); }}); }} catch (e) {{}}
      // 老版 DOM 没有稳定 testid 时才补扫，避免「外层卡 + 内层 wrapper」重复点击
      if (!cards.length) {{
        try {{ dbm.thumbCards().forEach(c => {{ if (cards.indexOf(c) < 0) cards.push(c); }}); }} catch (e) {{}}
        try {{ dbm.mdboxCards().forEach(c => {{ if (cards.indexOf(c) < 0) cards.push(c); }}); }} catch (e) {{}}
        try {{ dbm.composerAttachmentCards().forEach(c => {{ if (cards.indexOf(c) < 0) cards.push(c); }}); }} catch (e) {{}}
      }}
      if (!cards.length) break;
      let clicked = 0;
      cards.forEach(c => {{
        let del = null;
        try {{ del = c.querySelector(dbm._attachmentDelSel()); }} catch (e) {{}}
        if (!del) {{
          try {{
            const bs = Array.from(c.querySelectorAll("button,[role='button']"))
              .filter(b => !(b.innerText || "").trim());
            if (bs.length) del = bs[bs.length - 1];
          }} catch (e) {{}}
        }}
        if (!del) return;
        try {{ if (dbm.realClick(del)) {{ clicked++; removed++; }} }} catch (e) {{}}
      }});
      if (!clicked) break;
      await dbm.sleep(500);
    }}
    let left = 0;
    try {{ left = dbm.attachmentCards().length; }} catch (e) {{
      left = Math.max(dbm.thumbCards().length, dbm.mdboxCards().length,
                      dbm.composerAttachmentCards().length);
    }}
    // 卡片删掉后 file input 里可能仍挂着旧 FileList（React 未同步清理），
    // attachmentState 的 count 取 max(卡片, fileCount, img)，残留会让计数虚高，
    // 下一轮上传误判"附件已齐"。清原生 value 与 Python 侧 _reset_upload_input 同理。
    try {{
      const scope = dbm.attachRegion() || document;
      scope.querySelectorAll("input[type=file]").forEach(inp => {{
        try {{ inp.value = ""; }} catch (e) {{}}
      }});
    }} catch (e) {{}}
    return {{ removed, left }};
  }};
  // ===================== 安全确认弹窗 =====================
  // 发送后豆包可能弹出"确认安全/内容安全"对话框，需要点击确认按钮
  dbm.confirmSafetyDialog = () => {{
    // 查找模态对话框
    const dialogs = Array.from(document.querySelectorAll(
      "[role='dialog'],[role='alertdialog'],[class*='modal'],[class*='Modal'],[class*='dialog'],[class*='Dialog'],[data-state='open']"
    )).filter(dbm.vis);
    for (const dlg of dialogs) {{
      const btns = Array.from(dlg.querySelectorAll("button,[role='button']")).filter(dbm.vis);
      // 确认按钮：文本匹配确认/确定/继续/同意等
      const confirmBtn = btns.find(b => {{
        const t = (b.innerText || "").trim();
        return /^(确认|确定|同意|我知道了|继续生成|继续|是|确认生成|确认安全|确认内容|确定生成|OK|Confirm)$/.test(t)
               || /确认|确定|继续|同意/.test(t);
      }});
      if (confirmBtn) {{
        dbm.realClick(confirmBtn);
        return {{ ok: true, text: (confirmBtn.innerText || "").trim().slice(0, 20),
                 dialogText: ((dlg.innerText || "").trim()).slice(0, 80) }};
      }}
    }}
    return {{ ok: false, reason: "no_safety_dialog" }};
  }};
  // ===================== 新建对话 =====================
  // 在豆包页面创建一个新对话，避免多个任务共用同一对话导致上下文混乱
  // 查找侧边栏"新对话"按钮（文本/aria-label/title 含"新对话"/"新建对话"）
  dbm.startNewConversation = () => {{
    // 1. 查找侧边栏中的"新对话"按钮
    const candidates = Array.from(document.querySelectorAll(
      "button,[role='button'],a"
    )).filter(el => {{
      if (!dbm.vis(el)) return false;
      const t = (el.innerText || "").trim();
      const label = (el.getAttribute("aria-label") || el.getAttribute("title") || "").trim();
      return t === "新对话" || t === "新建对话" || t === "开始新对话" ||
             /新对话|新建对话|开始新对话/.test(t) ||
             /新对话|新建对话/.test(label);
    }});
    if (candidates.length) {{
      // 选最靠左上角的一个（侧边栏通常在左侧）
      const btn = candidates.slice().sort((a, b) => {{
        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        return (ra.x + ra.y) - (rb.x + rb.y);
      }})[0];
      dbm.realClick(btn);
      return {{ ok: true, method: "click_button", text: (btn.innerText || "").trim().slice(0, 20) }};
    }}
    // 2. 查找带"+"图标的按钮（有些版本用"+"图标表示新对话）
    const iconBtns = Array.from(document.querySelectorAll(
      "button,[role='button'],a"
    )).filter(el => {{
      if (!dbm.vis(el)) return false;
      const cls = String(el.className || "");
      const svg = el.querySelector("svg");
      // 在侧边栏区域（x < 300）的带 svg 的按钮
      const rect = el.getBoundingClientRect();
      if (rect.x > 300) return false;
      return (cls.includes("new") || cls.includes("create") || cls.includes("add")) && svg;
    }});
    if (iconBtns.length) {{
      dbm.realClick(iconBtns[0]);
      return {{ ok: true, method: "click_icon_button" }};
    }}
    // 3. 兜底：通过 URL 跳转创建新对话（doubao.com/chat/ 根路径会创建新对话）
    //    注意：此方法会重载页面，需在调用后重新注入脚本
    return {{ ok: false, reason: "no_new_chat_button", suggest_navigate: true }};
  }};
  // 检查页面是否出现生成确认文本（豆包回复"本次使用...生成，预计等待..."）
  dbm.checkGenerationConfirmed = () => {{
    // 在消息流中查找确认文本
    const messages = Array.from(document.querySelectorAll(
      "[class*='message'],[class*='bubble'],[class*='content'],[class*='assistant'],[class*='reply']"
    )).filter(dbm.vis);
    for (const msg of messages) {{
      const t = (msg.innerText || "").trim();
      if (t.includes("本次使用") && t.includes("预计等待") && t.includes("视频生成好后")) {{
        return {{ ok: true, text: t.slice(0, 150), source: "message" }};
      }}
    }}
    // 兜底：检查整个文档
    const body = (document.body.innerText || "");
    if (body.includes("本次使用") && body.includes("预计等待") && body.includes("视频生成好后")) {{
      return {{ ok: true, text: "found_in_body", source: "body" }};
    }}
    return {{ ok: false }};
  }};
  // 检测豆包是否明确回复"生成失败"（内容审核拒绝 / 生成失败 / 系统繁忙）。
  // 严格只扫消息气泡文本（不用常驻按钮文案，避免误判，教训同 quotaNotice）；
  // Python 端还会要求"页面无 <video> + 连续命中"才采信。
  dbm.generationFailed = () => {{
    // ⚠️⚠️ 2026-09-22 实测补充：豆包的拒绝话术**会变**，而且常带空格/斜杠。
    //   本次 9 并发事故里豆包的原话是：
    //     "生成内容中疑似包含侵权 / 违规内容，无法返回该内容，
    //      换个主题再试试，生成额度未扣除。"
    //   而旧表里写的是"内容违规"（词序相反）和"无法**生成**该内容"（动词不同），
    //   **一个都命中不了** → 5 个任务一路空转到 1700s+ 才超时失败。
    //   所以这里 words + 正则双重匹配：正则专门消化话术里的空格 / 全半角斜杠 /
    //   换行，避免下次豆包再改一个字就全线失效。
    const RULES = [
      {{ kind: "moderation", words: [
        "不符合社区规范", "不符合相关规范", "违反社区规范", "违反内容规范",
        "违反相关规定", "内容涉嫌违规", "内容违规", "审核未通过", "未通过审核",
        "无法生成相关内容", "无法生成该内容", "该内容无法生成", "无法为你生成该内容",
        // ↓ 2026-09-22 实测话术（豆包会把拒绝理由换着说，两类都撞上过）
        "疑似包含侵权", "侵权内容", "违规内容", "无法返回该内容",
        "换个主题再试试", "换个话题再试试", "生成额度未扣除", "涉嫌侵权", "涉嫌违规",
        //   同一批任务里豆包给的第二种理由：版权限制
        "涉及版权限制", "版权限制", "版权受限", "涉及版权",
        "请更换输入内容", "更换输入内容后重试", "请更换内容", "更换内容后重试"
      ]}},
      {{ kind: "failed", words: [
        "视频生成失败", "生成视频失败", "视频生成出错", "生成出错", "生成失败",
        "未能生成视频", "没能生成视频", "生成不成功", "无法为你生成视频",
        "不能生成该视频", "视频没有生成成功", "无法返回该内容"
      ]}},
      {{ kind: "busy", words: [
        "系统繁忙，请稍后", "系统开小差", "服务开小差", "当前使用人数过多",
        "请稍后再试", "请稍后重试", "网络繁忙，请稍后"
      ]}}
    ];
    // 正则兜底：话术里的空格 / 全角斜杠 / 换行会让纯子串匹配失效
    const PATTERNS = [
      {{ kind: "moderation", re: /侵权\\s*[／/\\|]?\\s*违规/ }},
      {{ kind: "moderation", re: /违规\\s*[／/\\|]?\\s*内容/ }},
      {{ kind: "moderation", re: /无法返回该内容/ }},
      {{ kind: "moderation", re: /换个\\s*主题|换个\\s*话题/ }},
      {{ kind: "moderation", re: /额度\\s*未扣除|不\\s*扣除\\s*额度/ }},
      {{ kind: "moderation", re: /疑似\\s*包含/ }},
      {{ kind: "moderation", re: /涉嫌\\s*违规|涉嫌\\s*侵权/ }},
      {{ kind: "moderation", re: /版权\\s*限制|版权\\s*受限|涉及\\s*版权/ }},
      {{ kind: "moderation", re: /更换\\s*输入\\s*内容|更换\\s*内容|换个\\s*内容/ }}
    ];
    // "让你改输入"这一类通用拒绝（豆包下一版话术大概率还是这个套路）
    const PATTERNS2 = [
      {{ kind: "moderation", re: /请\\s*更换[^。]{{0,10}}(内容|输入|素材|描述)/ }},
      {{ kind: "moderation", re: /(内容|素材|描述)[^。]{{0,8}}后\\s*重试/ }}
    ];
    const ALL_PATTERNS = PATTERNS.concat(PATTERNS2);
    const messages = Array.from(document.querySelectorAll(
      "[class*='message'],[class*='bubble'],[class*='content'],[class*='assistant'],[class*='reply']"
    )).filter(dbm.vis);
    // ★ 2026-09-24：跳过**我们自己发出去的**消息。
    //   确认文本/提示词由 setPrompt 登记在 dbm.__mine（见 setPrompt 里的注释）。
    //   事故：确认文本被改成"…修改为不涉及版权、不侵权、不违规的提示词…"，
    //   自带"涉及版权/不侵权/不违规" → 我们自己发的消息触发了自己判自己失败。
    //   用户气泡与助手气泡的 className 实测无法区分，所以只能靠这条登记簿。
    const MINE = dbm.__mine || [];
    // ★★ 2026-10-13 修复"版权申诉后仍被旧拒绝文案判死"：
    //   旧逻辑扫**全部**气泡、取第一个命中 —— 版权申诉的两条对话发出去后，
    //   第一轮的旧拒绝文案永久残留在会话里；豆包改写提示词+重新生成要
    //   5~10 分钟，宽限期一过（实测 18:36:16，宽限截止后 4 秒）就被旧文案
    //   再次命中判死，两条申诉等于白发。
    //   现在**只把"豆包最新一条有效回复"当判决**：
    //   - 申诉后豆包只要回了任何新内容（改写确认 / 生成进度 / 新拒绝 /
    //     成片卡片），旧拒绝即告失效，判决以新回复为准；
    //   - 若最新有效回复仍是旧拒绝（豆包迟迟不接茬），照常返回 failed，
    //     由宽限期（copyright_appeal_grace_sec）与回收预算兜底。
    //   细节：
    //   a) 父子去重（同 __collectBeanMessages）：选择器会同时命中消息容器与
    //      其内部节点，文本互为前缀/后缀时只算一条，避免把气泡内碎片当成
    //      "更新的消息"；
    //   b) 判决只认长度 ≥ 8 字的气泡：拒绝话术都是完整句子，而按钮
    //      （「重新生成」）/时间戳类碎片通常 < 8 字 —— 短碎片既不参与判决，
    //      也不遮蔽它前面那条完整消息。
    const MIN_VERDICT = 8;
    // ★★ 2026-10-23 修复"版权拒绝被输入区菜单遮蔽、永不申诉"：
    //   实测页面（会话 38448799092518146，18:10）豆包已回
    //     「生成的视频可能涉及版权限制，请更换输入内容后重试」
    //   但 generationFailed() 仍返回 failed:false —— 原因是选择器
    //   `[class*='content']` 同时命中了输入框下方的模式菜单
    //   `guidance-input-content`（文本「对话 图像生成 视频生成 PPT 生成 帮我写作…」），
    //   它排在消息之后、长度 40 ≥ MIN_VERDICT，于是被当成"最后一条回复"，
    //   真正的版权拒绝被判成"不是最新的消息"而忽略 → 不申诉、不改写、不回复，
    //   任务一路空等到超时（实测 576s 仍在等）。
    //   三条过滤：①排除输入区/菜单区节点 ②排除纯时间戳 ③排除模式菜单文案。
    const inInputArea = (el) => {{
      try {{
        return !!(el.closest
          && el.closest("#input-engine-container,[data-testid='chat_input'],"
            + "[class*='guidance-input'],[class*='input-engine'],"
            + "[class*='sender'],[class*='Sender'],"
            + "[class*='input-area'],[class*='inputArea'],"
            + "[contenteditable='true'],[contenteditable=true]"));
      }} catch (e) {{ return false; }}
    }};
    const TS_RE = /^(今天|昨天|前天|\\d{{1,2}}-\\d{{1,2}})\\s*\\d{{1,2}}:\\d{{2}}$|^\\d{{1,2}}:\\d{{2}}$/;
    const MENU_RE = /图像生成[\\s\\S]*视频生成|视频生成[\\s\\S]*PPT|帮我写作|录音转写/;
    let prevSeen = "";
    let last = "";
    for (const msg of messages) {{
      const t = (msg.innerText || "").trim().replace(/\\s+/g, " ");
      if (!t || t.length > 600) continue;
      // 父子节点文本重复（容器 vs 内部节点）→ 只算一条
      if (prevSeen && (t === prevSeen || prevSeen.indexOf(t) === 0
                       || t.indexOf(prevSeen) === 0)) continue;
      prevSeen = t;
      // 输入框 / 模式菜单不是对话消息
      if (inInputArea(msg)) continue;
      if (TS_RE.test(t)) continue;
      if (MENU_RE.test(t) && t.length <= 80) continue;
      // 这是我们说的话，不是豆包的判决
      let mineHit = false;
      for (const m of MINE) {{
        if (m && (t.indexOf(m) >= 0 || m.indexOf(t.slice(0, 40)) >= 0)) {{ mineHit = true; break; }}
      }}
      if (mineHit) continue;
      // 正常流程确认消息不算失败
      if (t.includes("视频生成好后") && t.includes("预计等待")) continue;
      if (t.length < MIN_VERDICT) continue;
      last = t;
    }}
    if (!last) return {{ failed: false }};
    for (const rule of RULES) {{
      for (const w of rule.words) {{
        if (last.includes(w)) {{
          return {{ failed: true, kind: rule.kind, word: w, text: last.slice(0, 150) }};
        }}
      }}
    }}
    for (const p of ALL_PATTERNS) {{
      if (p.re.test(last)) {{
        return {{ failed: true, kind: p.kind, word: "re:" + String(p.re).slice(0, 24),
                  text: last.slice(0, 150) }};
      }}
    }}
    return {{ failed: false }};
  }};
  // 豆包「视频生成参数确认」态（2026-09-22 九并发事故里新发现的第二类卡死）。
  // 现在豆包经常不直接开始生成，而是先铺一屏参数＋分镜表，结尾说
  //     "确认后我再开始生成视频。"
  // 然后**等用户在输入框里回复确认**。我们的确认文本发出去之后，若豆包没接茬
  // （既不开始生成、也不报错），页面就永远停在那一屏 —— 实测 4 个任务就这么
  // 一路空转到 1790s 超时才失败。这里把这种状态显式识别出来，交给 Python 侧
  // 提前判死、换账号重试，不再干等半个钟头。
  //
  // myText：我们自己发出的确认文本（Python 侧传入），用来把它从"尾巴正文"里剔掉。
  dbm.awaitingConfirm = () => {{
    // 判据（刻意做得保守，宁可漏判也绝不误杀正在生成的任务）：
    //   ① 会话里最后一条"长消息"（豆包的正式回复通常上百字，而我们的确认文本
    //      只有几十字、UI 文案更短）里含"等你确认"类关键词；
    //   ② 且这条之后没有任何新的长消息 —— 即豆包还没接茬；
    //   ③ 且页面没有 <video>、没有"已开始生成"的确认消息、没有"生成中"字样。
    const KEY = [
      "确认后我再开始生成", "确认后我开始生成", "确认后再开始生成",
      "确认后开始生成", "确认后即可开始生成", "确认之后开始生成",
      "请确认后开始生成", "回复确认后开始", "确认后我将开始生成",
      "确认后才会开始生成", "确认无误后开始生成", "确认后我再生成"
    ];
    const RUNNING = ["正在生成", "生成中", "排队中", "视频生成好后",
                     "正在为你生成", "生成进度"];
    try {{
      if (dbm.checkGenerationConfirmed && dbm.checkGenerationConfirmed().ok) {{
        return {{ waiting: false }};
      }}
    }} catch (e) {{}}
    try {{
      const vs = dbm.pageVideos ? dbm.pageVideos() : [];
      if (vs && vs.length) return {{ waiting: false }};
    }} catch (e) {{}}
    const body = (document.body.innerText || "");
    if (!body) return {{ waiting: false }};
    for (const r of RUNNING) {{
      if (body.indexOf(r) >= 0) return {{ waiting: false }};
    }}
    // 收集所有带文本的消息节点，按 DOM 顺序去重（父子节点文本相同的只算一次）
    const nodes = Array.from(document.querySelectorAll(
      "[class*='message'],[class*='bubble'],[class*='content'],[class*='assistant'],[class*='reply']"
    ));
    const seen = [];
    for (const n of nodes) {{
      const t = (n.innerText || "").trim().replace(/\\s+/g, " ");
      if (!t || t.length < 8) continue;
      const prev = seen.length ? seen[seen.length - 1] : "";
      // 与上一条完全一样、或是上一条的前缀/后缀（典型的父子节点重复）→ 跳过
      if (prev && (t === prev || prev.indexOf(t) === 0 || t.indexOf(prev) === 0)) continue;
      seen.push(t);
    }}
    if (!seen.length) return {{ waiting: false }};
    let lastLong = -1;
    for (let i = seen.length - 1; i >= 0; i--) {{
      if (seen[i].length >= 60) {{ lastLong = i; break; }}
    }}
    if (lastLong < 0) return {{ waiting: false }};
    let hit = false;
    for (const k of KEY) {{
      if (seen[lastLong].indexOf(k) >= 0) {{ hit = true; break; }}
    }}
    if (!hit) return {{ waiting: false }};
    return {{ waiting: true, last: seen[lastLong].slice(-90),
              after: seen.slice(lastLong + 1).map(function(s) {{ return s.slice(0, 40); }}) }};
  }};
  // ===================== 2026-09-29：四类对话场景识别 =====================
  // 区分豆包常见的三种"抱歉"类拒绝 + 正常的"需要确认"态。
  // 注意：我们自己的确认文本里可能含"版权/侵权/违规"等字眼，因此这些检测
  // 也只扫豆包气泡（跳过 dbm.__mine 登记的自发消息），与 generationFailed 一致。
  //
  // 需求2："抱歉，我无法生成你要求的内容。你可以尝试提出其他需求…"
  //   → 需要回"请根据内容进行修改…"让它改提示词重生成。
  // 需求3："抱歉，由于模型可能带来准确性问题，我无法为你生成相应内容…"
  //   → 需要回"确认，使用seedance 2.0 fast 生成视频"，20s 后若还需二次确认，
  //     再回"字字动画提示 + 参考图"。
  // 需求1/需求4：普通的"需要确认"走既有 checkGenerationConfirmed / 版权申诉逻辑。
  dbm.__collectBeanMessages = () => {{
    const MINE = dbm.__mine || [];
    const nodes = Array.from(document.querySelectorAll(
      "[class*='message'],[class*='bubble'],[class*='content'],[class*='assistant'],[class*='reply']"
    )).filter(dbm.vis);
    const out = [];
    for (const n of nodes) {{
      const t = (n.innerText || "").trim().replace(/\\s+/g, " ");
      if (!t || t.length > 600) continue;
      let mineHit = false;
      for (const m of MINE) {{
        if (m && (t.indexOf(m) >= 0 || m.indexOf(t.slice(0, 40)) >= 0)) {{ mineHit = true; break; }}
      }}
      if (mineHit) continue;
      out.push(t);
    }}
    return out;
  }};
  // 需求2：豆包"我无法生成你要求的内容"
  dbm.matchesRejectModify = () => {{
    const msgs = dbm.__collectBeanMessages();
    for (const t of msgs) {{
      if (t.indexOf("抱歉") >= 0 && t.indexOf("我无法生成你要求的内容") >= 0) {{
        return {{ hit: true, text: t.slice(0, 150) }};
      }}
    }}
    const body = (document.body.innerText || "");
    if (body.indexOf("我无法生成你要求的内容") >= 0) {{
      return {{ hit: true, text: "found_in_body" }};
    }}
    return {{ hit: false }};
  }};
  // 需求3：豆包"由于模型可能带来准确性问题…我无法为你生成相应内容"
  dbm.matchesRejectAccuracy = () => {{
    const msgs = dbm.__collectBeanMessages();
    for (const t of msgs) {{
      if (t.indexOf("抱歉") >= 0 && t.indexOf("由于模型可能带来准确性问题") >= 0
          && t.indexOf("我无法为你生成相应内容") >= 0) {{
        return {{ hit: true, text: t.slice(0, 150) }};
      }}
    }}
    const body = (document.body.innerText || "");
    if (body.indexOf("由于模型可能带来准确性问题") >= 0
        && body.indexOf("我无法为你生成相应内容") >= 0) {{
      return {{ hit: true, text: "found_in_body" }};
    }}
    return {{ hit: false }};
  }};
  // ===================== 无水印视频下载 =====================
  // 豆包管理器给"无水印下载"按钮注入了专属 class .dbm-doubao-no-watermark-download，
  // 且按钮非 hover 时就已在 DOM 中且可见（实测 opacity:1, visibility:visible）。
  // 直接 querySelector 定位，返回按钮坐标，由 Python 端用 CDP 真实鼠标点击（比 el.click() 可靠）。

  // 元素上所有可能携带"无水印下载"语义的文本（按钮文案/aria/title/class 拼接）
  dbm._btnText = (el) => {{
    if (!el) return "";
    return ((el.innerText || el.textContent || "") + " "
      + (el.getAttribute("aria-label") || "") + " "
      + (el.getAttribute("title") || "") + " "
      + String(el.className || "")).replace(/\\s+/g, "");
  }};
  // 判断元素是否是"无水印下载"入口（模糊包含即可，不再要求文本全等）
  dbm._isNoWatermarkEl = (el) => {{
    if (!el) return false;
    const hay = dbm._btnText(el);
    const cls = String(el.className || "");
    if (cls.includes("dbm-doubao-no-watermark-download")) return true;
    if (/no[-_]?watermark/i.test(cls)) return true;
    // "无水印/去水印"都算；"加水印/水印设置"等反向语义词不同，不会误中
    if (hay.includes("无水印") || hay.includes("去水印")) return true;
    return false;
  }};
  dbm._clickableSel = () =>
    "button,a,[role='button'],[class*='download'],[class*='Download'],[class*='watermark'],[class*='Watermark']";
  dbm._usableRect = (el) => {{
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return null;
    const st = getComputedStyle(el);
    if (st.display === "none" || st.visibility === "hidden") return null;
    return r;
  }};
  dbm._scoreNoWm = (el) => {{
    const t = dbm._btnText(el);
    const cls = String(el.className || "");
    let s = 0;
    if (cls.includes("dbm-doubao-no-watermark-download")) s += 100;
    if (/no[-_]?watermark/i.test(cls)) s += 40;
    if (t.includes("无水印下载") || t.includes("去水印下载")) s += 20;
    else if (t.includes("无水印") || t.includes("去水印")) s += 10;
    return s;
  }};
  // 最后一个 <video> 的几何信息（供 Python 端 CDP hover 唤出悬浮控制条）
  dbm.lastVideoRect = () => {{
    // 用穿透式查找：成片可能在 shadow DOM / iframe 里，顶层 querySelectorAll 找不到
    const v = dbm._lastVideoEl ? dbm._lastVideoEl() : (dbm.q("video").slice(-1)[0] || null);
    if (!v) return null;
    const r = v.getBoundingClientRect();
    return {{ x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height),
              cx: Math.round(r.x + r.width / 2), cy: Math.round(r.y + r.height / 2),
              // 右下角：豆包/管理器的下载工具条通常出现在视频右下
              rx: Math.round(r.x + r.width * 0.75), by: Math.round(r.y + r.height * 0.82),
              src: (v.currentSrc || v.src || "").slice(0, 80),
              isBlob: /^blob:/.test(v.currentSrc || v.src || "") }};
  }};
  // ★ 2026-10-23：新版成片卡片在"点播放"之前根本不存在 <video>（只有封面
  //   <img> + 播放图标）。lastVideoRect() 返回 null，Python 端连一次悬停都不做，
  //   hover 唤出的「无水印下载」按钮自然永远找不到 —— 线上表现为无限重试
  //   (reason=button_not_found, videoRect=null)。这里给出统一的悬停目标：
  //   优先最后一个 <video>，没有就退回成片卡片矩形（videoCardRect 已能定位）。
  dbm.hoverRect = () => {{
    const v = dbm.lastVideoRect();
    if (v && v.w) return v;
    const c = dbm.videoCardRect ? dbm.videoCardRect() : null;
    if (!c || !c.found) return null;
    return {{ x: c.x, y: c.y, w: c.w, h: c.h,
              cx: c.cx, cy: c.cy, rx: c.rx, by: c.bry,
              src: "", isBlob: false, byCard: c.by }};
  }};
  // 点卡片里的播放图标（inline xgplayer），把 <video> 真正挂载出来。
  // ⚠️ 只点小播放图标，绝不点卡片本体 —— 点卡片会打开「创建画布」预览面板，
  //    把聊天页整个盖住，「无水印下载」按钮随之消失。
  //    管理器/浏览器插件的下载按钮注入逻辑依赖页面里存在 <video>，所以这一步
  //    同时也是"唤出无水印按钮"的前提。
  dbm.clickPlayIcon = () => {{
    // 1. 先定位最后一个成片卡片，合成 hover 事件强制挂载悬浮层
    //    （播放图标/工具条都是 mouseenter 后才渲染的，未 hover 时 DOM 里根本没有）
    let cards = [];
    try {{
      cards = Array.from(document.querySelectorAll(
        '[class*="video-hover-button-group-container"],[class*="block-video"]'))
        .filter(el => dbm._usableRect(el));
    }} catch (e) {{}}
    const card = cards.length ? cards[cards.length - 1] : null;
    if (card) {{
      try {{
        const cr = card.getBoundingClientRect();
        for (const ty of ["mouseover", "mouseenter", "mousemove"]) {{
          card.dispatchEvent(new MouseEvent(ty, {{ bubbles: true,
            clientX: cr.x + cr.width / 2, clientY: cr.y + cr.height / 2 }}));
        }}
      }} catch (e) {{}}
    }}
    // 2. 收集播放图标候选（只查可用矩形，不做 opacity 过滤——hover 渐入期 opacity 可能为 0）
    let cands = [];
    try {{
      document.querySelectorAll('[class*="play-icon"],[class*="playIcon"]')
        .forEach(el => {{ if (dbm._usableRect(el)) cands.push(el); }});
    }} catch (e) {{}}
    if (!cands.length && card) {{
      try {{
        card.querySelectorAll('[class*="play"],[class*="Play"]')
          .forEach(el => {{ if (dbm._usableRect(el)) cands.push(el); }});
      }} catch (e) {{}}
    }}
    // 3. 优先取最后一个卡片内部的图标，避免点到历史消息的播放按钮
    let el = null;
    if (card) {{
      for (let i = cands.length - 1; i >= 0; i--) {{
        if (card.contains(cands[i])) {{ el = cands[i]; break; }}
      }}
    }}
    if (!el && cands.length) el = cands[cands.length - 1];
    if (!el) return {{ ok: false, reason: "no_play_icon",
                       cards: cards.length, cands: cands.length }};
    const r = el.getBoundingClientRect();
    try {{
      el.dispatchEvent(new MouseEvent("mouseover", {{ bubbles: true }}));
      el.dispatchEvent(new MouseEvent("mousedown", {{ bubbles: true }}));
      el.dispatchEvent(new MouseEvent("mouseup", {{ bubbles: true }}));
      el.click();
    }} catch (e) {{
      return {{ ok: false, reason: "click_exc:" + e }};
    }}
    return {{ ok: true, x: Math.round(r.x + r.width / 2),
              y: Math.round(r.y + r.height / 2), candCount: cands.length }};
  }};
  // 内部查找：返回 DOM 元素（供同页面函数取 href），不直接回传 Python（DOM 引用无法序列化）
  dbm._findNoWatermarkRaw = () => {{
    const last = dbm._lastVideoEl ? dbm._lastVideoEl() : (dbm.q("video").slice(-1)[0] || null);
    let best = null;
    const consider = (el, bonus) => {{
      if (!el || !dbm._isNoWatermarkEl(el)) return;
      const s = dbm._scoreNoWm(el) + bonus + (dbm._usableRect(el) ? 2 : 0);
      if (!best || s > best.s) best = {{ el: el, s: s }};
    }};
    // 1) 只在【最后一个视频】容器内向上最多 25 层查找，避免拿到历史视频卡片的旧按钮
    if (last) {{
      let node = last;
      for (let i = 0; i < 25 && node; i++) {{
        node = node.parentElement;
        if (!node) break;
        node.querySelectorAll(dbm._clickableSel()).forEach(el => consider(el, 0));
        if (best && best.s >= 100) break;
      }}
    }}
    // 2) 全局兜底（class 专属按钮 / 文本按钮），取分数最高者
    if (!best) {{
      Array.from(document.querySelectorAll(dbm._clickableSel())).forEach(el => consider(el, -5));
    }}
    // 3) elementFromPoint 在最后一个视频右下区域 11×9 网格采样探测
    //    （按钮是 hover 才渲染的悬浮层、又不在常规 button 标签里时的兜底）
    if (!best && last) {{
      const r = last.getBoundingClientRect();
      outer:
      for (let gy = 2; gy >= 0; gy--) {{
        for (let gx = 10; gx >= 4; gx--) {{
          const px = r.x + r.width * (gx / 10);
          const py = r.y + r.height * (gy / 8);
          let el = document.elementFromPoint(px, py);
          for (let k = 0; k < 5 && el; k++) {{
            if (el.querySelectorAll) {{
              el.querySelectorAll(dbm._clickableSel()).forEach(c => consider(c, -8));
            }}
            if (el.matches && dbm._isNoWatermarkEl(el)) {{ consider(el, -8); }}
            el = el.parentElement;
          }}
          if (best) break outer;
        }}
      }}
    }}
    return best;
  }};
  // 对外（Python）：只回标量坐标与诊断信息
  dbm.findNoWatermarkButton = () => {{
    const found = dbm._findNoWatermarkRaw();
    if (!found || !found.el) return {{ found: false }};
    const el = found.el;
    const r = dbm._usableRect(el) || el.getBoundingClientRect();
    return {{
      found: true,
      x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2),
      w: Math.round(r.width), h: Math.round(r.height),
      score: found.s,
      text: (el.innerText || el.textContent || "").trim().slice(0, 20),
      cls: String(el.className || "").slice(0, 80),
      tag: el.tagName,
      by: found.s >= 100 ? "class" : (found.s >= 20 ? "text" : "fuzzy"),
      dpr: window.devicePixelRatio || 1,
      videoRect: dbm.lastVideoRect()
    }};
  }};
  // DOM 级点击「无水印下载」按钮（2026-11-02）：直接对元素派发事件，
  // 彻底摆脱 Python 侧 CDP 真实鼠标坐标点击对"窗口可见且在屏幕内 + DPI 缩放匹配"的强依赖。
  dbm.clickNoWatermarkButton = () => {{
    const found = dbm._findNoWatermarkRaw();
    if (!found || !found.el) return {{ ok: false, reason: "no_btn" }};
    const el = found.el;
    try {{
      el.dispatchEvent(new MouseEvent("mouseover", {{ bubbles: true }}));
      el.dispatchEvent(new MouseEvent("mousedown", {{ bubbles: true }}));
      el.dispatchEvent(new MouseEvent("mouseup", {{ bubbles: true }}));
      el.click();
      return {{ ok: true, tag: el.tagName,
               text: (el.innerText || el.textContent || "").trim().slice(0, 20) }};
    }} catch (e) {{
      return {{ ok: false, reason: "click_exc:" + e }};
    }}
  }};
  // DOM 级点击豆包原生「重新发送/重试」入口（替代 CDP 坐标点击）
  dbm.clickRetryButton = () => {{
    try {{
      const els = Array.from(
        document.querySelectorAll("button,[role=button],span,div"))
        .filter(e => /^(重新发送|重试)$/.test((e.innerText || '').trim()) && e.offsetParent);
      if (!els.length) return {{ ok: false, reason: "no_retry" }};
      const t = els[els.length - 1];
      t.dispatchEvent(new MouseEvent("mouseover", {{ bubbles: true }}));
      t.dispatchEvent(new MouseEvent("mousedown", {{ bubbles: true }}));
      t.dispatchEvent(new MouseEvent("mouseup", {{ bubbles: true }}));
      t.click();
      return {{ ok: true, text: (t.innerText || "").trim().slice(0, 20) }};
    }} catch (e) {{
      return {{ ok: false, reason: "click_exc:" + e }};
    }}
  }};
  // 坐标命中诊断：给定视口坐标，返回 elementFromPoint 命中的元素及其 8 层父链中
  // 是否有无水印按钮、该按钮当前是否处于 :hover。用于判断 CDP 鼠标事件到底有没有
  // 真正落到按钮上（Electron + 系统显示缩放时 CDP 坐标可能与 CSS 像素错位）。
  dbm.probeAt = (x, y) => {{
    const out = {{ x: Math.round(x), y: Math.round(y), dpr: window.devicePixelRatio || 1,
                   hit: false, hover: false, depth: -1, tag: "", cls: "", text: "",
                   btnRect: null }};
    let el = null;
    try {{ el = document.elementFromPoint(x, y); }} catch (e) {{ el = null; }}
    if (!el) return out;
    out.tag = el.tagName;
    out.cls = String(el.className || "").slice(0, 80);
    out.text = (el.innerText || el.textContent || "").trim().slice(0, 20);
    let node = el;
    for (let i = 0; i < 8 && node; i++) {{
      if (dbm._isNoWatermarkEl && dbm._isNoWatermarkEl(node)) {{
        out.hit = true;
        out.depth = i;
        try {{ out.hover = node.matches(":hover"); }} catch (e) {{}}
        const r = node.getBoundingClientRect();
        out.btnRect = {{ x: Math.round(r.x), y: Math.round(r.y),
                         w: Math.round(r.width), h: Math.round(r.height) }};
        if (!out.text) out.text = (node.innerText || node.textContent || "").trim().slice(0, 20);
        break;
      }}
      node = node.parentElement;
    }}
    return out;
  }};

  dbm.getNoWatermarkUrl = async () => {{
    const videos = dbm.q("video");
    if (!videos.length) return {{ ok: false, reason: "no_video_on_page" }};
    const lastVideo = videos[videos.length - 1];
    const vsrc = lastVideo.currentSrc || lastVideo.src || "";
    const vRect = lastVideo.getBoundingClientRect();
    let debug = {{ videoCount: videos.length,
                  videoSrc: vsrc.slice(0, 80),
                  isBlob: /^blob:/.test(vsrc),
                  vRect: {{ x: Math.round(vRect.x), y: Math.round(vRect.y),
                            w: Math.round(vRect.width), h: Math.round(vRect.height) }} }};

    const raw = dbm._findNoWatermarkRaw();
    if (!raw || !raw.el) {{
      // 诊断：列出页面所有含"水印/下载"的按钮
      let diag = [];
      Array.from(document.querySelectorAll("button,a,[role='button']")).forEach(el => {{
        const t = (el.innerText || el.getAttribute("aria-label") || "").trim();
        if ((t.includes("水印") || t.includes("下载")) && t.length < 30) {{
          diag.push({{ tag: el.tagName, text: t.slice(0, 20),
                       cls: String(el.className || "").slice(0, 50) }});
        }}
      }});
      debug.downloadLikeButtons = diag.slice(0, 15);
      debug.videoRect = dbm.lastVideoRect();
      return {{ ok: false, reason: "no_no_watermark_button", debug: debug }};
    }}

    const btn = raw.el;
    const r = dbm._usableRect(btn) || btn.getBoundingClientRect();
    const x = Math.round(r.x + r.width / 2);
    const y = Math.round(r.y + r.height / 2);
    const btnText = (btn.innerText || btn.textContent || "").trim().slice(0, 20);
    const btnCls = String(btn.className || "").slice(0, 60);
    debug.btn = {{ tag: btn.tagName, text: btnText, cls: btnCls, score: raw.s,
                   rect: {{ x: Math.round(r.x), y: Math.round(r.y),
                            w: Math.round(r.width), h: Math.round(r.height) }} }};

    // 1. 链接形式：直接取 href
    if (btn.tagName === "A" || btn.hasAttribute("href")) {{
      const href = btn.href || btn.getAttribute("href") || "";
      if (href.startsWith("http") && !href.startsWith("javascript:")) {{
        return {{ ok: true, url: href, source: "no_watermark_href", text: btnText, debug: debug }};
      }}
    }}
    // 2. data 属性携带 URL
    const dataUrl = btn.getAttribute("data-url") || btn.getAttribute("data-src")
                    || btn.getAttribute("data-href") || btn.getAttribute("data-video-url") || "";
    if (dataUrl && dataUrl.startsWith("http")) {{
      return {{ ok: true, url: dataUrl, source: "no_watermark_data", text: btnText, debug: debug }};
    }}
    // 3. 返回按钮坐标，由 Python 端先 hover 视频唤出悬浮工具条，再 CDP 真实鼠标点击
    return {{ ok: true, url: "", source: "need_click", text: btnText, x: x, y: y,
              videoRect: dbm.lastVideoRect(), debug: debug }};
  }};
  // 扫描页面中所有可见的按钮文本（用于诊断"无水印下载"按钮是否真的存在）
  dbm.scanAllButtons = () => {{
    const out = [];
    document.querySelectorAll("button,[role='button'],a").forEach(el => {{
      if (!dbm.vis(el)) return;
      const t = (el.innerText || "").trim();
      const label = (el.getAttribute("aria-label") || el.getAttribute("title") || "").trim();
      if (t && t.length < 30) out.push({{ tag: el.tagName, text: t, label: label.slice(0, 20) }});
    }});
    return out.slice(0, 50);
  }};
""" + _EXTRA_DETECT_JS + _NO_WM_RESOLVER_JS + _CANVAS_CLOSE_JS + """
  // ★ 2026-11-02：常驻「创建画布」面板看门狗，弹窗即关（DOM 级兜底）
  try { dbm.__installCanvasGuard(); } catch (e) {}
  window.__dbm = dbm;
  return { ok: true };
})()
"""

    # ★ 2026-11-02：优先使用独立模板 page_inject.template.js（可维护 + node 语法校验），
    #   文件缺失/异常时回退到上方内联 f-string，保证既有行为不变。
    _tpl = _load_page_inject_template()
    if _tpl is not None:
        body = "\n" + _tpl.replace("__DBM_SEL_PLACEHOLDER__", sel_json)

    # ★★★ 2026-09-22：给注入脚本打**版本标记**。
    #   之前 _ensure_injected 只探测"window.__dbm 在不在"，在就直接返回、不再注入。
    #   可浏览器里的 webview 往往跨多次桥接重启一直不刷新，页面上残留的是**上一次**
    #   注入的旧脚本 —— 于是我们改了 generationFailed 词表 / 新增 awaitingConfirm，
    #   线上却一个都没生效，排查时只会看到"新逻辑明明写了却没触发"。
    #   现在把脚本正文的 md5 前 12 位写进 dbm.__ver，探测时比对版本，
    #   版本不符（或压根没有 __ver 的旧脚本）就强制重新注入。
    _MARK = "  window.__dbm = dbm;"
    # ★ 2026-11-14：两条注入路径在这里统一收口，追加同一段防护补丁。
    #   __ver 由补丁后的正文算出，md5 变化会让桥接重启后自动重新注入。
    _i0 = body.rindex(_MARK)
    body = body[:_i0] + _MINUTES_GUARD_JS + body[_i0:]
    ver = hashlib.md5(body.encode("utf-8")).hexdigest()[:12]
    i = body.rindex(_MARK)
    return body[:i] + '  dbm.__ver = "%s";\n' % ver + body[i:]


_VER_RE = re.compile(r'dbm\.__ver = "([0-9a-f]{12})"')
_VER_CACHE = {}


def inject_js_ver(selectors):
    """当前注入脚本的版本号（= 脚本正文 md5 前 12 位），用于判断页面里是否旧脚本。"""
    try:
        key = json.dumps(selectors or {}, sort_keys=True, ensure_ascii=False)
    except Exception:
        key = repr(selectors)
    v = _VER_CACHE.get(key)
    if v is None:
        m = _VER_RE.search(build_inject_js_cached(selectors) or "")
        v = m.group(1) if m else ""
        _VER_CACHE[key] = v
    return v


# ---------------------------------------------------------------------------
# 任务状态机
# ---------------------------------------------------------------------------

class TaskStore:
    def __init__(self):
        self.tasks = load_json(TASKS_PATH, {})
        self._lock = threading.Lock()
        self._recover()

    def _recover(self):
        """服务重启后的任务恢复策略。

        ★ 2026-11-03：宿主（字字动画）已关闭时，残留任务一律**取消**，不再重新排队。
          这些分镜的软件端已经不在了：桥接就算重新派发、重新生成，产出的视频也
          没有人回收；而宿主下次打开又会提交一批新任务，形成「重复派发」。
          旧实现无条件把非终态任务改成 queued，正是重复派发的直接源头。
          只有确认宿主会话仍有效（心跳新鲜 + 进程仍在）时才恢复排队。
        """
        try:
            ended = HOST_GUARD.session_ended()
        except Exception:
            ended = False
        n = 0
        cancelled = 0
        with self._lock:
            for t in self.tasks.values():
                # failed = 一致性校验拒绝回传，是终态；漏掉会在服务重启时
                # 被重新排队、重新提交、再次扣额度并再次被拒。
                if t.get("status") in ("done", "error", "failed"):
                    continue
                if ended:
                    t["status"] = "error"
                    t["percent"] = 0
                    t["error"] = "cancelled"
                    t["message"] = "字字动画已关闭，任务已自动取消"
                    t["assigned_to"] = ""
                    t["updated_at"] = now_str()
                    logs = t.setdefault("logs", [])
                    logs.append("[%s] 字字动画已关闭，任务已自动取消（不重新派发）" % now_str())
                    if len(logs) > 200:
                        t["logs"] = logs[-200:]
                    cancelled += 1
                else:
                    t["status"] = "queued"
                    t["percent"] = 3
                    t["assigned_to"] = ""
                    t["message"] = "服务重启，重新排队"
                    # 重置心跳：否则这些任务是上一轮进程留下的旧时间戳，
                    # 一启动就会被孤儿回收判成"宿主已放弃"而误取消。
                    t["last_poll_ts"] = time.time()
                    n += 1
            if n or cancelled:
                self._persist()
        if cancelled:
            print(f"[doubao-bridge] 宿主会话已结束，服务重启时自动取消 {cancelled} 个残留任务（不重新派发）")
        elif n:
            print(f"[doubao-bridge] 宿主会话有效，服务重启时恢复 {n} 个在途任务重新排队")

    def create(self, payload):
        tid = time.strftime("%Y%m%d%H%M%S") + "_" + uuid.uuid4().hex[:6]
        task = {
            "id": tid,
            "status": "queued",
            "percent": 3,
            "message": "已进入队列，等待空闲账号",
            "prompt": payload.get("prompt", ""),
            "negative_prompt": payload.get("negative_prompt", ""),
            "duration": str(payload.get("duration") or DEFAULT_CONFIG["default_duration"]),
            "aspect": str(payload.get("aspect") or DEFAULT_CONFIG["default_aspect"]),
            "account": payload.get("account", ""),
            "first_frame": payload.get("first_frame", ""),
            "images": list(payload.get("images") or []),  # 参考图本地路径列表（首帧优先）
            "audios": list(payload.get("audios") or []),  # 参考音频本地路径列表（最多 3 个）
            # ★ 2026-11-03：分镜映射。由插件 generate() 提交时携带，含 dest
            #   （字字动画分镜窗口对应的视频绝对路径）。成品落盘后桥接会直接
            #   复制过去。
            "scene": dict(payload.get("scene") or {}),
            "delivered_scene_path": "",   # 已回传的分镜目标路径
            "delivered_scene_at": "",     # 回传时间
            "assigned_to": "",          # 已分配的账号 target id
            "worker_slot": 0,           # 账号槽位号（账号1/账号2…）
            # ★ 2026-11-14：提交协商完成、豆包真正开始生成的时刻（0=未完成）。
            #   回收/回传链路全部以此为闸门：协商（尤其带参考音频的强制二次
            #   确认）没走完之前，绝不允许检测视频、扫盘、下载或置 done。
            "generation_ready_ts": 0,
            "has_reference_audio": False,
            "negotiation_done": False,
            "requeues": 0,              # 改派次数（额度/模型权限原因）
            "video_path": "",
            "video_url": "",
            "error": "",
            "logs": [],
            "created_at": now_str(),
            "updated_at": now_str(),
            # 宿主轮询心跳初值。宿主提交成功后会立刻开始轮询（默认 3 秒一次），
            # 若提交请求超时/宿主当场失败，这个任务就永远没人轮询，也不会有人来
            # 取消它 —— 给初值后，孤儿回收就能把它收掉，不会一直占着队列烧额度。
            "last_poll_ts": time.time(),
        }
        with self._lock:
            self.tasks[tid] = task
            self._persist()
        return task

    def get(self, tid):
        return self.tasks.get(tid)

    def touch_poll(self, tid):
        """记录宿主最后一次轮询该任务的时间（仅内存，不落盘）。

        调用频率是每任务每几秒一次，走 update() 会反复把整个 tasks.json 重写一遍，
        代价太大，所以这里直接改内存字典。用途：宿主一旦判该分镜失败/被中断就
        不再轮询，桥接据此判定"宿主已放弃"并自动取消，避免继续排队重试烧额度。
        """
        with self._lock:
            t = self.tasks.get(tid)
            if t is not None:
                t["last_poll_ts"] = time.time()

    def list(self):
        return sorted(self.tasks.values(), key=lambda t: t["created_at"], reverse=True)

    def update(self, tid, **fields):
        with self._lock:
            t = self.tasks.get(tid)
            if not t:
                return
            t.update(fields)
            t["updated_at"] = now_str()
            self._persist()

    def log(self, tid, message):
        # 同步回显到 stderr：字字动画宿主会把插件 stdout/stderr 收进 generator_log，
        # 之前桥接日志只有 /api/tasks 能看到，宿主日志里一片空白，出问题无法定位。
        try:
            print(f"[doubao-bridge][{tid}] {message}", file=sys.stderr, flush=True)
        except Exception:
            pass
        with self._lock:
            t = self.tasks.get(tid)
            if not t:
                return
            msg = str(message or "")
            logs = t["logs"]
            # ★ 2026-09-24：相邻**完全重复**的日志合并成 "…（×N）"。
            #   事故：轻量检测每轮都命中同一个拒绝并记一句，25 分钟刷了 80 多条
            #   一模一样的行 —— 200 条上限被挤爆，真正有用的上下文（提交时刻、
            #   页面诊断、下载环节）全被顶掉，排查时只剩一片重复。
            #   合并后"发生了 N 次"的信息仍在，位置却只占一行。
            #   stderr 回显不受影响，仍逐条实时输出。
            if logs:
                prev = logs[-1]
                sp = prev.find("] ")
                raw = prev[sp + 2:] if sp >= 0 else prev
                n = 1
                if raw.endswith("）") and "（×" in raw:
                    k = raw.rindex("（×")
                    try:
                        n = int(raw[k + 2:-1])
                        raw = raw[:k]
                    except ValueError:
                        n = 1
                if raw == msg and n < 99999:
                    logs[-1] = "[%s] %s（×%d）" % (now_str(), msg, n + 1)
                    t["updated_at"] = now_str()
                    self._persist()
                    return
            logs.append("[%s] %s" % (now_str(), msg))
            if len(logs) > 200:
                t["logs"] = logs[-200:]
            t["updated_at"] = now_str()
            self._persist()

    def _persist(self):
        try:
            save_json(TASKS_PATH, self.tasks)
        except Exception as e:
            print(f"[bridge] 任务落盘失败: {e}")


# ---------------------------------------------------------------------------
# 任务执行流水线
# ---------------------------------------------------------------------------

class TargetGone(Exception):
    """分配给本 worker 的账号 webview 被关闭。"""


class PageDegraded(Exception):
    """账号页面处于"半加载卡死"状态：侧边栏渲染了，主内容区（composer / "视频生成"
    入口）没渲染出来。实测是页面加载时有 1 个 JS chunk 没拉到（正常 9 个 script 缺 1
    个、textarea 缺失），表现为可见按钮只有 3~4 个（正常 20 个左右）。

    这种状态下 _wait_chat_ready 会误判就绪、ensureVideoMode 会点到一个无关元素，
    于是反复报 video_mode_not_active 空耗几十分钟 —— 多账号并行时看起来就像
    "只有一个账号在走流程"。

    ⚠️ 修复手段只能用 Page.navigate 重新导航：**不能用 Page.reload**，实测 reload
    会把 Electron 的整个 browser-stack 打没（9 个 webview 全部消失）。
    """


class EditorNotVisible(Exception):
    """提示词输入框在 DOM 里但不可见（视频模式下豆包会把 composer 换成一个
    `.pointer-events-none invisible absolute inset-0` 的隐藏副本），此时填词必然失败。

    旧代码会一路走到 needs_calibration（"豆包网页结构需要标定"），其实选择器没坏，
    是页面状态不对。正确做法是唤醒/重置页面后重排任务，而不是报标定。
    """


class QuotaExceeded(Exception):
    """账号额度不足/被限流（页面出现“请求超限”等提示）。"""


class ModelLocked(Exception):
    """所选模型需要更高会员等级（菜单项带“升级”标签）。"""


def _norm_txt(s):
    """归一化用于比对的文本：去掉所有空白（含全角空格）与常见标点。

    豆包的气泡 innerText 会在正文里插换行、在词之间插空格（「侵权 / 违规内容」），
    跟我们 setPrompt 塞进去的原文不是严格子串关系，比对前必须先抹平。
    """
    return re.sub(r"[\s\u3000,，。.、;；:：!！?？\"'“”‘’()（）\[\]【】《》/\\|-]+",
                  "", str(s if s is not None else ""))


class GenerationFailed(Exception):
    """豆包服务端明确回复生成失败（内容审核拒绝 / 生成失败 / 系统繁忙持续）。

    确定没有成品视频产生，可安全地在下一批换账号重新分发（有限次数）。
    kind: moderation(审核拒绝) / failed(生成失败) / busy(系统繁忙)
    """
    def __init__(self, message, kind="failed", page_text=""):
        super().__init__(message)
        self.kind = kind
        self.page_text = page_text


class GenerationTimeout(Exception):
    """等待超时且页面始终没有出现视频（大概率未生成），可换账号有限重试。"""


class DownloadFailed(Exception):
    """视频已在账号页面出现，但无水印下载环节失败（按钮取不到/文件损坏/过小）。

    此时豆包对话里已有成品，绝不能重新生成（浪费额度），标记失败提示手动处理。
    """


class TaskCancelled(Exception):
    """任务被用户主动取消。"""


class AccountWorker:
    """一个账号 webview 对应一个 worker：独立 CDP 会话、独立任务队列，互不干扰，可并发。

    ★ 2026-11-02：不再继承 threading.Thread。
    早期 worker 继承 Thread 但 run() 仅是每秒 sleep 的空转死循环，任务实际由
    Orchestrator 单线程驱动；每上线一个账号就白占一个常驻线程（9 账号 = 9 个空转线程）。
    『句柄 + 状态机』语义不需要线程本体，故移除继承与 w.start()。
    """

    def __init__(self, scheduler, slot, target):
        self.scheduler = scheduler
        self.store = scheduler.store
        self.config = scheduler.config
        self.selectors = load_json(SELECTORS_PATH, {})
        self.slot = slot                       # 账号槽位号（账号1、账号2…）
        self.target_id = target["id"]          # 固定绑定的 CDP target（重启会变）
        # 管理器注入的稳定账号 UUID：跨重启/换顺序/换账号都不变，用于每日额度记账
        self.account_uuid = str(target.get("uuid") or "")
        self.account_name = str(target.get("account_name") or "")
        self.tab_token = "w" + uuid.uuid4().hex[:12]  # 用于在管理器窗口定位/激活本账号 tab
        self.bridge = ManagerBridge(self.config)  # 独立实例：独立 WebSocket 会话
        self.task_q = queue.Queue()
        self.busy = False
        self.current_tid = None
        self._fg_locked = False               # 是否持有前台输入锁
        self.nickname = ""
        self.dead = False
        self.done_count = 0
        self.submitted = False                 # 是否已提交生成（提交后页面丢失不能重排）
        self.model_name = ""                   # 当前页面已选模型
        self.quota_ok = True                   # 额度是否可用
        self.quota_msg = ""                    # 额度不足时的页面提示原文
        self.quota_marked_at = 0.0             # 标记额度不足的时间（用于自动恢复重试）
        self.quota_recover_ts = 0.0            # 固定恢复时间戳（次日0:01），防止每次重算"明天"永不恢复
        # 该账号**缺少哪些模型**（模型名 → 标记时刻）。豆包菜单项带"升级"标签说明此账号
        # 无该模型权限（如需会员的 Seedance 2.5）。以前 ModelLocked 不记标记，调度器会
        # 反复挑中同一个账号重试（实测同一账号空转 16 次、每次还新建对话），既慢又刷屏。
        self.model_locked = {}                 # {模型名: 标记时刻}
        self.page_busy = False                 # 页面是否有生成中的任务
        self._last_activate_reason = ""        # 最近一次激活管理器标签页的失败原因
        self._last_attach_ts = 0.0             # 上次 CDP 重连时刻（强制重连节流用）
        self._fast_detect_hit = False          # 本轮是否已检测到视频（避免日志刷屏）
        self._fast_detect_miss = 0             # 检测到视频但下载未触发的连续次数
        self._submit_video_baseline = set()    # 提交时页面已有的历史视频（回收时排除）
        self._stale_video_warned = False       # 是否已提示过"只有历史视频"
        self.degraded_until = 0.0              # 页面半加载卡死时，本时间戳前不再派单
        self._force_home_reset = False         # 下个任务开始前先把页面重置回豆包首页
        self.epoch = 0                         # 见 retire()：作废"上一代"仍在跑的线程
        self.cooling_until = 0.0               # 刚被作废的账号，这段时间里不再派单
        self._own_texts = []                   # 我们自己往会话里发过的文本（判死时排除，见 _own_text_hit）
        self._appeal_sent = 0                  # 本任务已发出的版权申诉次数（见 _copyright_appeal）
        self._appeal_logged = False
        self._appeal_grace_until = 0.0         # 申诉后的判死宽限期截止时刻
        self._appeal_grace_logged = False

    def retire(self):
        """作废所有仍在本 worker 上运行的旧线程，并让它进入短暂冷却。

        ★ 2026-09-22 九并发事故实测出来的坑：用户点「取消全部任务」后，
        cancel_task 立刻把 worker 标成空闲（busy=False）并 detach 掉 CDP ——
        但旧的 submit 线程可能还**卡在一次长超时的 CDP 调用里**（实测卡了 69 秒
        才抛 "CDP 调用超时: Runtime.evaluate"）。它醒来之后会继续执行收尾代码：
          1) w.busy = False         → 而这个 busy 此刻属于**新**任务，等于把新
             任务的账号又释放给第三个任务；
          2) w.bridge.detach()      → 把**新**任务刚建好的 WebSocket 掐断，
             新任务随即报「CDP 未连接」「CDP 调用超时」。
        结果就是两个任务先后派给同一个账号（本次日志里 #0 和 #1 都是账号9），
        双双失败。

        这里的办法是给 worker 编一个"世代号"：释放账号前先 bump epoch。旧线程
        醒来发现 epoch 变了，就只安静退出，绝不碰 worker 的任何共享状态。
        再加一个短冷却，避免新任务在旧线程还在敲 CDP 的窗口里立刻接手同一个页面。
        """
        self.epoch += 1
        # 旧线程可能仍持有前台输入锁：这里替它归还，新线程才能正常抢锁。
        if self._fg_locked:
            try:
                self.scheduler.input_lock.release()
            except Exception:
                pass
            self._fg_locked = False
        self.cooling_until = time.time() + 20.0
        return self.epoch

    def _dbm_set_prompt(self, text, timeout=30):
        """统一的 setPrompt 出口：顺手在 **Python 侧** 记下"这话是我们说的"。

        页内 `dbm.__mine`（见注入脚本 setPrompt）是主防线，但它活在页面里 ——
        页面刷新 / 脚本重灌 / worker 重建都会清空，而豆包的历史气泡还在，误判
        立刻复活。所以这里再存一份，判死时两边取并集。
        """
        s = str(text if text is not None else "").strip()
        if s:
            try:
                self._own_texts.append(s)
                if len(self._own_texts) > 12:
                    self._own_texts = self._own_texts[-12:]
            except Exception:
                pass
        return self._eval_safe(
            "window.__dbm.setPrompt(%s)" % js_quote(s), timeout=timeout)

    def _own_text_hit(self, text):
        """`generationFailed()` 抓到的这段话，是不是**我们自己发出去的**？

        为什么需要：豆包的用户消息与助手消息 **className 完全一致**（实测两边都
        是 `pl-8 w-full pr-[...]`），从 DOM 结构上分不出谁说的。而宿主的
        `confirm_generation_text` 被写成了「…先将提示词内容修改为不涉及版权、
        不侵权、不违规的提示词…」—— 自带审核关键词，一旦被判死逻辑当成豆包的
        拒绝，秒级判死会把**所有任务在刚提交时全部误杀**。
        """
        t = str(text if text is not None else "").strip()
        if not t:
            return False
        cand = list(getattr(self, "_own_texts", None) or [])
        cf = str(self.config.get("confirm_generation_text", "") or "").strip()
        if cf and cf not in cand:
            cand.append(cf)          # 配置兜底：_own_texts 为空时仍能挡住
        tn = _norm_txt(t)
        for m in cand:
            m = str(m or "").strip()
            if len(m) < 8:
                continue
            # 双向包含：气泡会带时间戳/换行，两边都不是严格的相等关系
            if (m in t or t in m or m[:40] in t or t[:40] in m):
                return True
            # 归一化后再来一遍：豆包会在气泡里插换行/全角空格，直接包含会漏
            mn = _norm_txt(m)
            if len(mn) >= 8 and (mn in tn or tn in mn
                                 or mn[:40] in tn or tn[:40] in mn):
                return True
        return False

    def _gen_failed_effective(self):
        """取一次 generationFailed()，并滤掉"我们自己说的话"这种误报。

        所有判死点都必须走这里，不要直接 eval `generationFailed()`。
        """
        fr = self._eval_safe("window.__dbm.generationFailed()") or {}
        if not isinstance(fr, dict) or not fr.get("failed"):
            return fr
        # 申诉宽限期：刚回过「我已获得授权」，豆包需要时间消化。这段时间内就算
        # 页面上的拒绝文本还在，也不判死 —— 否则下一轮轮询（几秒后）立刻二次
        # 命中判死，这次申诉等于白发。宽限期一过仍拒绝就照常判死。
        if str(fr.get("kind", "") or "") in ("moderation", "failed") \
                and time.time() < float(getattr(self, "_appeal_grace_until", 0.0) or 0):
            if not getattr(self, "_appeal_grace_logged", False):
                self._appeal_grace_logged = True
                try:
                    self.store.log(
                        getattr(self, "current_tid", None) or "",
                        "申诉宽限期内，暂不判死，继续等豆包消化（剩余 %ds）"
                        % int(float(self._appeal_grace_until) - time.time()))
                except Exception:
                    pass
            return {}
        if self._own_text_hit(fr.get("text", "")):
            # 命中自发言：不算豆包拒绝。留痕一次，便于日后确认是不是误杀。
            _tid = getattr(self, "current_tid", None)
            if _tid and not getattr(self, "_own_hit_logged", False):
                self._own_hit_logged = True
                try:
                    self.store.log(
                        _tid,
                        "已忽略一条疑似自发言的拒绝命中（是我们自己发的文本，"
                        "非豆包回复）: %s" % str(fr.get("text", ""))[:120])
                except Exception:
                    pass
            return {}
        return fr

    # 版权/授权类拒绝话术。只对这类话术申诉（"我已获得授权"）——
    # 涉政、违禁、色情那类拒绝回这句没有任何意义，只会把会话刷成垃圾。
    _COPYRIGHT_RE = re.compile(
        r"版权|著作|授权|知识产[权]|侵[权]|版[权]限制|ip\s*(?:侵权|受限)",
        re.IGNORECASE)

    def _is_copyright_refusal(self, text):
        return bool(self._COPYRIGHT_RE.search(str(text or "")))

    def _appeal_reset(self):
        """每个新任务开始时清零申诉状态（否则同一个账号跑过一次后永不申诉）。"""
        self._appeal_sent = 0
        self._appeal_logged = False
        self._appeal_grace_until = 0.0
        self._appeal_grace_logged = False

    def _send_reply_text(self, tid, text, idle_wait=60.0, max_try=3):
        """往会话里再发一句话（申诉/追问通用）。

        与发确认文本同一套姿势（2026-09-22 事故结论）：
        **必须等豆包流式输出结束**再发，否则 `findSendTarget()` 纯几何搜索会点到
        「停止」按钮，点了没反应、`isSent()` 恒假。发之前还要 `revealEditor()`
        —— 视频模式下 composer 是隐藏 ghost，只 focusEditor 唤不醒。
        返回是否发送成功。
        """
        try:
            self._ensure_injected(tid)
        except Exception:
            pass
        deadline = time.time() + max(0.0, idle_wait)
        for _try in range(max(1, int(max_try or 1))):
            try:
                self.check_cancel(tid)
            except Exception:
                return False
            # 1) 等豆包把话说完
            _logged = False
            while time.time() < deadline:
                bsy = self._eval_safe("window.__dbm.isPageBusy()") or {}
                if not bsy.get("busy"):
                    break
                if not _logged:
                    _logged = True
                    self.store.log(
                        tid, f"豆包仍在输出（{str(bsy.get('reason') or '')}），"
                             f"等它说完再发「{text[:20]}」…")
                try:
                    self.sleep_cancel(tid, 3, step=1)
                except Exception:
                    return False
            # 2) 唤醒输入框 → 填 → 发送
            self._eval_safe(
                "window.__dbm.revealEditor ? window.__dbm.revealEditor() : null")
            self._eval_safe("window.__dbm.focusEditor()")
            try:
                self.sleep_cancel(tid, 0.3)
            except Exception:
                return False
            r = self._dbm_set_prompt(text) or {}
            if not r.get("ok"):
                self.store.log(tid, f"第 {_try + 1} 次发送「{text[:20]}」："
                                    f"输入框不可用，5s 后重试")
                try:
                    self.sleep_cancel(tid, 5, step=1)
                except Exception:
                    return False
                continue
            self._eval_safe("window.__dbm.esc()")
            try:
                self.sleep_cancel(tid, 0.3)
            except Exception:
                return False
            for prefer in ("false", "true"):
                r2 = self._eval_safe(f"window.__dbm.clickSend({prefer})") or {}
                if r2.get("ok"):
                    try:
                        self.sleep_cancel(tid, 2.0, step=0.5)
                    except Exception:
                        return False
                    if self._eval_safe("window.__dbm.isSent()"):
                        return True
            self.store.log(tid, f"第 {_try + 1} 次发送「{text[:20]}」未生效，5s 后重试")
            try:
                self.sleep_cancel(tid, 5, step=1)
            except Exception:
                return False
        return False

    def _copyright_appeal(self, tid, fr):
        """命中版权拒绝时的"申诉"：先回一句「修改提示词」（modify_prompt_text），
        再回一句「继续生成」（copyright_appeal_text），给豆包两次机会消化。

        返回 True  = 申诉已发出，**调用方不要判死**，继续等豆包（它有可能接着生成）；
        返回 False = 不可申诉（未开启/已用尽/非版权类/发送失败）→ 调用方照常判死。

        只发 copyright_appeal_max 次（默认 1）：豆包若再次拒绝，再多说几遍也
        不会改判，只会把会话刷成垃圾、白占额度、拖长批次。
        注意：判死点的连续命中计数必须在申诉成功后**清零**，否则下一轮立刻二次
        命中判死，这次申诉等于白发。
        """
        if not bool(self.config.get("copyright_appeal_enabled", True)):
            return False
        if not isinstance(fr, dict) or not fr.get("failed"):
            return False
        if str(fr.get("kind", "") or "") not in ("moderation", "failed"):
            return False
        text = str(fr.get("text", "") or "")
        if not bool(self.config.get("copyright_appeal_all_moderation", False)) \
                and not self._is_copyright_refusal(text):
            return False
        try:
            mx = int(self.config.get("copyright_appeal_max", 1) or 0)
        except (TypeError, ValueError):
            mx = 1
        if mx <= 0 or getattr(self, "_appeal_sent", 0) >= mx:
            return False
        # 第一步：要求豆包"修改提示词"（保持原文与核心不变）
        modify = str(self.config.get("modify_prompt_text", "改写提示词，保持原文和核心不变") or "").strip()
        # 第二步：根据参考图要求其继续使用 Seedance 2.0 Fast 生成 15 秒视频
        appeal = str(self.config.get("copyright_appeal_text", "根据参考图，继续使用Seedance 2.0 Fast来生成15秒视频") or "").strip()
        if not modify and not appeal:
            return False
        self._appeal_sent = getattr(self, "_appeal_sent", 0) + 1
        self.store.log(tid, f"豆包回复版权相关拒绝（{text[:80]}），"
                            f"自动申诉第 {self._appeal_sent}/{mx} 次（修改提示词 → 继续生成）")
        try:
            idle = float(self.config.get("copyright_appeal_idle_wait_sec", 60) or 0)
        except (TypeError, ValueError):
            idle = 60.0
        try:
            tries = int(self.config.get("copyright_appeal_retries", 3) or 1)
        except (TypeError, ValueError):
            tries = 3
        # 先发「修改提示词」
        ok = True
        if modify:
            self.store.log(tid, f"申诉第 {self._appeal_sent} 次·先发「修改提示词」：「{modify}」")
            ok = self._send_reply_text(tid, modify, idle_wait=idle, max_try=tries)
        # 再发「继续生成文本」（上一步成功才发，避免豆包还没收到修改提示词就又来一句）
        if ok and appeal:
            self.store.log(tid, f"申诉第 {self._appeal_sent} 次·再发「继续生成文本」：「{appeal}」")
            ok = self._send_reply_text(tid, appeal, idle_wait=idle, max_try=tries)
        if ok:
            try:
                # ★ 2026-10-13：120s → 180s。实测豆包收到申诉后到 visibly 开始
                # 重新生成可能要 2 分钟以上（18:34:12 申诉 → 18:36:16 宽限刚过
                # 4 秒就被旧拒绝文案判死），120s 覆盖不住"豆包还没接茬"的窗口。
                grace = float(self.config.get("copyright_appeal_grace_sec", 180) or 0)
            except (TypeError, ValueError):
                grace = 180.0
            self._appeal_grace_until = time.time() + max(0.0, grace)
            self.store.update(
                tid, message=f"已回复「{modify or appeal}」，等待豆包继续生成…")
            self.store.log(tid, f"申诉（修改提示词 + 继续生成文本）已发送，{int(grace)}s 宽限期内"
                                f"不再判死，继续等待豆包出片")
        else:
            self.store.log(tid, f"申诉发送失败，照常判死")
        return ok

    def _apply_quota_mark(self, mark):
        """把持久化额度标记应用到本 worker（worker 重建/昵称补查时用）。"""
        self.quota_ok = False
        self.quota_msg = mark.get("msg", "") or self.quota_msg
        self.quota_marked_at = mark.get("marked_at", time.time())
        self.quota_recover_ts = mark.get("recover_at_ts", 0.0)

    def quota_available(self):
        """额度是否可派任务：被标记不足后，到固定恢复时间（次日0:01）自动恢复。

        注意：恢复时只更新内存状态，不清除持久化标记。
        标记由 find_quota_mark() 在到期清理时自动移除，或由 /api/accounts/reset 手动清除。
        这样即使服务重启，expired 标记也会被清除，未 expired 标记仍可被恢复。
        """
        if self.quota_ok:
            return True
        if self.quota_recover_ts and time.time() >= self.quota_recover_ts:
            # 到点自动恢复（恢复时间在标记时固定，不随调用时刻滚动）
            self.quota_ok = True
            self.quota_msg = ""
            self.quota_marked_at = 0.0
            self.quota_recover_ts = 0.0
            # 不清除持久化标记：标记由 find_quota_mark() 到期清理或手动重置处理
            return True
        return False

    # 缺模型标记的冷却时长（秒）：期间不再把需要该模型的任务派给本账号。
    # 会员权限短时间内不会变，但也不永久拉黑（换号/开通后能自动恢复）。
    MODEL_LOCK_TTL_SEC = 1800

    def model_available(self, model):
        """本账号是否具备指定模型（缺模型的账号在冷却期内跳过）。"""
        m = (model or "").strip()
        if not m:
            return True
        ts = self.model_locked.get(m)
        if not ts:
            return True
        if time.time() - ts >= self.MODEL_LOCK_TTL_SEC:
            self.model_locked.pop(m, None)   # 冷却结束，允许再试一次
            return True
        return False

    def locked_models(self):
        return [m for m, ts in self.model_locked.items()
                if time.time() - ts < self.MODEL_LOCK_TTL_SEC]

    def display_name(self):
        return f"账号{self.slot}" + (f"（{self.nickname}）" if self.nickname else "")

    def account_label(self):
        """给人看的账号名：优先管理器里的手机号/备注，其次稳定 UUID 短码。

        只用于控制台与接口展示；下载目录、成品归属校验仍用 display_name()，
        避免改动已有的目录名与文件匹配规则。
        """
        name = str(getattr(self, "account_name", "") or "").strip()
        if name:
            return name
        uid = str(getattr(self, "account_uuid", "") or "")
        if uid:
            return "账号" + uid[:8]
        return f"账号{self.slot}"

    def _account_dl_dir(self):
        """本账号专属下载目录：<base>/<日期>_<账号名>/，多账号各自隔离。

        下载路径与回收扫描统一走这里，保证"豆包落盘到哪"和"桥接从哪认领"是
        同一个目录。日期按本 worker 首次调用时锁定（self._dl_date），整轮任务
        内一致，避免跨午夜时 attach 与 collect 扫到不同文件夹。
        """
        base = self.config.get("download_dir") or detect_download_dir()
        if not base:
            return ""
        if getattr(self, "_dl_date", "") == "":
            self._dl_date = time.strftime("%Y-%m-%d")
        d = account_download_dir(base, self.display_name(), self._dl_date)
        try:
            Path(d).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return d

    def matches(self, keyword):
        kw = (keyword or "").strip()
        if not kw:
            return False
        return kw in self.nickname or kw == f"账号{self.slot}" or kw == str(self.slot)

    def stop(self):
        self.dead = True
        try:
            self.task_q.put_nowait(None)
        except Exception:
            pass

    def _refresh_target(self):
        for a in self.bridge.list_accounts():
            if a["id"] == self.target_id:
                return a
        return None

    def handle_stage_error(self, tid, exc):
        """submit_stage/collect_stage 抛异常时的统一处理（由编排器在单线程内调用）。

        负责：按异常类型更新任务状态/额度标记，并兜底释放前台锁与 CDP 会话。
        返回 None。busy/current_tid 由编排器在外层清理。
        """
        try:
            if isinstance(exc, TargetGone):
                self.dead = True
                if not self.submitted:
                    # 还没提交：任务放回队列，等其他在线账号接手
                    self.store.update(tid, status="queued", percent=3, assigned_to="",
                                      message=f"{self.display_name()}页面关闭，任务已重新排队")
                    self.store.log(tid, f"账号页面关闭，任务重新入队: {exc}")
                else:
                    self.store.update(tid, status="error", percent=0,
                                      message="生成过程中账号页面被关闭", error=str(exc))
                return
            if isinstance(exc, EditorNotVisible):
                # 还没提交：任务放回队列，本账号下轮会先重置首页再重试
                self.store.update(tid, status="queued", percent=3, assigned_to="",
                                  message=f"{self.display_name()}输入框未渲染，任务已重新排队")
                self.store.log(tid, f"提示词输入框不可见，任务重新入队: {exc}")
                return
            if isinstance(exc, PageDegraded):
                # 页面半加载卡死且重新导航也没修好：任务放回队列换账号，
                # 本账号已在 _ensure_page_healthy 里标记 degraded_until，30 分钟内不派单。
                self.store.update(tid, status="queued", percent=3, assigned_to="",
                                  message=f"{self.display_name()}页面异常，任务已重新排队")
                self.store.log(tid, f"账号页面半加载卡死，任务重新入队: {exc}")
                return
            if isinstance(exc, (QuotaExceeded, ModelLocked)):
                kind = "额度不足" if isinstance(exc, QuotaExceeded) else "无模型权限"
                if isinstance(exc, QuotaExceeded):
                    self.quota_ok = False
                    self.quota_msg = str(exc)
                    self.quota_marked_at = time.time()
                    # 2026-11-03 v3：额度耗尽一次性落「3/3 满额 + 不可派发 + 已封禁 + 次日 00:01」
                    mark = self.scheduler.mark_quota_exhausted_full(self, str(exc))
                    self.quota_recover_ts = mark.get("recover_at_ts", 0.0)
                if self.submitted:
                    # 防重复：提示词已发送（不可逆），提交后额度尽/无权限不再改派，
                    # 否则同一分镜会被重复发到其他账号 tab
                    self.store.log(tid,
                        f"提示词已发送到{self.display_name()}，但该账号{kind}（{str(exc)[:80]}）。"
                        f"为避免同一分镜被重复发送到其他账号 tab，任务不再自动改派。"
                        f"请重新生成分镜——{kind}账号已被标记，新任务将自动路由到其他可用账号。")
                    self.store.update(tid, status="error", percent=0,
                                      message=f"{self.display_name()}提交后{kind}，未自动改派以防重复发送",
                                      error=f"submitted_then_{kind}：{exc}")
                else:
                    # 提交前失败：无副作用，安全改派给其他账号
                    t2 = self.store.get(tid)
                    n = int((t2 or {}).get("requeues", 0)) + 1
                    online = len(self.scheduler.workers)
                    if n > max(online, 1) * 2:
                        self.store.update(tid, status="error", percent=0, requeues=n,
                                          message=f"所有在线账号均{kind}",
                                          error=f"all_accounts_{kind}：{exc}")
                    else:
                        self.store.update(tid, status="queued", percent=3, assigned_to="",
                                          requeues=n,
                                          message=f"{self.display_name()}{kind}，任务改派其他账号（{n}）")
                        self.store.log(tid, f"{self.display_name()}{kind}：{exc}，"
                                            f"任务已重新排队（{n}，未提交无副作用）")
                return
            if isinstance(exc, TaskCancelled):
                self.store.log(tid, f"任务已取消: {exc}")
                self.store.update(tid, status="error", percent=0,
                                  message="已取消", error="cancelled")
                return
            if isinstance(exc, (GenerationFailed, GenerationTimeout)):
                # 豆包确定没产出视频（明确失败消息 / 全程无视频超时）：
                # 安全地重新排队，由批次屏障保证【下一批】才重新分发，且任务不绑账号，
                # 编排器会自动选其他可用账号。超过最大重试次数才最终判 error。
                t = self.store.get(tid) or {}
                n = int(t.get("gen_retries", 0) or 0) + 1
                max_n = int(self.config.get("max_gen_retries", 2))
                kind = getattr(exc, "kind", "") if isinstance(exc, GenerationFailed) else ""
                moderation = kind == "moderation"
                accuracy_reject = kind == "accuracy_reject"
                # 内容/准确性判定类失败：与账号无关，换账号重试必然同样失败，直接失败不再重排队。
                no_requeue = (moderation and bool(self.config.get("moderation_no_requeue", True))) \
                    or (accuracy_reject and bool(self.config.get("accuracy_no_requeue", True)))
                reason = ("内容审核拒绝" if moderation
                          else "模型准确性问题，无法生成" if accuracy_reject
                          else "豆包生成失败" if isinstance(exc, GenerationFailed)
                          else "生成超时无视频")
                # ★ 2026-09-24 用户要求：审核拒绝**不再重排队**，直接返回失败和原因。
                #   ★ 2026-10-01 起，模型"准确性问题"拒绝（accuracy_reject，即需求3）同样直接失败，
                #   不再尝试二次确认/换账号重试。两类拒绝都决定于提示词/参考图本身，换账号必得同句拒绝。
                if no_requeue:
                    raw = str(getattr(exc, "page_text", "") or "").strip() or str(exc)
                    raw = raw[:200]
                    if moderation:
                        label, hint = "内容审核拒绝", "请修改提示词或参考图后手动重新生成"
                    else:  # accuracy_reject
                        label, hint = "模型准确性问题", "请调整提示词或更换参考图后手动重新生成"
                    self.store.log(
                        tid, f"{label}，按配置不再重排队、直接返回失败（{hint}）: {raw}")
                    self.store.update(
                        tid, status="error", percent=0,
                        message=f"{label}：{raw[:160]}。{hint}",
                        error=(f"accuracy_rejected：{raw}" if accuracy_reject
                               else f"moderation_rejected：{raw}"))
                    return
                if n > max_n:
                    hint = ("；多次均为内容审核拒绝，多半是提示词/参考图触发审核，"
                            "请修改文案或更换参考图后手动重新生成" if moderation else "")
                    self.store.log(tid,
                        f"{reason}，已自动换账号重试 {max_n} 次仍失败，任务终止{hint}：{exc}")
                    self.store.update(tid, status="error", percent=0,
                                      message=f"{reason}（已重试{max_n}次）{hint}",
                                      error=f"generation_failed_after_retries：{exc}")
                else:
                    self.store.log(tid,
                        f"{reason}，分镜重新排队，将在本批全部回传后的下一批换账号重试"
                        f"（第 {n}/{max_n} 次）：{str(exc)[:100]}")
                    self.store.update(tid, status="queued", percent=3,
                                      assigned_to="", worker_slot=None,
                                      gen_retries=n, submitted=False, submit_ts=0,
                                      last_failed_target=self.target_id,
                                      message=f"{reason}，等待下一批换账号重试（{n}/{max_n}）")
                    # 失败账号不标记额度（生成失败通常不扣免费次数），但本 worker 的句柄
                    # 状态复位；它仍可在下一批被其他/同一任务选用
                    self.submitted = False
                return
            if isinstance(exc, DownloadFailed):
                # 视频已生成、卡在下载环节：成品在账号对话里，绝不自动重新生成。
                self.store.log(tid, f"下载环节失败（不自动重发生成）：{exc}")
                _extra = ""
                _lce = getattr(self, "_last_claim_error", "")
                if _lce:
                    _extra = f"（认领主循环末次异常：{_lce[:160]}）"
                self.store.update(tid, status="error", percent=0,
                                  message=f"视频已生成但下载失败：{str(exc)[:120]}{_extra}",
                                  error=f"download_failed：{exc}")
                return
            tb = traceback.format_exc()[-800:]
            self.store.log(tid, f"任务异常: {exc}\n{tb}")
            self.store.update(tid, status="error", percent=0,
                              message=f"失败：{exc}", error=str(exc))
        finally:
            # 兜底释放前台输入锁 + CDP 会话（幂等，collect_stage 已释放也无妨）
            self._fg_release()
            try:
                self.bridge.detach()
            except Exception:
                pass

    def check_cancel(self, tid):
        t = self.store.get(tid)
        if t and t.get("error") == "cancelled":
            raise TaskCancelled("任务已取消")

    def set_status(self, tid, status, percent, message):
        self.check_cancel(tid)
        self.store.update(tid, status=status, percent=percent, message=message)
        self.store.log(tid, f"[{status}] {message}")

    def sleep_cancel(self, tid, seconds, step=0.5):
        """分片休眠，每 step 秒检查一次取消标记。"""
        end = time.time() + seconds
        while time.time() < end:
            remaining = end - time.time()
            wait = min(step, remaining)
            if wait > 0:
                time.sleep(wait)
            self.check_cancel(tid)

    def _eval_safe(self, expression, timeout=30):
        """执行 JS，页面重载/上下文销毁时返回 None 而不抛异常。"""
        try:
            return self.bridge.evaluate(expression, timeout=timeout)
        except Exception:
            return None

    def _close_minutes_panel(self, tid=None):
        """主动关掉豆包右侧「智能纪要 / 画布」docked 面板。

        前端看门狗在后台标签页会被 Chromium 节流（setInterval 降到分钟级，
        日志里多次出现「非活动 webview 的 rAF 为 0fps」），单靠页面定时器
        关不住。提交、协商、轻量检测、回收这些关键节点必须由 Python 侧经
        CDP 主动触发。2 秒节流，避免高频 evaluate 拖慢轮询。
        """
        now = time.time()
        if now - getattr(self, "_minutes_close_ts", 0.0) < 2.0:
            return None
        self._minutes_close_ts = now
        return self._eval_safe(
            "(function(){try{return (window.__dbm && window.__dbm.closeMinutesPanel)"
            " ? window.__dbm.closeMinutesPanel() : null;}catch(e){return null;}})()",
            timeout=8)

    def _keep_active(self):
        """重新施加生命周期/焦点模拟（页面导航后这些状态可能丢失）。"""
        try:
            self.bridge._ws.send("Emulation.setFocusEmulationEnabled", {"enabled": True})
        except Exception:
            pass
        try:
            self.bridge._ws.send("Page.setWebLifecycleState", {"state": "active"})
        except Exception:
            pass

    def _set_tab_token(self):
        """在自己的豆包页面写 sessionStorage token（跨同 tab 导航保留），供管理器定位本 tab。"""
        try:
            self.bridge.evaluate(
                f"sessionStorage.setItem('__dbm_token', {json.dumps(self.tab_token)}); true")
        except Exception:
            pass

    def _is_page_hidden(self):
        """读**真实**可见性（不是被 force_page_visible 覆盖后的值）。

        覆盖只是骗豆包前端让它正常渲染；自动化这边判断"要不要还原窗口"必须看
        真实状态，否则窗口一直最小化却永远检测不到，豆包即使渲染了也拿不到轮询。
        """
        try:
            v = self._eval_safe(
                "(typeof document.__dbmRealHidden === 'function')"
                " ? !!document.__dbmRealHidden() : !!document.hidden", timeout=6)
            return bool(v)
        except Exception:
            return True        # 读不到时保守处理，走一次救窗口流程

    def _ensure_all_webviews_render(self, tid=None, min_interval=90):
        """确保管理器里**所有** webview 都在渲染（rAF 正常）。

        详见 ManagerBridge.force_render_all_webviews 的注释：非 active 的 webview
        被宿主设为 visibility:hidden → Chromium 不合成 → rAF 恒为 0fps → 豆包的
        「视频模式」UI 挂载不上来 → no_video_entry。这是并发时"只有 1~2 个账号能跑"
        的真正根因，必须在这里兜底。

        失败不致命（返回 False），调用方继续按原流程走。
        """
        if not self.config.get("force_render_all_webviews", True):
            return False
        global _RENDERALL_TS
        now = time.time()
        do = False
        with _RENDERALL_LOCK:
            if now - _RENDERALL_TS >= min_interval:
                _RENDERALL_TS = now
                do = True
        if not do:
            return False
        try:
            res = self.bridge.force_render_all_webviews(timeout=20) or {}
        except Exception as e:
            res = {"ok": False, "reason": f"exc:{e}"}
        if res.get("ok"):
            n = res.get("n")
            vis = res.get("visibility") or []
            hidden = sum(1 for v in vis if v != "visible")
            if tid:
                self.store.log(
                    tid, f"已强制 {n} 个 webview 参与渲染"
                         f"（仍被判 hidden 的 {hidden} 个）——"
                         f"非活动 webview 的 rAF 为 0fps 会导致「视频生成」UI 挂不上来")
            return True
        if tid:
            self.store.log(tid, f"强制 webview 渲染未成功（{res.get('reason')}），"
                                f"继续按原流程尝试")
        return False

    def _ensure_window_visible(self, tid=None, min_interval=60, wait_sec=30):
        """页面被判 hidden（管理器窗口最小化/被完全遮挡）时把窗口还原并置前，
        并且**阻塞等到页面真的变 visible 才返回**。

        这是 2026-09-19 定位到的卡死根因：窗口最小化 → 所有 webview 的
        document.visibilityState 变 hidden → 豆包前端不渲染"视频生成"入口、
        不推进生成轮询 → 填表卡住、等不到成片（表现为"必须手动点一下账号"）。

        ⚠️ 并发关键：「还原窗口」这个动作可以节流（避免 N 个线程反复抢焦点），
        但**等待页面变 visible 绝不能跳过**。早期版本节流命中就直接 return，
        结果并发时只有第一个线程去拉窗口、其余线程撞在还没恢复的 hidden 页面上
        全部失败（实测 3 并发只有 1 个成功，就是那个错峰 2 秒才开始的）。
        """
        # ★ 先让所有 webview 参与渲染。这一条与"窗口是否被最小化"无关：
        #   非 active 的 webview 即便 visibilityState 是 visible，rAF 也是 0fps，
        #   「视频生成」UI 挂不上来。必须无条件在每次救窗口时都兜一次。
        self._ensure_all_webviews_render(tid)
        if not self.config.get("auto_raise_manager_window", True):
            return False
        if not self._is_page_hidden():
            return False
        # 1) 温和手段：CDP bringToFront（每个线程都做，只激活窗口，无副作用）
        try:
            self.bridge._ws.send("Page.bringToFront")
        except Exception:
            pass
        # 2) 全局节流：同一时刻只允许一个线程真正去还原窗口
        global _RAISE_TS
        now = time.time()
        do_raise = False
        with _RAISE_LOCK:
            if now - _RAISE_TS >= min_interval:
                _RAISE_TS = now
                do_raise = True
        if do_raise:
            ok, detail = raise_manager_window()
            if tid:
                self.store.log(
                    tid, f"检测到{self.display_name()}页面不可见（管理器窗口被最小化/遮挡），"
                         f"已尝试还原窗口（{detail}）")
        # 3) 关键：无论是不是自己拉的，都必须等到页面真的可见再继续
        deadline = time.time() + wait_sec
        while time.time() < deadline:
            if not self._is_page_hidden():
                self._keep_active()
                return True
            if tid:
                self.sleep_cancel(tid, 1.0, step=0.5)
            else:
                time.sleep(1.0)
        if tid:
            self.store.log(
                tid, f"{self.display_name()}页面在 {wait_sec}s 内仍未变为可见"
                     f"（管理器窗口可能被最小化且无法还原），继续尝试")
        return False

    def _activate_foreground(self, tid, reason="填写提示词"):
        """把本账号在豆包管理器中的 tab 激活为活动标签（前台），否则隐藏 webview 无法输入。

        调用方必须已持有 scheduler.input_lock（保证多账号不会互相抢前台 tab）。

        L2 并行提交（parallel_submit=True）时【不切 tab】：
        实测管理器的非活动 webview 与活动 webview 能力完全一致（详见 DEFAULT_CONFIG
        中 parallel_submit 的注释），而 activate_manager_tab 是全局互斥操作
        （新建 WS 连管理器主窗口点 button.browser-tab），多账号同时调用会互相把对方切走。
        这里只重新施加焦点/生命周期模拟后直接返回。
        """
        if self.config.get("parallel_submit", True):
            self._last_activate_reason = ""
            try:
                self._set_tab_token()
            except Exception:
                pass
            self._keep_active()
            # 不切 tab，但窗口若被最小化/遮挡仍要把页面救回 visible
            self._ensure_window_visible(tid)
            return True
        self._last_activate_reason = ""
        for attempt in range(3):
            self.check_cancel(tid)
            self._set_tab_token()
            res = self.bridge.activate_manager_tab(self.tab_token) or {}
            if res.get("ok"):
                self._last_activate_reason = ""
                if not res.get("wasAlreadyActive"):
                    self.store.log(tid, f"已在管理器激活{self.display_name()}标签页"
                                        f"（{reason}，方式={res.get('method')}）")
                # 激活后让 webview 获得焦点/保持 active
                try:
                    self.bridge._ws.send("Page.bringToFront")
                except Exception:
                    pass
                self._keep_active()
                self.sleep_cancel(tid, 1.2, step=0.6)
                return True
            self._last_activate_reason = str(res.get("reason") or "")
            self.store.log(tid, f"激活管理器标签页未成功（第{attempt+1}次）: {res.get('reason')}")
            if self._last_activate_reason == "manager_page_not_found":
                break   # 找不到管理器主窗口，重试无意义
            self.sleep_cancel(tid, 1.5, step=0.7)
        # 激活失败不致命：CDP 仍可操作，部分点击/上传可能仍生效
        self.store.log(tid, "管理器标签页激活失败，继续尝试（若不输入提示词请检查管理器窗口）")
        self._keep_active()
        return False

    def _ensure_foreground(self, tid, reason=""):
        """确认本账号 tab 仍在管理器前台；被手动切走就重新拉回来。

        豆包管理器的 webview 只有带 .active 的那个是 visibility:visible，切走后
        Chromium 会把它判为隐藏页面（不绘制、不跑 rAF、定时器降频），后续填表、
        上传图片、点击发送都会静默失效。任务开始时虽然激活过一次，但用户中途点了
        别的账号标签页就会失效——所以每次关键交互前都要兜底检查一次。

        ⚠️ 上面这段是历史假设，2026-09-18 真机实测已证伪：见 DEFAULT_CONFIG 中
        parallel_submit 的说明。L2 并行模式下本函数直接返回，不再切 tab
        （切 tab 会把其他正在并发提交的账号切走）。
        """
        if self.config.get("parallel_submit", True):
            self._keep_active()
            return True
        try:
            st = self._eval_safe("document.visibilityState", timeout=8) or ""
        except Exception:
            st = ""
        if st == "visible":
            return True
        self.store.log(tid, f"检测到{self.display_name()}标签页被切走"
                            f"（{reason}），正在重新激活…")
        self._set_tab_token()
        res = self.bridge.activate_manager_tab(self.tab_token) or {}
        if res.get("ok"):
            try:
                self.bridge._ws.send("Page.bringToFront")
            except Exception:
                pass
            self._keep_active()
            self.sleep_cancel(tid, 1.0, step=0.5)
            return True
        self.store.log(tid, f"重新激活标签页失败（{res.get('reason')}），继续尝试")
        return False

    def _apply_force_visible(self):
        """把 document.visibilityState / hidden 固定为 visible / false。

        管理器窗口最小化时 Chromium 会把所有 webview 判为 hidden，豆包前端随即
        不渲染"视频生成"入口、不推进生成状态 → 填表卡死、等不到成片。
        还原窗口是根本解法，但从发起还原到真正生效有 1~3 秒延迟，这段过渡期
        足以让并发的多个账号一起失败。这里直接把可见性 API 覆盖掉，前端就会
        按"页面可见"正常渲染与轮询。

        只覆盖只读属性，不改真实窗口状态，也不拦截事件（事件里再读 document.hidden
        拿到的同样是 false），对自动化来说是纯收益。失败不影响主流程。
        """
        if not self.config.get("force_page_visible", True):
            return False
        if getattr(self, "_force_visible_unsupported", False):
            return False     # 已确认本环境做不到，别再一遍遍试
        try:
            r = self._eval_safe(
                "(function(){\n"
                "  if (document.__dbmForceVisible) return true;\n"
                "  try {\n"
                "    var P = Object.getPrototypeOf(document);\n"
                "    var gv = Object.getOwnPropertyDescriptor(P, 'visibilityState');\n"
                "    var gh = Object.getOwnPropertyDescriptor(P, 'hidden');\n"
                "    var mk = function(v){ return { get: function(){ return v; },"
                " configurable: true }; };\n"
                "    var def = function(n, fn){ Object.defineProperty(document, n,"
                " { value: fn, configurable: true }); };\n"
                "    def('__dbmRealVis', function(){\n"
                "      try { return gv && gv.get ? gv.get.call(document)"
                " : document.visibilityState; }\n"
                "      catch(e) { return document.visibilityState; }\n"
                "    });\n"
                "    def('__dbmRealHidden', function(){\n"
                "      try { return gh && gh.get ? !!gh.get.call(document)"
                " : !!document.hidden; }\n"
                "      catch(e) { return !!document.hidden; }\n"
                "    });\n"
                "    Object.defineProperty(document, 'visibilityState', mk('visible'));\n"
                "    Object.defineProperty(document, 'hidden', mk(false));\n"
                "    Object.defineProperty(document, 'webkitHidden', mk(false));\n"
                "    Object.defineProperty(document, '__dbmForceVisible', mk(true));\n"
                "    return true;\n"
                "  } catch(e) { return 'exc:' + e; }\n"
                "})()", timeout=8)
            if r is True:
                return True
            # 不静默失败：实测 Electron 的 webview guest 里 document 自带一个
            # **不可重定义**的 visibilityState / hidden 访问器（configurable:false），
            # defineProperty 必然抛 "Cannot redefine property"，此时本开关无法生效。
            # 只提示一次（页面探针本来就是 visible，不是当前主要矛盾），不再刷屏。
            if isinstance(r, str) and r.startswith("exc:"):
                self._force_visible_unsupported = True
                self.store.log(
                    "", f"{self.display_name()}：本环境无法覆盖页面可见性"
                        f"（{r[:80]}），force_page_visible 不生效；"
                        f"页面本身 reported visible 时不影响流程")
            return False
        except Exception:
            return False

    def _page_health(self):
        """读取页面健康度（window.__dbm.pageHealth），失败返回 None。"""
        self._ensure_injected()
        h = self._eval_safe("window.__dbm ? window.__dbm.pageHealth() : null", timeout=15)
        return h if isinstance(h, dict) else None

    def _health_usable(self, h):
        """页面是否真正可用（能填词 / 能点视频入口）。

        统一走这里，避免各处判据不一致。
        ⚠️ 兼容旧版注入脚本：页面里跑的 __dbm 可能是本次更新前注入的，返回体里
        没有 usable 字段。这时若直接读 h.get("usable") 会得到 None → 被当成
        "永远不可用" → 每个页面都被反复重新导航，反而制造更多坏页面。
        所以缺字段时退回旧判据 not degraded（宁可放宽，也不能疯狂刷页面）。
        """
        if not isinstance(h, dict):
            return False
        if "usable" not in h:
            return not h.get("degraded")
        return bool(h.get("usable"))

    def _repair_degraded_page(self, tid=None, timeout=45):
        """对"半加载卡死"的页面做一次重新导航，等到页面真正可用为止。

        ⚠️ 只能用 Page.navigate：实测 Page.reload 会把 Electron 的 browser-stack
        整个打没（一次误操作让 9 个账号 webview 全部消失），绝对不能用。

        成功判据必须是 pageHealth().usable（加载完成 且 有视频入口或有输入框），
        **不能是 not degraded**：导航途中 readyState 为 'interactive' 时 degraded
        恒为 false，会造成"假修复"。2026-09-19 的日志里那句
        「页面已修复（按钮 11 个，入口=False）」就是这么来的 —— 判据放水导致修复
        假成功，紧接着 ensureVideoMode 又报 no_video_entry，白耗一整轮。

        另外要求**连续 2 次采样**都可用才算成功，避免加载到一半的瞬时假象。

        多个账号同时导航会互相抢带宽/渲染资源（6 并发时大量失败），所以整个
        导航+等待过程放在 _NAV_LOCK 里串行执行。
        """
        if not _nav_lock():
            # 别的账号正在导航且迟迟不释放：放弃这次修复，不要整批任务陪着排队
            if tid:
                self.store.log(tid, f"{self.display_name()}导航锁排队超时"
                                    f"（{_NAV_LOCK_WAIT:.0f}s），放弃本次重新导航")
            return False
        try:
            try:
                self.bridge._ws.send("Page.enable", {}, timeout=8)
            except Exception:
                pass
            try:
                self.bridge._ws.send("Page.navigate",
                                     {"url": "https://www.doubao.com/chat/"}, timeout=20)
            except Exception as e:
                if tid:
                    self.store.log(tid, f"{self.display_name()}重新导航失败: {e}")
                return False
            deadline = time.time() + timeout
            stable = 0          # 连续"可用"采样次数
            last = {}
            while time.time() < deadline:
                if tid:
                    self.sleep_cancel(tid, 2.0, step=1.0)
                else:
                    time.sleep(2.0)
                h = self._page_health() or {}
                last = h
                if self._health_usable(h):
                    stable += 1
                    if stable >= 2:
                        if tid:
                            self.store.log(
                                tid, f"{self.display_name()}页面已修复"
                                     f"（按钮 {h.get('buttons')} 个，"
                                     f"入口={h.get('hasVideoEntry')}，"
                                     f"输入框={h.get('textareas')}）")
                        return True
                else:
                    stable = 0
            if tid:
                self.store.log(
                    tid, f"{self.display_name()}导航后页面仍不可用"
                         f"（readyState={last.get('readyState')}，"
                         f"按钮 {last.get('buttons')} 个，"
                         f"入口={last.get('hasVideoEntry')}，"
                         f"输入框={last.get('textareas')}）")
            return False
        finally:
            _NAV_LOCK.release()

    def _ensure_page_healthy(self, tid=None, max_repair=1, grace_sec=10):
        """确保账号页面主内容区已渲染（不是"半加载卡死"）；卡死就重新导航修复。

        2026-09-19 真机结论（连续 120 秒观察 7 个 webview 得出的）：
        - 半加载是**加载期的一次性结果**：坏页面 120 秒不会自愈，好页面 120 秒
          也不会变坏。所以"等一会儿看看"是没用的，必须主动重新导航。
        - 与是否 active tab、与 document.hidden **都无关**：实测 3 个非 active 的
          后台 webview 完全健康（可见按钮 27~28、有视频入口、有可见输入框）。
        - 唯一有效的修复手段是 Page.navigate 重新加载，实测 6 秒生效，
          3 并发 3/3 成功。
        - 首页健康的标志是"存在可见 textarea"，会话页健康的标志是"存在可见
          contenteditable"；坏页面两者都是 0，也找不到"视频生成"入口。

        每次调用都会重新体检（不做缓存），可以在流程的多个关键点重复调用。
        """
        if not self.config.get("auto_repair_degraded_page", True):
            return True
        for attempt in range(max_repair + 1):
            h = self._page_health()
            if h is None:
                return True          # 读不到就别瞎修，按老逻辑继续
            if self._health_usable(h):
                return True
            # 宽限期：页面可能只是还没渲染完（并发时常见），先多等一会儿再判死。
            grace_end = time.time() + grace_sec
            while time.time() < grace_end:
                if tid:
                    self.sleep_cancel(tid, 2.0, step=1.0)
                else:
                    time.sleep(2.0)
                h = self._page_health()
                if h is None or self._health_usable(h):
                    return True
            h = self._page_health() or h
            if attempt >= max_repair:
                break
            if tid:
                self.store.log(
                    tid, f"⚠️ {self.display_name()}页面主内容区未渲染"
                         f"（可见按钮 {h.get('buttons')} 个、"
                         f"输入框 {h.get('textareas')} 个、"
                         f"视频入口={h.get('hasVideoEntry')}），"
                         f"重新导航修复（第 {attempt + 1} 次）")
            if self._repair_degraded_page(tid):
                return True
        # 修不好：再给最后一次机会复查，仍不行才判死
        h = self._page_health() or {}
        if self._health_usable(h):
            return True
        if tid:
            self.store.log(
                tid, f"{self.display_name()}页面修复失败"
                     f"（按钮 {h.get('buttons')} 个、输入框 {h.get('textareas')} 个），"
                     f"该账号暂停派单，任务重新排队")
        # 10 分钟（不是 30 分钟）：页面状态会随管理器/网络变化，太长的封禁会白白
        # 闲置一个账号，而实际上过一会儿重试往往就好了。
        self.degraded_until = time.time() + 600
        raise PageDegraded(
            f"{self.display_name()}豆包页面半加载卡死，重新导航后仍未恢复")

    # 会话页链接筛选：只认 /chat/<纯数字ID>。排除 /chat/cron-jobs、/chat/skills、
    # /chat/drive 这类功能页（实测点进去得到 b=11 的半加载页面）。
    _CONV_HREF_RE = re.compile(r"^/chat/\d+$")

    def _nav_and_wait(self, url, timeout=45, tid=None, label="", expect_re=None):
        """整页导航到 url，并等到页面真正可用（usable 且连续 2 次采样通过）。

        ⚠️ 只能 Page.navigate（Page.reload 会把 Electron 的 webview 全部打没）。
        所有导航都在 _NAV_LOCK 里串行：多个 webview 同时导航会互相抢带宽/渲染
        资源，这是坏页面的主要来源。

        expect_re：可选的"落地 URL 必须匹配"正则。
        ★★ 2026-09-19 实测的假成功陷阱：豆包会把打不开的会话**重定向回首页
        /chat/**，而首页按 usable 判据是"可用"的（可见按钮 26、入口=True、
        textarea=1）——只判 usable 就会把"被弹回首页"当成导航成功，于是我们以为
        进了会话页、其实又回到那个"一点「视频生成」就半加载"的首页。
        所以导航到会话页时必须校验落地 URL，不匹配就不算成功（换下一个会话）。

        另外：连续多次采样都是 degraded（彻底半加载）时提前放弃，不再干等满
        timeout——实测半加载页面 40 秒、120 秒都不会自己恢复，等下去纯属浪费，
        而失败得越快、换下一个会话的机会就越多。

        ⚠️ 排队超时直接放弃（不等锁）：详见 _nav_lock 的注释。
        返回 (是否可用, 最后一次 health)。
        """
        if not _nav_lock():
            if tid:
                self.store.log(tid, f"{self.display_name()}导航锁排队超时"
                                    f"（{_NAV_LOCK_WAIT:.0f}s），放弃本次导航{label}")
            return False, {}
        try:
            try:
                self.bridge._ws.send("Page.enable", {}, timeout=8)
            except Exception:
                pass
            try:
                self.bridge._ws.send("Page.navigate", {"url": url}, timeout=20)
            except Exception as e:
                if tid:
                    self.store.log(tid, f"{self.display_name()}导航失败{label}: {e}")
                return False, {}
            t0 = time.time()
            deadline = t0 + timeout
            stable = 0
            bad = 0
            wrong = 0
            last = {}
            while time.time() < deadline:
                if tid:
                    self.sleep_cancel(tid, 2.0, step=1.0)
                else:
                    time.sleep(2.0)
                if not self._ensure_injected():
                    continue
                h = self._page_health() or {}
                last = h
                if h.get("degraded"):
                    bad += 1
                    # 连续 3 次采样都是彻底半加载，且已经过了导航提交期 → 早退
                    if bad >= 3 and time.time() - t0 >= 6:
                        if tid:
                            self.store.log(
                                tid, f"{self.display_name()}导航后页面半加载"
                                     f"（按钮 {h.get('buttons')} 个，"
                                     f"入口={h.get('hasVideoEntry')}，"
                                     f"输入框={h.get('textareas')}），不再空等")
                        return False, h
                else:
                    bad = 0
                if not self._health_usable(h):
                    stable = 0
                    continue
                if expect_re and not re.search(expect_re, str(h.get("url") or "")):
                    # 页面可用，但没落在目标 URL 上（被弹回首页等）→ 不能算成功
                    stable = 0
                    wrong += 1
                    if wrong >= 3:
                        if tid:
                            self.store.log(
                                tid, f"{self.display_name()}导航后没停在目标页面"
                                     f"（实际 {str(h.get('url') or '')[:60]}），判定失败")
                        return False, h
                    continue
                stable += 1
                if stable >= 2:
                    return True, h
        finally:
            _NAV_LOCK.release()
        return False, last

    def _ensure_in_conversation(self, tid=None, timeout=45, max_try=3,
                                budget_sec=75):
        """确保页面停在一个会话页（/chat/<会话ID>）而不是首页 /chat/。

        为什么必须这样做（2026-09-19 真机实测，同样点一次「视频生成」入口）：
          首页  /chat/            → 主内容区被卸载、视频模式 UI 挂不上来 → 半加载
                                    （bodyLen 631→193，可见按钮 27→11，40 秒不恢复）
          会话页 /chat/<会话ID>   → 正常进入视频模式（出现「模型 Seedance …」「自动 · 10s」）
        用户"手动点进账号才开始走流程"正是因为手动进入时页面已在某个会话里。

        ⚠️ 必须用 Page.navigate 整页加载：实测用 location.href 做 SPA 跳转进会话页
        有相当概率把页面刷成半加载，而 Page.navigate 到会话页是稳定的
        （可见按钮 39、入口=True、输入框=1，40 秒不退化）。

        ★ 不同会话的"进去就是不是好页面"差别很大：实测有的会话整页进去后
        **直接就处于视频模式**（不用再点入口），有的进去就是坏的，还有的会被
        豆包直接弹回首页。所以这里最多试 max_try 个会话，撞上坏会话就换下一个，
        而不是原地反复重导航同一个。

        ⚠️ 必须校验落地 URL（expect_re）：豆包会把打不开的会话重定向回 /chat/，
        而首页按 usable 判据是"可用"的——不校验就会假成功。实测同一个 webview
        连导两次同一会话，第二次的落地 URL 就是 /chat/，却被判成"已进入会话页"。

        ⚠️⚠️ budget_sec（总预算，默认 75s）：本步骤最贵的地方在于它要**整页加载会话页**，
        而会话页远比首页重，多账号并发时几乎必然少拉 JS chunk（2026-09-19 晚实测：
        8 个 webview 里 6 个是"导航进会话页后变成半加载"，只有停在首页的那个健康）。
        一旦失败就会"换会话→再导航"，每次都抢全局 _NAV_LOCK，
        **一个账号在这里反复重试会把其余所有账号堵死**（6 个任务集体卡在
        preparing_page）。所以必须有硬预算，到点无条件放弃、回首页走原流程。

        返回 True = 已在会话页；False = 没做成（调用方按原流程继续，不阻断）。
        """
        _budget_end = time.time() + max(10.0, float(budget_sec or 0))
        # ★ 先把管理器窗口救回可见再导航。
        #   2026-09-19 实测：窗口最小化时 7 个 webview 的 document.visibilityState
        #   **全部是 hidden**（注意：这推翻了早前"guest 内恒为 visible"的结论，那个
        #   结论是在窗口没最小化时测出来的）。hidden 状态下做的每一次导航几乎必然
        #   产出半加载页面，这里不先救窗口就会白白烧掉 max_try 次导航机会。
        self._ensure_window_visible(tid)
        cur = str(self._eval_safe("location.href") or "")
        # 已在会话页**且页面健康**才算过关。只判断 URL 会漏掉"URL 还在会话页、
        # 但主内容区已经崩掉"的情况（实测几分钟后页面会自己退回首页半加载态，
        # 重试时必须重新导航，否则等于在坏页面上空点）。
        if re.search(r"doubao\.com/chat/\d+", cur):
            h0 = self._page_health() or {}
            if self._health_usable(h0):
                return True
        try:
            links = self._eval_safe(
                "(function(){return Array.from(document.querySelectorAll("
                "\"a[href*='/chat/']\")).filter(window.__dbm.vis).map(function(e){"
                "return {h:e.getAttribute('href'), t:(e.innerText||'').trim().slice(0,20)};});"
                "})()") or []
        except Exception:
            links = []
        # 候选会话：非"主对话"优先（主对话历史消息最多、加载最重，实测进它
        # 半加载概率更高）；按原始顺序稳定排序，避免每次换不同的会话导致抖动。
        cands = []
        for o in links:
            h = str(o.get("h") or "")
            if not self._CONV_HREF_RE.match(h):
                continue
            t = str(o.get("t") or "")
            cands.append((0 if "主对话" not in t else 1, h))
        cands.sort(key=lambda x: x[0])
        tried = []
        for idx, (_pri, href) in enumerate(cands[:max_try]):
            if href in tried:
                continue
            # 硬预算到点：不再抢导航锁、不再重试，直接回首页走原流程
            if time.time() >= _budget_end:
                if tid:
                    self.store.log(
                        tid, f"{self.display_name()}进入会话页已耗时 {budget_sec}s "
                             f"仍未成功，放弃（回首页按原流程继续，避免堵住其他账号）")
                return False
            tried.append(href)
            if idx == 0:
                if tid:
                    self.store.log(
                        tid, f"{self.display_name()}页面停在首页"
                             f"（首页点「视频生成」会把页面刷成半加载），"
                             f"整页导航进入会话 {href}")
            elif tid:
                self.store.log(tid, f"{self.display_name()}上一个会话进去后不可用，"
                                    f"换会话 {href} 再试")
            ok, h = self._nav_and_wait("https://www.doubao.com" + href,
                                       timeout=timeout, tid=tid,
                                       label=f"（会话 {href}）",
                                       # 必须真的落在会话页：豆包会把打不开的会话
                                       # 弹回首页，而首页是"可用"的 → 不校验就会
                                       # 假成功，又回到一点入口就半加载的首页。
                                       expect_re=r"doubao\.com/chat/\d+")
            if ok:
                if tid:
                    self.store.log(
                        tid, f"{self.display_name()}已进入会话页"
                             f"（按钮 {h.get('buttons')} 个，"
                             f"入口={h.get('hasVideoEntry')}，"
                             f"视频模式={h.get('isVideo')}，"
                             f"输入框={h.get('textareas')}，"
                             f"URL={str(h.get('url') or '')[:50]}）")
                return True
        if not tried:
            # 拿不到历史会话链接（半加载页面常见）：至少整页导航回首页把页面修好，
            # 别让后面在一个坏页面上继续空转。
            if tid:
                self.store.log(tid, f"{self.display_name()}侧边栏没有可用历史会话，"
                                    f"改为整页导航回首页修复页面")
            ok, _h = self._nav_and_wait("https://www.doubao.com/chat/",
                                        timeout=timeout, tid=tid, label="（首页）")
            if ok and tid:
                self.store.log(tid, f"{self.display_name()}页面已恢复"
                                    f"（整页导航回首页）")
            # 页面修好了，但确实没进会话页
            return False
        if tid:
            h = self._page_health() or {}
            self.store.log(tid, f"{self.display_name()}进入会话页后仍不可用"
                                f"（按钮 {h.get('buttons')} 个，"
                                f"入口={h.get('hasVideoEntry')}，"
                                f"输入框={h.get('textareas')}），按原流程继续")
        return False

    # 轻量探测：只判断 window.__dbm 是否还在（几十字节的 CDP 往返）。
    # 注入脚本本身有 64KB，绝不能在轮询里反复发送（详见 _ensure_injected 的注释）。
    _DBM_ALIVE_JS = (
        "typeof window.__dbm !== 'undefined' "
        "&& !!(window.__dbm && window.__dbm.pageInfo)"
    )

    def _dbm_alive(self):
        """window.__dbm 是否已就绪**且版本是当前脚本**（轻量探测，不注入）。

        ★ 2026-09-22：只看"在不在"是不够的。webview 跨多次桥接重启常常不刷新，
        页面里残留的是上一次注入的旧脚本 —— 于是新写的词表/新函数线上一个都不生效，
        表现为"代码改了却像没改"。现在比对 dbm.__ver，版本不符就当作未注入，
        由 _ensure_injected 强制重灌。
        """
        try:
            ver = inject_js_ver(self.selectors)
            if not ver:
                # 拿不到版本号（理论上不会）：退回老判据，至少不影响可用性
                return bool(self._eval_safe(self._DBM_ALIVE_JS, timeout=8))
            probe = ("typeof window.__dbm !== 'undefined' "
                     "&& !!(window.__dbm && window.__dbm.pageInfo) "
                     "&& window.__dbm.__ver === %s" % json.dumps(ver))
            return bool(self._eval_safe(probe, timeout=8))
        except Exception:
            return False

    def _ensure_injected(self, tid=None, retries=3):
        """确保 window.__dbm 注入成功（多账号并发/页面导航可能导致单次注入未生效）。

        注入后会校验库函数确实存在，避免后续 pageInfo() 因 __dbm 缺失而误报
        needs_calibration。

        ★★ 2026-09-19 晚并发优化（本次改动里收益最大的一处）：
          旧实现**每次进来都无条件灌一遍 64KB 脚本**，而本函数在
          `_wait_chat_ready`（每 1.5s）、collect_loop、`_fast_detect_video` 里被
          高频调用。7 个账号并发时每秒约 300KB 的 CDP 传输 + V8 编译压在渲染线程上，
          实测直接把豆包页面挤成"半加载"（就绪后 6 秒就只剩侧边栏）。
          改为**先做一次轻量探测，已经存在就直接返回**，绝大多数调用将零开销。

        ★ 2026-09-22 修正：这里的"已存在"必须同时满足**版本一致**（见 _dbm_alive）。
        否则页面残留旧脚本时永远走这条零开销分支，新逻辑一条都生效不了。
        """
        for i in range(retries):
            if tid:
                self.check_cancel(tid)
            if i == 0 and self._dbm_alive():
                # 已注入且版本一致：不再重复灌 64KB，只补一次可见性覆盖
                self._apply_force_visible()
                return True
            try:
                self.bridge.evaluate(build_inject_js_cached(self.selectors))
            except Exception:
                pass
            ok = self._dbm_alive()
            if ok:
                # 注入成功说明页面上下文可用；顺手补一次可见性覆盖（导航后会被清空）
                self._apply_force_visible()
                return True
            if tid:
                self.sleep_cancel(tid, 1.0, step=0.5)
            else:
                time.sleep(0.5)
        return False

    def _wait_page_visible(self, tid, timeout=45):
        """等待本账号 webview 真正处于"已布局/可见"状态。

        非活动 webview 被 Chromium 判为隐藏：不绘制、不跑 rAF、定时器降频，豆包这类
        SPA 常常因此根本不挂载编辑器 → 后面必然误报"找不到输入框/需要标定"。
        这里轮询 pageProbe()，只要页面还没排版出来就重新激活标签页，直到可见或超时。
        """
        deadline = time.time() + timeout
        last = {}
        while time.time() < deadline:
            self.check_cancel(tid)
            self._ensure_injected(tid, retries=2)
            last = self._eval_safe("window.__dbm ? window.__dbm.pageProbe() : null", timeout=15)
            if isinstance(last, dict) and (last.get("nodes") or 0) > 50 \
                    and not last.get("zeroLayout"):
                if last.get("hidden"):
                    # 页面排版正常但被判 hidden：豆包不会渲染"视频生成"入口，
                    # 后面必然卡在 no_video_entry。这里主动把窗口救回前台再继续。
                    if not self._ensure_window_visible(tid):
                        self.store.log(
                            tid, f"{self.display_name()}页面已排版但窗口不可见"
                                 f"（管理器窗口可能被最小化），继续")
                return last
            self.store.log(
                tid, f"{self.display_name()}页面尚未排版/可见"
                     f"（zeroLayout={last.get('zeroLayout') if isinstance(last, dict) else '?'}, "
                     f"nodes={last.get('nodes') if isinstance(last, dict) else '?'}），重新激活标签页")
            self._activate_foreground(tid, reason="页面不可见，重新激活")
            if self._last_activate_reason == "manager_page_not_found":
                break
            self.sleep_cancel(tid, 2.0, step=0.5)
        return last if isinstance(last, dict) else {}

    def _fg_acquire(self, tid=None, reason="", need_lock=True):
        """获取前台输入锁（阻塞直到其他账号释放），并激活本账号 tab。

        管理器同一时刻只有一个 webview tab 能接收真实键盘/鼠标输入，因此
        "填表+提交"阶段用此锁串行化。带超时轮询，可响应取消/停用。

        need_lock=False（L2 并行提交）：**不抢**全局 input_lock，只走一遍
        _activate_foreground（并行模式下它本身也不再切 tab）。
        各账号有独立的 ManagerBridge / WebSocket，可以真正并发填报提交。
        """
        if self._fg_locked:
            return
        if need_lock:
            # 跨进程：图片桥/视频桥互斥驱动同一个豆包管理器 UI（见 _crosslock）
            _xp = foreground_mutex("video")
            _xp.acquire()
            self._xp_fg = _xp
            while not self.scheduler.input_lock.acquire(timeout=1):
                if tid:
                    self.check_cancel(tid)
                if self.dead:
                    raise TargetGone(f"{self.display_name()}已停用")
            self._fg_locked = True
        else:
            # 未持锁：_fg_release() 必须保持 no-op，不能误释放别的线程持有的锁
            self._fg_locked = False
        if tid:
            self._activate_foreground(tid, reason=reason)

    def _fg_release(self):
        """释放前台输入锁（幂等，供任务结束/异常兜底调用）。"""
        if self._fg_locked:
            try:
                self.scheduler.input_lock.release()
            except Exception:
                pass
            self._fg_locked = False
        # 释放跨进程前台锁（与 _fg_acquire 配对；持有者崩溃/异常也在此兜底释放）
        _xp = getattr(self, "_xp_fg", None)
        if _xp is not None:
            try:
                _xp.release()
            except Exception:
                pass
            self._xp_fg = None

    # ------------------------------------------------------------------
    # ★ 2026-11-03：无水印下载「解析窗口」的获取 / 释放 / 时间片让位
    # ------------------------------------------------------------------
    def _nowm_window_acquire(self, tid):
        """非阻塞地尝试成为全局下载解析窗口的所有者。

        返回 True=已独占（调用方必须在回收结束时 _nowm_window_release）；
        False=当前有别的账号在解析，本轮应只保活、不触发任何下载动作。

        ⚠️ 死锁兜底：持锁线程若被异常强杀，owner.until 过期很久后锁仍被占，
        这里会强制释放一次再重抢（threading.Lock 允许非持有者 release）。
        """
        if getattr(self, "_nowm_window_held", False):
            return True
        got = _NOWM_WINDOW_LOCK.acquire(blocking=False)
        if not got:
            _ou = 0.0
            with _NOWM_WINDOW_GUARD:
                _ou = float(_NOWM_WINDOW_OWNER.get("until") or 0)
            if _ou and time.time() > _ou + 120:
                # 上一个所有者疑似异常退出且已远超时间片，强制解锁让队列继续
                try:
                    _NOWM_WINDOW_LOCK.release()
                except Exception:
                    pass
                got = _NOWM_WINDOW_LOCK.acquire(blocking=False)
            if not got:
                return False
        self._nowm_window_held = True
        try:
            _slice = float(self.config.get("nowm_window_slice_sec", 180) or 180)
        except (TypeError, ValueError):
            _slice = 180.0
        _slice = max(30.0, _slice)
        self._nowm_window_until = time.time() + _slice
        with _NOWM_WINDOW_GUARD:
            _NOWM_WINDOW_OWNER["tid"] = tid
            _NOWM_WINDOW_OWNER["worker"] = self.display_name()
            _NOWM_WINDOW_OWNER["until"] = self._nowm_window_until
        try:
            self.store.log(
                tid, f"[下载窗口] {self.display_name()} 获得独占解析窗口"
                     f"（{int(_slice)}s 时间片）——其余账号排队等待，"
                     f"避免并发点击打断管理器 get_download_info 解析")
        except Exception:
            pass
        return True

    def _nowm_window_release(self, tid=None, reason=""):
        """释放下载解析窗口（幂等）。成功 / 失败 / 异常 / 取消都必须调用。"""
        if not getattr(self, "_nowm_window_held", False):
            return
        self._nowm_window_held = False
        self._nowm_window_until = 0.0
        try:
            _NOWM_WINDOW_LOCK.release()
        except Exception:
            pass
        with _NOWM_WINDOW_GUARD:
            _NOWM_WINDOW_OWNER["tid"] = ""
            _NOWM_WINDOW_OWNER["worker"] = ""
            _NOWM_WINDOW_OWNER["until"] = 0.0
        if tid:
            try:
                self.store.log(tid, f"[下载窗口] 释放独占解析窗口（{reason}）")
            except Exception:
                pass

    def _nowm_window_slice_expired(self, tid):
        """独占时间片到期：主动让位，避免一个卡死的账号拖死其余排队账号。"""
        if not getattr(self, "_nowm_window_held", False):
            return False
        if time.time() < (getattr(self, "_nowm_window_until", 0.0) or 0):
            return False
        try:
            self.store.log(
                tid, "[下载窗口] 独占解析时间片到期仍未拿到成品，主动让位给排队账号"
                     "（本任务继续守候/扫盘，稍后重新排队，绝不无限占锁）")
        except Exception:
            pass
        self._nowm_window_release(tid, reason="时间片到期让位")
        # 让位后给其他账号 20s 优先窗口，再允许本任务重新排队
        self._nowm_window_retry_after = time.time() + 20.0
        return True

    def _force_foreground_for_download(self, tid):
        """下载窗口持有者专用：把本账号 tab 真正置为前台（绕过 parallel_submit 的
        "不切 tab" 策略），唤醒被后台化的冻结 webview。

        ★ 为什么安全、且是根治"下载环节丢片"的首选手段：
          - 下载窗口是全局串行锁，同一时刻只有本账号在下载；本函数只会被窗口持有者
            调用，不会与其它并发账号同时抢前台（它们此刻都在排队等窗口，并不下载）。
          - parallel_submit 下 _ensure_foreground/_activate_foreground 故意【不切 tab】，
            仅 keep_active；但被后台化的 webview 仍被 Chromium 重度节流，React fiber
            不 hydrate、resolveNoWmViaApi 失效，已生成的视频在 download 阶段点不动/
            解析不出直链——正是"下载环节丢片"的根因。
          - 把本 tab 真正 bringToFront 后，Chromium 恢复渲染、fiber 重新 hydrate，
            下载直链解析与按钮点击立即恢复。比"刷新页面"更快、零重渲染代价；刷新只作为
            它仍失败时的兜底。
        仅尽力而为，失败不致命（CDP 仍可操作）。
        """
        try:
            self._set_tab_token()
            res = self.bridge.activate_manager_tab(self.tab_token) or {}
            if res.get("ok"):
                try:
                    self.bridge._ws.send("Page.bringToFront")
                except Exception:
                    pass
                self._keep_active()
                self.sleep_cancel(tid, 1.0, step=0.5)
                return True
            else:
                self.store.log(
                    tid, f"下载窗口强制置前未成功（{res.get('reason')}），"
                         f"继续尝试其它唤醒手段")
        except Exception as e:
            self.store.log(tid, f"下载窗口强制置前异常（继续）: {e}")
        return False

    def _refresh_for_download(self, tid):
        """下载前刷新会话页（唤醒冻结 webview 的兜底手段，仅窗口持有者调用）。

        触发条件由调用方保证：video_appeared 已确认为真（刷新不会打断生成）、
        距上次刷新 ≥45s、本任务刷新次数 < 上限。重新渲染出 <video> 与下载入口、
        重新 hydrate fiber，让本次下载得以进行。仅作用于本账号自己的 bridge/target。
        """
        _now = time.time()
        _last = getattr(self, "_unfreeze_reload_ts", 0.0) or 0.0
        _n = getattr(self, "_unfreeze_reload_n", 0) or 0
        if _n >= 3 or (_now - _last) < 45:
            return  # 已达刷新上限或冷却中
        _conv = (self.store.get(tid) or {}).get("conversation_url")
        if not _conv:
            return
        try:
            self._unfreeze_reload_n = _n + 1
            self._unfreeze_reload_ts = _now
            self.store.log(
                tid, f"下载前刷新豆包会话页面以唤醒冻结 webview（第{_n + 1}次）…")
            self.bridge._ws.send("Page.navigate", {"url": _conv}, timeout=20)
            self.sleep_cancel(tid, 5, step=1)
            self._ensure_attached(tid)          # 重新注入 __dbm、重建 CDP 上下文
            self._ensure_task_conversation(tid) # 确保停在本任务的会话
            self.store.log(tid, "下载前刷新完成，页面已重新渲染，继续解析下载…")
        except Exception as e:
            self.store.log(tid, f"下载前刷新页面失败（忽略）: {e}")

    def _prepare_page_for_download(self, tid, video_confirmed=False,
                                   allow_refresh=False):
        """下载前确保本账号豆包页面处于可交互状态（唤醒被冻结的 webview）。

        ★ 并发根因（用户 2026-11-03「并发 2 个只回传 1 个」+「下载环节丢片」）：
            管理器单进程多 webview，parallel_submit 下 _ensure_foreground 故意
            【不切 tab】，被后台化的 webview 被 Chromium 重度节流：<video> 不渲染、
            React fiber 不 hydrate、resolveNoWmViaApi 失效，已生成的视频在 download
            阶段点不动/解析不出直链，整批只回传 1 个、或单任务偶发丢片。

            ⚠️ 旧实现用 document.visibilityState 判断冻结——但本插件对页面注入了
            _apply_force_visible，把 visibilityState 永久覆盖为 'visible'，该探针
            【永远为真】，冻结态完全不可见，刷新分支从不被触发。这才是"修了却还在
            丢片"的真正原因。

            新策略（不再依赖被覆盖的可见性探针）：
            1) 轻量保活；
            2) 仅【下载窗口持有者】才把本账号 tab 真正 bringToFront（绕开 parallel_submit
               不切 tab 的限制）。窗口是全局串行锁，同时只有本账号在下载，置前不会与
               其它并发账号冲突；置前后 Chromium 恢复渲染、fiber 重新 hydrate，下载直链
               解析与按钮点击立即恢复——首选、零重渲染代价的唤醒手段。
            3) JS 上下文丢失（__dbm dead）则重新注入；
            4) allow_refresh=True（主循环每 5 次前台尝试触发）时，在冷却/上限内刷新兜底。
               video_appeared 已确认，刷新不会打断生成。
        """
        try:
            self._ensure_foreground(tid, reason="下载前激活tab")
        except Exception as e:
            self.store.log(tid, f"下载前激活tab异常（继续）: {e}")
        _held = bool(getattr(self, "_nowm_window_held", False))
        # JS 上下文是否还在（被导航/崩溃会丢失 __dbm）
        try:
            _dbm = self._eval_safe("window.__dbm ? 'ok' : 'dead'")
        except Exception:
            _dbm = ""
        if not _held:
            # 非窗口持有者：绝不抢前台、绝不刷新（那会打扰正在下载的账号），仅保活等待。
            return
        # 窗口持有者：把本 tab 真正置前，唤醒冻结 webview（首选手段，幂等、代价低）
        _lf = getattr(self, "_last_force_front_ts", 0.0) or 0.0
        if _dbm != "ok" or (time.time() - _lf) >= 5:
            self._force_foreground_for_download(tid)
            self._last_force_front_ts = time.time()
        if _dbm != "ok":
            try:
                self._eval_safe(build_inject_js_cached(self.selectors), timeout=15)
            except Exception:
                pass
        # 刷新兜底（受 3 次 / 45s 约束；仅窗口持有者、且 video_appeared 已确认时）
        if allow_refresh and video_confirmed:
            self._refresh_for_download(tid)

    def _scan_video_files(self, dl_dir):
        """扫描下载目录中所有已知视频扩展名的文件，返回 Path 集合。"""
        if not dl_dir:
            return set()
        result = set()
        for ext in VIDEO_EXTS:
            for f in Path(dl_dir).glob(f"*{ext}"):
                result.add(str(f))
        return result

    def _dl_candidates(self, dl_dir):
        """下载目录里「自上次扫描以来新增或内容变化」的视频文件。

        用 (path, size, mtime) 签名去重，而非仅按路径（见 self._dl_pre_sigs）。
        豆包固定把成品存成 video.mp4 并覆盖同一路径，旧逻辑只按路径差集会把它当成
        旧文件永久跳过，导致已落盘成品不被认领、任务超时。此处同一路径只要被覆盖
        （size/mtime 变化）就重新纳入候选；稳定旧文件（含任务启动前就存在的）则按
        签名一致跳过，不会误认领。
        """
        out = []
        seen = getattr(self, "_dl_pre_sigs", None)
        if seen is None:
            seen = self._dl_pre_sigs = {}
        try:
            files = self._scan_video_files(dl_dir)
        except Exception:
            return out
        for f in files:
            try:
                st = Path(f).stat()
                sig = (st.st_size, int(st.st_mtime))
            except Exception:
                continue
            if seen.get(f) == sig:
                continue  # 与上次完全一致：稳定旧文件，跳过
            seen[f] = sig   # 新文件或内容变化（覆盖写入）：纳入候选
            out.append(f)
        return out

    def _net_video_since(self, since_ts):
        """网络监听里"自 since_ts 之后捕获到的视频响应 URL"（按捕获顺序）。

        webview 被 Chromium 冻结时 DOM 不渲染（pageVideos() 恒空），但网络层照常
        收到响应。这份证据独立于页面渲染，是判断"豆包到底出片没有"最可靠的依据——
        实测大量任务页面 <video> 恒为 0，而网络层早就拿到了 mp4。
        """
        out = []
        for item in (getattr(self.bridge, "_mp4_candidates", None) or []):
            try:
                u, ts = item[0], item[1]
            except Exception:
                continue
            try:
                if float(ts) >= since_ts and str(u).startswith("http"):
                    out.append(u)
            except (TypeError, ValueError):
                continue
        return out

    def _drain_net(self):
        """把 CDP 网络事件收进候选池。

        ⚠️ 之前只有 collect_loop 里 drain，而任务提交后的前 600 秒一直在跑
        _fast_detect_video，那段时间的 mp4 响应全部堆在 WS 队列里没人取；
        collect 入口一次 attach 又把候选清空，出片证据就这么丢了。
        所有轮询环节都必须调用它。
        """
        try:
            self.bridge.drain_network_events()
        except Exception:
            pass

    def _perf_video_new(self, click_time):
        """页面 performance 资源时间线里、提交之后新增的视频请求 URL（增量比对）。

        这是页面自己记的账：既不依赖 <video> DOM（shadow/iframe 里的拿不到），
        也不依赖 CDP Network 域（断连重连会丢）。只要豆包把 mp4 拉下来过就一定有。
        """
        try:
            perf = self._eval_safe(
                "window.__dbm && window.__dbm.perfVideos ? window.__dbm.perfVideos() : []",
                timeout=10) or []
        except Exception:
            return []
        names = []
        for e in perf or []:
            n = str((e or {}).get("name") or "") if isinstance(e, dict) else str(e)
            if n:
                names.append(n)
        base = getattr(self, "_submit_perf_baseline", None)
        if base is None:
            # 没能在提交时取到基线（旧任务 / 注入时机晚）：先把现状记为基线，
            # 之后出现的才算增量，避免把历史视频当成新片。
            self._submit_perf_baseline = set(names)
            return []
        new = [n for n in names if n not in base]
        if new:
            self._submit_perf_baseline.update(new)
        return new

    def _gate_evidence_with_progress(self, tid, hit, urls, reason):
        """证据 1/2/3 的「生成中」交叉校验闸门（2026-10-12）。

        实测 2026-10-12 两轮任务都在提交后 61s 出现"实时检测到视频已生成"的
        误报 —— 当时豆包还在生成（页面诊断 progress=true/done=false），视频类
        信号其实是生成占位动画/任务轮询请求。提前启动回收后按钮自然找不到，
        白白空转 5 分钟。
        文案位置比较（textState）能准确判断当前是否仍在生成：只要
        "生成中/预计等待"文案仍位于最后（progress=true 且 done=false），就把
        DOM/资源时间线/网络层证据视为占位噪声，不进入取片。
        done=true 或无信号（sig 拿不到）时不拦截 —— 保持原有取片能力。
        """
        if not hit:
            return False, urls, reason
        try:
            sig = self._eval_safe(
                "window.__dbm && window.__dbm.resultSignal ? "
                "window.__dbm.resultSignal() : null",
                timeout=10) or {}
        except Exception:
            sig = {}
        if isinstance(sig, dict) and (
                sig.get("quota") or (sig.get("progress") and not sig.get("done"))):
            if not getattr(self, "_ev_gate_logged", False):
                self._ev_gate_logged = True
                self.store.log(
                    tid, f"检测到视频类信号但页面文案仍在生成中，判定为占位噪声继续等待"
                         f"（信号：{reason[:100]}）")
            return False, urls, reason
        self._ev_gate_logged = False
        return True, urls, reason

    def _confirm_hit_concrete(self, tid, page_videos):
        """视频证据命中的「具体性」复核（2026-11-03，防假阳性早启动）。

        背景：实测提交后 61s 出现「实时检测到视频已生成」假阳性——当时页面诊断
        done=false、videoLike=0、deepVideo=0（豆包仍在生成，命中源是信号瞬时抖动/
        占位噪声），提前启动回收流程白白空转数分钟，还挤占独占解析窗口。

        规则：有具体视频 URL（深度 <video> 等硬证据）的命中直接放行（它们已过
        progress 闸门）；**无任何具体视频 URL** 的命中（纯文案/信号类证据）必须在
        二次取样中仍成立（done / noWm / download / regen 任一为真）才放行。
        CDP 复核失败时放行（宁可早启动再等待，也不愿因抖动漏掉真片）。
        """
        if page_videos:
            return True
        try:
            sig2 = self._eval_safe(
                "window.__dbm && window.__dbm.resultSignal ? "
                "window.__dbm.resultSignal() : null", timeout=10)
        except Exception:
            return True  # 复核通道异常：不拦截（避免 CDP 抖动误杀真命中）
        if not isinstance(sig2, dict):
            return True
        if sig2.get("quota"):
            return False
        return bool(sig2.get("done") or sig2.get("noWm")
                    or sig2.get("download") or sig2.get("regen"))

    def _video_evidence(self, tid, click_time):
        """综合多源证据判定"成片是否已经出来"。

        返回 (appeared, urls, reason)：
          appeared —— True 表示可以进入取片（点无水印下载 / 扫盘）流程
          urls     —— 可用于兜底直下的 http 直链（可能为空）
          reason   —— 命中途径，写日志用

        旧逻辑只认 document 顶层 <video src=...>：一旦豆包把成片放到
        shadow DOM / 同源 iframe / <source> 子标签 / MediaSource 里，或者只渲染
        封面、点播放时才建 <video>，就永远判不出来，任务只能空转到超时——
        表现正是"管理器里明明看得到片子，插件却一直报 0 个视频"。
        这里按可靠性依次检查四条独立证据：
          1) 深度 <video> 扫描（穿透 shadow / iframe / source）
          2) 页面 performance 资源时间线里的视频请求
          3) CDP 网络层嗅探到的 mp4 响应
          4) 结果卡片 UI 信号（无水印下载 / 下载 / 重新生成，且页面不再"生成中"）
        """
        self._drain_net()
        # ★ 2026-11-03 v3：额度耗尽文案优先于一切视频证据（最高优先级闸门）。
        #   账号页面常残留上一轮成片的 <video> / 资源记录，若不在最前面拦住，
        #   下面的硬证据分支会把「免费额度已用完」误判成「已出片」，进而
        #   _mark_seedance_generated() 虚增一次生成、凑出 3/3。
        #   这里做 5 秒节流的额度探测，命中直接判定未出片；上层回收循环的
        #   quotaExhausted() 会抛 QuotaExceeded，走确定性的满额封禁流程。
        _qnow = time.time()
        if _qnow - getattr(self, "_last_quota_ev_ts", 0.0) >= 5:
            self._last_quota_ev_ts = _qnow
            try:
                _qe = self._eval_safe("window.__dbm.quotaExhausted()") or ""
            except Exception:
                _qe = ""
            if _qe:
                return False, [], ""
        # 轮询可能每 2 秒一次，深度扫描之外的两条证据（资源时间线 / UI 信号）都是
        # 额外的 CDP evaluate，多账号并发时会明显加重开销 —— 统一做 10 秒节流
        # （2026-09-29 由 15s 收紧：成片在 DOM 检不出、又漏过网络嗅探时，能更快
        # 靠资源时间线 / 结果卡片 UI 信号确认，少空等几轮）。
        now = time.time()
        allow_slow = (now - getattr(self, "_last_slow_ev_ts", 0.0)) >= 10
        if allow_slow:
            self._last_slow_ev_ts = now
        # 1) 深度 <video> 扫描
        deep = []
        try:
            deep = self._eval_safe(
                "window.__dbm && window.__dbm.deepVideos ? window.__dbm.deepVideos() : []",
                timeout=12) or []
        except Exception:
            deep = []
        urls = []
        has_vid_el = False
        for v in deep or []:
            if not isinstance(v, dict):
                continue
            has_vid_el = True
            u = str(v.get("src") or "")
            if u.startswith("http") or u.startswith("blob:"):
                urls.append(u)
        if has_vid_el:
            where = ",".join(sorted({str(v.get("where") or "?") for v in deep
                                     if isinstance(v, dict)}))[:60]
            return self._gate_evidence_with_progress(
                tid, True, urls, f"深度扫描到 <video>（{where}，{len(deep)} 个）")
        # 2) 页面资源时间线
        perf_new = self._perf_video_new(click_time) if allow_slow else []
        if perf_new:
            return self._gate_evidence_with_progress(
                tid, True, [p for p in perf_new if p.startswith("http")],
                f"页面资源时间线出现视频请求（{len(perf_new)} 条，"
                f"样例: {[p[-60:] for p in perf_new[:2]]}）")
        # 3) 网络层嗅探
        net = self._net_video_since(click_time)
        if net:
            return self._gate_evidence_with_progress(
                tid, True, net,
                f"网络层捕获到 mp4 响应（样例: {[n[-60:] for n in net[:2]]}）")
        # 4) 结果卡片 UI 信号
        sig = {}
        if allow_slow:
            try:
                sig = self._eval_safe(
                    "window.__dbm && window.__dbm.resultSignal ? window.__dbm.resultSignal() : null",
                    timeout=12) or {}
            except Exception:
                sig = {}
        if isinstance(sig, dict) and sig:
            # ★ 2026-11-03 v3：额度文案是权威拒绝结论，任何出片信号都必须让位。
            if sig.get("quota"):
                return False, [], ""
            # 4a) 豆包自己的回复明确说"你的视频生成好了" —— 最强文本证据。
            # 实测线上：页面 deepVideo=0、perf 里也没有 mp4（成片卡片是懒加载的，
            # 只有封面 <img>），唯一能证明"已经出片"的就是这条文案。
            # 位置比较已在 JS 侧排除掉永久残留的"预计等待 5 分钟"历史文案。
            if sig.get("done"):
                return True, [], "页面文案提示已出片（" + \
                    ",".join(sig.get("hits") or [])[:60] + "）"
            # 4b) 结果卡片出现成片入口（无水印下载 / 下载 / 重新生成）
            # ★ 2026-11-14：右侧「智能纪要 / 画布」分屏（zen_split）面板里
            #   的「下载 / 编辑 / 复制」按钮不是成片入口。带参考音频时豆包会
            #   自动打开该面板，旧版据此误判「已出片」并下载了别的账号窗口
            #   的历史视频（实测：nodes 1367→2208、hits 全是 dl:下载icon）。
            _zen = False
            if allow_slow:
                try:
                    _zen = bool(self._eval_safe(
                        "(function(){try{return !!(window.__dbm && "
                        "window.__dbm.minutesPanelOpen && "
                        "window.__dbm.minutesPanelOpen());}catch(e){return false;}})()",
                        timeout=8))
                except Exception:
                    _zen = False
                if not _zen:
                    try:
                        _u = str(self._eval_safe("window.location.href", timeout=8) or "")
                        _zen = ("layout=zen_split" in _u
                                or "write-artifact-preview" in _u)
                    except Exception:
                        pass
            if not _zen and not sig.get("progress") and (
                    sig.get("noWm") or sig.get("download") or sig.get("regen")):
                return True, [], "结果卡片出现成片入口（" + \
                    ",".join(sig.get("hits") or [])[:60] + "）"
        return False, [], ""

    def _reveal_video(self, tid):
        """主动把懒加载的成片卡片"唤醒"出来。

        豆包的结果卡片不会自动渲染 <video>：对话里只有一张封面 <img>，必须
        ①滚动到可视区 ②鼠标 hover 才会真正创建 <video> 元素并加载 mp4。
        ★ 2026-10-12 取消"点击打开视频"步骤：点卡片会打开「创建画布」预览
        面板，把聊天页整个盖住，「无水印下载」按钮随之消失，后续所有悬停/
        点击全部落空。宁可本轮唤醒不到 <video>，也绝不能点卡片。

        返回 (ok, card)；card 含卡片矩形（cx/cy 中心、rx/bry 右下）。
        """
        try:
            card = self._eval_safe(
                "window.__dbm && window.__dbm.revealVideo ? window.__dbm.revealVideo() : null",
                timeout=15) or {}
        except Exception as e:
            self.store.log(tid, f"{self.display_name()} 唤醒成片卡片失败: {e}")
            return False, {}
        if not isinstance(card, dict) or not card.get("found"):
            return False, card if isinstance(card, dict) else {}
        # 滚动后给浏览器一帧时间做懒加载
        self.sleep_cancel(tid, 1.5, step=0.5)
        cx, cy = int(card.get("cx") or 0), int(card.get("cy") or 0)
        if cx > 0 and cy > 0:
            try:
                self.bridge.mouse_move_path(cx - 60, cy - 40, cx, cy, steps=6)
                self.sleep_cancel(tid, 0.8, step=0.3)
                rx, bry = int(card.get("rx") or 0), int(card.get("bry") or 0)
                if rx > 0 and bry > 0:
                    self.bridge.mouse_move_path(cx, cy, rx, bry, steps=8)
                    self.sleep_cancel(tid, 1.0, step=0.3)
            except Exception as e:
                self.store.log(tid, f"{self.display_name()} 悬停成片卡片异常: {e}")
        # hover 之后再确认一次：现在应该有 <video> 了。
        # ★ 2026-10-12 移除"hover 唤不醒就真点一下"兜底——点卡片打开的是
        #   「创建画布」预览面板（实测截图），成片卡片被盖住后无水印按钮找不
        #   到，回收流程全断。hover 唤不醒就交给下一轮轮询 / API 自解析。
        n = self._video_elem_count()
        if n <= 0:
            # ★ 2026-10-23：新版卡片（block-video）hover 不会挂 <video>，必须点
            #   卡片里的小播放图标才会挂载 inline xgplayer（实测：点完 <video>=1，
            #   且不会打开「创建画布」面板）。不点的话管理器注入的「无水印下载」
            #   按钮永远不出现 → 线上无限重试 button_not_found。
            pj = self._eval_safe(
                "window.__dbm && window.__dbm.clickPlayIcon ? "
                "window.__dbm.clickPlayIcon() : null", timeout=10) or {}
            if pj.get("ok"):
                self.sleep_cancel(tid, 1.6, step=0.4)
                n = self._video_elem_count()
                card["play_clicked"] = True
                if n <= 0:
                    # JS el.click() 未生效：再尝试一次页面内点击（2026-11-02，
                    # 不再依赖 CDP 坐标点击，避免窗口不可见/缩放错位导致落空）
                    pj2 = self._eval_safe(
                        "window.__dbm && window.__dbm.clickPlayIcon ? "
                        "window.__dbm.clickPlayIcon() : null", timeout=10) or {}
                    self.sleep_cancel(tid, 1.4, step=0.4)
                    n = self._video_elem_count()
                    if pj2.get("ok"):
                        card["play_dom_retried"] = True
                    else:
                        self.store.log(
                            tid, f"{self.display_name()} 播放图标二次点击仍无 <video>: "
                                 f"{json.dumps(pj2, ensure_ascii=False)[:120]}")
                self.store.log(
                    tid, f"{self.display_name()} 成片卡片无 <video>，已点播放图标"
                         f"@({pj.get('x')},{pj.get('y')})，现在 <video> {n} 个")
            else:
                self.store.log(
                    tid, f"{self.display_name()} 成片卡片无 <video> 且未找到播放图标: "
                         f"{json.dumps(pj, ensure_ascii=False)[:160]}")
        card["video_after"] = n
        self.store.log(
            tid, f"{self.display_name()} 唤醒成片卡片（方式={card.get('by')}，"
                 f"滚动 {card.get('scrolled')} 个容器，"
                 f"hover 后 <video> {n} 个）")
        return True, card

    def _video_elem_count(self):
        """页面里（含 shadow DOM / 同源 iframe）的 <video> 元素数量。"""
        try:
            return len(self._eval_safe(
                "window.__dbm && window.__dbm.deepVideos "
                "? window.__dbm.deepVideos() : []", timeout=12) or [])
        except Exception:
            return 0

    def _log_page_diag(self, tid, tag=""):
        """把页面现场完整 dump 到任务日志：下次再"看得到片子却检测不到"时可直接定位。"""
        try:
            d = self._eval_safe(
                "window.__dbm && window.__dbm.pageDiag ? window.__dbm.pageDiag() : null",
                timeout=15) or {}
        except Exception as e:
            self.store.log(tid, f"{self.display_name()} 页面诊断失败: {e}")
            return
        if not isinstance(d, dict) or not d:
            self.store.log(tid, f"{self.display_name()} 页面诊断：无输出（__dbm 可能未注入）")
            return
        try:
            s = json.dumps(d, ensure_ascii=False)
        except Exception:
            s = str(d)
        self.store.log(tid, f"{self.display_name()} 页面诊断{tag}: {s[:900]}")

    def _dest_video_path(self, dl_dir, when=None):
        """本次任务的成品文件名：<账号名>_<YYYYmmdd_HHMMSS>.mp4

        同秒撞名时自动加 _2 / _3 序号。用账号名而不是任务 id，是为了让人在下载
        目录里一眼看出"这片子是哪个账号下的"，也让插件能按文件名硬匹配归属。
        """
        base = "%s_%s" % (
            safe_account_name(self.display_name()),
            time.strftime("%Y%m%d_%H%M%S", time.localtime(when or time.time())))
        p = Path(dl_dir) / (base + ".mp4")
        i = 2
        while p.exists():
            p = Path(dl_dir) / ("%s_%d.mp4" % (base, i))
            i += 1
        return p

    def _delivery_gate(self, tid):
        """回收 / 回传阶段的硬闸门（2026-11-14 修复「二次确认没发就回传」）。

        返回 (ok, reason, ready_ts)：
          ok       —— 是否允许检测视频 / 扫盘 / 下载 / 置 done
          ready_ts —— 「协商完成、真正开始生成」的时刻；所有等待计时都应以它
                      为基准，而不是编排器的分发时刻或旧 submit_ts。

        三条硬规则：
          1) 任务不能是终态，且必须处于 generating / downloading；
          2) generation_ready_ts 必须 > 0（submit_stage 协商走完才盖章）；
          3) 回传必须由派发给本任务的那个账号窗口执行（assigned_to 匹配）。
        旧任务（升级前创建、无 generation_ready_ts 字段）用 submit_ts 兼容，
        避免桥接重启后在途任务永远卡死。
        """
        t = self.store.get(tid) or {}
        st = str(t.get("status") or "")
        if st in ("done", "error", "failed", "cancelled"):
            return False, "任务已结束", 0.0
        if st not in ("generating", "downloading"):
            return False, "任务仍在提交协商阶段（status=%s）" % (st or "?"), 0.0
        _assigned = str(t.get("assigned_to") or "").strip()
        if _assigned and _assigned != str(self.target_id):
            return False, "当前账号窗口与任务派发账号不一致（疑似跨账号串片）", 0.0
        try:
            ready = float(t.get("generation_ready_ts") or 0)
        except (TypeError, ValueError):
            ready = 0.0
        if "generation_ready_ts" in t:
            if ready <= 0:
                return False, "提交协商尚未完成（禁止提前回收/回传）", 0.0
        else:
            try:
                ready = float(t.get("submit_ts") or 0)
            except (TypeError, ValueError):
                ready = 0.0
            if ready <= 0:
                return False, "缺少生成开始时刻", 0.0
        return True, "", ready

    def _finish_done(self, tid, dest, msg, video_url="local_file"):
        """统一置 done 并写入成品的体积/MD5，便于回传后完整性校验与去重
        （2026-11-02 新增：原先不记录，串片/损坏无法对账）。

        ★ 2026-11-14：6 条落盘链路（无水印按钮 / 浏览器下载事件 / 目录扫盘 /
        http_download 直下 / 兜底认领 / 视频刚出现时提前扫盘）全部在这里收口，
        回传前统一做一致性校验。宁可让任务如实失败，也绝不把不属于该分镜的
        视频送进字字动画窗口——这正是用户反馈「偶发回传混乱」的根因。
        """
        _t = self.store.get(tid) or {}
        # ★ 2026-11-14：6 条落盘链路的最后一道闸门。协商未完成、二次确认
        #   还没发完、或不是本任务派发的账号窗口，一律不准置 done 回传。
        _g_ok, _g_why, _g_ready = self._delivery_gate(tid)
        if not _g_ok:
            if (_t.get("status") or "") == "done":
                return  # 幂等：已完成的任务忽略重复落盘，不覆盖成 failed
            self.store.log(tid, "回传闸门拒绝（禁止提前/串片回传）：%s | 文件=%s"
                           % (_g_why, dest))
            self.store.update(
                tid, status="failed", percent=100,
                message="回传闸门拒绝（防止串片）：%s" % _g_why,
                deliver_consistency_error="回传闸门拒绝：" + _g_why,
                deliver_consistency_path=str(dest))
            _unmark_video_delivered(str(dest), tid)
            return
        _ok, _why, _md5 = _video_consistency_check(
            str(dest), tid, _t, self.display_name())
        if not _ok:
            self.store.log(tid, "回传一致性校验未通过，拒绝回传：%s | 文件=%s"
                           % (_why, dest))
            self.store.update(
                tid, status="failed", percent=100,
                message="成品一致性校验未通过，拒绝回传（防止串片）：%s" % _why,
                deliver_consistency_error=_why,
                deliver_consistency_path=str(dest))
            # 落盘链路已在调本函数之前 mark_video_delivered，拒绝回传时
            # 必须回滚，否则被拒文件会污染清单并挡住后续正常任务。
            _unmark_video_delivered(str(dest), tid)
            return
        try:
            _sz = Path(dest).stat().st_size
            _md = _md5 or _file_md5(str(dest))
        except Exception:
            _sz, _md = 0, ""
        self.store.update(tid, status="done", percent=100, message=msg,
                          video_url=video_url, video_path=str(dest),
                          video_size=_sz, video_md5=_md)
        # ★ 2026-11-03：成品一落盘就立刻复制回分镜目标路径。
        #   以前只靠插件 generate() 轮询到 done 后 shutil.copy2 —— 宿主一旦判失败 /
        #   超时 / 关闭，generate() 已经不在了，视频就永远进不了分镜窗口。桥接侧
        #   主动回传后，宿主下次读取该分镜（或用户重新点生成）就能直接看到，
        #   且 generate() 开头的幂等跳过会立刻复用，不会重复生成 / 扣额度。
        try:
            _scene_dest = str((_t.get("scene") or {}).get("dest") or "").strip()
            if _scene_dest and self.config.get("scene_auto_deliver", True):
                _ok2, _info = deliver_to_scene(str(dest), _scene_dest, tid)
                if _ok2:
                    self.store.update(tid, delivered_scene_path=_scene_dest,
                                      delivered_scene_at=now_str(),
                                      delivered_scene_error="")
                    self.store.log(tid, "成品已自动回传分镜窗口：%s" % _scene_dest)
                else:
                    _err = str(_info.get("error") or _info.get("status") or "")
                    # 旧版只写一行「不影响任务完成」就静默吞掉；目标分镜可能
                    # 仍显示旧片 / 别的片，用户看到的正是「回传的不是该分镜」。
                    # 现在把失败状态落到任务字段，控制台可查、可人工核对。
                    self.store.update(
                        tid, delivered_scene_error=_err,
                        delivered_scene_status=str(_info.get("status") or "failed"))
                    self.store.log(
                        tid, "分镜回传未成功（目标分镜可能仍显示其它视频，请人工核对）："
                             "%s | dest=%s" % (_err, _scene_dest))
        except Exception as e:
            self.store.log(tid, "分镜回传异常（已忽略）：%s: %s" % (type(e).__name__, e))

    def _mark_seedance_generated(self, tid):
        """视频真实生成完成时计一次额度（回传成不成功都算，因为豆包侧已生成）。
        在 _collect_loop 检测到 video_appeared 时调用；内部按 tid 去重，重复调用安全。"""
        try:
            _day = time.strftime("%Y-%m-%d", time.localtime())
            _t = self.store.get(tid) or {}
            _m = _t.get("model") or getattr(self, "model_name", "") or self.config.get("model_name", "")
            _sch = getattr(self, "scheduler", None)
            if _sch is not None:
                _sch.seedance_quota_inc(self, _m, _day, tid)
        except Exception as e:
            print(f"[bridge] seedance 配额计数失败: {e}")

    def _is_my_account_file(self, path):
        """文件名前缀是不是本账号（兜底认领时用来挑"确定是自己人"的成品）。"""
        try:
            owner = parse_account_video_name(Path(str(path)).name)
        except Exception:
            return False
        return bool(owner) and \
            owner.lower() == safe_account_name(self.display_name()).lower()

    def _release_shared_source(self, src):
        """复制完立刻释放对"共享落点"的认领。

        video.mp4 这类原始落盘文件是所有账号共用的：豆包每次下载都覆盖同一个名字。
        认领表的 TTL 是 30 分钟，如果不释放，下一个账号在半小时里根本认领不到这个
        路径 → 后面的任务会集体"明明下了片子却拿不到"。
        """
        if src and not self._is_my_account_file(str(src)):
            release_download_file(str(src))

    def _fresh_dir_videos(self, dl_dir, since_ts):
        """下载目录里"修改时间 >= since_ts 且体积合格"的视频，按 mtime 倒序。

        与 _scan_video_files 的集合差集不同，这里用【修改时间】判定新旧。
        必须这样做的原因：豆包的无水印下载固定落盘成 video.mp4（同名覆盖），
        集合差集会把"被覆盖后的新片"当成"早就存在的旧文件"直接忽略掉，
        于是用户手动下载 / 第二轮下载的成品永远不会被发现。
        """
        if not dl_dir:
            return []
        out = []
        try:
            base = Path(dl_dir)
            if not base.exists():
                return []
            for ext in VIDEO_EXTS:
                for f in base.glob("*%s" % ext):
                    try:
                        st = f.stat()
                    except OSError:
                        continue
                    if st.st_mtime < since_ts or st.st_size <= 50 * 1024:
                        continue
                    # 已作为别的任务成品交付过的文件，永不再被认领
                    if is_video_delivered(str(f)):
                        continue
                    out.append((st.st_mtime, f))
        except Exception:
            return []
        out.sort(key=lambda x: x[0], reverse=True)
        return out

    def _claim_dir_video(self, tid, since_ts, reason):
        """页面检测不到视频时的"下载目录兜底认领"。

        返回 True 表示已认领并把任务置为 done（调用方应当直接 return）。

        覆盖的场景：豆包页面其实已经出片（甚至用户或管理器自己点了下载），
        文件就躺在下载目录里，但插件因为 pageVideos() 一直为空而完全不看磁盘，
        于是一路干等到超时失败，辛苦生成的片子白白浪费。

        ⚠️⚠️ 2026-09-20 已默认关闭（dir_fallback_enabled=False），用户明确要求
        **不做兜底认领**：这条路径最大的问题是它会认领 `video.mp4` —— 那是豆包的
        **共享落点**（每个账号每次下载都覆盖同一个文件名），没有账号前缀，
        归属完全靠"时间窗内谁在跑"来猜。多账号并发时极易把**别的账号**刚下的片子
        认领成本任务成品，日志里甚至自己就打印"无归属前缀，请人工核对"。
        而且页面没检出 <video> 本身就说明这次下载来源不明，可能是用户手动点的
        **带水印**"下载"。交一个归属不明 + 可能带水印的成品，比失败更糟。
        关闭后任务如实走失败路径，用户重跑即可。
        """
        if not self.config.get("dir_fallback_enabled", True):
            # 兜底已关闭：一个都不认领，返回 False 让调用方按失败处理。
            return False
        dl_dir = self._account_dl_dir()
        if not dl_dir:
            return False
        cands = self._fresh_dir_videos(dl_dir, since_ts - 5)
        # 两轮：先只挑"文件名带本账号前缀"的（归属确定），都不行再考虑
        # video.mp4 这类无前缀的原始落盘文件（归属靠认领表 + 时间窗仲裁）。
        for prefer_owned in (True, False):
            for _mtime, pf in cands:
                owned = self._is_my_account_file(str(pf))
                if prefer_owned and not owned:
                    continue
                if not prefer_owned and owned:
                    continue
                # 硬匹配：别账号前缀 / 别任务的 dbm_ 副本，一律跳过
                if is_foreign_video_file(str(pf), tid, self.display_name()):
                    continue
                if not claim_download_file(str(pf), tid):
                    continue
                try:
                    self.sleep_cancel(tid, 2)
                    if not pf.exists() or pf.stat().st_size <= 50 * 1024:
                        release_download_file(str(pf))
                        continue
                except Exception:
                    release_download_file(str(pf))
                    continue
                # ★ 2026-10-25：MD5 水印指纹排除（带水印预览同体拒收）
                if self._is_watermarked_file(pf):
                    self.store.log(
                        tid, f"兜底候选文件 MD5 命中页面带水印指纹"
                             f"（带水印预览同体），拒收: {pf.name}")
                    release_download_file(str(pf))
                    continue
                safe_dest = self._dest_video_path(dl_dir, when=_mtime)
                claim_download_file(str(safe_dest), tid)
                try:
                    shutil.copy2(str(pf), str(safe_dest))
                    actual = str(safe_dest)
                except Exception as e:
                    self.store.log(tid, f"兜底复制失败，直接使用原文件: {pf}: {e}")
                    actual = str(pf)
                # 原始落盘文件（video.mp4）是【共享落点】：豆包每次下载都覆盖它。
                # 复制完必须立刻释放认领，否则下一个账号 30 分钟内根本认领不到，
                # 后面的任务会集体"拿不到片子"。
                if not self._is_my_account_file(str(pf)):
                    release_download_file(str(pf))
                try:
                    pre = getattr(self, "_dl_pre_files", None)
                    if pre is None:
                        pre = self._dl_pre_files = set()
                    pre.add(str(pf))
                    pre.add(actual)
                except Exception:
                    pass
                self.store.log(
                    tid, f"{reason}：下载目录兜底认领 {pf.name} -> {actual}"
                         f"（落盘 {time.strftime('%H:%M:%S', time.localtime(_mtime))}"
                         f"{'' if owned else '，无归属前缀，请人工核对'}）")
                mark_video_delivered(actual, tid)
                mark_video_delivered(str(pf), tid)
                self._finish_done(
                    tid, actual,
                    "生成完成（页面未检出视频，由下载目录兜底认领）")
                return True
        return False

    def _log_dir_hint(self, tid, since_ts):
        """任务失败前把下载目录里"疑似本次成品"的文件列出来，方便人工兜底回传。"""
        try:
            dl_dir = self._account_dl_dir()
            cands = self._fresh_dir_videos(dl_dir, since_ts - 5)[:5]
            if not cands:
                return
            lines = []
            for m, p in cands:
                try:
                    kb = int(p.stat().st_size / 1024)
                except OSError:
                    kb = 0
                lines.append(f"{p.name}（{kb}KB @"
                             f"{time.strftime('%H:%M:%S', time.localtime(m))}）")
            self.store.log(
                tid, "下载目录里发现疑似本次成品的文件，可手动拖回字字动画分镜: "
                     + "；".join(lines))
        except Exception:
            pass

    def _preview_url_set(self):
        """页面正在播放的**带水印预览流**地址集合。

        来源：页面 <video>（含 shadow DOM / iframe / <source>）的 src，以及
        pageVideos()。这些一定是带水印预览——豆包只对"无水印下载"给出去水印版本，
        页面里播放的那一版永远带水印。

        每次调用会顺手把当前页面视频 src 并入 bridge 上的持久集合，这样即使某一轮
        页面 DOM 变化导致 <video> 被移除（例如进入下一轮对话），之前见过的预览地址
        也不会被重新当成下载候选。
        """
        try:
            cur = self._eval_safe(
                "window.__dbm && window.__dbm.deepVideos "
                "? window.__dbm.deepVideos().map(function(v){return v.src;}) : []",
                timeout=10) or []
        except Exception:
            cur = []
        try:
            pv = self._eval_safe("window.__dbm.pageVideos()", timeout=10) or []
        except Exception:
            pv = []
        store = getattr(self.bridge, "_preview_urls", None)
        if store is None:
            store = set()
            try:
                self.bridge._preview_urls = store
            except Exception:
                pass
        for u in list(cur) + list(pv):
            if isinstance(u, str) and u.startswith("http"):
                store.add(u)
        return store

    def _watermark_fingerprints(self, force=False):
        """页面 fiber 里的**带水印指纹**（2026-10-25）。

        返回 {"hashes": set(带水印文件MD5), "urls": [带水印下载地址]}。
        来源：最后成片卡片 fiber 的 creations[].video.download_filehash /
        video_model.video_list[].file_hash（实测与带水印落盘文件 MD5 完全一致）、
        download_url 等。管理器 resolver 的 u() 兜底会把这些带水印地址误当
        "确认无水印"发出下载——落盘文件 MD5 命中 hashes 即拒收。
        fiber 暂不可得时返回空集合（放行，维持既有行为）。
        """
        now = time.time()
        cache = getattr(self, "_wm_fp_cache", None)
        if not force and cache and now - cache[0] < 10:
            return cache[1]
        fp = {"hashes": set(), "urls": []}
        try:
            r = self._eval_safe(
                "window.__dbm && window.__dbm.watermarkFingerprints "
                "? window.__dbm.watermarkFingerprints() : null",
                timeout=15) or {}
            if isinstance(r, dict):
                fp["hashes"] = set(
                    str(h).lower() for h in (r.get("hashes") or []) if h)
                fp["urls"] = [str(u) for u in (r.get("urls") or []) if u]
        except Exception:
            pass
        self._wm_fp_cache = (now, fp)
        return fp

    def _is_watermarked_file(self, path):
        """落盘文件 MD5 命中页面带水印指纹（带水印预览同体）时返回 True（拒收）。

        认领前调用（force 刷新指纹，认领是低频事件）。指纹为空时放行，
        避免 fiber 暂不可得误杀真无水印成品。
        """
        try:
            fp = self._watermark_fingerprints(force=True)
        except Exception:
            return False
        hashes = fp.get("hashes") or set()
        if not hashes:
            return False
        try:
            return _file_md5(path) in hashes
        except Exception:
            return False

    def _cap_is_video(self, url):
        """hook 截获的 URL 噪声很大（fetch/xhr 包含埋点、鉴权等所有请求），
        采用前必须用 _probe_video 确认是可读视频；失败的 URL 缓存，避免每轮重复探测。

        ★ 另外排除带水印预览流（2026-09-19 根因）：页面 <video> 的 src 也是一条
        mp4 响应，能通过 _probe_video，但它带水印，绝不能当无水印成品下载回传。
        """
        if not url:
            return False
        # URL 级图片过滤：hook 常截获缩略图/海报/封面的图片请求（.jpg~tp 等），
        # 直接拒绝，不浪费探测也不给 _probe_video 误判机会
        if _IMG_URL_RE.search(url):
            return False
        try:
            if is_preview_video_url(url, self._preview_url_set()):
                return False
        except Exception:
            pass
        # ★ 2026-10-25：fiber 带水印指纹 URL（download_url 等，resolver u() 兜底
        #   会把它误当确认无水印发出）同样拒绝，复用预览流同款匹配规则。
        try:
            _wmu = (self._watermark_fingerprints() or {}).get("urls") or []
            if _wmu and is_preview_video_url(url, set(_wmu)):
                return False
        except Exception:
            pass
        bad = getattr(self, "_bad_cap_urls", None)
        if bad is None:
            bad = self._bad_cap_urls = set()
        if url in bad:
            return False
        # ★ 2026-11-03：官方无水印下载直链常与账号鉴权绑定，探测必须带当前账号
        #   Cookie，否则 403/HTML 会被误判成"不是视频"并永久拉黑该直链。
        try:
            _cap_cookies = self.bridge.get_cookies_header()
        except Exception:
            _cap_cookies = None
        try:
            ok = bool(self._probe_video(url, cookies=_cap_cookies))
        except Exception:
            ok = False
        if not ok:
            bad.add(url)
        return ok

    def _download_started(self, tid, action_ts, baseline_videos):
        """检查自 action_ts 起下载是否已经被触发（不等待，只查一次）。

        baseline_videos: 点击前的页面视频URL基线（预快照），用于 JS capsSince 过滤。
        注意：不使用"当前 pageVideos"做过滤，因为无水印下载URL可能与预览URL相同或
        相似，用当前值会误过滤。应传入点击前的快照。

        返回 None=未启动；否则 dict：
          {"kind":"url", "url":...}     截获/嗅探到无水印 http 地址
          {"kind":"local", "path":...}  下载目录出现成品文件
          {"kind":"browser"}           浏览器下载事件已开始/完成
        """
        # 0. 页面 JS hook 截获（a.click / window.open / fetch / xhr）
        baseline_js = list(baseline_videos or [])
        caps = self._eval_safe(
            f"window.__dbm.capsSince({int(action_ts * 1000)}, {json.dumps(baseline_js, ensure_ascii=False)})", timeout=10) or []
        _prev0 = self._preview_url_set()
        for c in caps:
            u = (c or {}).get("url", "")
            if not u:
                continue
            # 同样排除带水印预览流：hook 也可能截到页面自己拉预览的请求
            if is_preview_video_url(u, _prev0):
                self.store.log(tid, f"JS hook 截获的是预览流，忽略: {u[:70]}")
                continue
            if self._cap_is_video(u):
                self.store.log(tid, f"JS hook 截获下载地址(via={c.get('via')}): {u[:90]}")
                return {"kind": "url", "url": u}
        # 1. CDP 网络嗅探
        try:
            self.bridge.drain_network_events()
        except Exception:
            pass
        # ★★ 必须排除"页面 <video> 正在播放的预览流"。
        #    2026-09-19 根因：hover 视频 → 豆包开始加载/播放预览 → 网络层立刻出现
        #    一条 mp4 响应 → 旧代码把它当成"无水印下载地址"返回，于是下载并回传了
        #    **带水印**的预览流。实测最近 12 个任务 12/12 都是这个地址。
        #    判据：页面 <video> 的 src 永远是带水印预览，绝不能当无水印成品。
        _preview = self._preview_url_set()
        try:
            _wm_u0 = set((self._watermark_fingerprints() or {}).get("urls") or [])
        except Exception:
            _wm_u0 = set()
        _skipped = []
        for u, ts in getattr(self.bridge, "_mp4_candidates", []):
            if ts < action_ts - 1 or not u.startswith("http"):
                continue
            if is_preview_video_url(u, _preview):
                _skipped.append(u)
                continue
            # ★ 2026-10-25：fiber 带水印指纹 URL（download_url 等）同样不是无水印
            if _wm_u0 and is_preview_video_url(u, _wm_u0):
                _skipped.append(u)
                continue
            self.store.log(tid, f"网络嗅探到下载地址（已排除预览流）: {u[:90]}")
            return {"kind": "url", "url": u}
        if _skipped:
            self.store.log(
                tid, f"忽略 {len(_skipped)} 条带水印预览流地址（不是无水印下载）: "
                     f"{_skipped[0][:70]}")
        # 2. 浏览器下载事件
        for info in (getattr(self.bridge, "_downloads", {}) or {}).values():
            if float(info.get("ts", 0) or 0) >= action_ts - 1 and \
                    info.get("state") in ("inProgress", "completed"):
                return {"kind": "browser", "state": info.get("state"),
                        "name": info.get("name", "")}
        # 3. 下载目录新成品文件（mtime 在动作之后，>50KB，大小稳定）
        dl_dir = self._account_dl_dir()
        try:
            for f in self._scan_video_files(dl_dir):
                pf = Path(f)
                if not pf.exists():
                    continue
                st = pf.stat()
                if st.st_mtime >= action_ts - 2 and st.st_size > 50 * 1024:
                    time.sleep(0.6)
                    if pf.exists() and pf.stat().st_size == st.st_size:
                        # ★ 内容签名校验（2026-10-20）：管理器偶发把封面图存成
                        #   .mp4 名（今日实测 2.4MB PNG 被当无水印成品回传）。
                        #   认领前先验文件头，不是 mp4 一律不认领，交还后续流程。
                        if not _head_is_mp4(pf):
                            self.store.log(
                                tid, f"跳过非 mp4 内容的落盘文件（文件头不是 ftyp）: "
                                     f"{pf.name}")
                            continue
                        # ★ 2026-10-25：MD5 命中 fiber 带水印指纹（带水印预览同体）
                        #   不作无水印成品——resolver u() 兜底误发的文件走这里拦截。
                        if self._is_watermarked_file(pf):
                            self.store.log(
                                tid, f"落盘文件 MD5 命中页面带水印指纹"
                                     f"（带水印预览同体），不作无水印成品: {pf.name}")
                            continue
                        # 多账号共用下载目录：必须认领成功才认作本任务的成品，
                        # 否则会把别的账号刚下载的视频当成自己的拿走
                        if claim_download_file(str(pf), tid):
                            return {"kind": "local", "path": str(pf)}
                        self.store.log(tid, f"跳过已被其他任务认领的下载文件: {pf.name}")
        except Exception:
            pass
        return None

    def _fg_click_no_watermark(self, tid, baseline_videos=None):
        """前台完整"悬停下载"流程（根治：人工把鼠标放到按钮上就能下载，说明该入口
        主要由 hover 触发，而非 click；且 CDP 坐标在系统缩放时可能与 CSS 像素错位）。

        流程（全程持前台锁、真实分步鼠标轨迹）：
          1. 激活 tab → hover 视频中心 → 右下角，唤出悬浮工具条
          2. 定位「无水印下载」按钮（短暂重试，等悬浮层挂载）
          3. probeAt 命中闭环 + devicePixelRatio 坐标校准（必须确认鼠标真落在按钮上）
          4. 真人轨迹移入按钮 → 悬停 + 微抖动（hover 触发型下载此时就应启动）
          5. 检测下载是否已启动（JS hook / 网络 / 浏览器下载事件 / 落盘文件）
          6. 未启动再真实 click；仍不行则"移出→移入"强制重发 mouseenter 后再点

        baseline_videos: 调用方传入的点击前页面视频URL基线（来自 pageVideos() 快照），
                         用于 _download_started 的 capsSince 过滤。若未传则自行捕获。
        返回:
          {ok:True, url:"..."}      拿到无水印 URL
          {ok:True, started:True}   浏览器侧下载已启动（等待落盘/事件收敛）
          {ok:False, reason, diag}  失败，diag 含命中诊断（用于定位页面结构变化）

        ★ confirmed 字段（2026-09-19 水印修复补）：
          True  = 确实定位到并悬停/点击了「无水印下载」按钮，产物可信
          False = **没找到按钮**，只是碰巧发现下载目录多了个文件。
                  那种文件可能是用户手动点的"下载"（带水印）、或别账号留下的，
                  调用方不能拿它当无水印成品交付。
        """
        self._fg_acquire(tid, reason="无水印下载")
        diag = {}
        try:
            self._eval_safe(build_inject_js_cached(self.selectors), timeout=15)
            self._keep_active()
            self.sleep_cancel(tid, 0.8, step=0.4)

            # ---- 0. 成片卡片是懒加载的：页面里没有 <video> 时先滚动到底 + hover 唤醒 ----
            # 实测线上：文案写着"你的视频生成好了"，但 deepVideo=0、perf 里一条 mp4
            # 都没有 —— 因为对话里只有封面 <img>，不滚动不 hover 就永远不建 <video>。
            # 不唤醒的话后面"hover 视频 / 找无水印按钮"两步都无从谈起，必然超时。
            try:
                _has_v = int(self._eval_safe(
                    "window.__dbm && window.__dbm.deepVideos "
                    "? window.__dbm.deepVideos().length : 0") or 0)
            except Exception:
                _has_v = 0
            if _has_v <= 0:
                self._reveal_video(tid)

            # ---- 1. hover 视频唤出悬浮工具条（分步真实轨迹）----
            # ★ 2026-10-23：新版卡片没有 <video> 时 lastVideoRect() 恒为 null，
            #   旧逻辑因此一次鼠标事件都不发；改用 hoverRect（video 优先，退回卡片矩形）。
            vr = self._eval_safe(
                "window.__dbm.hoverRect ? window.__dbm.hoverRect() : "
                "window.__dbm.lastVideoRect()", timeout=15)
            cur = (0, 0)
            if isinstance(vr, dict) and vr.get("w"):
                cx, cy = int(vr.get("cx", 0)), int(vr.get("cy", 0))
                rx, by_ = int(vr.get("rx", 0)), int(vr.get("by", 0))
                if cx > 0 and cy > 0:
                    self.bridge.mouse_move_path(cx - 60, cy - 40, cx, cy, steps=6)
                    self.sleep_cancel(tid, 0.4, step=0.2)
                    cur = (cx, cy)
                if rx > 0 and by_ > 0:
                    self.bridge.mouse_move_path(cur[0], cur[1], rx, by_, steps=8)
                    self.sleep_cancel(tid, 0.8, step=0.3)
                    cur = (rx, by_)
            else:
                self.sleep_cancel(tid, 0.5, step=0.2)

            action_ts = time.time()
            # 使用调用方传入的基线（点击前快照），避免当前页面已有视频URL导致误过滤
            baseline_videos = baseline_videos or (self._eval_safe("window.__dbm.pageVideos()") or [])

            # ---- 2. 定位按钮（悬浮层挂载可能滞后，重试 5 次）----
            fb = None
            for _ in range(5):
                fb = self._eval_safe(
                    "window.__dbm.findNoWatermarkButton()", timeout=15) or {}
                if fb.get("found"):
                    break
                self.sleep_cancel(tid, 0.8, step=0.3)
            if not fb.get("found"):
                # ★ 2026-10-23：注入的「无水印下载」按钮要求页面里存在 <video>。
                #   新版卡片 hover 不会挂 <video>，这里点一次卡片里的小播放图标
                #   （inline 播放器，不会打开「创建画布」面板），再把鼠标移回卡片，
                #   给注入逻辑一点时间后重新找按钮。
                pj = self._eval_safe(
                    "window.__dbm.clickPlayIcon ? window.__dbm.clickPlayIcon() : null",
                    timeout=10) or {}
                if pj.get("ok"):
                    self.store.log(
                        tid, f"{self.display_name()} 未找到无水印按钮，点播放图标"
                             f"@({pj.get('x')},{pj.get('y')}) 唤醒 <video>…")
                    self.sleep_cancel(tid, 1.4, step=0.4)
                    vr2 = self._eval_safe(
                        "window.__dbm.hoverRect ? window.__dbm.hoverRect() : null",
                        timeout=12)
                    if isinstance(vr2, dict) and vr2.get("w"):
                        vr = vr2
                        _c2x, _c2y = int(vr2.get("cx", 0)), int(vr2.get("cy", 0))
                        _r2x, _b2y = int(vr2.get("rx", 0)), int(vr2.get("by", 0))
                        self.bridge.mouse_move_path(cur[0], cur[1], _c2x, _c2y, steps=8)
                        self.sleep_cancel(tid, 0.4, step=0.2)
                        self.bridge.mouse_move_path(_c2x, _c2y, _r2x, _b2y, steps=8)
                        cur = (_r2x, _b2y)
                        self.sleep_cancel(tid, 0.6, step=0.2)
                    for _ in range(5):
                        fb = self._eval_safe(
                            "window.__dbm.findNoWatermarkButton()", timeout=15) or {}
                        if fb.get("found"):
                            break
                        self.sleep_cancel(tid, 0.8, step=0.3)
            diag = {"find": fb, "dpr": fb.get("dpr"), "videoRect": fb.get("videoRect")}
            if not fb.get("found"):
                # 极端情况：找不到按钮，但 hover 视频本身可能已触发下载。
                # ⚠️ 这里必须标 confirmed=False：没点到「无水印下载」按钮，
                #    落盘的文件可能是用户手动点的"下载"（带水印）或别账号留下的，
                #    不能当无水印成品交付（2026-09-19 水印修复）。
                st = self._download_started(tid, action_ts, baseline_videos)
                if st:
                    return {"ok": True, "started": True, "how": st["kind"],
                            "confirmed": False,
                            **({"url": st["url"]} if st["kind"] == "url" else {}),
                            **({"file_path": st["path"]} if st["kind"] == "local" else {})}
                diag["reason_extra"] = "button_not_found_after_hover"
                return {"ok": False, "reason": "button_not_found", "diag": diag}

            bx, by = int(fb["x"]), int(fb["y"])
            dpr = float(fb.get("dpr") or 1)
            rect = fb.get("videoRect")  # 仅备用
            diag["button"] = {"x": bx, "y": by, "score": fb.get("score"),
                              "text": fb.get("text"), "by": fb.get("by")}

            # ---- 2.5 DOM 级点击优先（2026-11-02）：直接对按钮元素派发事件，
            #   彻底摆脱窗口可见性 + DPI 缩放依赖；未触发下载再回退坐标流程。
            dom_r = self._eval_safe(
                "window.__dbm.clickNoWatermarkButton ? "
                "window.__dbm.clickNoWatermarkButton() : {ok:false,reason:'no_fn'}",
                timeout=10) or {}
            if dom_r.get("ok"):
                self.sleep_cancel(tid, 2.0, step=0.4)
                st = self._download_started(tid, action_ts, baseline_videos)
                if st:
                    self.store.log(tid, f"DOM 点击触发下载（跳过坐标校准）: {st.get('kind')}")
                    return ({"ok": True, "url": st["url"], "source": "dom_click"}
                            if st["kind"] == "url"
                            else {"ok": True, "started": True, "how": st["kind"],
                                  **({"file_path": st["path"]} if st.get("path") else {})})
                # ★ 2026-11-03 根因修复：DOM 点击已被管理器受理时，绝不能再回退
                #   坐标流程对同一按钮反复 hover/click。实测那一整套流程一轮要 60s+，
                #   会把管理器正在进行的 get_download_info 解析反复打断/重启，按钮
                #   随之卡在「解析中… → 下载失败」死循环（5 并发只有 1 个成功）。
                #   正确做法：立即返回「已触发、等待落盘」，由上层守候 + 扫盘接管。
                _dom_txt = str(dom_r.get("text") or "")
                _accepted = bool(_dom_txt) and ("无水印下载" not in _dom_txt)
                if not _accepted:
                    try:
                        _bs0 = self._eval_safe(
                            "window.__dbm.noWatermarkBtnState ? "
                            "window.__dbm.noWatermarkBtnState() : null", timeout=8) or {}
                        _live = str((_bs0 or {}).get("text") or "")
                        if _live and "无水印下载" not in _live:
                            _accepted = True
                            _dom_txt = _live
                    except Exception:
                        pass
                if _accepted:
                    self.store.log(
                        tid, f"DOM 点击已被管理器受理（按钮「{_dom_txt}」），"
                             f"不再回退坐标流程重复点击，转为等待解析/落盘…")
                    return {"ok": True, "started": True, "clicked": True,
                            "confirmed": True, "how": "dom_click_pending"}
                self.store.log(
                    tid, f"DOM 点击未立即触发下载，回退坐标流程: "
                         f"{json.dumps(dom_r, ensure_ascii=False)[:120]}")

            # ---- 3. 坐标命中校准（应对系统显示缩放导致 CDP 坐标错位）----
            def probe(px, py):
                return self._eval_safe(
                    f"window.__dbm.probeAt({int(px)},{int(py)})", timeout=10) or {}

            candidates = [(bx, by, "css")]
            if abs(dpr - 1) > 0.01:
                candidates += [(round(bx * dpr), round(by * dpr), "css*dpr"),
                               (round(bx / dpr), round(by / dpr), "css/dpr")]
            candidates += [(bx - 4, by, "left"), (bx + 4, by, "right"),
                           (bx, by - 4, "up"), (bx, by + 4, "down")]
            tx = ty = None
            hit_probe = {}
            for px, py, tag in candidates:
                p = probe(px, py)
                if p.get("hit"):
                    tx, ty, hit_probe = px, py, p
                    diag["coord"] = tag
                    break
            if tx is None:
                # 所有候选都不命中：仍用原坐标试一次，但记录完整现场供诊断
                tx, ty = bx, by
                p0 = probe(bx, by)
                diag["miss_probe"] = p0
                self.store.log(tid,
                    f"无水印按钮坐标未通过命中校验 dpr={dpr} "
                    f"probe={json.dumps(p0, ensure_ascii=False)[:220]}")

            # ---- 4. 真人轨迹移入按钮 → 悬停 + 微抖动（hover 即下载的关键）----
            self.bridge.mouse_move_path(cur[0], cur[1], tx, ty, steps=10)
            self.sleep_cancel(tid, 0.7, step=0.3)
            for ddx, ddy in ((2, 0), (-2, 1), (1, -2), (-1, -1), (0, 0)):
                self.bridge.mouse_move(tx + ddx, ty + ddy)
                self.sleep_cancel(tid, 0.12, step=0.06)
            hp = probe(tx, ty)
            diag["hover_probe"] = {"hit": hp.get("hit"), "hover": hp.get("hover"),
                                   "depth": hp.get("depth"), "tag": hp.get("tag"),
                                   "cls": hp.get("cls"), "text": hp.get("text")}
            self.store.log(tid,
                f"悬停无水印按钮@({tx},{ty}) 命中={hp.get('hit')} :hover={hp.get('hover')} "
                f"depth={hp.get('depth')} 元素={hp.get('tag')}.{str(hp.get('cls',''))[:40]}")

            # ---- 5. 悬停后先看下载是否已自行启动（该按钮很可能 hover 即触发）----
            st = self._download_started(tid, action_ts, baseline_videos)
            if st:
                self.store.log(tid, f"悬停即触发下载: {st.get('kind')}")
                return {"ok": True, "started": True, "how": st["kind"],
                        **({"url": st["url"]} if st["kind"] == "url" else {}),
                        **({"file_path": st["path"]} if st["kind"] == "local" else {})}
            self.sleep_cancel(tid, 1.2, step=0.4)
            st = self._download_started(tid, action_ts, baseline_videos)
            if st:
                return {"ok": True, "started": True, "how": st["kind"],
                        **({"url": st["url"]} if st["kind"] == "url" else {}),
                        **({"file_path": st["path"]} if st["kind"] == "local" else {})}

            # ---- 6. click 兜底 ----
            self.bridge.mouse_click(tx, ty)
            self.sleep_cancel(tid, 2.5, step=0.5)
            st = self._download_started(tid, action_ts, baseline_videos)
            if st:
                self.store.log(tid, f"点击触发下载: {st.get('kind')}")
                return ({"ok": True, "url": st["url"], "source": "click"}
                        if st["kind"] == "url"
                        else {"ok": True, "started": True, "how": st["kind"],
                              **({"file_path": st["path"]} if st.get("path") else {})})

            # ---- 7. 强制重发 mouseenter：移出视频区 → 再移回按钮 → 再点 ----
            if isinstance(vr, dict) and vr.get("x") is not None:
                out_x = max(5, int(vr.get("x", 10)) - 30)
                out_y = max(5, int(vr.get("y", 10)) - 30)
                self.bridge.mouse_move_path(tx, ty, out_x, out_y, steps=6)
                self.sleep_cancel(tid, 0.5, step=0.2)
                self.bridge.mouse_move_path(out_x, out_y, tx, ty, steps=10)
                self.sleep_cancel(tid, 0.8, step=0.3)
                hp2 = probe(tx, ty)
                diag["reenter_probe"] = {"hit": hp2.get("hit"), "hover": hp2.get("hover")}
                st = self._download_started(tid, action_ts, baseline_videos)
                if st:
                    return ({"ok": True, "url": st["url"], "source": "reenter"}
                            if st["kind"] == "url"
                            else {"ok": True, "started": True, "how": st["kind"],
                                  **({"file_path": st["path"]} if st.get("path") else {})})
                self.bridge.mouse_click(tx, ty)
                self.sleep_cancel(tid, 2.5, step=0.5)
                st = self._download_started(tid, action_ts, baseline_videos)
                if st:
                    return ({"ok": True, "url": st["url"], "source": "reenter_click"}
                            if st["kind"] == "url"
                            else {"ok": True, "started": True, "how": st["kind"],
                                  **({"file_path": st["path"]} if st.get("path") else {})})

            # ★ 2026-10-25：点击后读取按钮文案状态（解析中…/下载中…/解析失败），
            #   供上层日志与节奏判定（「解析失败」= 豆包暂未签发无水印）。
            try:
                diag["btn_state"] = self._eval_safe(
                    "window.__dbm.noWatermarkBtnState ? "
                    "window.__dbm.noWatermarkBtnState() : null", timeout=8)
            except Exception:
                pass
            # clicked=True：按钮确认命中且已真实点击（resolver 解析失败、或管理器
            # 带外下载对插件不可见时也会走到这里）——上层据此转入"已点击待落盘"
            # 监视，由扫盘分支接管（认领带 MD5 水印指纹排除，带水印拒收）。
            return {"ok": False, "reason": "hover_and_click_no_download",
                    "clicked": True, "diag": diag}
        finally:
            self._fg_release()

    def _wait_chat_ready(self, tid, want_video, timeout_sec=45,
                         require_video_entry=False):
        """轮询等待豆包页面就绪，替代固定 sleep（多账号并发时后台标签页加载慢）。

        want_video=True：等待已进入视频模式（出现模型/时长控件）。
        want_video=False：等待首页视频入口或编辑器出现即可。
        require_video_entry=True：必须等到**可见的**"视频生成"入口（或已进入视频
          模式）才算就绪。默认 False 时 hasComposer 就能通过——而首页本身就有输入框，
          等于没等；并发时各页面刚跳转完还在渲染，随后 ensureVideoMode 必然报
          no_video_entry。创建/跳转新对话后应当用 True。
        导航后 __dbm 可能丢失，循环内反复注入脚本。
        """
        deadline = time.time() + timeout_sec
        last_state = {}
        while time.time() < deadline:
            self.check_cancel(tid)
            self._keep_active()
            # 页面重载后上下文可能重建，反复注入脚本
            # ★ 并发优化：这里每 1.5s 一轮，绝不能再无条件灌 64KB 脚本
            #   （旧实现 7 并发时每秒约 300KB 压在渲染线程上，把页面挤成半加载）。
            #   _ensure_injected 已改为"先轻量探测、已注入则零开销"。
            self._ensure_injected(tid, retries=1)
            # 导航会清掉可见性覆盖，这里每轮补一次，保证豆包按"可见"状态渲染入口
            self._apply_force_visible()
            st = self._eval_safe("window.__dbm ? window.__dbm.chatReadyState() : null", timeout=15)
            if isinstance(st, dict):
                last_state = st
                if want_video and st.get("isVideo"):
                    return st
                if not want_video:
                    if require_video_entry:
                        # 入口必须是"可见的"（chatReadyState 已按 dbm.vis 过滤）
                        if st.get("isVideo") or st.get("hasVideoEntry"):
                            return st
                    elif (st.get("hasVideoEntry") or st.get("hasComposer")
                          or st.get("isVideo")):
                        return st
            self.sleep_cancel(tid, 1.5, step=0.7)
        return last_state

    def submit_stage(self, tid):
        """分发阶段：连接账号 → 新对话 → 填表 → 上传参考图 → 提交 → 发"确认生成视频"，
        确认豆包已在服务端开始生成后返回。

        parallel_submit=True（默认）时由编排器在**独立线程**里并发调用：不抢
        scheduler.input_lock、不切管理器 tab，各账号用自己的 CDP 连接并行填报。
        parallel_submit=False 时保持改造前的串行语义（持锁 + 真实切 tab）。

        成功返回后【不 detach】；CDP 会话保留到约 6 分钟后的 collect_stage 复用。
        """
        t = self.store.get(tid)
        timeout = int(self.config.get("task_timeout_sec", 1200))
        # 按时长兜底：30 秒视频豆包要 15~20 分钟，沿用旧的 1200s 会在成片出来前就判超时
        _need = min_timeout_for((t or {}).get("duration"))
        if timeout < _need:
            self.store.log(tid, f"{self.display_name()} 时长 {(t or {}).get('duration')}s 生成较久，"
                                f"总超时由 {timeout}s 自动放宽到 {_need}s")
            timeout = _need
        # 安全确认等待时间计入总超时
        confirm_wait = int(self.config.get("safety_confirm_wait_sec", 100)) \
            if self.config.get("auto_confirm_generation", True) else 0
        deadline = time.time() + timeout + confirm_wait + 60
        self.submitted = False
        self._stage_deadline = deadline
        self._fast_detect_hit = False      # 每个任务独立：是否已实时检测到视频
        self._fast_detect_miss = 0         # 检测到视频但下载未触发的连续次数
        self._submit_video_baseline = set()  # 每个任务独立：提交时的历史视频基线
        self._stale_video_warned = False
        self._submit_perf_baseline = None    # 提交时页面资源时间线基线（提交后固化）
        self._diag_bucket = -1               # 页面现场 dump 的节流桶
        self._audio_none_first_ts = 0.0      # 含音频协商 none 态首回计时（每任务清零）
        self._appeal_reset()                 # 每任务独立：版权申诉次数清零

        # 1. 连接调度器分配给本 worker 的账号 webview（管理器由调度器统一启动）
        self.set_status(tid, "connecting", 12, f"连接{self.display_name()}…")
        target = None
        while time.time() < deadline:
            self.check_cancel(tid)
            target = self._refresh_target()
            if target:
                break
            self.sleep_cancel(tid, 2)
        if not target:
            raise TargetGone(f"{self.display_name()}的豆包页面已关闭")
        self.store.log(tid, f"使用 {self.display_name()} | {target['url'][:70]}")
        self.bridge.attach(target, self._account_dl_dir())
        # attach 后立刻固定可见性：并行时管理器窗口若处于最小化/正在还原的过渡期，
        # 页面 hidden 会让豆包不渲染"视频生成"入口，填表必然卡死。
        self._apply_force_visible()
        # 上一轮本账号"输入框不可见"没救回来 → 先重置回首页（实测重置后 composer
        # 会重新正常渲染）。只能用 Page.navigate，不能用 Page.reload。
        if self._force_home_reset:
            self._force_home_reset = False
            try:
                self.bridge._ws.send("Page.enable", {}, timeout=8)
            except Exception:
                pass
            try:
                self.bridge._ws.send(
                    "Page.navigate", {"url": "https://www.doubao.com/chat/"}, timeout=20)
                self.store.log(tid, f"{self.display_name()}上一轮输入框未渲染，"
                                    f"本次先重置到豆包首页")
                time.sleep(6)
                self._ensure_injected(tid)
            except Exception as e:
                self.store.log(tid, f"{self.display_name()}重置首页失败（继续）: {e}")

        # L2 并行提交：不再抢全局 input_lock，也不切换管理器 tab（各账号独立 CDP
        # 连接，非活动 webview 与活动 webview 能力一致，详见 parallel_submit 注释）。
        # 关掉 parallel_submit 时 need_lock=True，行为与改造前完全一致。
        self.set_status(tid, "preparing_page", 15,
                        f"{self.display_name()} 准备视频创作页…")
        self._fg_acquire(tid, reason="分镜分发",
                         need_lock=not self.config.get("parallel_submit", True))

        # 2. 注入自动化脚本，创建新对话，确保进入视频创作模式
        self.set_status(tid, "preparing_page", 20, f"{self.display_name()} 准备视频创作页…")
        self._keep_active()
        self._eval_safe(build_inject_js_cached(self.selectors))
        # 2.0b 关键守卫：确认本账号 webview 真的排版/可见了再往下走。
        #      非活动 webview 里豆包不挂载编辑器，后面必然误报"需要标定"（多并发第二个
        #      账号报标定就是这个原因）；不可见就反复重新激活标签页。
        probe = self._wait_page_visible(tid, timeout=45)
        self.store.log(tid, f"{self.display_name()}页面探针: "
                            f"{json.dumps(probe, ensure_ascii=False)[:260]}")
        # 2.0c 页面健康度守卫：先确认这个账号的豆包页面不是"半加载卡死"状态。
        #      卡死的页面只剩侧边栏 3~4 个按钮、没有 composer 和"视频生成"入口，
        #      后面必然一路报 video_mode_not_active 空耗到超时。这里拦下来重新导航。
        self._ensure_page_healthy(tid)
        # 2.0 创建新对话（避免多个任务共用同一对话导致上下文混乱）
        #      多账号并发时后台标签页加载慢，全程用"就绪轮询"代替固定 sleep。
        try:
            ncr = self._eval_safe("window.__dbm.startNewConversation()") or {}
            if ncr.get("ok"):
                self.store.log(tid, f"已创建新对话（{ncr.get('method')}）: {ncr.get('text', '')}")
                st = self._wait_chat_ready(tid, want_video=False, timeout_sec=40,
                                           require_video_entry=True)
                self.store.log(tid, f"新对话页已就绪（isVideo={st.get('isVideo')}, "
                                    f"入口={st.get('hasVideoEntry')}, 编辑器={st.get('hasComposer')}）")
            elif ncr.get("suggest_navigate"):
                # 兜底：通过 URL 跳转创建新对话
                # ⚠️ 2026-09-19 实测定位的头号坑：给 location.href 赋**当前同样的 URL**
                # 会触发整页重新加载（实测 window 上的标记被清空、DOM 从 1315 节点
                # 掉回 748 再重建）。并发 4 个账号同时整页重载，豆包有概率少加载
                # 一个 JS chunk → 主内容区不渲染（只剩侧边栏 3~4 个按钮）→ 随后必然
                # 一路 no_video_entry。而绝大多数账号本来就已经停在首页，这次跳转
                # 纯属无谓的整页刷新。故：已在首页就直接跳过。
                cur = str(self._eval_safe("location.href") or "")
                if cur.rstrip("/") == "https://www.doubao.com/chat":
                    self.store.log(tid, "已在豆包首页，跳过整页跳转"
                                        "（避免并发时整页重载把页面刷成半加载）")
                    st = self._wait_chat_ready(tid, want_video=False, timeout_sec=30,
                                               require_video_entry=True)
                    self.store.log(tid, f"首页就绪（isVideo={st.get('isVideo')}, "
                                        f"入口={st.get('hasVideoEntry')}, "
                                        f"编辑器={st.get('hasComposer')}）")
                else:
                    self.store.log(tid, "未找到新对话按钮，通过 URL 跳转创建新对话")
                    self._eval_safe("window.location.href = 'https://www.doubao.com/chat/';")
                    st = self._wait_chat_ready(tid, want_video=False, timeout_sec=50,
                                               require_video_entry=True)
                    self.store.log(tid, f"跳转后页面已就绪（isVideo={st.get('isVideo')}, "
                                        f"入口={st.get('hasVideoEntry')}, "
                                        f"编辑器={st.get('hasComposer')}）")
            else:
                self.store.log(tid, f"创建新对话未成功（{ncr.get('reason')}），继续在当前对话操作")
                self._wait_chat_ready(tid, want_video=False, timeout_sec=20)
        except Exception as e:
            self.store.log(tid, f"创建新对话时异常（继续操作）: {e}")
        self._keep_active()
        # best-effort 探测账号昵称，便于控制台展示和账号关键字路由
        if not self.nickname:
            nick = self._eval_safe(
                "(window.__dbm && window.__dbm.guessNick) ? window.__dbm.guessNick() : null")
            if isinstance(nick, str) and nick.strip():
                self.nickname = valid_nickname(nick)
                # 昵称补查持久化额度标记：页面重开后 target_id 已变，
                # worker 重建时匹配不到旧标记，这里按 nickname 兜底恢复
                if self.quota_ok:
                    mark = self.scheduler.find_quota_mark(self.target_id, self.nickname)
                    if not mark:
                        mark = self.scheduler._find_quota_mark_by_nickname(self.nickname)
                    if mark:
                        self._apply_quota_mark(mark)
                        self.store.log(tid, f"{self.display_name()}按昵称恢复额度不足标记"
                                            f"（{mark.get('recover_at_str', '')}前不可派单）")

        # 2.1c 第二次健康度守卫（真正关键的一次）。
        #      第一次守卫在"创建/跳转新对话"之前，而**整页跳转才是把页面刷成半加载的
        #      那一步**（见 suggest_navigate 分支的注释）。跳转之后必须再查一次，
        #      否则健康检查形同虚设——4 并发实测就是这样放过 3 个坏页面的。
        if self._ensure_page_healthy(tid):
            self._wait_chat_ready(tid, want_video=False, timeout_sec=30,
                                  require_video_entry=True)

        # ★★ 点「视频生成」之前必须先确保所有 webview 都在渲染。
        #    非 active 的 webview rAF 恒为 0fps（宿主 visibility:hidden），
        #    React 挂载不了视频模式 UI —— 点了也只会把主内容区卸载掉。
        #    实测：不开启时 7 个账号只有 1~2 个能进视频模式；开启后 7/7 成功。
        self._ensure_all_webviews_render(tid)

        # 2.1d 别停在首页：首页点「视频生成」会把页面刷成半加载，会话页才点得动。
        #      详见 _ensure_in_conversation 的注释（2026-09-19 真机对照实测）。
        if self.config.get("prefer_conversation_page", True):
            try:
                self._ensure_in_conversation(tid)
            except Exception as e:
                self.store.log(tid, f"{self.display_name()}进入会话页时异常"
                                    f"（按原流程继续）: {e}")

        # 2.2 视频模式检测/进入：【已按需求彻底移除】
        # 用户明确要求插件不进入视频模式、也不检测视频模式控件（不读 isVideo、
        # 不点"视频生成"、不判断模型/时长控件）。插件直接进入"填提示词 + 上传附件 + 发送"
        # 流程，由用户自行确保当前对话框（普通对话或视频生成对话）处于期望状态。
        video_ok = False
        info = {}

        # 取一次完整页面信息（含模型/时长按钮文本）；先确保注入成功，避免 __dbm 缺失误报标定
        self._ensure_injected(tid)
        info = self._eval_safe("window.__dbm.pageInfo()") or {}
        # 用 raw（未做可见性过滤）计数区分两种情况：
        #   raw=0 → 页面根本没渲染出输入框（未激活/未加载/白屏），应重试激活而不是报标定
        #   raw>0 但可见=0 → 元素被隐藏，也先重试；只有两者都为 0 才算真需要标定
        has_input = bool(info.get("textareas") or info.get("editables"))
        has_raw = bool(info.get("textareas_raw") or info.get("editables_raw"))
        if not has_input:
            self.store.log(
                tid, f"{self.display_name()}未找到可见输入框（可见="
                     f"{info.get('textareas')}/{info.get('editables')}，原始="
                     f"{info.get('textareas_raw')}/{info.get('editables_raw')}，zero="
                     f"{info.get('zero_layout')}），重新激活标签页并等待渲染")
            if self._ensure_injected(tid):
                info = self._eval_safe("window.__dbm.pageInfo()") or {}
            if not (info.get("textareas") or info.get("editables")):
                self._wait_page_visible(tid, timeout=40)
                self._ensure_injected(tid)
                info = self._eval_safe("window.__dbm.pageInfo()") or {}
            has_input = bool(info.get("textareas") or info.get("editables"))
            has_raw = bool(info.get("textareas_raw") or info.get("editables_raw"))
        if not has_input and not has_raw:
            self.store.update(tid, status="needs_calibration", percent=0,
                              message="页面上没找到提示词输入框，需要标定选择器（见 /api/debug/pageinfo）",
                              error="selector_miss:prompt_input")
            return
        if not has_input:
            self.store.log(tid, f"{self.display_name()}输入框存在于 DOM 但不满足可见性"
                                f"（原始={info.get('textareas_raw')}/{info.get('editables_raw')}），"
                                f"先尝试唤醒输入区，无效则判定页面未渲染并重新导航")
            # 1) 先把管理器窗口救回前台（窗口最小化时豆包不渲染 composer）
            self._ensure_window_visible(tid)
            # 2) 唤醒输入区：优先直接聚焦已经可见的输入框；全都不可见时才剥掉
            #    祖先链上的 visibility:hidden / pointer-events:none
            try:
                rev = self._eval_safe("window.__dbm.revealEditor ? "
                                      "window.__dbm.revealEditor() : null", timeout=15)
                self.store.log(tid, f"唤醒输入区结果: {json.dumps(rev, ensure_ascii=False)[:200]}")
            except Exception as e:
                self.store.log(tid, f"唤醒输入区异常: {e}")
            self.sleep_cancel(tid, 3, step=1)
            self._ensure_injected(tid)
            info = self._eval_safe("window.__dbm.pageInfo()") or {}
            has_input = bool(info.get("textareas") or info.get("editables"))
            if not has_input:
                # 3) 唤醒也没用 ⇒ 基本可以确定是页面主内容区没渲染。
                #    真机实测：坏页面 textarea=0，唯一的 contenteditable 是
                #    .pointer-events-none.invisible 浮层里的隐藏副本，点任何祖先
                #    都唤不回来。这时候再"激活标签页 / 点祖先容器"纯属空转，
                #    直接重新导航修页面才是正解。
                self.store.log(tid, f"{self.display_name()}唤醒无效，判定页面主内容区未渲染，"
                                    f"强制重新体检并修复")
                try:
                    self._ensure_page_healthy(tid)
                except PageDegraded:
                    self._force_home_reset = True
                    raise
                self._ensure_injected(tid)
                info = self._eval_safe("window.__dbm.pageInfo()") or {}
                has_input = bool(info.get("textareas") or info.get("editables"))
            if not has_input:
                # 4) 仍然不行：别再报"需要标定"（选择器没坏，是页面状态不对），
                #    标记下轮重置首页后把任务重新排队换账号/重来。
                self._force_home_reset = True
                raise EditorNotVisible(
                    f"{self.display_name()}提示词输入框不可见"
                    f"（可见={info.get('textareas')}/{info.get('editables')}, "
                    f"原始={info.get('textareas_raw')}/{info.get('editables_raw')}）")
        # 【已按需求移除视频模式检测】不再因“未进入视频模式/未检测到视频控件”而报标定或告警，
        # 直接进入填提示词与上传附件流程。video_ok 保留为 False 仅为兼容下游变量存在性。
        self.store.log(tid, "已跳过视频模式检测，直接填写提示词与上传附件")

        # 2.5 账号忙等：页面里已有生成中的任务（手动提交/重启前残留）时先等它完成
        busy = self.bridge.evaluate("window.__dbm.isPageBusy()") or {}
        if busy.get("busy"):
            self.page_busy = True
            self.set_status(tid, "preparing_page", 16,
                            f"{self.display_name()}正在生成上一个任务，排队等待空闲…")
            self.store.log(tid, f"账号忙（{busy.get('reason')} {busy.get('text') or busy.get('cls') or ''}），等待空闲")
            wait_deadline = time.time() + min(900, timeout - 60)
            while time.time() < wait_deadline:
                self.check_cancel(tid)
                self.sleep_cancel(tid, 5)
                busy = self.bridge.evaluate("window.__dbm.isPageBusy()") or {}
                if not busy.get("busy"):
                    break
            else:
                raise RuntimeError(f"{self.display_name()}长时间忙（上一个任务未完成），任务改派")
            self.page_busy = False
            self.store.log(tid, f"{self.display_name()}已空闲，开始填写任务")

        # 2.6 选择模型：【已按需求移除】
        # 用户明确要求插件不再点击/选择模型，直接用豆包页面当前的模型提交
        # （页面默认模型即为 Seedance 2.0 Fast，无需插件再去点开模型下拉）。
        # 因此不再调用 window.__dbm.ensureModel(...)，self.model_name 保持为空，
        # 下方确认文本也不会再做模型名归一化。
        # 提交前预检：只信"今日视频生成免费次数用完"这类明确强信号（quotaExhausted）。
        # 此时 submitted=False，命中后改派其他账号是安全的（提示词尚未发送，无副作用）。
        # 不使用宽松的 quotaNotice（正则含"升级会员/开通会员"，豆包界面常驻会员推广按钮，
        # 会把健康账号误判为额度尽并冻结到次日）；弱信号仅记录、不中断任务。
        qe = self._eval_safe("window.__dbm.quotaExhausted()") or ""
        if qe:
            self.store.log(tid, f"{self.display_name()}提交前检测到额度已尽（未发送提示词）: {qe}")
            raise QuotaExceeded(f"{self.display_name()}：{qe}")
        qn = self._eval_safe("window.__dbm.quotaNotice()")
        if qn:
            self.store.log(tid, f"{self.display_name()}提交前页面出现弱额度提示（忽略，不中断）: {qn}")

        # 4. 填提示词：聚焦编辑器 → 清空残留 → CDP 真实输入（TipTap/ProseMirror 可正确响应）
        self._ensure_foreground(tid, reason="填写提示词前")
        self.set_status(tid, "filling_form", 25, "填写视频提示词…")
        prompt = t.get("prompt", "").strip()
        if not prompt:
            raise RuntimeError("任务缺少视频提示词")
        foc = self.bridge.evaluate("window.__dbm.focusEditor()")
        if not foc or not foc.get("ok"):
            self.store.update(tid, status="needs_calibration", percent=0,
                              message="找不到提示词输入框，需要标定选择器",
                              error="selector_miss:prompt_input")
            return
        # 填提示词：JS execCommand 输入（对 TipTap/ProseMirror 可靠；函数内部自动清空残留）
        r = self._dbm_set_prompt(prompt) or {}
        if not r.get("ok"):
            self.store.update(tid, status="needs_calibration", percent=0,
                              message="找不到提示词输入框，需要标定选择器",
                              error="selector_miss:prompt_input")
            return
        self.sleep_cancel(tid, 0.5)
        actual = (self.bridge.evaluate("window.__dbm.editorText()") or "").strip()
        if prompt[:15].replace("\n", "") not in actual.replace("\n", "").replace(" ", ""):
            # 重试一次
            self._dbm_set_prompt(prompt)
            self.sleep_cancel(tid, 0.5)
            actual = (self.bridge.evaluate("window.__dbm.editorText()") or "").strip()
        self.store.log(tid, f"提示词已填入（{len(prompt)} 字），编辑器现有 {len(actual)} 字")

        # 5. 传参考项（参考图 + 参考音频）：CDP 直接给隐藏 file input 设文件。
        #    ★ 2026-11-13 实测：豆包对话框的附件 input accept 同时含图片与音频
        #    扩展名（.png…/.mp3/.wav/.m4a…），图片卡与音频卡能一批同时渲染。
        #    一次 DOM.setFileInputFiles 会替换整个 FileList，因此图片与音频必须
        #    合并成一个列表一次塞入，不能分两批上传（第二批会清掉第一批）。
        requested_images = list(t.get("images") or [])
        requested_audios = list(t.get("audios") or [])
        ff = (t.get("first_frame") or "").strip()
        missing = [p for p in requested_images + requested_audios
                   if not p or not Path(p).is_file()]
        if ff and not Path(ff).is_file():
            missing.append(ff)
        if missing:
            raise RuntimeError(f"attachment_upload_failed：参考项文件缺失，停止提交：{missing}")
        images = list(requested_images)
        if ff and Path(ff).exists() and not any(
                os.path.normcase(os.path.realpath(p)) == os.path.normcase(os.path.realpath(ff))
                for p in images):
            images.insert(0, ff)
        audios = [p for p in requested_audios if p and Path(p).is_file()]
        attachments = images + audios
        if attachments:
            self._ensure_foreground(tid, reason="上传参考项前")
            self.set_status(tid, "filling_form", 30,
                            f"上传参考项（参考图 {len(images)} 张 + "
                            f"参考音频 {len(audios)} 个）…")
            ok, detail = self.bridge.upload_images(
                attachments, progress=lambda msg: self.store.log(tid, msg),
                check_cancel=lambda: self.check_cancel(tid))
            self.store.log(tid, f"参考项上传: {'成功' if ok else '失败'} | {detail}")
            if not ok:
                # 参考项是视频任务的关键输入，上传失败不能静默退化为纯文生视频
                self.store.update(
                    tid, status="error", percent=0,
                    message=f"{self.display_name()}参考项上传失败",
                    error=f"attachment_upload_failed：{detail}")
                return
            self.sleep_cancel(tid, 1.5)
        else:
            self.store.log(tid, "无参考图 / 参考音频，走纯文生视频")

        # 5.5 发送前最后复检附件：豆包是"先渲染 chip、再往服务器传"，
        #     失败态往往在 chip 出现后好几秒才标出来，上传那一刻的确认盖不住。
        #     若此时仍有失败/裂图，发出去必然生成不了带参考图的视频，直接报错，
        #     杜绝"日志写已上传 N 张、页面却显示上传失败"的假成功。
        if attachments:
            try:
                st = self.bridge.evaluate("window.__dbm.attachmentState()") or {}
                # 还在转圈的再等一会儿，避免把"稍慢"误判成"失败"
                wait_to = time.time() + 12
                while st.get("uploading") and not (st.get("failed") or st.get("broken")) \
                        and time.time() < wait_to:
                    self.sleep_cancel(tid, 1.0)
                    st = self.bridge.evaluate("window.__dbm.attachmentState()") or {}
                # 与 upload_images 的判定保持一致：以渲染层附件卡为准（cardCount
                # 现在同时计入图片卡与音频文件卡），file input 仅在渲染层全 0 时
                # 作补充并 cap 到期望数——否则其它 input 残留文件会让 count 虚高。
                _v = max(int(st.get("cardCount", 0)), int(st.get("composerCount", 0)))
                _fc = min(int(st.get("fileCount", 0)), len(attachments))
                _eff = _v if _v > 0 else _fc
                if (st.get("failed") or st.get("broken") or st.get("uploading")
                        or _eff != len(attachments)):
                    self.store.log(tid, f"发送前复检附件异常: {json.dumps(st, ensure_ascii=False)}")
                    self.store.update(
                        tid, status="error", percent=0,
                        message=f"{self.display_name()}参考项上传失败（发送前复检）",
                        error=(f"attachment_upload_failed：发送前复检发现失败 {st.get('failed', 0)} 个"
                               f"、附件未加载 {st.get('broken', 0)} 个、上传中 {st.get('uploading', 0)} 个"
                               f"、附件 {_eff}/{len(attachments)} 个"
                               f"（card={st.get('cardCount', 0)} file={st.get('fileCount', 0)}"
                               f" img={st.get('composerCount', 0)}）"))
                    return
                self.store.log(tid, f"发送前复检附件: 正常 {_eff} 个"
                                    f"（上传中 {st.get('uploading', 0)}）")
            except TaskCancelled:
                raise
            except Exception as e:
                raise RuntimeError(f"发送前附件复检失败，未提交任务：{e}") from e

        # 6. 选比例 + 时长：【已按需求移除】
        # 用户明确要求插件不再点击/选择比例与时长，直接用豆包页面当前的比例与时长提交。
        # 因此不再调用 window.__dbm.pickAspectDuration(...)，页面保持默认（自动比例 + 当前时长档）。
        # ——注意：下面的"历史视频基线"记录仍是【轮询下载】所必需，必须保留。

        # 记录提交时刻页面已存在的视频（基线）：回收时只认"提交后才新出现"的视频。
        # 实测踩过坑：页面里残留着上一次生成的 <video>，实时轮询一看到有视频就判定
        # "已生成"并下载，结果下载到的是历史旧片（文件名 豆包_创作原视频_20260912180829.mp4），
        # 本次分镜永远拿不到正确视频。
        try:
            self._submit_video_baseline = set(
                self._eval_safe("window.__dbm.pageVideos()") or [])
        except Exception:
            self._submit_video_baseline = set()
        # 深度基线一并记录：成片若在 shadow DOM / iframe 里，普通 pageVideos 看不到，
        # 只记普通基线会导致深度扫描把历史旧片判成"本次新片"→ 串片。
        try:
            _dv = self._eval_safe(
                "window.__dbm && window.__dbm.deepVideos ? window.__dbm.deepVideos() : []") or []
            for _v in _dv:
                if isinstance(_v, dict) and str(_v.get("src") or ""):
                    self._submit_video_baseline.add(str(_v.get("src")))
        except Exception:
            pass
        # 页面资源时间线基线：提交时已加载过的视频请求不算本次成果
        try:
            _pv = self._eval_safe(
                "window.__dbm && window.__dbm.perfVideos ? window.__dbm.perfVideos() : []") or []
            self._submit_perf_baseline = set(
                str((_e or {}).get("name") or "") for _e in _pv
                if isinstance(_e, dict) and (_e or {}).get("name"))
        except Exception:
            self._submit_perf_baseline = set()
        if self._submit_video_baseline:
            self.store.log(tid, f"提交时页面已有 {len(self._submit_video_baseline)} 个历史视频，"
                                f"回收时只认新出现的视频")
        self._stale_video_warned = False


        # 7. 提交：点右下角发送按钮（填字后出现）。多级回退，且每步校验编辑器是否清空
        #    点发送前必须确认 tab 还在前台：这是整个流程里最不能出错的一步，
        #    一旦页面被切走导致点击落空，任务会白等一整轮超时。
        self._ensure_foreground(tid, reason="点击发送前")
        self.set_status(tid, "submitting", 38, "提交生成任务…")
        self.bridge.evaluate("window.__dbm.esc()")   # 关掉时长下拉等残留弹层
        self.sleep_cancel(tid, 0.6)
        click_time = time.time()
        sent = False

        def _after_click(tag):
            self.sleep_cancel(tid, 2.2)
            ok = bool(self.bridge.evaluate("window.__dbm.isSent()"))
            self.store.log(tid, f"{tag} → {'提交成功（编辑器已清空）' if ok else '编辑器仍有文字，未提交'}")
            return ok

        # 尝试 1：点 <button>/[role=button] 祖先
        r = self.bridge.evaluate("window.__dbm.clickSend(false)") or {}
        if r.get("ok"):
            self.store.log(tid, f"点击发送按钮: <{r.get('tag')}> {r.get('cls','')[:40]} "
                                f"@({r.get('x')},{r.get('y')}) {r.get('w')}x{r.get('h')} isBtn={r.get('isBtn')}")
            sent = _after_click("第1次点击(button)")
        else:
            self.store.log(tid, f"发送按钮未命中（{r.get('reason')}）")

        # 尝试 2：点 cursor:pointer 指针覆盖层（React 处理器可能挂在覆盖层上）
        if not sent:
            self.bridge.evaluate("window.__dbm.esc()")
            self.sleep_cancel(tid, 0.4)
            r = self.bridge.evaluate("window.__dbm.clickSend(true)") or {}
            if r.get("ok"):
                self.store.log(tid, f"点击发送覆盖层: <{r.get('tag')}> {r.get('cls','')[:40]} @({r.get('x')},{r.get('y')})")
                sent = _after_click("第2次点击(overlay)")

        # 尝试 3：Enter 键回退
        if not sent:
            self.store.log(tid, "按钮点击未生效，改用 Enter 键提交")
            self.bridge.evaluate("window.__dbm.focusEditor()")
            self.bridge.evaluate("window.__dbm.pressEnter()")
            sent = _after_click("Enter键")

        # 本账号 tab 已在前台持锁：若三级发送仍未生效，重新聚焦编辑器、重填一次再发。
        # （不能再调 _fg_acquire——当前已持有不可重入的 input_lock）
        if not sent:
            self.store.log(tid, "三次发送未生效，在前台 tab 重新聚焦并重填提示词后重试…")
            try:
                self._keep_active()
                self._eval_safe("window.__dbm.focusEditor()")
                self.sleep_cancel(tid, 0.4)
                self._dbm_set_prompt(prompt)
                self.sleep_cancel(tid, 0.6)
                self._eval_safe("window.__dbm.esc()")
                self.sleep_cancel(tid, 0.3)
                for prefer in ("false", "true"):
                    rr = self._eval_safe(f"window.__dbm.clickSend({prefer})") or {}
                    if rr.get("ok"):
                        self.sleep_cancel(tid, 2.0, step=0.5)
                        if self._eval_safe("window.__dbm.isSent()"):
                            sent = True
                            self.store.log(tid, "重填后发送成功（编辑器已清空）")
                            break
                if not sent:
                    self._eval_safe("window.__dbm.focusEditor()")
                    self._eval_safe("window.__dbm.pressEnter()")
                    self.sleep_cancel(tid, 2.0, step=0.5)
                    sent = bool(self._eval_safe("window.__dbm.isSent()"))
            except TaskCancelled:
                raise
            except Exception as e:
                self.store.log(tid, f"前台重填重试异常: {e}")
                sent = False

        if not sent:
            self.check_cancel(tid)
            self.store.update(
                tid, status="error", percent=0,
                message=f"{self.display_name()}已填好提示词但未能自动点中发送按钮",
                error="send_not_confirmed：已自动填好提示词/时长/首帧，请在管理器窗口手动点发送，或检查网页是否改版")
            return
        self.submitted = True   # 已提交生成：此后账号页面丢失不能再把任务改派
        self.store.update(tid, submitted=True)

        # 7.4 提交后检测额度耗尽提示（豆包回复"今日视频生成免费次数用完了，你明天再来"）
        #     等30秒给豆包充分时间返回额度耗尽回复。只信 quotaExhausted 强信号；
        #     quotaNotice 弱信号（含"升级会员"等常驻文案）容易误判，仅记录不中断——
        #     此时已 submitted，误判失败会白白浪费一次提交，真正额度尽还有强信号+
        #     最终视频超时兜底。
        self.sleep_cancel(tid, 30)
        quota_exhausted = self._eval_safe("window.__dbm.quotaExhausted()") or ""
        if quota_exhausted:
            self.store.log(tid, f"{self.display_name()}额度耗尽: {quota_exhausted}")
            raise QuotaExceeded(f"{self.display_name()}：{quota_exhausted}")
        qn_after = self._eval_safe("window.__dbm.quotaNotice()")
        if qn_after:
            self.store.log(tid, f"{self.display_name()}提交后出现弱额度提示（忽略，继续等待生成）: {qn_after}")

        # 7.5 安全确认弹窗：发送后豆包可能弹出"确认安全"对话框，需点击确认
        self.sleep_cancel(tid, 2)
        safety_confirmed = False
        for attempt in range(8):
            self.check_cancel(tid)
            r = self.bridge.evaluate("window.__dbm.confirmSafetyDialog()") or {}
            if r.get("ok"):
                self.store.log(tid, f"已点击安全确认弹窗: {r.get('text','')} "
                                f"(对话框内容: {r.get('dialogText','')[:50]})")
                safety_confirmed = True
                break
            self.sleep_cancel(tid, 2)
        if not safety_confirmed:
            self.store.log(tid, "未检测到安全确认弹窗（可能已直接进入生成或无需确认）")

        # local_* 只是客户端临时消息；未持久化前不继续补发确认文本。
        self._verify_submission(tid)

        # 7.6 等待生成确认消息：豆包回复"本次使用…生成，预计等待…视频生成好后…"。
        #     本阶段仍持有前台锁、本账号 tab 在前台。改为【轮询提前结束】：一旦检测到
        #     确认消息立即切下一个账号（豆包通常 20-60s 内回复），不必死等满 100s；
        #     超时仍未回复则发送"确认生成视频"文本兜底后再切走。
        submit_ts = time.time()
        if self.config.get("auto_confirm_generation", True):
            # ★ 2026-09-29：四类对话场景协商（需求1/2/3/4）统一交给 _negotiate_generation
            #   处理：正常"需要确认"/二次确认、豆包"我无法生成你要求的内容"、
            #   豆包"由于模型可能带来准确性问题…"、版权拒绝(复用 _copyright_appeal)。
            # ★ 2026-11-14：参考项含参考音频时强制二次确认。audios 是上面
            #   submit_stage 里已按 is_file() 过滤过的参考音频列表，是唯一真相源。
            self._negotiate_generation(
                tid, prompt, attachments, submit_ts,
                has_reference_audio=bool(audios))

        self._verify_submission(tid)

        # 分发阶段完成：记录提交时刻，任务进入 generating。CDP 会话保留（不 detach），
        # 前台锁由编排器统一释放后切到下一个账号。编排器会在 submit_ts + 回收间隔
        # （默认 6 分钟）后按分镜顺序调用 collect_stage 回收成品。
        # ★ 2026-11-14：只有协商（含带参考音频的强制二次确认）全部走完，
        #   才在这里盖章「允许回收」。此前 _collect_all_ready 用编排器的分发
        #   时刻算 elapsed，协商一长（音频任务实测空转 160s+）就提前启动回收，
        #   把别的账号窗口的历史成片当成自己的成品回传给字字动画。
        self.store.update(
            tid, status="generating", percent=45, submitted=True,
            submit_ts=submit_ts, assigned_to=self.target_id,
            generation_ready_ts=time.time(),
            has_reference_audio=bool(audios), negotiation_done=True,
            message=f"已由{self.display_name()}提交，等待豆包生成（编排器将按时回收）…")
        self.store.log(tid, f"分镜分发完成 → {self.display_name()}，"
                            f"提交时刻 {time.strftime('%H:%M:%S', time.localtime(submit_ts))}，"
                            f"编排器随后切换下一账号")
        return submit_ts

    @staticmethod
    def _normalize_model_in_text(text, model):
        """把确认/申诉文本里写死的 Seedance 2.x 模型名，替换成实际选用的模型（小写），
        避免模型兜底切换后文本与实际模型不一致（如回"使用 seedance 2.5"实为 2.0 Fast）。"""
        if not text or not model:
            return text
        m = re.search(r"seedance\s*2[\.\s]*[0-9]+(?:\s*(?:fast|mini|pro|lite|air))?", text, re.I)
        if not m:
            return text
        return text[:m.start()] + str(model).lower() + text[m.end():]

    def _negotiate_generation(self, tid, prompt, attachments, submit_ts,
                              has_reference_audio=False):
        """2026-09-29 四类对话场景协商（需求1/2/3/4）。

        2026-11-14 新增：has_reference_audio=True（提交的参考项含参考音频）时
        强制完成二次确认，两轮都用 audio_second_confirm_text 固定提示词，
        不受模型名改写影响，并重新带上参考项（音频不跨轮继承）。

        提交提示词后，豆包可能停在以下几种状态之一，本方法统一协商处理：
          需求1：正常"需要确认"（含二次确认）→ 回 confirm_generation_text；
                 回完等 second_confirm_wait_sec(20s) 再查，若仍要二次确认则再回一次。
          需求3：豆包回"抱歉，由于模型可能带来准确性问题…我无法为你生成相应内容"
                 → 首回 confirm_generation_text；20s 后若仍需二次确认，
                   再回"字字动画提示(prompt) + 参考图"。
          需求4：版权拒绝 → 复用既有 _copyright_appeal，本方法不改动其行为。

        循环最多 max_confirm_replies 轮，防无限；整体受 safety_confirm_wait_sec 窗口约束
        （沿用旧 7.6 的等待上限），超时未确认则兜底发一次确认文本并交回收阶段处理。
        返回 True=已确认受理（豆包开始生成）；False=未确认（交回收阶段兜底）。
        """
        # ★ 2026-11-14：含参考音频任务的确认句固定为这一句（用户明确要求
        #   "确认提示词还是…"），不能被 _normalize_model_in_text 按当前模型改写。
        _audio_confirm_fallback = "确认，使用seedance 2.0 fast来生成15秒视频"
        force_audio_second = bool(
            has_reference_audio
            and self.config.get("audio_second_confirm_enabled", True))
        audio_confirm_text = str(self.config.get(
            "audio_second_confirm_text", _audio_confirm_fallback)
            or _audio_confirm_fallback).strip() or _audio_confirm_fallback
        confirm_text = str(self.config.get(
            "confirm_generation_text", "确认，使用seedance 2.0 fast 来生成15秒视频") or "").strip()
        if force_audio_second:
            # 含参考音频：首回与二次确认统一用固定提示词。
            confirm_text = audio_confirm_text
        elif getattr(self, "model_name", ""):
            # 2026-10-09：模型兜底切换后，让确认文本里的模型名与实际选用模型一致
            confirm_text = self._normalize_model_in_text(confirm_text, self.model_name)
        # 需求2 已取消：不再读取/发送 reject_modify_text
        reject_accuracy_reason = str(self.config.get(
            "reject_accuracy_reason",
            "由于模型可能带来准确性问题，豆包判定无法生成该内容，已直接返回失败"
            "（如需继续，请调整提示词或更换参考图后手动重新生成）") or "").strip()
        second_wait = int(self.config.get("second_confirm_wait_sec", 20) or 20)
        max_replies = int(self.config.get("max_confirm_replies", 3) or 3)
        try:
            idle_wait = max(0.0, float(self.config.get("confirm_idle_wait_sec", 120) or 0))
        except (TypeError, ValueError):
            idle_wait = 120.0
        try:
            max_try = int(self.config.get("confirm_send_retries", 4) or 1)
        except (TypeError, ValueError):
            max_try = 4
        overall_deadline = submit_ts + float(
            self.config.get("safety_confirm_wait_sec", 100) or 100)
        if force_audio_second:
            # 含音频必须留够「首回 + 复查 + 二次确认」的时间；控制台可能把
            # safety_confirm_wait_sec 配成 5s，沿用会立刻 break，二次确认做不完。
            max_replies = max(max_replies, 2)
            overall_deadline = max(
                overall_deadline, submit_ts + 2 * (float(second_wait) + 60.0))
            self.store.log(
                tid, "参考项含参考音频 → 启用强制二次确认；固定提示词「%s」"
                     % audio_confirm_text)

        def _send_confirm(text):
            """★ 2026-11-14 三轮：确认文案一律纯文本，不重传参考图 / 参考音频。

            旧版每一轮确认都调 _send_reply_with_images(...) 强制重传参考项，
            实测日志 12:00:21 / 12:00:56 两次各重新上传
            11 个参考项（9 图 + 2 音频），用户明确要求「只发送确认文案」。
            这里传空附件列表：既不上传任何参考项，又保留原方法「等豆包说完
            → 唤醒输入框 → 填文本 → clickSend / pressEnter 兜底」全部稳健姿势。
            发送前再清一次输入区残留附件，确保这一轮绝不夹带图片或音频卡。
            """
            try:
                self._close_minutes_panel(tid)
                self._eval_safe(
                    "(function(){try{if(window.__dbm && window.__dbm.clearAttachments)"
                    "{window.__dbm.clearAttachments();}}catch(e){} return true;})()",
                    timeout=8)
            except Exception:
                pass
            return self._send_reply_with_images(
                tid, text, [], idle_wait=idle_wait, max_try=max_try)

        def _probe():
            # 1) 已确认受理（豆包确认开始生成）
            cr = self._eval_safe("window.__dbm.checkGenerationConfirmed()") or {}
            if cr.get("ok"):
                return ("confirmed", cr)
            # 2) 明确失败 / 版权拒绝（要求页面无 <video> 才采信，防单帧误判；
            #    具体判死/申诉交给调用处走 _copyright_appeal 或 genfail 计数控制）
            fr = self._gen_failed_effective()
            if fr.get("failed") and not (self._eval_safe("window.__dbm.pageVideos()") or []):
                return ("failed", fr)
            # 3) 需求3：豆包"由于模型可能带来准确性问题…我无法为你生成相应内容"
            ra = self._eval_safe("window.__dbm.matchesRejectAccuracy()") or {}
            if ra.get("hit"):
                return ("reject_accuracy", ra)
            # 4) 需要确认（"确认后我再开始生成"等）
            aw = self._eval_safe("window.__dbm.awaitingConfirm()") or {}
            if aw.get("waiting"):
                return ("awaiting", aw)
            # 5) 暂无结论
            return ("none", {})

        reply_count = 0
        genfail = [0]  # 明确失败连续命中计数（防单帧误判，沿用旧 7.6 的 2 次阈值）

        def _on_failed(info):
            """命中明确失败时的统一处理：版权先申诉；连续 2 次才判死。

            返回 True=已处理并 continue（申诉或再观察）；返回 False=已抛异常（不会返回）。
            """
            if self._copyright_appeal(tid, info):
                genfail[0] = 0
                self.sleep_cancel(tid, 5, step=1)
                return True
            genfail[0] += 1
            if genfail[0] >= 2:
                kind = str(info.get("kind", "failed") or "failed")
                cn = "内容审核拒绝" if kind == "moderation" else "豆包生成失败"
                self.store.log(tid, f"{cn}（协商阶段连续命中，无视频产出）: "
                                   f"{str(info.get('text',''))[:100]}")
                raise GenerationFailed(
                    f"{self.display_name()}：{cn}：{str(info.get('text',''))[:80]}",
                    kind=kind, page_text=str(info.get("text", "")))
            self.store.log(tid, f"协商阶段疑似失败（第 {genfail[0]} 次，再观察），暂不判死")
            self.sleep_cancel(tid, 3, step=1)
            return True
        while reply_count < max_replies:
            self.check_cancel(tid)
            self._close_minutes_panel(tid)
            # 硬性总时限：防止任何状态下无限空转（沿用旧 7.6 的 safety_confirm_wait_sec 窗口）
            if time.time() >= overall_deadline:
                self.store.log(tid, "已达协商总时限，结束协商交回收阶段")
                break
            # 周期性处理可能弹出的安全确认框
            try:
                dr = self._eval_safe("window.__dbm.confirmSafetyDialog()") or {}
                if dr.get("ok"):
                    self.store.log(tid, f"协商期间处理安全弹窗: {dr.get('text','')}")
            except Exception:
                pass
            st, info = _probe()
            if st == "confirmed":
                self.store.log(tid, "豆包已确认开始生成（协商完成）")
                return True
            if st == "failed":
                if _on_failed(info):
                    continue
            else:
                genfail[0] = 0
            if st == "reject_accuracy":
                # 需求3：命中"由于模型可能带来准确性问题…我无法为你生成相应内容"。
                # 该拒绝属内容/准确性判定，与账号无关，重试无意义；直接判失败并说明原因，
                # 交由 handle_stage_error 按 accuracy_reject 处理（不重排队、直接返回失败）。
                page_text = str(info.get("text", "") or "")
                reason = reject_accuracy_reason
                if page_text:
                    reason = f"{reason}\n豆包原文：{page_text[:200]}"
                self.store.log(tid, f"需求3命中（豆包：{page_text[:60]}）→ 直接返回失败：{reason[:80]}")
                raise GenerationFailed(
                    f"{self.display_name()}：{reason}",
                    kind="accuracy_reject", page_text=page_text)
            if st == "awaiting":
                # 普通需求1 / 二次确认重发：发确认文本（带参考图，受 config 控制）
                already = (reply_count > 0)
                note = "（二次确认）" if already else ""
                self.store.log(tid, f"需要确认{note} → 回「{confirm_text[:20]}…」")
                ok = _send_confirm(confirm_text)
                if ok:
                    reply_count += 1
                    # 20s 后查是否仍需二次确认
                    self.sleep_cancel(tid, second_wait, step=2)
                    st2, info2 = _probe()
                    if st2 == "confirmed":
                        return True
                    if st2 == "failed":
                        if _on_failed(info2):
                            continue
                    # ★ 2026-11-14：参考项含参考音频 → 必须完成二次确认。
                    #   旧逻辑只有豆包再次明确弹「请确认」(st2=="awaiting") 才重发，
                    #   而带音频时豆包常停在参数确认屏但页面状态仍是 none，加上
                    #   短协商窗口，二次确认经常被跳过。这里只要豆包还没确认开始
                    #   生成、页面也没有视频，就按需求再回一次固定提示词，并强制
                    #   重传参考项（音频不跨轮继承，不重传等于这轮没有音频参考）。
                    if force_audio_second and reply_count < 2:
                        _pvs = self._eval_safe("window.__dbm.pageVideos()") or []
                        if not _pvs:
                            self.store.log(
                                tid, "参考项含参考音频 → 发送二次确认（固定提示词）")
                            ok2 = _send_confirm(audio_confirm_text)
                            reply_count += 1
                            self.store.update(
                                tid, audio_second_confirm_done=bool(ok2),
                                audio_second_confirm_text=audio_confirm_text)
                            self.store.log(
                                tid, "二次确认%s，累计确认 %d/%d 次"
                                     % ("成功" if ok2 else "发送失败",
                                        reply_count, max_replies))
                            # 给豆包一点时间受理，再看是否已经确认开始生成
                            self.sleep_cancel(tid, min(10, second_wait), step=2)
                            st3, info3 = _probe()
                            if st3 == "confirmed":
                                return True
                            if st3 == "failed":
                                if _on_failed(info3):
                                    continue
                            continue
                        self.store.log(tid, "页面已出现视频，跳过二次确认以免打断生成")
                    if st2 == "awaiting":
                        continue  # 下一轮再回 confirm（二次确认重发，需求1）
                    continue
                else:
                    self.store.log(tid, "确认文本发送失败，交回收阶段兜底")
                    return False
            # st == "none"：暂无结论，再等一会（受 overall_deadline 约束）
            self.store.log(tid, "页面暂无明确状态，继续等待豆包响应…")
            # ★ 2026-11-14：带参考音频时豆包常停在参数确认屏，_probe() 却
            #   一直返回 "none"。旧版只能空转到 160s 总时限，首回拖到最后才
            #   由兜底发出、二次确认根本没机会发（实测日志：回复数 0/3）。
            #   页面稳定 15s 后主动发首回固定提示词，让两轮确认真正跑完。
            if force_audio_second and reply_count == 0:
                _now_none = time.time()
                if not getattr(self, "_audio_none_first_ts", 0.0):
                    self._audio_none_first_ts = _now_none
                if _now_none - self._audio_none_first_ts >= 15.0:
                    _pvs0 = self._eval_safe("window.__dbm.pageVideos()") or []
                    if not _pvs0:
                        self.store.log(
                            tid, "参考项含参考音频 → 页面无明确状态，主动发送首回确认")
                        ok0 = _send_confirm(audio_confirm_text)
                        reply_count += 1
                        self.store.log(
                            tid, "主动首回确认%s" % ("成功" if ok0 else "发送失败"))
                        self.sleep_cancel(tid, second_wait, step=2)
                        st0, info0 = _probe()
                        if st0 == "confirmed":
                            return True
                        if st0 == "failed":
                            if _on_failed(info0):
                                continue
            # ★ 2026-11-14 全面检查修复：带参考音频时豆包常停在参数确认屏、
            #   但 _probe() 返回 "none"。旧版把强制二次确认只写在 awaiting
            #   分支内，none 分支根本够不着，需求实际只在窄路径生效。
            #   条件 0 < reply_count < 2 保证「已发过首回、且最多补一次」，
            #   从不发首回的纯加载态不打扰，交给回收阶段自愈。
            if force_audio_second and 0 < reply_count < 2:
                _pvs = self._eval_safe("window.__dbm.pageVideos()") or []
                if not _pvs:
                    self.store.log(
                        tid, "参考项含参考音频 → 页面无明确状态时补发二次确认（固定提示词）")
                    ok2 = _send_confirm(audio_confirm_text)
                    reply_count += 1
                    self.store.update(
                        tid, audio_second_confirm_done=bool(ok2),
                        audio_second_confirm_text=audio_confirm_text)
                    self.sleep_cancel(tid, min(10, second_wait), step=2)
                    st3, info3 = _probe()
                    if st3 == "confirmed":
                        return True
                    if st3 == "failed":
                        if _on_failed(info3):
                            continue
                    continue
            if time.time() >= overall_deadline:
                break
            self.sleep_cancel(tid, min(5, second_wait), step=1)
        # 循环结束（达上限或超时）：兜底处理
        self.store.log(tid, f"协商窗口结束（回复数 {reply_count}/{max_replies}），兜底处理…")
        fr = self._gen_failed_effective()
        if fr.get("failed") and fr.get("kind") in ("moderation", "failed") \
                and not (self._eval_safe("window.__dbm.pageVideos()") or []):
            if self._copyright_appeal(tid, fr):
                return False
            kind = str(fr.get("kind", "failed") or "failed")
            cn = "内容审核拒绝" if kind == "moderation" else "豆包生成失败"
            raise GenerationFailed(
                f"{self.display_name()}：{cn}：{str(fr.get('text',''))[:80]}",
                kind=kind, page_text=str(fr.get("text", "")))
        if reply_count == 0:
            # 至少兜底发一次确认文本（带参考图），沿用旧 7.6 行为
            ok = _send_confirm(confirm_text)
            if ok:
                reply_count += 1
            self.store.log(tid, f"兜底发送确认文本：{'成功' if ok else '失败'}")
        if force_audio_second and 0 < reply_count < 2:
            # ★ 2026-11-14：协商窗口结束时若只发过一次，必须补上二次确认。
            #   旧版把这件事「交给回收阶段自愈」，但自愈只在 awaitingConfirm()
            #   命中时才触发，页面停在 none 时永远不补 —— 字字动画端却在此时
            #   就收到了别的账号窗口的视频。两轮确认必须在分发完成前发完。
            _pvs = self._eval_safe("window.__dbm.pageVideos()") or []
            if not _pvs:
                self.store.log(tid, "协商窗口结束 → 补发二次确认（固定提示词）")
                ok2 = _send_confirm(audio_confirm_text)
                reply_count += 1
                self.store.update(
                    tid, audio_second_confirm_done=bool(ok2),
                    audio_second_confirm_text=audio_confirm_text)
                self.store.log(tid, "二次确认%s，累计确认 %d/%d 次"
                               % ("成功" if ok2 else "发送失败",
                                  reply_count, max_replies))
                self.sleep_cancel(tid, min(10, second_wait), step=2)
            else:
                self.store.log(tid, "页面已出现视频，跳过补发二次确认以免打断生成")
        elif force_audio_second:
            self.store.log(tid, "协商窗口结束，二次确认已由前序轮次完成")
        return False

    def _send_reply_with_images(self, tid, text, attachments, idle_wait=120.0,
                                max_try=4, force_images=False):
        """往会话里再发一句话 + 重新上传参考项（参考图 + 参考音频）。

        与 _send_reply_text 同套稳健姿势：等豆包说完 → 唤醒输入框 → 填文本 →
        重传参考项（豆包每轮独立、附件不继承）→ 发送。返回是否发送成功。
        attachments 是「本地路径列表」，图片与音频一并通过同一 file input 上传。
        """
        try:
            self._ensure_injected(tid)
        except Exception:
            pass
        deadline = time.time() + max(0.0, idle_wait)
        for _try in range(max(1, int(max_try or 1))):
            try:
                self.check_cancel(tid)
            except Exception:
                return False
            _logged = False
            while time.time() < deadline:
                bsy = self._eval_safe("window.__dbm.isPageBusy()") or {}
                if not bsy.get("busy"):
                    break
                if not _logged:
                    _logged = True
                    self.store.log(
                        tid, f"豆包仍在输出（{str(bsy.get('reason') or '')}），"
                             f"等它说完再发「{text[:20]}」…")
                try:
                    self.sleep_cancel(tid, 3, step=1)
                except Exception:
                    return False
            self._eval_safe(
                "window.__dbm.revealEditor ? window.__dbm.revealEditor() : null")
            self._eval_safe("window.__dbm.focusEditor()")
            try:
                self.sleep_cancel(tid, 0.3)
            except Exception:
                return False
            r = self._dbm_set_prompt(text) or {}
            if not r.get("ok"):
                self.store.log(tid, f"第 {_try + 1} 次发送「{text[:20]}」："
                                   f"输入框不可用，5s 后重试")
                try:
                    self.sleep_cancel(tid, 5, step=1)
                except Exception:
                    return False
                continue
            # 重传参考项（仅第 1 轮，避免重复附件堆叠）。
            # force_images=True 时无视 confirm_with_images 开关（需求3二次回明确要求带参考项）。
            if _try == 0 and attachments and (force_images or self.config.get("confirm_with_images", True)):
                _cf_atts = [p for p in attachments if p and Path(p).exists()]
                if _cf_atts:
                    try:
                        self._ensure_foreground(tid, reason="回复时上传参考项")
                        i_ok, i_detail = self.bridge.upload_images(
                            _cf_atts, progress=lambda msg: self.store.log(tid, msg),
                            check_cancel=lambda: self.check_cancel(tid))
                        self.store.log(tid, f"回复参考项上传: "
                                            f"{'成功' if i_ok else '失败'} | {i_detail}")
                        if i_ok:
                            try:
                                self.sleep_cancel(tid, 1.0, step=0.5)
                            except Exception:
                                pass
                        else:
                            self.store.log(tid, "回复参考项未上传成功，降级纯文本"
                                                 "（本轮视频可能不带参考项）")
                    except Exception as e:
                        self.store.log(tid, f"回复上传参考项异常（忽略，纯文本）: {e}")
                else:
                    self.store.log(tid, "回复参考项文件已不存在，纯文本发送")
            try:
                self.sleep_cancel(tid, 0.5)
            except Exception:
                return False
            self._eval_safe("window.__dbm.esc()")
            try:
                self.sleep_cancel(tid, 0.3)
            except Exception:
                return False
            for prefer in ("false", "true"):
                r2 = self._eval_safe(f"window.__dbm.clickSend({prefer})") or {}
                if r2.get("ok"):
                    try:
                        self.sleep_cancel(tid, 2.0, step=0.5)
                    except Exception:
                        return False
                    if self._eval_safe("window.__dbm.isSent()"):
                        return True
            self._eval_safe("window.__dbm.focusEditor()")
            self._eval_safe("window.__dbm.pressEnter()")
            try:
                self.sleep_cancel(tid, 2.0, step=0.5)
            except Exception:
                return False
            if bool(self._eval_safe("window.__dbm.isSent()")):
                return True
            self.store.log(tid, f"第 {_try + 1} 次发送「{text[:20]}」未生效，5s 后重试")
            try:
                self.sleep_cancel(tid, 5, step=1)
            except Exception:
                return False
        return False


    def _verify_submission(self, tid):
        deadline = time.time() + float(self.config.get("submission_ack_timeout_sec", 150))
        last_url = ""
        page_tail = ""
        retried = False
        next_diag = 0.0
        while time.time() < deadline:
            self.check_cancel(tid)
            # ★ 2026-11-14：发送文案后豆包会自动打开右侧智能纪要面板，
            #   等服务端会话确认的这段时间里每 2 秒主动关一次（后台标签页
            #   的前端定时器被节流，只能靠 CDP 主动触发）。
            self._close_minutes_panel(tid)
            last_url = self._eval_safe("String(location.href)") or ""
            if re.fullmatch(r"https://www\.doubao\.com/chat/[0-9]+/?(?:[?#].*)?", last_url):
                self.store.update(tid, conversation_url=last_url)
                self.store.log(tid, f"提交已持久化到服务端会话：{last_url}")
                return
            # 每 15 秒采样一次页面现场：URL 停在 local_ 时能看清豆包是否给出了
            # 发送失败提示（附件上传失败 / 网络断开 / 需要重试），不再黑等。
            if time.time() >= next_diag:
                next_diag = time.time() + 15
                page_tail = str(self._eval_safe(
                    "String((document.body ? document.body.innerText : '') || '')"
                    ".trim().slice(-160)") or "")
                self.store.log(tid, f"等待服务端会话确认中… URL={last_url} "
                                    f"页面末尾: {page_tail[:120]}")
                # 命中豆包原生的「重新发送/重试」入口就点一次：发送失败（含附件
                # 上传失败）时消息停在 local_ 态，豆包会在气泡旁给出原生重试按钮，
                # 点它比干等 150 秒后判死更有救回机会（仅一次，防止重复扣额度）。
                if not retried:
                    _r = self._eval_safe(
                        "window.__dbm && window.__dbm.clickRetryButton ? "
                        "window.__dbm.clickRetryButton() : "
                        "(() => { const els = Array.from("
                        "document.querySelectorAll('button,[role=button],span,div'))"
                        ".filter(e => /^(重新发送|重试)$/.test((e.innerText || '').trim())"
                        " && e.offsetParent); if (!els.length) return {ok:false,reason:'no_retry'};"
                        " const t = els[els.length - 1];"
                        " t.dispatchEvent(new MouseEvent('mouseup', {bubbles:true}));"
                        " t.click(); return {ok:true, text:(t.innerText||'').trim().slice(0,20)}; })()",
                        timeout=10) or {}
                    if _r.get("ok"):
                        retried = True
                        self.store.log(tid, f"页面出现发送失败重试入口，DOM 点击原生重试: "
                                            f"{_r.get('text')}")
            self.sleep_cancel(tid, 2)
        # 可能已发出请求但网络响应丢失，不自动重发以免重复扣额度。
        raise RuntimeError(
            f"submission_not_acknowledged：消息未获得服务端会话确认（{last_url or '页面不可读'}）；"
            f"页面末尾: {page_tail[:100] or '（读取失败）'}；"
            "请检查豆包页面的发送失败提示及网络连接，核实后重试")

    def _ensure_task_conversation(self, tid):
        """回收只在本任务保存的会话执行；跳回首页后最多恢复一次。"""
        expected = (self.store.get(tid) or {}).get("conversation_url")
        if not expected:  # 兼容旧任务
            return
        current = self._eval_safe("String(location.href)")
        if not current:
            raise RuntimeError("无法读取任务会话地址，暂停本轮回收")
        if current.rstrip('/') == expected.rstrip('/'):
            return
        if getattr(self, "_restored_conversation_tid", None) == tid:
            raise RuntimeError(f"任务会话再次丢失，停止回收其他页面：{current}")
        self._restored_conversation_tid = tid
        self.store.log(tid, f"任务页面已离开原会话，恢复：{expected}")
        self.bridge._ws.send("Page.navigate", {"url": expected}, timeout=20)
        self.sleep_cancel(tid, 5)
        self._ensure_injected(tid)
        current = self._eval_safe("String(location.href)") or ""
        if current.rstrip('/') != expected.rstrip('/'):
            raise RuntimeError(f"任务会话恢复失败：{current}")

    def _log_detect_progress(self, tid, waited, n_videos):
        """轻量检测进度诊断：按分钟节流输出，避免刷屏但保证能看出卡在哪。

        之前这个环节在"没检测到视频"时完全不写日志，日志里只剩每 30 秒一次的
        "重新连接"，最后任务超时也无从下手。这里把现场信息（等待时长、页面 URL、
        可见性、__dbm 是否存活、<video> 标签数）打出来。
        """
        bucket = int(waited // 60)
        if getattr(self, "_detect_log_tid", None) != tid:
            self._detect_log_tid = tid
            self._detect_log_bucket = -1
        if bucket == getattr(self, "_detect_log_bucket", -1):
            return
        self._detect_log_bucket = bucket
        info = {}
        try:
            info = self._eval_safe(
                "({url: String(location.href).slice(0,70),"
                " vis: document.visibilityState,"
                " dbm: (window.__dbm ? 'ok' : 'dead'),"
                " n: document.querySelectorAll('video').length})",
                timeout=8) or {}
        except Exception:
            pass
        self.store.log(
            tid, f"{self.display_name()} 检测进度：已等待 {int(waited)}s，"
                 f"识别到视频 {n_videos} 个"
                 + (f" / <video> 标签 {info.get('n')} 个" if info.get('n') is not None else "")
                 + f"，__dbm={info.get('dbm', '?')}，可见性={info.get('vis', '?')}"
                 + (f"，URL={info.get('url')}" if info.get('url') else ""))

    def _fast_detect_video(self, tid):
        """轻量视频检测（非阻塞，仅一轮）：重 attach CDP → 检测 <video> 元素 → 尝试下载。

        用于编排器轮询切换账号时的快速探测：不持有前台锁，仅在检测到视频后立即
        通过 _fg_click_no_watermark 持锁点击下载按钮。若视频未出现则返回 False，
        编排器继续检查下一个账号。
        """
        # ★ 2026-11-14：防御性闸门，防止任何绕过编排器的调用提前检测视频。
        _g_ok, _g_why, _g_ready = self._delivery_gate(tid)
        if not _g_ok:
            return False
        self._close_minutes_panel(tid)
        # 重建 CDP 会话（submit 与本次之间可能已超时/断连）。
        # 注意：_ensure_attached 内部已对强制重连做 30 秒节流，避免每轮轮询都
        # detach+attach 把 webview 搞崩。
        attached = self._ensure_attached(tid, force_refresh=True)
        if not attached:
            self.store.log(tid, f"{self.display_name()} CDP 重 attach 失败，跳过本轮检测")
            return False
        try:
            # 保持 webview active，防止 Chromium 冻结导致 <video> 不渲染
            self._keep_active()
            # 页面可能已导航（豆包提交后会跳到新会话，URL 变化）→ window.__dbm 会丢。
            # _ensure_attached 虽有注入，但导航发生在它之后的话这里就没有了，补一次。
            self._ensure_injected(tid)
            self._ensure_task_conversation(tid)
            # 已等待时长：★ 以「协商完成、真正开始生成」为零点。旧版用
            # submit_ts（协商窗口起点）会把协商耗时算成生成等待，150s 一到
            # 就无条件转完整回收，哪怕二次确认还没发出去。
            base_ts = _g_ready or 0.0
            if base_ts <= 0:
                try:
                    base_ts = float((self.store.get(tid) or {}).get("submit_ts") or 0)
                except (TypeError, ValueError):
                    base_ts = 0.0
            if base_ts <= 0:
                if getattr(self, "_detect_first_tid", None) != tid:
                    self._detect_first_tid = tid
                    self._detect_first_ts = time.time()
                base_ts = self._detect_first_ts
            waited = time.time() - base_ts

            # 快速检测视频是否已出现：不再只认顶层 <video src>，改为多源证据判定
            # （深度 <video> / 页面资源时间线 / 网络层 mp4 / 结果卡片 UI 信号）。
            appeared, page_videos, reason = self._video_evidence(tid, base_ts)
            # ★ 2026-11-03：无具体视频源的命中需二次复核（防生成中的信号抖动假阳性，
            #   实测提交后 61s 误报提前启动回收、空转数分钟）。
            if appeared and not self._confirm_hit_concrete(tid, page_videos):
                if not getattr(self, "_ev_flip_logged", False):
                    self._ev_flip_logged = True
                    self.store.log(
                        tid, f"{self.display_name()} 视频证据命中但无具体视频源"
                             f"且信号复查不成立，判定为生成中占位噪声，继续等待…")
                appeared = False
            if not appeared:
                self._fast_detect_miss = 0
                # ★★ 2026-09-24：这一段以前**完全没有失败检测** —— 于是
                #   "生成的视频可能涉及版权限制，请更换输入内容后重试"这类明确拒绝，
                #   要等到 600 多秒后转交完整回收流程才被发现（实测 615s 才判死）。
                #   提交后到转交回收之间的这十几分钟里，每轮都白等。
                #   现在每轮都查一次：命中明确拒绝（连续 2 次取样，间隔 1.5s）就
                #   立刻判死，把账号还给编排器去接下一个分镜。
                #   busy（系统繁忙）此阶段不采信——可能自愈，留给回收阶段判断。
                try:
                    _fd_chk = bool(self.config.get("fast_detect_fail_check", True))
                except Exception:
                    _fd_chk = True
                if _fd_chk:
                    fr = self._gen_failed_effective()
                    if (fr.get("failed")
                            and fr.get("kind") in ("moderation", "failed")
                            and not page_videos):
                        self.sleep_cancel(tid, 1.5, step=0.5)
                        frb = self._gen_failed_effective()
                        if (frb.get("failed")
                                and frb.get("kind") in ("moderation", "failed")):
                            # ★ 2026-09-24：版权类拒绝先申诉「我已获得授权」。
                            #   成功就结束本轮、交给宽限期继续等（豆包可能就此开始
                            #   生成）；宽限期内 _gen_failed_effective 不会判死。
                            if self._copyright_appeal(tid, frb):
                                self._log_detect_progress(tid, waited, 0)
                                return False
                            _k = frb.get("kind", "failed")
                            _cn = ("内容审核拒绝" if _k == "moderation"
                                   else "豆包生成失败")
                            self.store.log(
                                tid, f"{_cn}（轻量检测阶段命中，已等待 {int(waited)}s，"
                                     f"立即判死不再等待出片）: "
                                     f"{str(frb.get('text', ''))[:120]}")
                            raise GenerationFailed(
                                f"{self.display_name()}：{_cn}："
                                f"{str(frb.get('text', ''))[:80]}",
                                kind=_k, page_text=str(frb.get("text", "")))
                # 诊断：这里以前什么都不记，日志里只剩每 30 秒一次的"重新连接",
                # 最后任务超时也查不出到底卡在哪。现在按分钟节流输出现场信息。
                self._log_detect_progress(tid, waited, 0)
                # 每 3 分钟把页面现场完整 dump 一次（iframe / shadow / canvas /
                # 按钮文案 / 末尾气泡），保证下次"看得到片子却检测不到"能直接定位。
                _bucket = int(waited) // 180
                if _bucket != getattr(self, "_diag_bucket", -1) and _bucket >= 1:
                    self._diag_bucket = _bucket
                    self._log_page_diag(tid, f"（已等待 {int(waited)}s）")
                # 2026-09-29 等待优化：轻量检测持续确认不到成片时，提前转交完整的
            # collect_stage —— 它会解冻 webview、必要时重载页面、扫描下载目录、直接
            # 抓 video src，比在 _fast_detect_video 里原地空转更可能把"管理器看得见、
            # DOM 却检不出"的成片捞回来。阈值 fast_detect_thaw_after_sec 默认 150s，
            # 远小于 fast_detect_max_wait_sec，避免每个任务都白等 4~10 分钟。
            try:
                thaw_after = int(
                    self.config.get("fast_detect_thaw_after_sec", 150) or 0)
            except (TypeError, ValueError):
                thaw_after = 150
            if thaw_after > 0 and waited >= thaw_after:
                self.store.log(
                    tid, f"{self.display_name()} 轻量检测已等待 {int(waited)}s "
                         f"仍未确认成片，提前转交完整回收流程（解冻/重载/扫盘兜底）")
                return True
            # 关键兜底：等太久就交给完整回收流程。collect_stage 还有页面重载、
                # 扫描下载目录、直接抓 video src 等多条退路；不转交的话只会原地
                # 空转到超时，已经在豆包生成好的视频就彻底丢了。
                try:
                    max_wait = int(self.config.get("fast_detect_max_wait_sec", 420) or 0)
                except (TypeError, ValueError):
                    max_wait = 420
                if max_wait > 0 and waited >= max_wait:
                    self.store.log(
                        tid, f"{self.display_name()} 轻量检测已等待 {int(waited)}s "
                             f"仍未发现视频，转由完整回收流程兜底")
                    return True
                return False
            # 只认"提交之后才新出现"的视频：页面里可能还有上次生成残留的旧片。
            # 不区分就会一看到视频就下载，结果拿到历史旧视频。
            baseline = getattr(self, "_submit_video_baseline", None) or set()
            new_urls = [u for u in page_videos if u not in baseline] if baseline else list(page_videos)
            if page_videos and baseline and not new_urls:
                if not getattr(self, "_stale_video_warned", False):
                    self._stale_video_warned = True
                    self.store.log(
                        tid, f"{self.display_name()}页面有 {len(page_videos)} 个视频，"
                             f"但都是提交前就存在的历史视频（本次尚未生成完），继续等待…")
                return False
            # ★ 2026-11-03 根因修复：轻量检测阶段**不再抢先点击**「无水印下载」。
            #   这个点击发生在编排器每 2 秒的轮询里，绕过 collect_stage 的全局
            #   「下载解析窗口」锁；5 个账号在这里同时点按钮、同时发
            #   get_download_info，正是"5 个视频只回传 1 个"的并发冲突源。
            #   下载动作统一收归 collect_stage（串行窗口内执行），这里只负责把任务
            #   转交给完整回收流程：速度损失几秒，成功率大幅提升。
            if not getattr(self, "_fast_detect_hit", False):
                self._fast_detect_hit = True
                self.store.log(tid, f"{self.display_name()} 实时检测到视频已生成，"
                                    f"转入串行回收队列…（依据：{reason}"
                                    f"{'，本次新增 ' + str(len(new_urls)) + ' 个视频源' if new_urls else ''}"
                                    f"{'，另有 ' + str(len(page_videos) - len(new_urls)) + ' 个历史视频' if baseline and page_videos else ''}）")
                self._log_page_diag(tid, "（命中成片）")
            # set_status 是 AccountWorker 的方法，不是 TaskStore 的。
            self.set_status(tid, "downloading", 50,
                            f"{self.display_name()} 检测到视频，正在获取无水印版本…")
            return True
        except (GenerationFailed, GenerationTimeout):
            # ★★ 2026-09-24 BUG 修复（头号）：判死异常**必须向上传播**给编排器，
            #   由 handle_stage_error 决定"审核拒绝直接失败 / 普通失败换账号重试"。
            #   以前它掉进下面那个 `except Exception`，只记一句"轻量检测异常"就
            #   return False —— 编排器下一轮再调、再命中、再抛，同一个任务 25 分钟
            #   里刷了 80 多条一模一样的日志，200 条上限被刷爆、有用信息全被挤掉，
            #   任务自己却一直挂着，最后被字字动画侧超时掐掉（1950s，status 变成
            #   cancelled 而不是 moderation_rejected）。
            raise
        except TaskCancelled:
            raise
        except Exception as e:
            self.store.log(tid, f"{self.display_name()} 轻量检测异常: {e}")
            return False

    def collect_stage(self, tid):
        """回传阶段（由编排器按分镜顺序、提交后约 6 分钟逐个调用）：监测豆包成品 →
        点「无水印下载」→ 捕获 URL/落盘文件 → 下载 → 置 done 回传字字动画。

        进入时 submit_stage 建立的 CDP 会话（self.bridge._ws）仍保留，直接复用。
        本阶段不长期持前台锁：各账号在自己 target 轮询监测；仅点无水印下载按钮那一下
        经 _fg_click_no_watermark 短暂持锁激活本 tab。结束（成功/失败）后 detach。

        ★ 2026-11-03：本阶段独占「无水印下载解析窗口」（全局串行锁），
          见 _NOWM_WINDOW_LOCK 的说明。任何退出路径都在 finally 里释放。
        """
        # ★ 2026-11-14：回收阶段的独立硬闸门（编排器闸门之外第二道防线）。
        _g_ok, _g_why, _g_ready = self._delivery_gate(tid)
        if not _g_ok:
            self.store.log(tid, "回收阶段闸门未通过，拒绝启动回收：%s" % _g_why)
            return
        # 兜底：上一次回收若异常退出可能残留窗口标志，先幂等清理，避免锁被虚占
        try:
            self._nowm_window_release(tid, reason="进入回收前清理")
        except Exception:
            pass
        self._nowm_window_held = False
        self._nowm_window_until = 0.0
        self._nowm_window_retry_after = 0.0
        self._nowm_window_yielded = False
        deadline = getattr(self, "_stage_deadline", None) or (time.time() + 1200)
        # 回收阶段必须有自己的完整预算：_stage_deadline 是"提交时刻 + task_timeout_sec"，
        # 而回收是在提交后 fast_detect_max_wait_sec（默认 600s）才启动的。
        # 于是 task_timeout_sec=1000 时回收只剩约 400s，成片明明快出来了却被判超时
        # （实测日志：22:44 进入回收、22:51 就"生成超时无视频"）。
        # 这里保证回收至少拿到 min_collect_sec（默认 900s）的独立等待时间。
        try:
            _min_collect = float(self.config.get("min_collect_sec", 900) or 0)
        except (TypeError, ValueError):
            _min_collect = 900.0
        # 按时长兜底：回收预算至少要覆盖本任务时长的生成耗时。
        # 旧的固定 900s（15 分钟）保底只到提交后约 19 分钟，30 秒视频还没出片就被判超时。
        _gen_need = float(expected_gen_sec((self.store.get(tid) or {}).get("duration")))
        if _min_collect < _gen_need:
            _min_collect = _gen_need
        if _min_collect > 0 and deadline - time.time() < _min_collect:
            self.store.log(
                tid, f"{self.display_name()} 回收预算不足，延长至 {int(_min_collect)}s "
                     f"（原剩余 {int(max(0, deadline - time.time()))}s）")
            deadline = time.time() + _min_collect
        # ★ 2026-10-13：版权申诉的宽限期也是有效等待预算。轻量检测阶段命中拒绝
        # → 自动申诉（两条对话）→ 转交回收时宽限期可能还没走完；若回收预算短于
        # "宽限截止+300s"，豆包还在消化申诉任务就被判超时，申诉等于白发。
        # 实测事故：18:34:12 申诉发出，18:36:16（宽限截止后 4 秒）被判死。
        _grace_until = float(getattr(self, "_appeal_grace_until", 0.0) or 0)
        if _grace_until > time.time() and deadline < _grace_until + 300:
            self.store.log(
                tid, f"{self.display_name()} 回收预算覆盖申诉宽限期，"
                     f"延长至宽限截止+300s（原剩余 {int(max(0, deadline - time.time()))}s）")
            deadline = _grace_until + 300
        self.set_status(tid, "generating", 45, "豆包生成中（编排器回收中）…")
        # 回收前先把本账号 tab 激活、等页面重新排版：这 6 分钟里前台早已切给别的账号，
        # 非活动 webview 不会渲染生成结果，pageVideos() 会一直为空 → 误判"出片超时"。
        try:
            self._fg_acquire(tid, reason="回收成品")
            self._ensure_foreground(tid, reason="回收成品前")
            self._ensure_injected(tid, retries=1)
            self._wait_page_visible(tid, timeout=25)
        except Exception as e:
            self.store.log(tid, f"回收前激活标签页异常（继续轮询）: {e}")
        finally:
            self._fg_release()
        # submit 与 collect 间隔约 6 分钟，期间 CDP 会话可能断开 / 页面上下文已失效；
        # 强制重新 attach 以重建干净的 JS 执行环境（__dbm hook 等）。
        attached = self._ensure_attached(tid, force_refresh=True, min_interval=0)
        if not attached:
            # 页面上下文彻底无效：尝试导航回原页再重新 attach
            self.store.log(tid, f"{self.display_name()} 页面上下文失效，导航回原页…")
            orig_url = self._eval_safe("window.location.href") or ""
            if orig_url:
                self._eval_safe(f"window.location.href = {js_quote(orig_url)};")
                self.sleep_cancel(tid, 3, step=1)
            attached = self._ensure_attached(tid, force_refresh=False)
            if not attached:
                raise TargetGone(f"{self.display_name()} 页面无法恢复，取消回收")
        try:
            self._collect_loop(tid, deadline)
        finally:
            # 回收阶段结束（成功/失败/异常/取消）后释放会话、前台锁与下载解析窗口
            self._fg_release()
            # ★ 2026-11-03：窗口锁必须无条件释放，否则排队账号全部饿死
            try:
                self._nowm_window_release(tid, reason="回收结束")
            except Exception:
                pass
            try:
                self.bridge.detach()
            except Exception:
                pass

    def _ensure_attached(self, tid, force_refresh=False, min_interval=30):
        """若 CDP 会话不存在（6 分钟空窗被断开 / 重启恢复），重新连接本账号 webview。

        force_refresh=True 时：即使 _ws 仍存活也强制 detach + 重新 attach，
        用于 collect_stage 入口（6 分钟后页面上下文可能已失效但 ws 连接还活着）。

        ⚠️ 强制重连必须节流：编排器的实时轮询每 2 秒就调一次 _fast_detect_video，
        如果不加限制就会每 2 秒 detach+attach 一次，日志里"重新连接"疯狂刷屏、
        几十秒后 webview 直接变成"页面已关闭"，生成好的视频再也取不回来。
        这里保证距上次重连不足 min_interval 秒时不再强制重建，只做 __dbm 存活检查。
        """
        now = time.time()
        if force_refresh and (now - getattr(self, "_last_attach_ts", 0.0)) < min_interval:
            force_refresh = False
        need_reattach = False
        if force_refresh or getattr(self.bridge, "_ws", None) is None:
            need_reattach = True
            if getattr(self.bridge, "_ws", None) is not None:
                try:
                    self.bridge.detach()
                except Exception:
                    pass
            target = self._refresh_target()
            if not target:
                raise TargetGone(f"{self.display_name()}的豆包页面已关闭（回收时无法连接）")
            self.store.log(tid, f"重新连接 {self.display_name()} | {target['url'][:70]}")
            # attach() 会清空网络嗅探到的视频候选。这些 URL 是"豆包到底出片没有"
            # 的唯一可靠证据（页面 <video> 可能因为 webview 冻结而恒空），重连到
            # 同一个会话时不能丢，否则刚抓到的证据一重连就没了。
            _prev_url = ""
            try:
                _prev_url = (getattr(self.bridge, "_ws_target", None) or {}).get("url", "")
            except Exception:
                _prev_url = ""
            _prev_cands = list(getattr(self.bridge, "_mp4_candidates", None) or [])
            self.bridge.attach(target, self._account_dl_dir())
            if _prev_cands and _prev_url and _prev_url == target.get("url"):
                _have = [u for u, _ in self.bridge._mp4_candidates]
                for u, ts in _prev_cands:
                    try:
                        if time.time() - float(ts) < 3600 and u not in _have:
                            self.bridge._mp4_candidates.append((u, ts))
                    except (TypeError, ValueError):
                        continue
            self._last_attach_ts = now
            self._set_tab_token()
            self._keep_active()
            self._eval_safe(build_inject_js_cached(self.selectors))
            # 验证新上下文是否真正可用：检查 __dbm hook 是否存在
            _dbg = self._eval_safe("window.__dbm ? 'ok' : 'dead'")
            if _dbg == "dead":
                self.store.log(tid, f"{self.display_name()} 页面上下文无效，尝试强制刷新…")
                return False  # 调用方负责 page reload
        else:
            # ws 存活但 __dbm 可能已丢失（页面被导航/重载过），强制重新注入
            _dbg = self._eval_safe("window.__dbm ? 'ok' : 'dead'")
            if _dbg == "dead":
                self.store.log(tid, f"{self.display_name()} JS 上下文失效，重新注入…")
                self._eval_safe(build_inject_js_cached(self.selectors))
        return True

    def _claim_err(self, tid, where, exc):
        """记录认领主循环里被吞掉的异常（避免静默超时），并保留最后一次异常供超时信息引用。

        ★ 2026-11-02：原来三处扫盘认领的 except Exception: pass / continue 会把
        stat/copy/claim 过程中的真实异常完全吞掉，导致"成品已落盘却永远命不中"只能安静
        超时、极难排查。这里改为记录日志 + 暂存到 self._last_claim_error。
        """
        msg = f"{where}: {exc}"
        try:
            self._last_claim_error = msg
        except Exception:
            pass
        try:
            self.store.log(tid, f"[claim] {msg}")
        except Exception:
            pass

    def _collect_loop(self, tid, deadline):
        video_url = None
        no_watermark_url = None
        warned = False
        quota_missed = 0
        video_appeared = False
        download_clicked = False
        click_time_for_dl = 0          # 每任务独立计时：初始为0，首次点击下载后设为当前时间-20s
                                        # 必须每次新任务都重置，避免跨任务继承旧时间戳导致误匹配
        fg_attempts = 0                # 前台 hover+点击尝试次数（不限上限，直到 deadline）
        last_fg_attempt_ts = 0.0       # 上次前台尝试时刻（每 12s 一轮）
        fg_min_interval = 8.0          # 前台重试最小间隔（解析失败/久无产出时升至 20s）
        first_click_ts = 0.0           # 首次确认点击无水印按钮的时刻（降频守候计时基准）
        keep_alive_tick = 0
        empty_videos_tick = 0
        reconnect_tried = False   # collect_stage 内仅重连一次，避免反复导航丢失上下文
        page_reloaded = False     # collect_stage 内仅尝试页面重载一次
        baseline_videos = []      # 点击前的页面视频URL基线，用于 capsSince 过滤（防止误过滤无水印URL）
        last_dir_scan_ts = 0.0    # 上次"页面无视频也扫盘"的时刻（避免每轮都 stat 整个目录）
        genfail_hits = 0        # 明确失败消息连续命中次数
        genfail_kind = ""
        genfail_text = ""
        pend_confirm_hits = 0   # 「豆包还在等我确认」连续命中次数（见 awaitingConfirm）
        self._pc_logged = False  # 参数确认态的一次性诊断日志（每任务重置）
        self._fg_cap_logged = False  # 前台重试达到上限的一次性日志（每任务重置）
        self._wm_btn_state_last = ""  # 无水印按钮文案状态（变化时才写日志）
        self._wm_slow_logged = False  # 「降频守候」一次性日志（每任务重置）
        self._collect_reloaded = False  # 整页重载兜底每任务仅一次（每任务重置）
        # ★ 2026-11-14 全面检查修复：这两个一次性标志此前未随任务重置。
        #   worker 按账号长期复用，某账号第一个任务触发补发后，该账号后续
        #   所有任务的回收阶段二次确认 / 目录兜底日志会永久不可达。
        self._collect_reconfirm_done = False
        self._dir_fb_logged = False
        self._last_claim_error = ""     # 认领主循环最后一次被吞异常（2026-11-02，超时信息引用）
        # ★ 2026-11-03：下载解析窗口状态（每任务重置，见 _NOWM_WINDOW_LOCK）
        self._nowm_window_wait_logged = False
        self._nowm_wd_resets = 0       # 90s 看门狗已重置次数（有上限，杜绝无限重试）
        # ★ 2026-11-03：下载前刷新唤醒冻结 webview 的计数（每任务重置）
        self._unfreeze_reload_n = 0
        self._unfreeze_reload_ts = 0.0
        # 等待计时基准：优先用提交时刻（与 6 分钟回收节奏一致），兼容无 submit_ts 的旧任务
        _t0 = self.store.get(tid) or {}
        # 落盘时间窗以「协商完成、真正开始生成」为零点：旧版用 submit_ts
        # （带音频任务比生成开始早 160s+），窗口里别的账号刚下的片子会被
        # 当成「本次新增」认领，正是用户反馈的跨账号串片。
        try:
            click_time = float(_t0.get("generation_ready_ts") or 0) \
                or float(_t0.get("submit_ts") or 0) or time.time()
        except (TypeError, ValueError):
            click_time = time.time()
        # 每次进入 collect_loop 都重新固化下载目录基线，避免跨任务/跨账号时
        # 旧基线导致差集计算错误（ENONTE / 漏判新下载文件）
        _dl_dir_init = self._account_dl_dir()
        self._dl_pre_files = set()
        # ★ 修复（2026-11-02）：下载目录去重改用「路径+大小+修改时间」签名，而非仅按路径。
        #   豆包常把成品固定存成 video.mp4 并覆盖写入同一路径；旧逻辑只按路径差集，
        #   会把「本次新覆盖的 video.mp4」当成任务启动时已存在的旧文件而永久跳过，
        #   成品明明已落盘却永远命不中，任务只能超时（日志实证：video.mp4 8079KB 落盘但未被认领）。
        #   改为 (size, mtime) 签名后，同一路径只要被覆盖（内容变化）就重新纳入候选；
        #   稳定旧文件（含任务启动前就存在的）则按签名一致跳过，不会误认领。
        self._dl_pre_sigs = {}
        if _dl_dir_init and Path(_dl_dir_init).exists():
            self._dl_pre_files = self._scan_video_files(_dl_dir_init)
            for _f in self._dl_pre_files:
                try:
                    _st = Path(_f).stat()
                    self._dl_pre_sigs[_f] = (_st.st_size, int(_st.st_mtime))
                except Exception:
                    pass
        while time.time() < deadline:
            self._close_minutes_panel(tid)
            # 关键：多账号并发时，其他 worker 切走本账号 tab 后，webview 会被 Chromium
            # 冻结/节流（定时器、渲染、网络都被限制），导致豆包页面即使视频已生成也不会
            # 插入 <video> 元素，pageVideos() 永远返回空，任务卡死在 generating。
            # 每 3 次循环（约 9 秒）重新发 Page.setWebLifecycleState("active") +
            # Emulation.setFocusEmulationEnabled，强制本账号 webview 保持 active 渲染。
            # 这两个 CDP 命令只作用于本 worker 自己 attach 的豆包 webview target，
            # 不影响其他 worker 的前台 tab 操作。
            self.check_cancel(tid)
            # ★ 2026-11-03 根因修复：视频已出现后，先抢全局「无水印下载解析窗口」。
            #   抢不到的账号本轮不做任何下载动作（不点按钮、不发 get_download_info），
            #   只保活等待；等前一个账号解析落盘并释放窗口后再依次进入。
            #   这是"5 个任务只回传 1 个"的架构级修复：管理器单进程的
            #   解析/落盘链路一次只能可靠服务一个账号。
            if (video_appeared and not no_watermark_url and not download_clicked
                    and not getattr(self, "_nowm_window_held", False)
                    and not getattr(self, "_nowm_window_yielded", False)
                    and time.time() >= (getattr(self, "_nowm_window_retry_after", 0.0) or 0)):
                if not self._nowm_window_acquire(tid):
                    if not self._nowm_window_wait_logged:
                        self._nowm_window_wait_logged = True
                        _ow = ""
                        with _NOWM_WINDOW_GUARD:
                            _ow = _NOWM_WINDOW_OWNER.get("worker") or ""
                        try:
                            self.store.log(
                                tid, f"[下载窗口] 当前由 {_ow or '其他账号'} 独占解析，"
                                     f"{self.display_name()} 排队等待"
                                     f"（本轮不触发下载，避免并发打断管理器解析）")
                        except Exception:
                            pass
            else:
                self._nowm_window_wait_logged = False
                # ★ 2026-11-03：刚抢到独占下载窗口，先确保本账号豆包页面已唤醒
                #   （并发下被后台化的 webview 需刷新才能重新渲染 <video> 与下载入口），
                #   否则拿着窗口却点不动按钮，时间片一到期就白让位、整批只回传 1 个。
                #   video_appeared 已为真（网络/DOM 确认出片），刷新不会打断生成。
                self._prepare_page_for_download(tid, video_confirmed=video_appeared)
            # 独占时间片到期主动让位（让位后仍可稍后重新排队，绝不无限占锁）
            if getattr(self, "_nowm_window_held", False):
                self._nowm_window_slice_expired(tid)
            self._ensure_task_conversation(tid)
            keep_alive_tick += 1
            if keep_alive_tick % 3 == 0:
                self._keep_active()
            # 网络事件队列 drain（如果 CDP 抖动会抛 ConnectionError，让上层重连）
            try:
                self.bridge.drain_network_events()
            except Exception as e:
                # drain 失败不致命：可能是 ws 临时抖动，记录后继续等下个周期
                self.store.log(tid, f"drain_network_events 失败（忽略）: {e}")
            elapsed = time.time() - click_time
            # 额度耗尽检测：豆包回复"今日视频生成免费次数用完了，你明天再来找我继续吧"
            # 用 _eval_safe 包裹：CDP 临时断开时返回 None 而不是直接抛错让任务失败。
            # 只信 quotaExhausted 强信号；此时任务已 submitted，弱信号误判会让本可成功的
            # 任务失败，故 quotaNotice（"升级会员/请求超限"等易被常驻文案误中）仅记录、不中断。
            qe = self._eval_safe("window.__dbm.quotaExhausted()") or ""
            if qe:
                self.store.log(tid, f"{self.display_name()}额度耗尽: {qe}")
                raise QuotaExceeded(f"{self.display_name()}：{qe}")
            qn = self._eval_safe("window.__dbm.quotaNotice()")
            if qn and quota_missed == 0:
                # 弱提示只在首次出现时记一条诊断日志，不累计、不中断
                quota_missed = 1
                self.store.log(tid, f"页面出现弱额度提示（仅记录，不中断生成）：{qn}")
            # 页面里的视频直链：不再只认顶层 <video src>，改为多源证据判定
            # （深度 <video> / 页面资源时间线 / 网络层 mp4 / 结果卡片 UI 信号）。
            # 只用于判断"是否已出片"，不加入候选列表——这些是带水印的预览。
            _appeared_now, _ev_urls, _ev_reason = self._video_evidence(tid, click_time)
            page_videos = _ev_urls
            # ★ 把页面里出现的视频 src 登记为"带水印预览流"。
            #   后面任何取片分支（JS hook / 网络嗅探 / 兜底直下）都必须先排除它们，
            #   否则就会把带水印预览当成无水印成品下载回传给字字动画。
            #   _video_evidence 的证据里包含"网络层 mp4"，那条可能就是无水印下载流，
            #   所以这里只登记确实来自页面 <video> 元素的部分（deepVideos 命中时
            #   才成立），避免误伤真正的下载地址。
            try:
                _pv = self._preview_url_set()
                _deep = self._eval_safe(
                    "window.__dbm && window.__dbm.deepVideos "
                    "? window.__dbm.deepVideos().map(function(v){return v.src;}) : []",
                    timeout=8) or []
                for u in _deep:
                    if isinstance(u, str) and u.startswith("http"):
                        _pv.add(u)
                # 页面 <video> 的 src 与 _ev_urls 完全一致的那些也是预览流。
                # （_ev_urls 主要来自 deepVideos，命中时两者等价。）
                if _deep:
                    for u in page_videos:
                        if isinstance(u, str) and u.startswith("http"):
                            _pv.add(u)
            except Exception:
                pass
            # 检测视频是否已出现在页面中（只认提交后新增的，排除历史残留视频）
            _baseline = getattr(self, "_submit_video_baseline", None) or set()
            _new_videos = [u for u in page_videos if u not in _baseline] if _baseline else list(page_videos)
            # ★ 2026-11-03：无具体视频源的命中需二次复核（防假阳性提前抢解析窗口）
            if _appeared_now and not video_appeared \
                    and not self._confirm_hit_concrete(tid, page_videos):
                _appeared_now = False
                if not getattr(self, "_ev_flip_logged", False):
                    self._ev_flip_logged = True
                    self.store.log(
                        tid, "视频证据命中但无具体视频源且信号复查不成立，"
                             "判定为生成中占位噪声，本轮不进入下载流程…")
            if not video_appeared and _appeared_now and (
                    not page_videos or not _baseline or _new_videos):
                video_appeared = True
                # ★ 额度计数：视频真实生成完成即计一次（回传成败无关，豆包侧已生成）。
                self._mark_seedance_generated(tid)
                self.store.log(tid, f"检测到视频已出现在页面中（依据：{_ev_reason}） "
                                f"src={(_new_videos or page_videos or ['(无直链)'])[-1][:80]}")
                self._log_page_diag(tid, "（回收命中成片）")
                # 关键兜底：若视频在 collect_stage 启动前已被 _fast_detect_video
                # 成功下载，download_clicked 此时仍为 False（按钮已消失），导致后续
                # "检查落盘文件"的整块代码（第 3278/3348 行）永远不会执行，
                # 文件被白白忽略，循环超时 → DownloadFailed 误报。
                # 在这里加一次"视频刚出现时立即扫盘"，覆盖上述窗口。
                if not download_clicked and not no_watermark_url:
                    dl_dir_check = self._account_dl_dir()
                    if dl_dir_check and Path(dl_dir_check).exists():
                        now_check = self._scan_video_files(dl_dir_check)
                        new_check = self._dl_candidates(dl_dir_check)
                        for nf in sorted(new_check):
                            pf = Path(nf)
                            try:
                                if not pf.exists():
                                    continue
                                # ★ 2026-11-14 回传一致性强化：这是 6 条落盘链路里
                                #   唯一既没有 mtime 下界、也没有带水印 MD5 排除的分支，
                                #   而 _dl_pre_sigs 基线是 collect 启动时刻（提交后约 6
                                #   分钟），窗口内任何别任务/手动放入的残留文件都会被
                                #   当成"本次新增"认领 → 偶发串片。与 L4/L5 对齐补齐。
                                if click_time and pf.stat().st_mtime < click_time - 60:
                                    continue
                                if self._is_watermarked_file(pf):
                                    self.store.log(
                                        tid, f"兜底扫盘候选命中带水印指纹，跳过: {pf.name}")
                                    continue
                                # 别任务的保护副本（dbm_<其他任务id>.mp4）不能当成本任务成品
                                if is_foreign_video_file(str(pf), tid, self.display_name()):
                                    continue
                                # ★ 2026-11-02 修复：已作为某分镜成品交付过的文件一律跳过，
                                #   防止不同分镜回传同一个视频（串片）。
                                if is_video_delivered(str(pf)):
                                    continue
                                # 多账号共用下载目录：已被别认领的文件直接跳过
                                if not claim_download_file(str(pf), tid):
                                    continue
                                fsize = pf.stat().st_size
                                if fsize > 50 * 1024:
                                    # 等写入完成
                                    self.sleep_cancel(tid, 2)
                                    if not pf.exists():
                                        continue
                                    fsize2 = pf.stat().st_size
                                    if fsize2 == fsize and fsize2 > 50 * 1024:
                                        # ★ 内容签名校验（2026-10-20）：封面图假成品拦截
                                        if not _head_is_mp4(pf):
                                            self.store.log(
                                                tid, f"兜底扫盘命中文件内容不是 mp4"
                                                     f"（文件头非 ftyp），跳过: {pf.name}")
                                            continue
                                        safe_dest = self._dest_video_path(dl_dir_check)
                                        claim_download_file(str(safe_dest), tid)
                                        try:
                                            shutil.copy2(str(pf), str(safe_dest))
                                            # ★ 2026-11-02 修复：复制后校验大小，防共享落点
                                            #   被覆盖导致串片。
                                            _dst2 = 0
                                            try:
                                                _dst2 = Path(safe_dest).stat().st_size
                                            except Exception:
                                                pass
                                            if fsize2 and _dst2 != fsize2:
                                                try:
                                                    Path(safe_dest).unlink(missing_ok=True)
                                                except Exception:
                                                    pass
                                                release_download_file(str(safe_dest))
                                                release_download_file(str(pf))
                                                self.store.log(
                                                    tid, f"复制后大小不一致（源 {fsize2} / 目标 {_dst2}），"
                                                         f"疑似落盘文件被覆盖，放弃本次认领: {pf.name}")
                                                continue
                                            self._release_shared_source(str(pf))
                                            self.store.log(tid,
                                                f"视频出现时兜底扫盘命中（prior dl）: "
                                                f"{pf} -> {safe_dest} "
                                                f"({fsize2 // 1024} KB)")
                                        except Exception as e:
                                            self.store.log(tid,
                                                f"兜底 copy 失败: {pf}: {e}")
                                            safe_dest = Path(pf)
                                        self._dl_pre_files.add(nf)
                                        self._dl_pre_files.add(str(safe_dest))
                                        mark_video_delivered(str(safe_dest), tid)
                                        mark_video_delivered(str(pf), tid)
                                        self._finish_done(
                                            tid, safe_dest,
                                            "生成完成（无水印下载文件，提前兜底）")
                                        return
                            except Exception as _ce:
                                self._claim_err(tid, "scan_prior_dl", _ce)
                                continue
            elif not video_appeared and not page_videos:
                # 诊断：page_videos 长时间为空时记录（每 60 秒一次）
                # 帮助判断是"豆包还在生成"还是"webview 被冻结导致 video 不渲染"
                empty_videos_tick += 1
                if empty_videos_tick % 20 == 0:  # 20 * 3s = 60s
                    # 页面不可见时豆包不推进生成、也不渲染 <video>，等再久也没用，
                    # 先把窗口救回 visible 再继续等。
                    self._ensure_window_visible(tid)
                    self.store.log(tid,
                        f"页面未检出成片（已等待 {int(elapsed)}s，四条证据均未命中）。"
                        f"已自动调 _keep_active 保持 active 生命周期。")
                    # 每 3 分钟完整 dump 一次页面现场：iframe / shadow / canvas /
                    # 按钮文案 / 末尾气泡 / 资源时间线，便于事后定位"看得到却检不到"。
                    if empty_videos_tick % 60 == 0:  # 60 * 3s = 180s
                        self._log_page_diag(tid, f"（已等待 {int(elapsed)}s）")
                    # CDP 静默断连兜底：_eval_safe 对断连 WS 返回 None 而不抛异常，
                    # 导致循环一直空转直到 deadline 超时。
                    #
                    # ⚠️ 刷新页面(reload)是破坏性操作：豆包现在出片普遍要 8~15 分钟，
                    # 5 分钟就 reload 会打断正在进行的生成、还把 __dbm 冲掉。
                    # 这里把门槛提到 reload_after_sec（默认 900s，0=永不刷新），
                    # 并且只要网络层已经抓到本次提交后的视频响应就绝不刷新。
                    try:
                        reload_after = float(
                            self.config.get("reload_after_sec", 900) or 0)
                        # 刷新会打断生成：门槛必须晚于本时长的预估生成耗时。
                        # 旧值 900s 正好落在 30 秒视频的生成窗口里，会直接把还在生成的页面冲掉。
                        if reload_after > 0:
                            _gen_need = float(
                                expected_gen_sec((self.store.get(tid) or {}).get("duration")))
                            if reload_after < _gen_need:
                                reload_after = _gen_need
                    except (TypeError, ValueError):
                        reload_after = 900.0
                    if elapsed >= reload_after and not reconnect_tried:
                        reconnect_tried = True
                        try:
                            self._ensure_attached(tid)
                            self.store.log(tid, "CDP 延迟重连成功，继续等待视频出现…")
                        except Exception as e:
                            self.store.log(tid, f"CDP 延迟重连失败（忽略）: {e}")
                        # 重连后若视频仍未出现，尝试强制刷新页面唤醒冻结的 webview
                        if not video_appeared and not page_reloaded:
                            _net_now = self._net_video_since(click_time)
                            if _net_now:
                                self.store.log(
                                    tid, "网络层已捕获本次提交后的视频响应，"
                                         "跳过页面刷新（刷新会打断生成、冲掉 __dbm）")
                            elif reload_after <= 0 or not (self.store.get(tid) or {}).get("conversation_url"):
                                self.store.log(
                                    tid, "已禁用刷新或未保存原任务会话地址，跳过刷新，继续等待")
                            else:
                                page_reloaded = True
                                try:
                                    self.store.log(tid,
                                        f"重连后仍无视频（已等待 {int(time.time()-click_time)}s），"
                                        f"尝试刷新页面唤醒冻结的 webview…")
                                    self.bridge._ws.send("Page.navigate", {
                                        "url": self.store.get(tid)["conversation_url"]}, timeout=20)
                                    self.sleep_cancel(tid, 5, step=1)
                                    self._ensure_attached(tid)
                                    # 本任务独立会话里的成片不能重新纳入历史基线。
                                    self.store.log(tid,
                                        "原任务会话恢复完成，保留发送前基线，继续检测成片…")
                                except Exception as e:
                                    self.store.log(tid, f"页面刷新失败（忽略）: {e}")
            # 【网络层证据】页面 DOM 里没有 <video> 不等于豆包没生成。
            # 实测大量任务 pageVideos() 恒为空、但桥接的网络监听早就抓到了本次提交
            # 之后的 mp4 响应（webview 被 Chromium 冻结时 DOM 不渲染，网络照常走）。
            # 此时必须认定"已出片"并进入前台取片流程，否则只能空转到超时，
            # 用户明明看得到片子却拿不回来。
            if not video_appeared:
                _net_vids = self._net_video_since(click_time)
                if _net_vids:
                    video_appeared = True
                    # ★ 额度计数：视频真实生成完成即计一次（回传成败无关，豆包侧已生成）。
                    self._mark_seedance_generated(tid)
                    self.store.log(
                        tid, f"网络层捕获到本次提交后的视频响应"
                             f"（页面 DOM 未渲染 <video>，按网络证据判定已出片）: "
                             f"{_net_vids[-1][:80]}")
            # 生成失败检测：页面无视频且豆包消息气泡明确说失败。
            #   - 审核拒绝/生成失败：连续 2 次命中即判死（不会再出视频）；
            #   - 系统繁忙：可能自愈，要求连续 3 次且已等待 ≥120s 才判失败。
            # 一旦页面出现 <video> 就清零，绝不在有成品时误判。
            if not page_videos:
                fr = self._gen_failed_effective()
                if fr.get("failed"):
                    genfail_kind = fr.get("kind", "failed")
                    genfail_text = fr.get("text", "")
                    # ★ 2026-09-24：版权/审核拒绝先申诉「我已获得授权」再给一次机会。
                    #   成功就清零命中计数继续等；豆包再次拒绝时申诉次数已用尽 → 判死。
                    if genfail_kind != "busy" and self._copyright_appeal(tid, fr):
                        genfail_hits = 0
                        # ★ 2026-10-13：申诉刚发出，回收预算必须覆盖
                        # "宽限截止+300s"的重新生成等待 —— 否则豆包还在消化申诉，
                        # deadline 先到判"生成超时"，两条申诉等于白发。
                        _gu = float(getattr(self, "_appeal_grace_until", 0.0) or 0)
                        if _gu + 300 > deadline:
                            deadline = _gu + 300
                            self.store.log(
                                tid, f"申诉已发出，回收预算延长至宽限截止+300s"
                                     f"（剩余 {int(max(0, deadline - time.time()))}s），"
                                     f"继续等豆包改写重生成")
                        self.sleep_cancel(tid, 5, step=1)
                        continue
                    need = 3 if genfail_kind == "busy" else 2
                    if genfail_kind != "busy" or elapsed >= 120:
                        genfail_hits += 1
                    else:
                        genfail_hits = 0
                    if genfail_hits >= need:
                        kind_cn = {"moderation": "内容审核拒绝",
                                   "failed": "豆包生成失败",
                                   "busy": "豆包系统繁忙"}.get(genfail_kind, "豆包生成失败")
                        self.store.log(tid,
                            f"{kind_cn}（回收阶段确认无视频产出，将换账号重试）: "
                            f"{genfail_text[:100]}")
                        raise GenerationFailed(
                            f"{self.display_name()}：{kind_cn}：{genfail_text[:80]}",
                            kind=genfail_kind, page_text=genfail_text)
                else:
                    genfail_hits = 0
            # 【卡在"等用户确认"】2026-09-22 新增。豆包现在常常先回一屏「视频生成
            # 参数确认」＋分镜表，结尾说"确认后我再开始生成视频。"，然后等用户在
            # 输入框回复确认。我们已经把确认文本发出去了，但豆包不接茬（既没开始
            # 生成也没报错）时，页面就永远停在那一屏 —— 实测 4 个任务各空转到
            # 1790s 才超时失败。这里在等够 pending_confirm_fail_sec 且连续 2 次
            # 采样都判定"仍在等确认"后提前判死，换账号重来，不再干等半个钟头。
            if not page_videos:
                try:
                    _pc_after = float(
                        self.config.get("pending_confirm_fail_sec", 300) or 0)
                except (TypeError, ValueError):
                    _pc_after = 300.0
                if _pc_after > 0 and elapsed >= _pc_after:
                    ac = self._eval_safe("window.__dbm.awaitingConfirm()") or {}
                    if not getattr(self, "_pc_logged", False):
                        # 一次性的诊断日志：下次再看日志就能一眼知道判定到底走了哪条分支
                        self._pc_logged = True
                        self.store.log(
                            tid, f"参数确认态首次采样（已等待 {int(elapsed)}s）: "
                                 f"{json.dumps(ac, ensure_ascii=False)[:200]}")
                    if ac.get("waiting"):
                        # ★ 2026-09-29 防御性"二次确认"自愈：
                        #   根因已定位——确认文本过长会让豆包把它当成"改写提示词+
                        #   重新生成"的新指令，从而再弹出一屏「视频生成参数确认」。
                        #   即便已把确认文本改短，极端情况下豆包仍可能卡在参数确认、
                        #   未开始生成。这里在判死前用简短确认文本**至多补发一次**
                        #   （每任务仅一次，杜绝循环），豆包接茬即开始生成；补发
                        #   失败则退回原有 pending_confirm_fail 逻辑判死换号。
                        if not getattr(self, "_collect_reconfirm_done", False):
                            self._collect_reconfirm_done = True
                            # ★ 2026-11-14：参考项含参考音频时，回收阶段补发也用
                            #   那句固定的二次确认提示词，让「含音频 → 二次确认」
                            #   规则贯穿协商与回收两个阶段，且不被模型名改写。
                            _rc_has_audio = bool(
                                (self.store.get(tid) or {}).get("audios") or [])
                            if _rc_has_audio and self.config.get(
                                    "audio_second_confirm_enabled", True):
                                _rc_text = str(self.config.get(
                                    "audio_second_confirm_text",
                                    "确认，使用seedance 2.0 fast来生成15秒视频")
                                    or "确认，使用seedance 2.0 fast来生成15秒视频").strip()
                            else:
                                _rc_text = str(self.config.get(
                                    "confirm_generation_text", "确认生成视频")
                                    or "确认生成视频").strip() or "确认生成视频"
                            self.store.log(
                                tid, f"回收阶段检测到豆包仍停在参数确认"
                                     f"（已等 {int(elapsed)}s），用「{_rc_text}」"
                                     f"补发一次（二次确认自愈，每任务仅一次）")
                            try:
                                _rc_ok = self._send_reply_text(
                                    tid, _rc_text, idle_wait=30.0, max_try=2)
                                self.store.log(
                                    tid, f"回收阶段补发确认："
                                         f"{'成功' if _rc_ok else '未生效（退回判死逻辑）'}")
                            except Exception as e:
                                self.store.log(
                                    tid, f"回收阶段补发确认异常（忽略）: {e}")
                            # 给豆包时间受理，重置计数重新观察，不立即判死
                            self.sleep_cancel(tid, 10, step=2)
                            pend_confirm_hits = 0
                            continue
                        pend_confirm_hits += 1
                        if pend_confirm_hits >= 2:
                            self.store.log(
                                tid, f"豆包停在「视频生成参数确认」未开始生成"
                                     f"（已等待 {int(elapsed)}s，确认文本已发送但豆包未接茬；"
                                     f"末条豆包消息: {str(ac.get('last') or '')[:60]}），"
                                     f"不再空等，提前判死换账号重试")
                            raise GenerationFailed(
                                f"{self.display_name()}：豆包等待参数确认未响应"
                                f"（已等 {int(elapsed)}s）",
                                kind="failed", page_text=str(ac.get("last") or ""))
                    else:
                        pend_confirm_hits = 0
            # 【下载目录兜底】页面始终没出现 <video> 时，也要定期扫一次下载目录。
            # 老逻辑里所有扫盘分支都要求 video_appeared 或 download_clicked 为前提，
            # 于是"页面 DOM 变了 / 插件漏检 / 用户或管理器自己点了下载"的情况下，
            # 成品明明已经躺在磁盘上，任务却只会干等到超时失败，片子白白浪费。
            # 这里补一条完全不依赖页面状态的退路（受 dir_fallback_* 配置控制）。
            if not video_appeared and not no_watermark_url and not download_clicked:
                try:
                    fb_after = float(
                        self.config.get("dir_fallback_after_sec", 150) or 0)
                except (TypeError, ValueError):
                    fb_after = 150.0
                if (fb_after > 0 and elapsed >= fb_after
                        and time.time() - last_dir_scan_ts >= 20):
                    last_dir_scan_ts = time.time()
                    if self.config.get("dir_fallback_enabled", True):
                        if self._claim_dir_video(tid, click_time, "页面未检出视频"):
                            return
                    elif not getattr(self, "_dir_fb_logged", False):
                        # ★ 2026-09-20 用户要求：兜底认领已关闭，这里如实报失败。
                        #   原来会直接把下载目录里最新落盘的 video.mp4 认领成
                        #   本任务成品（见 _claim_dir_video 的风险说明）。
                        #   关闭后不再认领，但把疑似成品列出来方便人工捞回。
                        self._dir_fb_logged = True
                        try:
                            self._log_dir_hint(tid, click_time)
                        except Exception:
                            pass
                        self.store.log(
                            tid, f"已等待 {int(elapsed)}s 页面始终未检出视频；"
                                 f"下载目录兜底认领已关闭"
                                 f"（dir_fallback_enabled=false），"
                                 f"不再认领归属不明的 video.mp4，任务按失败处理")
            # 视频出现后：周期性【持锁激活 tab → CDP hover 视频唤出悬浮工具条 →
            # 找/点「无水印下载」】，每 12 秒一轮，不限次数直到拿到 URL/文件或 deadline。
            # 旧逻辑只在后台探测返回 need_click 时才持锁，而该按钮常是 hover 悬浮层，
            # 后台根本探测不到，于是永远进不了点击分支——这是"视频已生成却卡住不下载"
            # 的核心根因。现在不管后台能不能看到按钮，都由前台流程兜底。
            # ★ 2026-10-23：加失败上限。旧逻辑"不限次数直到 deadline"，一旦页面
            #   结构变化（实测 49 轮 button_not_found）就会一直刷前台鼠标轨迹，
            #   既拖慢其它账号也刷爆日志。20 轮足够覆盖懒加载/注入延迟，超过后
            #   停止前台重试，避免无意义死循环。
            if fg_attempts >= 20 and not getattr(self, "_fg_cap_logged", False):
                self._fg_cap_logged = True
                self.store.log(
                    tid, f"{self.display_name()} 前台无水印下载已重试 {fg_attempts} 次"
                         f"仍未成功，停止前台悬停（避免死循环），等待其它通道/超时兜底")
            # ★ 2026-11-02：DOM 级兜底——每轮前台循环先关掉可能弹出的「创建画布」面板，
            #   避免它盖住聊天页导致「无水印下载」按钮消失、悬停/点击落空；
            #   与页面注入的 __installCanvasGuard 看门狗双保险（看门狗负责长间隔兜底，
            #   这里负责点击动作前的即时清理）。
            try:
                self._eval_safe(
                    "window.__dbm && window.__dbm.closeCanvasPanel ? "
                    "window.__dbm.closeCanvasPanel() : null", timeout=8)
            except Exception:
                pass
            # ★ 2026-11-03 深度修复（关键架构修正）：API 自解析独立于按钮点击状态运行。
            #   旧结构把 API 自解析包在「not download_clicked」门槛里——一旦点了
            #   「无水印下载」按钮进入等待，API 复调就被完全停掉；而视频同步到创作
            #   中心的时刻随时可能到来，等待期间恰恰最需要持续复调。
            # ★★ 2026-11-03 v2（每账号独立 API）：本块【不再】要求持有全局下载解析
            #   窗口（_nowm_window_held）。页面内 resolveNoWmViaApi 用的是「当前 webview
            #   自己的 Cookie」调 samantha 创作中心接口，各账号天然是互相独立的 HTTP
            #   会话，可以并发解析、互不挤占；而 _NOWM_WINDOW_LOCK 只是管理器单进程
            #   IPC 按钮链路的限流，把它套在纯 HTTP 自解析上反而让所有账号排队空等
            #   （日志实证：「当前由 账号3 独占解析，账号4 排队等待」期间账号4 明明
            #   已出片却连一次 API 都没调）。现在窗口锁只保留给下方按钮点击路径。
            if video_appeared and not no_watermark_url and \
                    time.time() - getattr(self, "_no_wm_api_ts", 0.0) >= 15:
                self._no_wm_api_ts = time.time()
                try:
                    rr = self._eval_safe(
                        "window.__dbm.resolveNoWmViaApi ? "
                        "window.__dbm.resolveNoWmViaApi() : null",
                        timeout=90) or {}
                except TaskCancelled:
                    raise
                except Exception as e:
                    rr = {"ok": False, "error": f"eval_exc:{e}"}
                if rr.get("ok") and rr.get("url"):
                    _cand_url = rr.get("url")
                    # ★ 2026-10-14：双重校验，避免把带水印预览流或非官方域名
                    #   误当无水印直链回传给主程序（主程序会报
                    #   "下载地址不是当前平台的官方无水印原片流"）。
                    #   1) 带水印预览流过滤：与页面 <video> src 同域名同 path
                    #      的地址一定是带水印的（但带 download=true 的官方下载流
                    #      已在 is_preview_video_url 里豁免，见该函数）。
                    #   2) 官方域名校验：★ 2026-11-03 v2 起与官方 runtime-resolver
                    #      的 U() 完全对齐，不再只认两个 videoweb 域名。
                    _is_preview = False
                    try:
                        _is_preview = is_preview_video_url(
                            _cand_url, self._preview_url_set())
                    except Exception:
                        pass
                    _is_official = False
                    try:
                        from urllib.parse import urlparse, parse_qs
                        _pu = urlparse(_cand_url)
                        _q = parse_qs(_pu.query).get("download", [None])[0]
                        _host = (_pu.hostname or "").lower()
                        _path = (_pu.path or "").lower()
                        _low = str(_cand_url).lower()
                        # 官方 U()：download=true 且满足下列任一即为确认无水印流
                        _is_official = bool(_q == "true" and (
                                _host.endswith(".videoweb-download.doubao.com")
                                or _host == "videoweb-download.doubao.com"
                                or _host.endswith(".videoweb.doubao.com")
                                or _host == "videoweb.doubao.com"
                                or ("doubao.com" in _host and "/download" in _path)
                                or re.search(r"(^|[.-])v\d+-vdl\.doubao\.com$", _host) is not None))
                        # 官方 U() 末条兜底：任意域名同时含 download=true 且
                        # video_mp4 / mime_type=video_mp4 也视为确认无水印流
                        if not _is_official and _q == "true" and (
                                "video_mp4" in _low or "mime_type=video_mp4" in _low):
                            _is_official = True
                    except Exception:
                        pass
                    if _is_preview or not _is_official:
                        self.store.log(tid,
                            f"API 自解析返回的 URL 未通过无水印校验"
                            f"(preview={_is_preview}, official={_is_official})，"
                            f"丢弃: {str(_cand_url)[:90]}")
                        rr = {"ok": False, "error": "url_not_official_no_wm"}
                    else:
                        no_watermark_url = _cand_url
                        self.store.log(tid,
                            f"页面内自解析到无水印直链(node={rr.get('nodeId')}, "
                            f"source={rr.get('source')}, "
                            f"ccMatched={rr.get('ccMatched')}): "
                            f"{str(no_watermark_url)[:90]}")
                if not rr.get("ok"):
                    # ★ 2026-11-03 深度修复：失败日志带齐诊断字段，便于事后定位
                    #   「真实 node_id 为何没拿到 / 接口返回的 code 是什么」。
                    #   - msgResolved 为空 + mniCodes 有值 → message_node_info 没解析到
                    #     asset node_id（已在前端 scanNode 全面兜底，若仍空说明接口体结构变了）；
                    #   - gdiCodes 全为 0 + 无地址 → 视频尚未同步到创作中心（耐心复调即可）；
                    #   - mniRaw 给出 message_node_info 原始响应片段，结构变化时可直接据此调整。
                    _diag = (f"ccTotal={rr.get('ccTotal')} "
                             f"ccMatched={rr.get('ccMatched')} "
                             f"ccIds={rr.get('ccIds')} "
                             f"ccCodes={rr.get('ccCodes')} "
                             f"msgResolved={rr.get('msgResolved')} "
                             f"mniCodes={rr.get('mniCodes')} "
                             f"gdiCodes={rr.get('gdiCodes')} "
                             f"mniRaw={rr.get('mniRaw')}")
                    self.store.log(tid,
                        f"页面内自解析无水印直链失败: {rr.get('error')} | {_diag}，"
                        f"继续复调等待（视频可能仍在同步到创作中心）")
            # ★ 2026-11-03：只有拿到全局「下载解析窗口」的账号才能触发下载动作。
            #   其余账号即使已出片也绝不并发点按钮 / 并发调 get_download_info，
            #   否则管理器解析通道被挤爆，整批只有 1 个能落盘（本次事故根因）。
            if video_appeared and not no_watermark_url and \
                    fg_attempts < 20 and \
                    not download_clicked and \
                    getattr(self, "_nowm_window_held", False) and \
                    time.time() - last_fg_attempt_ts >= fg_min_interval:
                last_fg_attempt_ts = time.time()
                # ★ 2026-10-25 状态感知重试节奏：
                #   「解析中…/下载中…」= 管理器 resolver 正在工作，跳过本轮点击；
                #   「解析失败」或点击后 30s 仍无合格产物 = 豆包暂未签发无水印
                #   （限流/未同步创作中心），降频到 20s 守候——此时盲点只会经
                #   resolver u() 兜底再触发一次带水印下载，白白污染下载目录。
                _skip_click = False
                try:
                    _bs = self._eval_safe(
                        "window.__dbm.noWatermarkBtnState ? "
                        "window.__dbm.noWatermarkBtnState() : null",
                        timeout=8) or {}
                except Exception:
                    _bs = {}
                _bs_text = str((_bs or {}).get("text") or "")
                if _bs.get("found") and _bs_text and _bs_text != "无水印下载" \
                        and _bs_text != self._wm_btn_state_last:
                    self._wm_btn_state_last = _bs_text
                    self.store.log(tid, f"无水印按钮状态: 「{_bs_text}」")
                if "解析中" in _bs_text or "下载中" in _bs_text:
                    _skip_click = True
                elif "解析失败" in _bs_text:
                    fg_min_interval = 20.0
                    _skip_click = True
                elif download_clicked and first_click_ts \
                        and time.time() - first_click_ts > 30:
                    if fg_min_interval != 20.0:
                        fg_min_interval = 20.0
                    if not self._wm_slow_logged:
                        self._wm_slow_logged = True
                        self.store.log(
                            tid, "已点击无水印按钮超 30s 仍未产出合格文件，豆包可能"
                                 "暂未签发无水印（限流/未同步创作中心），转为 20s "
                                 "间隔守候（避免盲点触发兜底带水印下载）")
                if _skip_click:
                    continue
                fg_attempts += 1
                # ★ 2026-11-03：每 5 次前台尝试仍未拿到直链，重新唤醒可能被冻结的
                #   webview（刷新会话页面）。并发下单个账号的 webview 易被后台化，
                #   仅靠 keep_active 不足以让 fiber 重新 hydrate，刷新可将其救回。
                #   video_appeared 已为真，刷新安全。
                if not no_watermark_url and fg_attempts % 5 == 0:
                    # allow_refresh=True：每 5 次前台尝试仍未拿到直链，刷新兜底唤醒
                    # 冻结 webview（仅窗口持有者、video_appeared 已确认，刷新安全）。
                    self._prepare_page_for_download(
                        tid, video_confirmed=video_appeared, allow_refresh=True)
                # ★ 2026-11-03 深度修复：API 自解析已前移为独立复调块（与按钮点击状态
                #   完全解耦，见上方），这里只负责前台 hover/点击「无水印下载」按钮。
                #   API 已解析到直链时本块已被外层 gate（not no_watermark_url）跳过。
                if not no_watermark_url:
                    baseline_videos = self._eval_safe("window.__dbm.pageVideos()") or []
                    try:
                        cr = self._fg_click_no_watermark(tid, baseline_videos)
                    except TaskCancelled:
                        raise
                    except Exception as e:
                        cr = {"ok": False, "reason": f"fg_click_exc:{e}"}
                        self.store.log(tid, f"前台点击无水印下载异常: {e}")
                    if cr.get("ok") and cr.get("url"):
                        no_watermark_url = cr.get("url")
                        self.store.log(tid,
                            f"前台获取到无水印URL: {str(no_watermark_url)[:80]}")
                    elif cr.get("ok") and cr.get("started") \
                            and cr.get("confirmed", True) is False \
                            and cr.get("file_path"):
                        # ★ 没点到「无水印下载」按钮却冒出一个文件：来源不可信
                        #   （可能是用户手动点的"下载"=带水印，或别的账号刚下的片子）。
                        #   2026-09-19 水印修复：宁可放弃这一轮继续点，也不回传带水印视频。
                        try:
                            self._release_shared_source(cr.get("file_path"))
                        except Exception:
                            pass
                        try:
                            release_download_file(str(cr.get("file_path")))
                        except Exception:
                            pass
                        self.store.log(
                            tid, f"第{fg_attempts}次：未定位到「无水印下载」按钮却出现文件 "
                                 f"{str(cr.get('file_path'))[-40:]}，来源不可信，"
                                 f"放弃该候选继续重试（避免回传带水印视频）")
                    elif cr.get("ok") and cr.get("started"):
                        # 悬停/点击已触发浏览器侧下载（下载事件/落盘/页面内脚本下载），
                        # 时间窗放宽到 20s 前，覆盖本次前台动作内部的耗时
                        if not download_clicked:
                            click_time_for_dl = time.time() - 20
                            first_click_ts = time.time()
                            # ★ 2026-11-03：记录本次真实点击时间，供看门狗节流重击
                            #   （距上次点击 <120s 不再重击，避免重启管理器 resolver 打断同步）。
                            self._last_btn_click_ts = time.time()
                            self._nowm_resolve_logged = False
                            self._nowm_wait_logged = False
                            self.store.log(tid,
                                f"无水印下载已触发（{cr.get('how')}），等待文件落盘/URL…")
                        else:
                            self.store.log(tid,
                                f"第{fg_attempts}次前台动作再次触发下载（{cr.get('how')}）")
                        download_clicked = True
                        # _download_started 已确认本地文件存在，立即 copy 保护，避免 Electron 清理
                        fp = cr.get("file_path") or ""
                        if fp and Path(fp).exists():
                            # ★ 内容签名校验（2026-10-20）：落盘文件可能实为封面图
                            #   （2.4MB PNG 假成品），copy 回传前必须验文件头。
                            if not _head_is_mp4(fp):
                                self.store.log(
                                    tid, f"疑似落盘文件内容不是 mp4（文件头非 ftyp），"
                                         f"不作为成品交付，继续等待其他渠道: "
                                         f"{str(fp)[-50:]}")
                            elif self._is_watermarked_file(fp):
                                # ★ 2026-10-25：MD5 命中 fiber 带水印指纹
                                #   （download_filehash 等）——resolver u() 兜底
                                #   误发的带水印文件，拒收继续等真无水印。
                                self.store.log(
                                    tid, f"落盘文件 MD5 命中页面带水印指纹"
                                         f"（带水印预览同体），拒收继续等待: "
                                         f"{str(fp)[-50:]}")
                            else:
                                dl_dir = self._account_dl_dir()
                                safe_dest = self._dest_video_path(dl_dir)
                                claim_download_file(str(safe_dest), tid)
                                try:
                                    shutil.copy2(fp, str(safe_dest))
                                    self._release_shared_source(fp)
                                    self.store.log(tid,
                                        f"直接 copy 已检测到的无水印文件: {fp} -> {safe_dest}"
                                        f" ({Path(fp).stat().st_size // 1024} KB)")
                                    mark_video_delivered(str(safe_dest), tid)
                                    mark_video_delivered(str(fp), tid)
                                    self._finish_done(
                                        tid, safe_dest,
                                        "生成完成（无水印下载文件）")
                                    return
                                except Exception as e:
                                    self.store.log(tid, f"直接 copy 失败（忽略）: {fp}: {e}")
                    else:
                        self.store.log(tid,
                            f"第{fg_attempts}次前台悬停/点击未触发下载"
                            f"(reason={cr.get('reason')})，稍后继续 "
                            f"diag={json.dumps(cr.get('diag') or {}, ensure_ascii=False)[:400]}")
                        # ★ 2026-10-25：按钮确认命中并点击但无下载信号（resolver
                        #   解析失败，或管理器带外下载对插件不可见）——转入"已点击
                        #   待落盘"监视，管理器产物落盘时由下方扫盘分支接管；
                        #   扫盘认领带 MD5 水印指纹排除，带水印预览同体一律拒收。
                        if cr.get("clicked") and not download_clicked:
                            download_clicked = True
                            click_time_for_dl = time.time() - 20
                            first_click_ts = time.time()
                            self.store.log(tid,
                                "已确认点击「无水印下载」按钮，等待管理器解析/落盘"
                                "（落盘认领带带水印指纹校验，非无水印拒收）…")
                        # ★ 2026-10-24：整页重载一次性兜底。
                        #   SPA 导航进入会话时，管理器的注入器/懒渲染可能整体缺席：
                        #   线上实测（01:17-01:23）卡片已出片但 <video>=0、注入按钮
                        #   不存在、播放图标也未挂载，20 轮 hover 全落空；
                        #   而整页重载后 <video> 与注入按钮都直接出现。
                        #   第 4 次失败且页面仍无 <video>、未触发过下载时重载一次。
                        if not self._collect_reloaded and fg_attempts >= 4 \
                                and not download_clicked:
                            try:
                                _vc = int(self._eval_safe(
                                    "window.__dbm && window.__dbm.deepVideos "
                                    "? window.__dbm.deepVideos().length : 0",
                                    timeout=10) or 0)
                            except Exception:
                                _vc = 0
                            if _vc <= 0:
                                self._collect_reloaded = True
                                self.store.log(
                                    tid, f"{self.display_name()} 页面始终无 <video>/无水印按钮，"
                                         f"整页重载一次以恢复成片卡片渲染…")
                                try:
                                    self._eval_safe("location.reload()", timeout=5)
                                except Exception:
                                    pass
                                self.sleep_cancel(tid, 8, step=1)
                                try:
                                    self._eval_safe(
                                        build_inject_js_cached(self.selectors),
                                        timeout=15)
                                except Exception:
                                    pass
                                continue
                        # 前2次及此后每5次做一次全页按钮扫描，便于从日志判断页面真实结构
                        if fg_attempts <= 2 or fg_attempts % 5 == 0:
                            all_btns = self._eval_safe(
                                "window.__dbm.scanAllButtons()") or []
                            wm = [b for b in all_btns
                                  if "水印" in (b.get("text", "") + b.get("label", ""))]
                            dlb = [b for b in all_btns
                                   if "下载" in (b.get("text", "") + b.get("label", ""))]
                            self.store.log(tid,
                                f"页面按钮扫描: 含'水印'的={wm[:5]}, 含'下载'的={dlb[:5]}")
            # ★ 2026-11-02 修复：管理器「无水印下载」按钮卡死自愈（根治 1788s 空等）。
            #   管理器按钮内部 resolver（get_download_info）偶发返回空 / 视频 asset 尚未
            #   同步到创作中心，按钮会停在「解析中…」且不产出文件。原逻辑一旦把按钮点击
            #   记为 download_clicked，上方恢复块（含页面内 API 自解析重试）被「not
            #   download_clicked」永久跳过，只剩下方扫盘等待 → 1788s 超时失败。
            #   看门狗：点击后 >90s 仍无无水印 URL/文件，且按钮仍卡「解析中…」（非
            #   「下载中…」这种正常下载中），判定管理器端卡死，清除 download_clicked 让
            #   恢复块重新进入——重新跑 API 自解析（asset 同步后即可拿直链，直接
            #   http_download 绕开卡死按钮），按钮脱离「解析中…」后也会被再次点击触发
            #   本地下载。仅当「下载中…」或已有新文件时才不重置，避免打断正常下载。
            # ★ 2026-11-03 深度修复：停止「重击按钮反复打断管理器解析」的破坏行为。
            #   日志实证：点「无水印下载」→ 按钮「解析中…」→ 约 90s 后退回「无水印下载」
            #   （管理器自带 ~90s 超时，内部 resolver 自行放弃）→ 90s 看门狗重置并再次点击 →
            #   无限重启管理器 resolver，永远跑不完；若视频需 >90s 同步到创作中心，则管理器
            #   路径注定失败。正确做法：
            #   ① 按钮处于「解析中…/下载中…」时：绝不重置、绝不重击，耐心守候（仅在该态
            #      持续超过 10 分钟才判定管理器卡死、优雅让位）；
            #   ② 按钮已退回空闲/「解析失败」：管理器 resolver 已自行放弃，此时靠页面内
            #      API 自解析（每 15s 复调、耐心等待视频同步到创作中心）才是正解，不再无脑
            #      重击按钮——仅当距上次点击 ≥120s 才给按钮一次 nudge 重新触发解析。
            if (download_clicked and not no_watermark_url and first_click_ts
                    and time.time() - first_click_ts > 90):
                _btn_txt = ""
                try:
                    _bs_now = self._eval_safe(
                        "window.__dbm.noWatermarkBtnState ? "
                        "window.__dbm.noWatermarkBtnState() : null", timeout=8) or {}
                    _btn_txt = str((_bs_now or {}).get("text") or "")
                except Exception:
                    pass
                # ① 管理器正在解析/下载中：绝不打断、绝不重置（核心修复）
                if "解析中" in _btn_txt or "下载中" in _btn_txt:
                    _resolve_elapsed = time.time() - (first_click_ts or time.time())
                    if _resolve_elapsed <= 600:
                        if not getattr(self, "_nowm_resolve_logged", False):
                            self._nowm_resolve_logged = True
                            self.store.log(
                                tid, f"管理器「无水印下载」处于「{_btn_txt}」，视频可能"
                                     f"仍在同步到创作中心，耐心守候解析（不打断、不重置）…")
                        if "下载中" in _btn_txt:
                            self._nowm_resolve_logged = False  # 进入下载说明快好了，重置心跳
                        # 不打断、不重置：自然落到下方文件/URL 检测，下一轮继续守候
                    else:
                        # 超过 10 分钟仍解析中：管理器确实卡死，优雅释放窗口让位
                        self.store.log(
                            tid, "管理器「无水印下载」解析超过 10 分钟无产物，判定卡死，"
                                 "释放解析窗口让位给排队账号（本任务保留守候/扫盘）")
                        self._nowm_window_release(tid, reason="解析超时让位")
                        self._nowm_window_retry_after = time.time() + 60
                        first_click_ts = 0
                        download_clicked = False
                # ② 按钮已退回空闲/「解析失败」：管理器 resolver 自行放弃。
                #    优先靠 API 自解析（每 15s 复调）推进；仅节流地给按钮一次 nudge。
                elif "下载中" not in _btn_txt:
                    _has_new_file = False
                    try:
                        _dd = self._account_dl_dir()
                        if _dd and Path(_dd).exists():
                            for _nf in self._dl_candidates(_dd):
                                try:
                                    _pf = Path(_nf)
                                    if (_pf.exists()
                                            and _pf.stat().st_mtime >= first_click_ts - 5
                                            and _pf.stat().st_size > 50 * 1024
                                            and not is_foreign_video_file(
                                                str(_pf), tid, self.display_name())
                                            and not is_video_delivered(str(_pf))):
                                        _has_new_file = True
                                        break
                                except Exception:
                                    pass
                    except Exception:
                        pass
                    if not _has_new_file:
                        _since_click = time.time() - (getattr(self, "_last_btn_click_ts", 0) or 0)
                        if _since_click < 120:
                            # 节流守候：靠 API 自解析推进，不重置、不重击（避免重启管理器
                            # resolver 打断创作中心同步），下一轮继续复调。
                            if not getattr(self, "_nowm_wait_logged", False):
                                self._nowm_wait_logged = True
                                self.store.log(
                                    tid, "管理器按钮已空闲但 API 自解析也未命中，继续复调"
                                         f"API 等待视频同步到创作中心（距上次点击 {int(_since_click)}s，"
                                         f"暂不重击以免打断同步）…")
                            # 不重置 download_clicked，避免重复进入点击分支；保持 API 复调即可
                        else:
                            # 已超过 120s，给管理器按钮一次 nudge（重击）重新触发解析
                            self._last_btn_click_ts = time.time()
                            self._nowm_wd_resets = getattr(self, "_nowm_wd_resets", 0) + 1
                            if self._nowm_wd_resets > 6:
                                # 多次 nudge 仍无产物：释放窗口让位，避免拖死排队账号
                                self.store.log(
                                    tid, "无水印下载按钮多次重击仍无产物，停止重试，"
                                         "释放解析窗口让位给排队账号（本任务保留守候/扫盘）")
                                self._nowm_window_release(tid, reason="多次重击无产物")
                                self._nowm_window_retry_after = time.time() + 60
                                first_click_ts = 0
                                download_clicked = False
                            else:
                                self.store.log(
                                    tid, "管理器按钮已空闲，重击一次「无水印下载」重新触发解析"
                                         f"（第 {self._nowm_wd_resets}/6 次 nudge）…")
                                download_clicked = False
                                first_click_ts = 0
                                fg_attempts = 0
                                self._fg_cap_logged = False
            # 若已点击下载按钮，检查 JS hook 截获 + 网络请求 + 浏览器下载事件 + 落盘文件
            if download_clicked and not no_watermark_url:
                # 0. 页面下载通道 hook（a.click/window.open/fetch/xhr），每轮都查
                # 使用 baseline_videos（点击前快照）而非当前 page_videos，避免无水印URL被误过滤
                caps = self._eval_safe(
                    f"window.__dbm.capsSince({int(click_time_for_dl * 1000)}, {json.dumps(baseline_videos, ensure_ascii=False)})") or []
                for c in caps:
                    u = (c or {}).get("url", "")
                    if u and self._cap_is_video(u):
                        no_watermark_url = u
                        self.store.log(tid,
                            f"页面 hook 捕获无水印URL(via={c.get('via')}): {u[:80]}")
                        break
                # 每轮都 drain，CDP 事件队列里的新视频响应/下载进展及时取出
                try:
                    self.bridge.drain_network_events()
                except Exception:
                    pass
                # 1. 检查网络请求中的新视频URL（不依赖 page_videos 过滤）
                if not no_watermark_url:
                    # ★★ 排除带水印预览流（2026-09-19 根因）：
                    #    旧代码直接取"点击后出现的最后一条 mp4"，而那条往往是页面
                    #    <video> 的预览流 → 下载并回传了带水印版本。
                    _prev2 = self._preview_url_set()
                    try:
                        _wm_u2 = set(
                            (self._watermark_fingerprints() or {}).get("urls") or [])
                    except Exception:
                        _wm_u2 = set()
                    new_candidates = [
                        u for u, ts in self.bridge._mp4_candidates
                        if ts >= click_time_for_dl - 2
                        and u.startswith("http")
                        and not is_preview_video_url(u, _prev2)
                        and not (_wm_u2 and is_preview_video_url(u, _wm_u2))
                    ]
                    if new_candidates:
                        # 优先挑带 Content-Disposition: attachment 的——那是真正的
                        # "下载"响应；普通 video/mp4 多半只是页面播放。
                        _meta = getattr(self.bridge, "_mp4_meta", None) or {}
                        _att = [u for u in new_candidates
                                if (_meta.get(u) or {}).get("attachment")]
                        no_watermark_url = (_att[-1] if _att else new_candidates[-1])
                        self.store.log(tid, f"从网络请求中捕获到下载URL"
                                        f"（已排除预览流，attachment={bool(_att)}）: "
                                        f"{no_watermark_url[:80]}")
                # 2. 浏览器下载事件检测（Page.downloadProgress completed）：
                #    不依赖 CDP suggestedFilename 构建路径（Electron 实际落盘文件名可能不同），
                #    改为扫描下载目录找最新 mp4 文件，发现后立即复制保护，防止 Electron 清理。
                if not no_watermark_url:
                    dl_dir = self._account_dl_dir()
                    if dl_dir and Path(dl_dir).exists():
                        now_files = self._scan_video_files(dl_dir)
                        new_files = self._dl_candidates(dl_dir)
                        if new_files:
                            # 取最新修改时间的文件（不依赖 CDP 报告的文件名）
                            best = None
                            best_mtime = 0.0
                            # 按修改时间倒序挑第一个"能被本任务认领"的新文件：
                            # 多账号并发时下载目录是共用的，最新文件可能是别的账号的
                            cands = []
                            for nf in new_files:
                                pf = Path(nf)
                                try:
                                    if not pf.exists():
                                        continue
                                    # 别任务的保护副本（dbm_<其他任务id>.mp4）不能当成本任务成品
                                    if is_foreign_video_file(str(pf), tid, self.display_name()):
                                        continue
                                    # ★ 2026-11-02 修复：已作为某分镜成品交付过的文件
                                    #   （含本账号/别账号的 <账号>_<时间>.mp4 保护副本）一律跳过，
                                    #   防止不同分镜回传同一个视频（串片）。
                                    if is_video_delivered(str(pf)):
                                        continue
                                    st = pf.stat()
                                    if st.st_size > 50 * 1024:
                                        cands.append((st.st_mtime, pf))
                                except Exception:
                                    continue
                            for mtime, pf in sorted(cands, key=lambda x: x[0], reverse=True):
                                if mtime < click_time_for_dl - 5:
                                    break
                                # ★ 内容签名校验（2026-10-20）：封面图假成品拦截
                                if not _head_is_mp4(pf):
                                    self.store.log(
                                        tid, f"下载事件候选文件内容不是 mp4"
                                             f"（文件头非 ftyp），跳过: {pf.name}")
                                    continue
                                # ★ 2026-10-25：MD5 水印指纹排除（resolver u()
                                #   兜底会把带水印 download_url 误发下载）
                                if self._is_watermarked_file(pf):
                                    self.store.log(
                                        tid, f"下载事件候选文件 MD5 命中带水印指纹"
                                             f"（带水印预览同体），拒收: {pf.name}")
                                    continue
                                if claim_download_file(str(pf), tid):
                                    best, best_mtime = pf, mtime
                                    try:
                                        best_size = pf.stat().st_size
                                    except Exception:
                                        best_size = 0
                                    break
                                self.store.log(tid, f"跳过已被其他任务认领的文件: {pf.name}")
                            if best and best_mtime >= click_time_for_dl - 5:
                                safe_dest = self._dest_video_path(dl_dir)
                                claim_download_file(str(safe_dest), tid)
                                try:
                                    shutil.copy2(str(best), str(safe_dest))
                                    # ★ 2026-11-02 修复：复制后立即校验大小，防止复制过程中
                                    #   共享落点 video.mp4 被下一分镜覆盖写入导致内容错乱（串片）。
                                    _dst_size = 0
                                    try:
                                        _dst_size = Path(safe_dest).stat().st_size
                                    except Exception:
                                        pass
                                    if best_size and _dst_size != best_size:
                                        try:
                                            Path(safe_dest).unlink(missing_ok=True)
                                        except Exception:
                                            pass
                                        release_download_file(str(safe_dest))
                                        release_download_file(str(best))
                                        self.store.log(
                                            tid, f"复制后大小不一致（源 {best_size} / 目标 {_dst_size}），"
                                                 f"疑似落盘文件被覆盖，放弃本次认领并重新检测: {pf.name}")
                                        continue
                                    self._release_shared_source(str(best))
                                    self.store.log(tid,
                                        f"下载事件确认无水印文件（已复制保护）: "
                                        f"{best} -> {safe_dest} ({best.stat().st_size // 1024} KB)")
                                    self._dl_pre_files.add(str(best))
                                    self._dl_pre_files.add(str(safe_dest))
                                    mark_video_delivered(str(safe_dest), tid)
                                    mark_video_delivered(str(best), tid)
                                    self._finish_done(
                                        tid, safe_dest,
                                        "生成完成（无水印下载文件）")
                                    return
                                except Exception as e:
                                    self.store.log(tid,
                                        f"复制下载文件失败（忽略）: {best} -> {safe_dest}: {e}")
                # 3. 检查本地下载目录是否有新增的视频文件
                #    （"无水印下载"按钮可能直接触发浏览器下载到磁盘）
                #    一旦检测到，立即 copy2 到 dbm_{tid}.mp4 保护文件，防止 Electron 后续清理。
                if not no_watermark_url:
                    dl_dir = self._account_dl_dir()
                    if dl_dir and Path(dl_dir).exists():
                        now_files = self._scan_video_files(dl_dir)
                        new_files = self._dl_candidates(dl_dir)
                        for nf in sorted(new_files):
                            pf = Path(nf)
                            try:
                                if not pf.exists():
                                    continue
                                # 别任务的保护副本（dbm_<其他任务id>.mp4）不能当成本任务成品
                                if is_foreign_video_file(str(pf), tid, self.display_name()):
                                    continue
                                # ★ 2026-11-02 修复：已作为某分镜成品交付过的文件一律跳过，
                                #   防止不同分镜回传同一个视频（串片）。
                                if is_video_delivered(str(pf)):
                                    continue
                                # 多账号共用下载目录：已被别认领的文件直接跳过
                                if not claim_download_file(str(pf), tid):
                                    continue
                                fsize = pf.stat().st_size
                                mtime = pf.stat().st_mtime
                                # 文件必须是点击后创建的，且大小够（>50KB）
                                if mtime >= click_time_for_dl - 5 and fsize > 50 * 1024:
                                    # 等待文件写入完成（大小稳定）
                                    self.sleep_cancel(tid, 2)
                                    # 二次验证：文件仍未被 Electron/浏览器清理
                                    if not pf.exists():
                                        self.store.log(tid,
                                            f"下载文件已被清理，跳过: {nf}")
                                        continue
                                    fsize2 = pf.stat().st_size
                                    if fsize2 == fsize and fsize2 > 50 * 1024:
                                        # ★ 内容签名校验（2026-10-20）：封面图假成品拦截
                                        if not _head_is_mp4(pf):
                                            self.store.log(
                                                tid, f"落盘文件内容不是 mp4"
                                                     f"（文件头非 ftyp），跳过: {pf.name}")
                                            self._dl_pre_files.add(nf)
                                            continue
                                        # ★ 2026-10-25：MD5 水印指纹排除
                                        #   （带水印预览同体拒收，防 resolver 兜底误发）
                                        if self._is_watermarked_file(pf):
                                            self.store.log(
                                                tid, f"落盘文件 MD5 命中带水印指纹"
                                                     f"（带水印预览同体），拒收: {pf.name}")
                                            self._dl_pre_files.add(nf)
                                            continue
                                        # 立即复制成 <账号名>_<时间>.mp4 保护，防止原文件被清理
                                        safe_dest = self._dest_video_path(dl_dir)
                                        claim_download_file(str(safe_dest), tid)
                                        try:
                                            shutil.copy2(str(pf), str(safe_dest))
                                            # ★ 2026-11-02 修复：复制后校验大小，防共享落点
                                            #   被覆盖导致串片。
                                            _dst2 = 0
                                            try:
                                                _dst2 = Path(safe_dest).stat().st_size
                                            except Exception:
                                                pass
                                            if fsize2 and _dst2 != fsize2:
                                                try:
                                                    Path(safe_dest).unlink(missing_ok=True)
                                                except Exception:
                                                    pass
                                                release_download_file(str(safe_dest))
                                                release_download_file(str(pf))
                                                self.store.log(
                                                    tid, f"复制后大小不一致（源 {fsize2} / 目标 {_dst2}），"
                                                         f"疑似落盘文件被覆盖，放弃本次认领: {pf.name}")
                                                continue
                                            self._release_shared_source(str(pf))
                                            actual_path = str(safe_dest)
                                            self.store.log(tid,
                                                f"检测到下载文件已落盘并复制保护: "
                                                f"{pf} -> {safe_dest} "
                                                f"({fsize2 // 1024} KB)")
                                        except Exception as e:
                                            self.store.log(tid,
                                                f"复制保护失败，直接使用原文件: {pf}: {e}")
                                            actual_path = str(pf)
                                        # 更新基线，防止本轮后续迭代重复检测同一文件
                                        self._dl_pre_files.add(nf)
                                        self._dl_pre_files.add(actual_path)
                                        mark_video_delivered(actual_path, tid)
                                        mark_video_delivered(str(pf), tid)
                                        self._finish_done(
                                            tid, actual_path,
                                            "生成完成（无水印下载文件）")
                                        return
                            except Exception as _ce:
                                self._claim_err(tid, "scan_dl", _ce)
                                continue
            # 只使用无水印URL，不回退到带水印的视频流地址
            # ★ 2026-11-03 深度修复：探测带当前账号 Cookie（官方下载直链常需鉴权），
            #   且探测失败时拉黑并清空 no_watermark_url，让 API 自解析重新签发新直链。
            #   旧逻辑 probe 失败后 URL 永久占位、每轮空转直到超时——这是"解析到直链
            #   却始终下不下来"的死角，也是"确保每次下载都能成功"必须堵住的漏洞。
            _probe_ok = False
            if no_watermark_url:
                try:
                    _probe_cookies = self.bridge.get_cookies_header()
                except Exception:
                    _probe_cookies = None
                try:
                    _probe_ok = bool(self._probe_video(
                        no_watermark_url, cookies=_probe_cookies))
                except Exception:
                    _probe_ok = False
                if not _probe_ok:
                    _bad = getattr(self, "_bad_cap_urls", None)
                    if _bad is None:
                        _bad = self._bad_cap_urls = set()
                    _bad.add(no_watermark_url)
                    self.store.log(
                        tid, "无水印直链探测失败（HEAD/Range 未确认为视频，可能是"
                             "鉴权失效或临时 404），丢弃并重新解析: "
                             + str(no_watermark_url)[:90])
                    no_watermark_url = None
                    video_url = None
            if no_watermark_url and _probe_ok:
                video_url = no_watermark_url
                # 立即下载验证：URL 可能截获到 API 端点等非视频链接
                self.set_status(tid, "downloading", 92, "下载无水印视频…")
                download_dir = self._account_dl_dir()
                Path(download_dir).mkdir(parents=True, exist_ok=True)
                dest = self._dest_video_path(download_dir)
                cookies = self.bridge.get_cookies_header()
                self.store.log(tid, f"下载无水印视频: {video_url[:100]}")
                try:
                    http_download(video_url, str(dest), cookies=cookies,
                                  cancel_check=lambda: self.check_cancel(tid))
                    size = dest.stat().st_size
                except Exception as e:
                    raise DownloadFailed(
                        f"无水印视频下载失败（网络/IO）：{e}。视频仍在 {self.display_name()} 对话中，"
                        f"不自动重新生成，可手动下载后重试本任务。")
                # 内容签名校验：豆包成片统一 mp4，文件头 4~8 字节必须是 ftyp。
                # 挡住"体积够大但实际是图片/网页"的假成品（2026-10-12：3MB .jpg~tp
                # 通过了 _probe_video HEAD 探测，被存成 .mp4 的图片）。
                _head = b""
                try:
                    with open(dest, "rb") as _fh:
                        _head = _fh.read(16)
                except Exception:
                    pass
                _looks_video = len(_head) >= 8 and _head[4:8] == b"ftyp"
                if size < 50 * 1024 or not _looks_video:
                    # 假视频 URL（如 API 端点/图片），加入黑名单并 invalidate，继续等下一个
                    bad = getattr(self, "_bad_cap_urls", None)
                    if bad is None:
                        bad = self._bad_cap_urls = set()
                    bad.add(video_url)
                    _why = (f"{size} 字节" if size < 50 * 1024
                            else f"内容不是视频（文件头 {_head[:8]!r}，{size} 字节）")
                    self.store.log(tid,
                        f"下载内容无效（{_why}），URL 已加入黑名单，继续等待其他渠道: {video_url[:80]}")
                    no_watermark_url = None
                    video_url = None
                    try:
                        dest.unlink(missing_ok=True)
                    except Exception:
                        pass
                    # 不清除 download_clicked，继续等浏览器下载事件或重新点击
                else:
                    self.store.log(tid, f"无水印视频已保存: {dest}（{size // 1024} KB）")
                    mark_video_delivered(str(dest), tid)
                    self._finish_done(
                        tid, dest, "生成完成（无水印）", video_url=video_url)
                    return
            # 进度缓升 45 → 85
            pct = min(85, 45 + int(elapsed / 8))
            msg = f"豆包生成中… 已等待 {int(elapsed)}s"
            if video_appeared and not no_watermark_url and not download_clicked:
                msg = f"视频已生成，正在获取无水印版本… 已等待 {int(elapsed)}s"
            elif download_clicked and not no_watermark_url:
                msg = f"已点击「无水印下载」，等待URL/文件… 已等待 {int(elapsed)}s"
            self.store.update(tid, percent=pct, message=msg)
            if not warned and elapsed > 180:
                warned = True
                self.store.log(tid, "已等待 3 分钟，若页面卡住请检查管理器窗口")
            self.check_cancel(tid)
            self.sleep_cancel(tid, int(self.config.get("poll_interval_sec", 3)))

        # 循环正常结束（deadline 到期）：video_url 仍为 None，说明全程未拿到有效视频
        waited = int(time.time() - click_time)
        if not video_appeared:
            # 失败前把页面现场整个 dump 出来：下一次再出现"看得到片子却检不到"，
            # 日志里就有 iframe / shadow / canvas / 按钮文案 / 资源时间线可查。
            self._log_page_diag(tid, "（超时前最后一次）")
            # 失败前把下载目录里的候选文件列出来：很可能是页面漏检而不是没生成，
            # 用户可以直接把文件拖回分镜，不用重新排队烧账号额度。
            self._log_dir_hint(tid, click_time)
            raise GenerationTimeout(
                f"{self.display_name()}：等待 {waited}s 页面始终未出现视频，"
                f"豆包可能静默生成失败，将换账号重试。")
        else:
            self._log_dir_hint(tid, click_time)
            raise DownloadFailed(
                f"等待无水印下载超时（{waited}s）：豆包页面已有视频，但未能获取「无水印下载」。"
                f"视频成品仍在 {self.display_name()} 的对话中，请到管理器手动点「无水印下载」，"
                f"本任务不会自动重新生成以免浪费额度。")

    def _probe_video(self, url, min_size=100 * 1024, cookies=None):
        """检测 URL 是否是有效的视频。

        要求：Content-Type 明确包含 video/，或响应体前 16 字节含 MP4 ftyp 签名。
        避免因 API 端点（如 /list）返回非空但非视频内容而被误判为有效。

        ★ 2026-11-03：cookies 为当前账号的 Cookie 头。官方无水印下载直链常与账号
        鉴权绑定，不带 Cookie 的 HEAD/Range 探测会拿到 403/HTML，被误判成"不是视频"
        而永久卡住 no_watermark_url。下方 Range 请求用 **headers 展开，自动带 Cookie。
        """
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Referer": "https://www.doubao.com/",
        }
        if cookies:
            headers["Cookie"] = cookies
        # 1. 先 HEAD 探测
        try:
            req = urllib.request.Request(url, method="HEAD", headers=headers)
            with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
                ct = resp.headers.get("Content-Type", "")
                cl = int(resp.headers.get("Content-Length", 0) or 0)
                ct_l = (ct or "").lower()
                # 明确的视频类型 + 足够大的体积才在 HEAD 阶段放行
                if "video" in ct_l and cl >= min_size:
                    return True
                # 明确的非视频类型：体积再大也不能当视频。
                # 2026-10-12 根因：旧逻辑 `or cl >= min_size` 让 3MB 的 .jpg~tp
                # 缩略图直接通过 HEAD 探测，被当成无水印视频下载回传（存成 .mp4 的图片）。
                if ct_l and (ct_l.startswith("image/") or ct_l.startswith("text/")
                             or "json" in ct_l or "javascript" in ct_l
                             or "html" in ct_l):
                    return False
                # 二进制流/未知类型：仅当声明了足够大的 Content-Length 才放行
                if (not ct_l or "octet-stream" in ct_l or "binary" in ct_l) \
                        and cl >= min_size:
                    return True
                # Content-Type 不包含 video/ 且无明确大小声明，直接拒绝
                if "video" not in ct_l and cl == 0:
                    return False
        except Exception:
            pass
        # 2. GET Range 0-1023 探测，要求响应体真正含视频特征
        try:
            req = urllib.request.Request(url, method="GET", headers={
                **headers,
                "Range": "bytes=0-1023",
            })
            with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
                data = resp.read(1024)
                ct = resp.headers.get("Content-Type", "").lower()
                # 必须满足以下之一才算有效视频：
                #   (a) Content-Type 明确含 video/
                #   (b) 响应体前 4 字节含 MP4 ftyp 签名
                if "video" in ct:
                    return len(data) > 0
                if len(data) >= 4 and data[4:8] == b"ftyp":
                    return True
                return False
        except Exception:
            return False


# ---------------------------------------------------------------------------
# 多账号调度器
# ---------------------------------------------------------------------------

class Orchestrator(threading.Thread):
    """分发（可并行）→ 多账号实时轮询异步回收。

    流程（对应需求）：
      1. 分发：取队首分镜，按账号序号选第一个可用账号（在线 / 额度ok / 未占用）；
         账号1忙或无额度则顺延账号2。
         · parallel_submit=True（默认，L2）：每个 (分镜, 账号) 起一个独立线程跑
           submit_stage，多个账号同时填报提交。实测非活动 webview 与活动 webview
           能力一致（见 DEFAULT_CONFIG.parallel_submit 注释），无需切 tab、无需串行。
         · parallel_submit=False：退回改造前的严格串行（阻塞跑完一个再下一个）。
         直到没有"可分发任务 + 可用账号"组合为止（队列空或无账号可用）。
      2. 各账号提交后豆包在服务端并行生成（互不影响，无需保持 tab 在前台）。
      3. 回收（实时轮询异步化）：提交后约 60 秒即可开始检测（不再固定等 360 秒）。
         编排器每 2 秒轮询所有 in-flight 任务，对每个任务执行轻量 CDP 检测
         （attach → pageVideos → 若视频出现则持锁点击下载按钮）。检测到视频后
         立即启动独立异步回收线程运行 collect_stage，编排器不阻塞，继续检查
         下一个账号。各账号的回收线程并发运行，先完成的先回传。
         回收后释放账号 busy 状态，允许承接下一批分镜。
    """

    def __init__(self, scheduler):
        super().__init__(daemon=True, name="dbm-orchestrator")
        self.sch = scheduler
        self.store = scheduler.store
        self.config = scheduler.config
        self.inflight = []   # [{"tid","worker","submit_ts"}] 按分发先后排序
        self._dispatch_threads = []   # 并行分发的线程句柄（仅用于回收，不 join）
        # ★ 2026-11-13：事件驱动即时派发。/api/tasks 提交、账号上下线、
        #   回收完成、解除冷却等都会 set()，编排器立刻再跑一轮 _cycle()，
        #   不再被动等 run() 固定 2 秒 + 回收轮询整批结束。
        self._wake = threading.Event()

    def wake(self):
        """请求编排器立刻再跑一轮（线程安全、可重复调用、可合并）。"""
        ev = getattr(self, "_wake", None)
        if ev is None:
            ev = threading.Event()
            self._wake = ev
        ev.set()

    def run(self):
        ev = getattr(self, "_wake", None)
        if ev is None:
            ev = threading.Event()
            self._wake = ev
        while True:
            try:
                self._cycle()
            except Exception as e:
                print(f"[doubao-bridge] 编排异常: {e}")
                try:
                    print(traceback.format_exc()[-600:])
                except Exception:
                    pass
            # 有事件立刻回到 _cycle；无事件保持 2 秒的回收轮询节奏。
            # 与旧的"进入 _collect_all_ready() 就阻塞到整批回传"不同，
            # 现在每轮只做一次回收轮询，任何时刻来了新任务都能在下一轮派出去。
            ev.wait(2)
            ev.clear()

    # ---------------- 任务 / 账号选取 ----------------
    def _queued_tasks(self):
        # FIFO：与原调度一致，最早提交的排最前
        return [t for t in reversed(self.store.list())
                if t.get("status") == "queued" and not t.get("assigned_to")]

    def _live_workers_sorted(self):
        # 快照遍历，避免与 scheduler.tick 增删 worker 并发时 dict changed size
        with self.sch._lock:
            return sorted(list(self.sch.workers.values()), key=lambda x: x.slot)

    def _pick_worker_for(self, task, skip_ids=None):
        """按账号序号选第一个可用账号；账号1忙/无额度/不在线则顺延账号2、3…。

        skip_ids: 本批次已尝试过的账号 target_id 集合（无论成功失败，每账号每批最多
        领一个分镜），避免提交前失败的账号在同批被反复重试、也保证"每账号在途≤1"。
        任务带 last_failed_target（上次生成失败的账号）时软降权：先在【其他】账号里选，
        只有它是唯一可用账号时才复用，保证重试尽量换账号、且单账号场景仍能跑。
        """
        kw = (task.get("account") or "").strip()
        skip_ids = skip_ids or set()
        last_fail = task.get("last_failed_target") or ""
        workers = self._live_workers_sorted()
        # 轮询游标：从上一轮最后分派的账号之后一位开始扫（绕回），消除"永远从账号1起"
        # 的跨批次偏置。游标基于稳定身份（昵称优先，与每日额度计数同源），账号上下线
        # 不会改变它的指向。仅做列表顺序轮转（只读），游标推进只在 _cycle 实际分派成功后发生。
        _cursor_key = getattr(self.sch, "_dispatch_cursor_key", "") or ""
        if _cursor_key:
            try:
                _ci = next((i for i, _w in enumerate(workers)
                            if self.sch._seedance_account_key(_w) == _cursor_key), -1)
                if _ci >= 0:
                    workers = workers[_ci + 1:] + workers[:_ci + 1]
            except Exception:
                pass
        # 本批需要的模型：缺该模型的账号（菜单项带"升级"标签）直接跳过，
        # 免得像以前那样在同一个没权限的账号上反复重试十几次。
        _model = str(task.get("model") or getattr(self.sch, "config", {}).get("model_name") or "").strip()
        _today_day = time.strftime("%Y-%m-%d", time.localtime())

        def _scan(exclude_fail):
            for w in workers:
                if w.target_id in skip_ids:
                    continue
                if exclude_fail and last_fail and w.target_id == last_fail:
                    continue
                if w.dead or w.busy:
                    continue
                # ★ 2026-11-13 硬闸门①：账号页此刻必须还开着。
                #   scheduler.tick() 每 3 秒才同步一次上下线，中间这 3 秒里
                #   已关闭账号的 worker 仍是 stale 快照；只看 w.dead 会把它派出去。
                try:
                    if not self.sch.account_is_live(w):
                        continue
                except AttributeError:
                    pass
                if not w.model_available(_model):
                    continue
                if getattr(w, "degraded_until", 0.0) > time.time():
                    continue    # 页面半加载卡死且修不好：30 分钟内不再派单给它
                # 刚被作废（用户取消）的账号：旧线程可能还卡在 CDP 长超时里，
                # 立刻派新任务过去会被它的残留指令/收尾代码干扰。等冷却结束再派。
                if getattr(w, "cooling_until", 0.0) > time.time():
                    continue
                # ★ 2026-11-13 硬闸门②：额度。除了 worker 内存态，还按
                #   target_id + nickname 复查持久化封禁，防止页面重开后标记丢失。
                try:
                    if not self.sch.quota_preflight_ok(w):
                        continue
                except AttributeError:
                    if not w.quota_available():
                        continue
                # 控制台「强制冷却」：只挡新派发，在途任务照常生成 / 回收 / 回传。
                if self.sch.is_account_cooldown(w):
                    continue
                # 受限额模型每日额度（按当前自然日归属）：满额则当天不再分派该账号。
                # seedance_daily_full 定义在 Scheduler，Orchestrator 需经 self.sch 调用。
                if self.sch.seedance_daily_full(w, _model, _today_day):
                    continue
                if kw and not w.matches(kw):
                    continue
                return w
            return None

        return _scan(True) or _scan(False)

    # ---------------- 主循环 ----------------
    def _cycle(self):
        # 派发前对账：今日 00:00–23:59 的历史生成次数必须已反映到账号额度，
        # 否则重启后 target_id 变化会让账号1 显示 0/2 并继续被超额派单。
        try:
            self.sch._reconcile_today_ledger()
        except Exception:
            pass
        # ★ 2026-11-03 宿主存活闸门：字字动画已关闭时，编排器一律不派发。
        #   任务已由 watchdog 全部取消成终态，这里兜住任何漏网的派发路径。
        try:
            if HOST_GUARD.enabled and HOST_GUARD.is_offline():
                return
        except Exception:
            pass
        # Fix 1：确保管理器在运行（Scheduler.tick 每 3 秒巡检一次，但 Orchestrator
        # _cycle 每 2 秒执行，若 tick 还没跑过管理器，需在此兜底启动）。
        if not self.sch.ctrl.manager_running():
            try:
                self.sch.ctrl.launch_manager()
                print("[doubao-bridge] 管理器未运行，已尝试自动启动")
            except ManagerAlreadyRunning:
                # 已有实例（或刚拉起的实例）正在启动，等下个周期再判；
                # 绝不重复 Popen，否则会弹「程序已经在运行中，请勿重复启动」。
                pass
            except Exception as e:
                print(f"[doubao-bridge] 启动管理器失败（等待任务触发）: {e}")
            time.sleep(2)
            return

        # ★ 2026-11-13：每一轮分派开始前，都先拿一份"当前已打开账号"的
        #   新鲜名单（1.5 秒内复用缓存，不刷 CDP）。/api/tasks 提交那一刻
        #   已强制做过一次实时扫描，这里再兜住"任务还在排队、账号中途被关掉"
        #   以及"账号重开后 target_id 变了"两种情形。
        try:
            self.sch.refresh_live_ids(max_age=1.5)
        except Exception:
            pass

        # Fix：检查是否有可用的账号 worker（账号页面已打开且被调度器枚举）
        # 管理器启动后需要时间加载账号页面，CDP 端口就绪不等价于账号已发现。
        # 若当前没有 worker，等待 Scheduler.tick() 完成账号枚举（每次 tick 间隔 3 秒）。
        workers = self._live_workers_sorted()
        if not workers:
            print("[doubao-bridge] 账号尚未枚举（管理器正在加载账号页面），等待调度器…")
            return
        # 有 worker 但都已不在实时名单里（账号页刚被全部关掉）：一律不派发。
        try:
            live_workers = [w for w in workers if self.sch.account_is_live(w)]
        except AttributeError:
            live_workers = workers
        if not live_workers:
            print("[doubao-bridge] 豆包账号页均已关闭（实时扫描），本轮不派发任务", flush=True)
            return

        # 先做在途任务恢复（重启/重载后，把 generating 任务重新挂回在线账号）

        # 阶段 1：分发。每账号至多领 1 个分镜——_pick_worker_for() 会跳过 busy
        # 的账号，而 busy 要等该账号回收完成才复位，所以"账号里已生成但还没下载的视频
        # 被新对话覆盖"这个风险已经按账号粒度挡住了。
        #
        # 这里刻意【不做】全局批次屏障。原实现是"只要 inflight 非空就一律不分发"，
        # 于是逐个提交任务时：任务1分给账号1进入生成（约 5~6 分钟），期间任务2
        # 明明可以分给空闲的账号2/3/4，却只能干排队，直到任务1回收完才动。
        # 账号越多、浪费越明显。现在只要还有空闲账号就继续填。
        #
        # L2（parallel_submit=True）：每个 (分镜, 账号) 起独立线程并发提交，
        # 本循环不再被 submit_stage 阻塞，9 个分镜的填报同时完成。
        parallel = bool(self.config.get("parallel_submit", True))
        attempted = set()
        dispatched = 0
        last_key = None   # 本批最后分派账号的稳定身份，批末用于推进轮询游标
        while True:
            picked = None
            for task in self._queued_tasks():
                w = self._pick_worker_for(task, skip_ids=attempted)
                if w:
                    picked = (task, w)
                    break
            if not picked:
                # 满额友好提示：所有在线账号今日受限额模型都已用满，且仍有排队任务
                try:
                    queued = self._queued_tasks()
                    if queued:
                        _day = time.strftime("%Y-%m-%d", time.localtime())
                        _mm = str(self.config.get("model_name") or "").strip()
                        _now = time.time()
                        if self.sch._seedance_all_full(_day, _mm):
                            if getattr(self, "_last_seedance_full_hint", 0) < _now - 600:
                                self._last_seedance_full_hint = _now
                                for t in queued:
                                    self.store.log(t["id"],
                                        "今日 Seedance 额度已用尽（Fast " +
                                        f"{self.sch._daily_limit_for('Seedance 2.0 Fast')} 次 / Mini " +
                                        f"{self.sch._daily_limit_for('Seedance 2.0 Mini')} 次，" +
                                        "任一模型达上限即整账号两个模型都停派），" +
                                        "所有在线账号均停派，任务保持排队，等待次日 0:01 自动恢复")
                        else:
                            # 全部账号被手动强制冷却时，给出明确原因，别让队列看起来"卡死"
                            try:
                                _live = [w for w in self._live_workers_sorted()
                                         if not w.dead]
                                _cooled = _live and all(
                                    self.sch.is_account_cooldown(w) for w in _live)
                            except Exception:
                                _cooled = False
                            if _cooled and getattr(self, "_last_cooldown_hint", 0) < _now - 600:
                                self._last_cooldown_hint = _now
                                for t in queued:
                                    self.store.log(t["id"],
                                        "所有在线账号均处于「强制冷却」，任务保持排队；"
                                        "到任务控制台点对应账号的「解除冷却」即可继续派发")
                except Exception:
                    pass
                break
            attempted.add(picked[1].target_id)
            if parallel:
                self._dispatch_async(picked[1], picked[0], ordinal=dispatched)
            else:
                self._dispatch_one(picked[1], picked[0])
            dispatched += 1
            # 记录本批最后分派账号（稳定身份），批末统一推进游标；
            # 本批内不即时改游标，保证所有 _pick_worker_for 读到同一基准。
            try:
                last_key = self.sch._seedance_account_key(picked[1])
            except Exception:
                pass
        if dispatched:
            # 轮询游标：整批分发结束后推进到本批最后分派的账号，下一批从其后一位起扫。
            # 仅改 worker 扫描起点，所有可用性/额度/降权/在途过滤保持不变。
            if last_key:
                try:
                    self.sch._set_dispatch_cursor(last_key)
                except Exception:
                    pass
            mode = "并行" if parallel else "串行"
            print(f"[doubao-bridge] 已{mode}分发 {dispatched} 个分镜"
                  f"（当前在途 {len(self.inflight)} 个）")

        # 阶段 2：回收。多账号并发时，不再固定等待360秒，而是轮询所有在途任务，
        # 哪个账号的视频先准备好就先回收哪个，提高效率。
        # Fix 2+3：实时监控轮询，多账号切换检查，找到即回收
        if self.inflight:
            self._collect_all_ready()
            if not self.inflight:
                print("[doubao-bridge] 在途分镜已全部回收")
        # 本轮只做一次回收轮询就返回；run() 等 2 秒或收到 wake 事件立刻再跑一轮，
        # 新提交的任务无需等本批在途任务全部回传。

    def _has_dispatchable_work(self):
        """是否已有"排队任务 + 空闲可用账号"的组合可以立刻开工。

        _collect_all_ready() 改成单轮轮询后不再依赖它打断阻塞，但控制台与
        run() 的即时唤醒判断仍会用它做一次轻量探测。只看队首若干个任务，
        避免任务多时反复全量扫描。
        """
        queued = [t for t in reversed(self.store.list())
                  if t.get("status") == "queued" and not t.get("assigned_to")][:5]
        for t in queued:
            if self._pick_worker_for(t):
                return True
        return False

    def _collect_all_ready(self):
        """★ 2026-11-13：单轮回收轮询，扫一遍 inflight 就立即返回。

        原实现是 `while self.inflight: ... time.sleep(2)`：一旦有任务在途，
        编排器线程就被这个循环锁死，直到整批全部回传才回到 _cycle() 的分发
        阶段。期间字字动画新点的"生成视频"只能干等，表现就是"分批次派发 /
        点了没反应"。现在改成由 run() 的事件循环驱动——每轮只做一次检测，
        新任务到来时 wake() 会立刻打断等待并先走分发阶段。
        回收本身仍在独立线程里跑，退出轮询不影响任何在途任务。
        """
        delay = int(self.config.get("return_delay_sec", 360))  # 保留：旧配置兼容，实际由 min_wait_sec 控制
        min_wait_sec = int(self.config.get("min_wait_sec", 60))  # 最短等待时间（秒）

        # 收集正在回收中的任务 ID，防止并发启动多个 collect_stage
        collecting_set = set(it["tid"] for it in self.inflight if it.get("collecting"))

        if self.inflight:
            cleaned = []  # 本轮回传/失败的任务

            for item in list(self.inflight):
                w = item["worker"]
                tid = item["tid"]

                # 回收线程负责释放自己的 worker；已结束的旧条目只出列。
                if item.get("finished"):
                    cleaned.append(item)
                    continue
                if item.get("collecting"):
                    continue
                # 重排/改派后的旧条目绝不能再轮询或释放新任务的账号。
                cur = self.store.get(tid)
                if cur and (cur.get("status") == "queued"
                            or cur.get("assigned_to") != w.target_id):
                    if w.current_tid == tid:
                        w.busy = False
                        w.current_tid = None
                    cleaned.append(item)
                    continue
                # 清理已完成/失败的任务
                if not cur:
                    w.busy = False
                    w.current_tid = None
                    try:
                        w.bridge.detach()
                    except Exception:
                        pass
                    cleaned.append(item)
                    continue

                status = cur.get("status", "")
                if status == "done":
                    w.done_count += 1
                    w.busy = False
                    w.current_tid = None
                    cleaned.append(item)
                    continue

                if status == "error" or cur.get("error") == "cancelled":
                    w.busy = False
                    w.current_tid = None
                    w._fg_release()
                    try:
                        w.bridge.detach()
                    except Exception:
                        pass
                    cleaned.append(item)
                    continue

                # 跳过已在回收中的任务（异步线程处理）
                if tid in collecting_set:
                    continue

                # 额度检查
                if not w.quota_available():
                    self.store.log(tid, f"{w.display_name()} 额度耗尽，跳过回收")
                    self.store.update(tid, status="error", percent=0,
                                      message=f"{w.display_name()}额度耗尽",
                                      error="quota_exhausted_during_poll")
                    w.busy = False
                    w.current_tid = None
                    cleaned.append(item)
                    continue

                # ★ 2026-11-14：协商没走完（带参考音频的二次确认可能还没发）
                #   就绝不进入回收检测。旧版只看编排器的分发时刻，音频任务
                #   协商空转 160s 时，轻量检测早已按 150s 阈值转交完整回收，
                #   把别的账号窗口的历史成片回传给了字字动画。
                _gate_ok, _gate_why, _ready_ts = w._delivery_gate(tid)
                if not _gate_ok:
                    if not item.get("_gate_logged"):
                        item["_gate_logged"] = True
                        self.store.log(tid, "回收闸门：%s，暂不检测视频" % _gate_why)
                    continue
                # 等待计时必须以「协商完成、真正开始生成」为基准
                elapsed = time.time() - (_ready_ts or item["submit_ts"])
                item["elapsed"] = elapsed
                if elapsed < min_wait_sec:
                    continue  # 还未到最短等待时间，跳过

                # 执行轻量视频检测（快速 CDP attach → pageVideos → 点击下载）
                try:
                    video_ready = w._fast_detect_video(tid)
                except TaskCancelled:
                    raise
                except (GenerationFailed, GenerationTimeout) as e:
                    # ★★ 2026-09-24 BUG 修复：轻量检测阶段抛的"确定失败"必须真的让
                    #   任务结束。以前它掉进下面那个 `except Exception`，只记一句
                    #   "将继续轮询"就 continue —— 下一轮再命中、再抛，同一个任务
                    #   25 分钟里刷了 80 多条「内容审核拒绝（轻量检测阶段命中）」，
                    #   日志 (上限 200 条) 被彻底刷爆、有用信息全被挤掉，任务自己
                    #   却一直挂着，最后被字字动画侧超时掐掉（1950s，status 变成
                    #   cancelled 而不是 moderation_rejected）。
                    #   判死必须交给 handle_stage_error —— 审核拒绝不重排队、
                    #   普通失败换账号重试，都是它负责的。
                    self.store.log(tid,
                                   f"{w.display_name()} 轻量检测判定失败，结束本任务")
                    my_epoch = w.epoch
                    try:
                        w.handle_stage_error(tid, e)
                    except Exception as he:
                        self.store.log(tid, f"失败处理异常（兜底置 error）: {he}")
                        self.store.update(tid, status="error", percent=0,
                                          message=f"生成失败：{str(e)[:120]}",
                                          error=f"detect_failed：{e}")
                    if w.epoch == my_epoch:
                        w.busy = False
                        w.current_tid = None
                    cleaned.append(item)
                    continue
                except Exception as e:
                    self.store.log(tid,
                                   f"{w.display_name()} 轻量检测异常（{e}），将继续轮询")
                    continue

                if video_ready:
                    # 检测到视频，异步启动完整回收线程
                    item["collecting"] = True
                    collecting_set.add(tid)
                    t = threading.Thread(
                        target=self._run_collect_stage,
                        args=(item,),
                        name=f"dbm-collect-{tid[:8]}",
                        daemon=True,
                    )
                    t.start()
                    self.store.log(tid,
                                   f"{w.display_name()} 已启动异步回收线程")
                # 否则继续下一轮轮询（不标记 collecting，下一轮还会重试）

            # 清理已完成的任务
            for it in cleaned:
                if it in self.inflight:
                    self.inflight.remove(it)
            if cleaned:
                collecting_set -= {it["tid"] for it in cleaned}
            # 单轮到此结束：不再 while + sleep(2) 阻塞编排器线程。
            # run() 会在 2 秒后（或收到 wake 事件时立刻）再跑一轮 _cycle()，
            # 于是"新任务分发"永远排在"回收轮询"之前，不再被整批回传卡住。

    def _run_collect_stage(self, item):
        """在独立线程中运行 collect_stage，不阻塞编排器主循环。

        收集完成后自动更新 busy / current_tid / collecting 标记。
        """
        w = item["worker"]
        tid = item["tid"]
        my_epoch = w.epoch
        # ★ 2026-11-02 修复：同一账号（同一 worker 实例 w）的多个分镜回收必须串行。
        #   并发回收会共享同一个豆包 tab 与 worker 内部状态（self._dl_pre_sigs 等）：
        #   ① 两个线程的点击互相干扰，误点视频卡片从而弹出「创建画布」面板；
        #   ② 共享落点 video.mp4 被并发读写，导致不同分镜回传同一个视频（串片）。
        #   同账号串行、跨账号仍并行，从根上消除这两类问题。
        _clk = getattr(w, "_collect_lock", None)
        if _clk is None:
            _clk = threading.Lock()
            try:
                w._collect_lock = _clk
            except Exception:
                pass
        _clk.acquire()
        try:
            self.store.log(tid, f"==== 异步回收线程启动：{w.display_name()} ====")
            w.collect_stage(tid)
            # ★ 2026-11-14：collect_stage 若因回传闸门未就绪直接返回，
            #   任务仍在协商中，绝不能把这个 inflight 条目标记 finished，
            #   否则编排器不再轮询、任务永远卡在 generating。
            _after = self.store.get(tid) or {}
            _gate_fn = getattr(w, "_delivery_gate", None)
            if (_after.get("status") in ("generating", "downloading")
                    and callable(_gate_fn) and not _gate_fn(tid)[0]):
                item["_gate_pending"] = True
                self.store.log(tid, "回收闸门尚未打开，保留在途状态等待协商完成")
            t = _after
            if t and t.get("status") == "done":
                w.done_count += 1
        except TaskCancelled:
            self.store.log(tid, f"{w.display_name()} 回收被取消")
        except Exception as e:
            if w.epoch == my_epoch and w.current_tid == tid:
                w.handle_stage_error(tid, e)
        finally:
            # 释放本账号回收锁，让同账号下一个分镜的回收线程得以进入（同账号串行）
            try:
                _clk.release()
            except Exception:
                pass
            # 先标记旧条目已结束，再释放账号；禁止旧条目重新进入轻量检测。
            # ★ 闸门未打开时保留 inflight / busy，等编排器下一轮重新判定。
            if item.pop("_gate_pending", False):
                item["collecting"] = False
            else:
                item["finished"] = True
                if w.epoch == my_epoch and w.current_tid == tid:
                    w.busy = False
                    w.current_tid = None
            # 账号刚空出来：立刻唤醒编排器去填排队的任务，不等 2 秒循环。
            try:
                self.wake()
            except Exception:
                pass

    def _dispatch_one(self, w, task):
        """同步分发一个分镜（parallel_submit=False 时使用；并行模式走 _dispatch_async）。"""
        self._mark_dispatched(w, task, parallel=False)
        self._run_dispatch_stage(w, task)

    def _dispatch_async(self, w, task, ordinal=0):
        """并行分发：先把账号标记成 busy（**同步**，否则本轮循环会重复挑中它），
        再起独立线程跑 submit_stage。多个账号因此可以同时填报提交。

        ordinal：本批次内的序号。早期版本为缓解 CDP 拥堵，用
        dispatch_stagger_sec 让第 N 个账号延迟 N×秒起步（最多 45 秒），
        表现就是用户看到的"分批次派发、点了要等一会儿才动"。
        ★ 2026-11-13 用户明确要求「不需要分批次派发，点击立即响应」：
          默认关闭错峰（dispatch_stagger_enabled=False / 配置值 0），
          所有空闲账号同一时刻开工。老 config.json 里残留的
          dispatch_stagger_sec=2 也不会自动生效，必须显式打开开关。

        线程句柄存 _dispatch_threads 只为观察/回收，不 join——编排器主循环不能被
        任何 submit_stage 阻塞，否则就退回串行了。
        """
        self._mark_dispatched(w, task, parallel=True)
        self._dispatch_threads = [t for t in self._dispatch_threads if t.is_alive()]
        stagger_enabled = bool(self.config.get("dispatch_stagger_enabled", False))
        stagger = float(self.config.get("dispatch_stagger_sec", 0) or 0) \
            if stagger_enabled else 0.0
        # ★ 2026-09-22：错峰上限原来是写死 20s。实测 9 个分镜**同时**超时重新排队时
        #   （都卡在 1774s 上，几乎同一秒释放），9 个 worker 会在 20s 内全部开始
        #   建连接 + 灌 60KB 注入脚本 + 上传参考图，CDP 直接被挤爆 —— 第二轮里
        #   5 个任务死在 "CDP 未连接" / "CDP 调用超时"。放开成可配置、默认 45s。
        try:
            stagger_cap = float(
                self.config.get("dispatch_stagger_max_sec", 45) or 0)
        except (TypeError, ValueError):
            stagger_cap = 45.0
        delay = min(ordinal * stagger, stagger_cap) if stagger > 0 else 0.0
        t = threading.Thread(target=self._run_dispatch_stage, args=(w, task, delay),
                             name=f"dbm-dispatch-{task['id'][:8]}", daemon=True)
        t.start()
        self._dispatch_threads.append(t)

    def _mark_dispatched(self, w, task, parallel=False):
        tid = task["id"]
        w.busy = True
        w.current_tid = tid
        w.submitted = False
        mode = "并行" if parallel else "串行"
        self.store.update(tid, assigned_to=w.target_id, worker_slot=w.slot,
                          worker_name=w.display_name(),
                          percent=8,
                          message=f"编排器分发到{w.display_name()}，开始{mode}填报…")
        self.store.log(tid, f"==== 编排器{mode}分发：{w.display_name()} ====")

    def _run_dispatch_stage(self, w, task, delay=0.0):
        """在调用方线程（串行=编排器线程，并行=独立线程）中跑完 submit_stage 并收尾。

        delay>0：并发错峰起步（见 _dispatch_async 的 dispatch_stagger_sec）。
        """
        tid = task["id"]
        my_epoch = w.epoch      # ★ 见 AccountWorker.retire()：epoch 变了说明本线程已作废
        if delay > 0:
            try:
                if w.current_tid == tid:
                    self.store.log(tid, f"{w.display_name()} 并行错峰等待 {delay:.0f}s 后开始填报")
            except Exception:
                pass
            time.sleep(delay)
        submit_ts = None
        try:
            submit_ts = w.submit_stage(tid)
        except Exception as e:
            w.handle_stage_error(tid, e)
            if w.epoch == my_epoch:
                # 只有"本代"线程才有权改 worker 状态；作废线程一律安静退出，
                # 否则会把接手同一账号的新任务的 busy 清掉。
                w.busy = False
                w.current_tid = None
            # 提交失败常常伴随任务重排：立刻唤醒，别让新任务等 2 秒。
            try:
                self.wake()
            except Exception:
                pass
            return
        finally:
            # submit_stage 若持了前台锁（串行模式），成败都要释放；
            # 并行模式下 _fg_locked=False，这里是 no-op。
            w._fg_release()
        if w.epoch != my_epoch:
            return
        if submit_ts:
            self.inflight.append({"tid": tid, "worker": w, "submit_ts": submit_ts})
            # w.busy 保持 True：该账号正在服务端生成，回收前不再接新分镜
        else:
            w.busy = False
            w.current_tid = None
        # 提交线程收尾（成功/失败都算）：账号状态变了，立刻让编排器再评估一次，
        # 尤其是失败重排的任务要在点击后马上被别的空闲账号接走。
        try:
            self.wake()
        except Exception:
            pass

    def _sleep_until(self, tid, target_ts):
        """分片等到 target_ts；任务被取消/置错时提前返回（交由 collect 收尾）。"""
        while time.time() < target_ts:
            t = self.store.get(tid)
            if not t:
                return
            if t.get("error") == "cancelled" or t.get("status") == "error":
                return
            time.sleep(min(2.0, max(0.1, target_ts - time.time())))

    def _collect_one(self, item):
        w = item["worker"]
        tid = item["tid"]
        my_epoch = w.epoch      # ★ 见 AccountWorker.retire()：epoch 变了说明本线程已作废
        # 状态守卫：等待 6 分钟期间任务若已被用户取消或置错，不再进入回收流程，
        # 只做会话清理并出列（item 由 _cycle 弹出），避免对已取消任务做无效点击/下载。
        cur = self.store.get(tid)
        if not cur or cur.get("error") == "cancelled" or cur.get("status") == "error":
            self.store.log(tid, "任务在回收等待期已取消/失败，跳过回收并释放账号")
            w.busy = False
            w.current_tid = None
            w._fg_release()
            try:
                w.bridge.detach()
            except Exception:
                pass
            return
        self.store.log(tid, f"==== 编排器按序回收：{w.display_name()} ====")
        w.busy = True
        w.current_tid = tid
        # ★ 2026-11-02 修复：同账号分镜回收串行化（见 _run_collect_stage 说明），
        #   防止并发回收共享豆包 tab 导致串片 / 误开「创建画布」。
        _clk = getattr(w, "_collect_lock", None)
        if _clk is None:
            _clk = threading.Lock()
            try:
                w._collect_lock = _clk
            except Exception:
                pass
        _clk.acquire()
        try:
            w.collect_stage(tid)
            t = self.store.get(tid)
            if t and t.get("status") == "done":
                w.done_count += 1
        except Exception as e:
            w.handle_stage_error(tid, e)
        finally:
            # 释放本账号回收锁，让同账号下一个分镜的回收线程得以进入（同账号串行）
            try:
                _clk.release()
            except Exception:
                pass
            # 同 _run_dispatch_stage：作废线程不得碰 worker 状态（可能已归新任务）。
            if w.epoch == my_epoch:
                w.busy = False
                w.current_tid = None


class Scheduler:
    """发现账号 webview → 每个账号起一个 AccountWorker → 按账号亲和性分配任务。

    - 每 3 秒巡检一次：管理器启动、账号上下线、任务分配
    - 任务带 account 关键字时只分给匹配账号；不带时任意空闲账号都可接
    - 新账号（后期 10 个、50 个）打开后自动上线接任务，无需重启
    """

    def __init__(self, store, config):
        self.store = store
        self.config = config
        self.ctrl = ManagerBridge(config)   # 仅用于启动管理器/枚举账号，不持有长连接
        self.workers = {}                   # target_id -> AccountWorker
        self._lock = threading.Lock()
        # 前台输入锁：管理器同一时刻只有一个 webview tab 能接收真实键盘/鼠标输入。
        # 由 Orchestrator 串行分发时持有（一个账号走完填表→提交→发确认才切下一个），
        # 生成等待期不持锁，回收时点"无水印下载"按钮再短暂持有。
        self.input_lock = threading.Lock()
        self.orchestrator = None            # 单线程串行编排器（分发/回收）
        self._slot_counter = 0
        # ★ 2026-09-22：账号序号"首见即锁定"表 {target_id: slot}。
        #   见 _assign_slot() 的说明：管理器上报的序号一直在抖，照抄会让日志里
        #   同一个账号几秒换一个号，前后完全对不上。
        self._slot_lock = {}
        self._wait_hinted = set()
        self._auto_opened = False           # 管理器启动后是否已自动打开所有账号
        # 持久化额度不足标记：{target_id: {marked_at, msg, recover_at_ts}}
        # worker 重建时从此恢复，避免页面刷新导致标记丢失
        self._quota_marks = load_json(QUOTA_MARKS_PATH, {})
        # 受限额模型每日生成计数：{日期: {账号身份: {模型桶: {"count":N,"tids":[...]}}}}，按提交时刻自然日归属
        self._seedance_quota = load_json(SEEDANCE_QUOTA_PATH, {}) or {}
        # 旧版 Fast/Mini 共用一个桶；升级后按任务实际模型拆成两个独立桶。
        self._migrate_legacy_shared_buckets()
        # 控制台「强制冷却」名单：{version, accounts:{稳定身份: {...}}}，手动解除前一直生效
        self._cooldowns = load_json(COOLDOWN_PATH, {}) or {}
        if not isinstance(self._cooldowns, dict):
            self._cooldowns = {}
        if not isinstance(self._cooldowns.get("accounts"), dict):
            self._cooldowns["accounts"] = {}
        self._cooldowns.setdefault("version", 1)
        self._cooldown_lock = threading.Lock()
        # 轮询游标：记录上一轮最后分派的账号稳定身份（昵称优先，target_id 兜底），
        # 下一轮从其后一位开始扫，消除"永远从账号1起"的偏置。基于稳定身份而非 slot，
        # 避免账号上下线导致游标错位。
        self._dispatch_cursor_key = (load_json(DISPATCH_STATE_PATH, {}) or {}).get("cursor_key", "") or ""
        # ---- 2026-11-13 派发前实时账号扫描 / 事件驱动即时派发 ----
        # _live_ids=None 表示"还没成功扫描过"，此时沿用 tick() 原有的账号上下线结果；
        # 一旦扫描成功（哪怕是空集合），就以它为准，只给当前已打开的账号派单。
        self._live_ids = None
        self._live_ids_ts = 0.0
        self._live_scan_lock = threading.Lock()
        self._live_scan_failures = 0
        # 调度器（枚举账号）和编排器（分发任务）各自的唤醒事件：提交任务时立刻
        # set，替代原来"最长等 3s tick / 2s 编排循环"的被动轮询。
        self._wake = threading.Event()
        # 页面额度同步可能被多个入口同时触发（3s tick + 点击派发事件），
        # 用非阻塞锁保证同一时刻只有一份在改 quota_ok / 落盘。
        self._quota_sync_lock = threading.Lock()
        # ---- 2026-11-14 今日历史额度账本（重启后不清零）------------------
        # 账号身份（昵称 / CDP target_id / 序号）在重启后都会变，只靠
        # seedance_quota.json 的账号 key 查历史，会把当天已用额度丢成 0。
        # 这份流水与账号无关：每次真实生成登记一个 tid，启动时再从
        # tasks.json 扫描当日 00:00:00–23:59:59 的已生成任务重建补全。
        self._today_ledger = load_json(TODAY_LEDGER_PATH, {}) or {}
        if not isinstance(self._today_ledger, dict):
            self._today_ledger = {}
        self._ledger_reconcile_lock = threading.Lock()
        self._ledger_reconcile_ts = 0.0
        self._ledger_stats = {}
        try:
            # 启动时先重建流水（此时账号还没上线，只重建不回填）；
            # 账号上线后的 tick / 派发判定会接着做身份漂移回填。
            self._reconcile_today_ledger(force=True)
        except Exception as e:
            print(f"[bridge] 今日历史额度启动重建失败（已忽略）: {e}")

    # 名单最多可信多久。超过后派发一律停住，宁可等下一次成功扫描，也不拿
    # 十几秒前的旧名单把任务派给已经关掉的账号。
    LIVE_IDS_MAX_STALE_SEC = 20.0

    def wake_scheduler(self):
        """让账号枚举循环立刻再跑一轮（新打开账号不用等 3 秒）。"""
        try:
            ev = getattr(self, "_wake", None)
            if ev is not None:
                ev.set()
        except Exception:
            pass

    def wake_orchestrator(self):
        """让编排器立刻再跑一轮（点击生成视频后马上分派）。"""
        try:
            o = getattr(self, "orchestrator", None)
            if o is not None:
                o.wake()
        except Exception:
            pass

    def wake_dispatch(self):
        """账号枚举 + 任务分派一起唤醒。用于 /api/tasks、解除冷却等即时响应点。"""
        self.wake_scheduler()
        self.wake_orchestrator()

    def refresh_live_ids(self, max_age=1.5, timeout=2, prune=True):
        """派发前刷新"当前已打开账号"名单，并立即剔除已关闭的空闲 worker。

        max_age>0 时命中短缓存（同一轮 _cycle 里会被调用很多次，避免刷 CDP）；
        max_age=0 强制实时扫描，用于用户点击"生成视频"的那一下。
        扫描失败（CDP 暂时不可用）时**保留上一次名单**，绝不把 None 当空集合。
        """
        now = time.time()
        with getattr(self, "_live_scan_lock", threading.Lock()):
            ids = getattr(self, "_live_ids", None)
            ts = getattr(self, "_live_ids_ts", 0.0)
            if ids is not None and max_age > 0 and now - ts < max_age:
                return set(ids), False
            ctrl = getattr(self, "ctrl", None)
            scanned = ctrl.live_account_ids(timeout=timeout) if ctrl is not None else None
            if scanned is None:
                self._live_scan_failures = getattr(self, "_live_scan_failures", 0) + 1
                return ids, False
            self._live_ids = set(scanned)
            self._live_ids_ts = now
            self._live_scan_failures = 0
            live = set(scanned)
        if not prune:
            return live, True
        removed = []
        self._last_pruned = []
        with self._lock:
            for tid, w in list(self.workers.items()):
                if tid in live:
                    continue
                # 忙碌中的账号：不打断在途任务（照常生成/下载/回传），
                # 但 account_is_live() 会挡住它之后再接任何新分镜。
                if getattr(w, "busy", False) or getattr(w, "current_tid", None):
                    continue
                try:
                    w.stop()
                except Exception:
                    pass
                self.workers.pop(tid, None)
                self._release_slot(tid)
                try:
                    removed.append(w.display_name())
                except Exception:
                    removed.append(tid[:8])
        self._last_pruned = list(removed)
        if removed:
            print(f"[doubao-bridge] 派发前扫描：已关闭账号 {len(removed)} 个，"
                  f"worker 立即下线（{', '.join(removed)}）", flush=True)
        return live, True

    def account_is_live(self, w):
        """这个 worker 的页面此刻是否还开着。派发前的硬闸门。"""
        ids = getattr(self, "_live_ids", None)
        if ids is None:
            return True   # 尚未成功扫描过：交给 tick() 的常规上下线结果
        if time.time() - getattr(self, "_live_ids_ts", 0.0) > self.LIVE_IDS_MAX_STALE_SEC:
            # 名单太久没刷新且 CDP 一直失败：停派比误派更安全，等下一轮成功扫描恢复。
            return False
        return getattr(w, "target_id", "") in ids

    def quota_preflight_ok(self, w):
        """派发前按稳定身份复查额度封禁，挡住"页面重开后封禁标记丢失"的账号。

        target_id 是 CDP 会话 GUID，账号页关掉重开就会变；worker 重建时如果
        昵称尚未抓到，find_quota_mark() 可能匹配不上旧的持久化封禁，
        worker 带着 quota_ok=True 上线 → 又被派一个注定失败的任务。
        这里在每次挑账号时按 target_id + nickname 再查一遍（纯内存，极快）。
        """
        try:
            if not w.quota_available():
                return False
        except Exception:
            return False
        try:
            mark = self.find_quota_mark(getattr(w, "target_id", ""),
                                       getattr(w, "nickname", ""))
        except Exception:
            mark = None
        if not mark:
            return True
        try:
            if hasattr(w, "_apply_quota_mark"):
                w._apply_quota_mark(mark)
            else:
                w.quota_ok = False
                w.quota_msg = mark.get("msg", "") or getattr(w, "quota_msg", "")
                w.quota_recover_ts = mark.get("recover_at_ts", 0.0)
        except Exception:
            pass
        return False

    def live_scan_info(self):
        """给 /api/health、任务控制台展示的实时扫描摘要。"""
        ids = getattr(self, "_live_ids", None)
        ts = getattr(self, "_live_ids_ts", 0.0)
        with self._lock:
            workers = list(self.workers.values())
        live_workers = [w for w in workers
                        if ids is None or getattr(w, "target_id", "") in ids]
        return {
            "scanned": ids is not None,
            "live_accounts": len(ids) if ids is not None else len(workers),
            "tracked_workers": len(workers),
            "offline_workers": len(workers) - len(live_workers),
            "idle_live_workers": sum(1 for w in live_workers
                                     if not getattr(w, "busy", False)
                                     and not getattr(w, "dead", False)),
            "last_scan_at": (time.strftime("%H:%M:%S", time.localtime(ts)) if ts else ""),
            "scan_failures": getattr(self, "_live_scan_failures", 0),
            "stale": bool(ids is not None and ts and
                          time.time() - ts > self.LIVE_IDS_MAX_STALE_SEC),
        }

    def preflight_dispatch(self, reason="", quick_quota_sync=True):
        """★ 字字动画侧点击"生成视频"/"派发任务"时调用。

        1) 立即同步扫描豆包管理器当前已打开的账号（一次 /json/list，毫秒级）；
        2) 剔除刚被关掉的空闲 worker，忙碌的留给在途任务但禁止再接新单；
        3) 事件驱动唤醒账号枚举 + 任务分派，不等 3s tick / 2s 编排循环；
        4) 返回本次可派发账号清单与跳过原因，随 /api/tasks 回给插件。
        """
        self._last_pruned = []
        live, scanned = self.refresh_live_ids(max_age=0.0, timeout=2)
        # 页面级额度状态也顺带刷一次：后台线程跑，最多等 0.6 秒，
        # 不让任何一次慢 CDP 求值把"点击立即响应"拖成长时间等待。
        if quick_quota_sync:
            self.request_quota_sync(wait_sec=0.6)
        with self._lock:
            workers = sorted(list(self.workers.values()),
                             key=lambda x: getattr(x, "slot", 0))
        day = time.strftime("%Y-%m-%d", time.localtime())
        model = str(self.config.get("model_name") or "").strip()
        # 刚被 refresh_live_ids 清掉的空闲 worker 也属于"因已关闭而跳过"，
        # 要把它们计进摘要，否则插件日志会显示"跳过 0 个"却不知账号去哪了。
        available, no_quota, cooled, busy = [], [], [], []
        offline = list(getattr(self, "_last_pruned", []) or [])
        for w in workers:
            try:
                name = w.display_name()
            except Exception:
                name = getattr(w, "target_id", "?")[:8]
            if live is not None and getattr(w, "target_id", "") not in live:
                offline.append(name)
                continue
            if getattr(w, "dead", False) or getattr(w, "busy", False) \
                    or getattr(w, "current_tid", None):
                busy.append(name)
                continue
            if not self.quota_preflight_ok(w) or self.seedance_daily_full(w, model, day):
                no_quota.append(name)
                continue
            try:
                if self.is_account_cooldown(w):
                    cooled.append(name)
                    continue
            except Exception:
                pass
            available.append(name)
        self.wake_dispatch()
        summary = {
            "scanned": bool(scanned) or live is not None,
            "live_accounts": len(live) if live is not None else len(workers),
            "tracked_workers": len(workers),
            "available_accounts": len(available),
            "available": available,
            "skipped_offline": offline,
            "skipped_no_quota": no_quota,
            "skipped_cooldown": cooled,
            "skipped_busy": busy,
            "immediate_dispatch": not bool(self.config.get("dispatch_stagger_enabled", False)),
            "reason": reason,
        }
        print(f"[doubao-bridge] 派发前扫描（{reason or 'manual'}）：已打开 "
              f"{summary['live_accounts']} 个 / 可派发 {len(available)} 个"
              + (f" / 已关闭跳过 {len(offline)}" if offline else "")
              + (f" / 无额度跳过 {len(no_quota)}" if no_quota else "")
              + (f" / 冷却跳过 {len(cooled)}" if cooled else ""), flush=True)
        return summary

    def request_quota_sync(self, wait_sec=0.0):
        """事件驱动刷新页面额度状态；不阻塞派发，完成后再唤醒编排器。"""
        def _run():
            try:
                self.sync_quota_status()
            except Exception:
                pass
            finally:
                self.wake_orchestrator()
        t = threading.Thread(target=_run, daemon=True, name="dbm-quota-preflight")
        t.start()
        if wait_sec > 0:
            t.join(wait_sec)
        return t

    def save_quota_marks(self):
        try:
            save_json(QUOTA_MARKS_PATH, self._quota_marks)
        except Exception as e:
            print(f"[bridge] 额度标记落盘失败: {e}")

    def _assign_slot(self, tid, reported=0):
        """给账号定一个**稳定**的序号（首见即锁定）。

        ★ 2026-09-22 日志序号抖动问题。原来每 tick 都拿管理器上报的 slot 覆盖
        worker.slot，而管理器那个号是按 webview 在 DOM 里的顺序算的：
          - React 重排 / 账号页增删 → 顺序变 → 同一个账号换号；
          - 页面导航后 URL 归一化 key 变了 → slot_map 匹配不上 → 掉到 slot=0
            → 走"按 targets 出现顺序补号"兜底 → 又是一套不稳定的号。
        于是日志里出现 账号6→账号3→账号5→账号3→账号6→账号4→账号7 这种来回跳，
        前后根本对不上号，没法定位是哪个账号在报错。

        改成首见即锁定：某个 target 第一次出现时定号，之后只要它还在就一直沿用，
        不再跟着管理器抖。代价是与管理器 UI 上显示的序号可能不一致，但换来的是
        整轮运行内日志可读（用户明确要求）。
        """
        locked = self._slot_lock.get(tid)
        if locked:
            return locked
        used = set(self._slot_lock.values())
        for _t, _w in self.workers.items():
            if _t != tid:
                used.add(_w.slot)
        slot = int(reported or 0)
        if slot <= 0 or slot in used:
            # 取最小空闲号（而不是 max+1）：账号上下线频繁时小号能被回收复用，
            # 序号不会一轮轮滚到账号 37、账号 52 这种没人看得懂的数字。
            slot = 1
            while slot in used:
                slot += 1
        self._slot_lock[tid] = slot
        return slot

    def _release_slot(self, tid):
        """账号下线时归还它的锁定序号（否则号会越用越大）。"""
        self._slot_lock.pop(tid, None)

    def mark_quota_exhausted(self, target_id, nickname, msg):
        """标记账号额度不足（固定恢复时间=次日0:01），持久化到文件。

        同时记录 target_id 和 nickname 双重身份：target_id 是 CDP 会话 GUID，
        页面重开会变；nickname 从页面抓取、跨重启稳定，用Nickname兜底匹配。
        """
        import datetime as _dt
        now = _dt.datetime.now()
        tomorrow_001 = (now + _dt.timedelta(days=1)).replace(hour=0, minute=1, second=0, microsecond=0)
        mark = {
            "target_id": target_id,
            "nickname": (nickname or "").strip(),
            "marked_at": time.time(),
            "msg": msg,
            "recover_at_ts": tomorrow_001.timestamp(),   # 固定时间戳，防止"移动靶"永不恢复
            "recover_at_str": tomorrow_001.strftime("%Y-%m-%d %H:%M"),
        }
        self._quota_marks[target_id] = mark
        self.save_quota_marks()
        return mark

    def seedance_quota_fill_to_limit(self, w, model, day, reason=""):
        """2026-11-03 v3：页面明确出现「免费额度已用完」时，把该账号当日受限额
        模型的计数直接补到上限，让「今日已生成 3/3 / 已满额·今日停派 / 不可派发」
        立即确定落地，不再依赖"检测到视频"那条会被历史文案噪声污染的计数链。

        豆包侧的额度结论是权威的：既然账号今天已无法再生成，补到上限既符合事实，
        也能防止插件继续往该账号派单。只在检测到确凿额度耗尽文案时调用。
        """
        limit = self._daily_limit_for(model)
        if not limit:
            return False
        acct = self._seedance_account_key(w)
        bucket = self._seedance_bucket(model)
        day_rec = self._seedance_quota.setdefault(day, {})
        acct_rec = day_rec.setdefault(acct, {})
        model_rec = acct_rec.setdefault(bucket, {"count": 0, "tids": []})
        tids = model_rec.setdefault("tids", [])
        count = int(model_rec.get("count", 0) or 0)
        if count >= limit and len(tids) >= limit:
            return False
        # 用可识别的占位标记补足 tids，不伪造真实任务 id；
        # seedance_quota_inc 以 len(tids) >= limit 封顶，补满后不会再累加。
        while len(tids) < limit:
            tids.append("quota_exhausted")
        model_rec["count"] = max(count, len(tids))
        try:
            save_json(SEEDANCE_QUOTA_PATH, self._seedance_quota)
        except Exception as e:
            print(f"[bridge] seedance 配额补满落盘失败: {e}")
        return True

    def mark_quota_exhausted_full(self, w, reason):
        """2026-11-03 v3：额度耗尽文案 → 一次性落「3/3 满额 + 不可派发 + 已封禁 + 次日 00:01」。

        以前只有 mark_quota_exhausted() 写被动封禁（quota_ok=False），seedance 计数
        仍靠"检测到视频"累加：控制台会出现「已封禁但今日已生成 0/3」，或更糟——
        历史残留的「你的视频生成好了」把额度拒绝误判成出片、虚增一次凑成 3/3。
        这里把两条链路合并成一个确定动作：
          1) 被动封禁标记（固定次日 00:01 恢复）；
          2) 主动每日计数直接补到上限（3/3、已满额·今日停派、不可派发）；
          3) 同步 worker 内存态，让本轮派发立刻生效。
        """
        msg = str(reason or "额度已用完")
        mark = self.mark_quota_exhausted(
            getattr(w, "target_id", ""), getattr(w, "nickname", ""), msg)
        try:
            day = time.strftime("%Y-%m-%d", time.localtime())
            model = (str(self.config.get("model_name") or "").strip()
                     or str(getattr(w, "model_name", "") or ""))
            if model:
                self.seedance_quota_fill_to_limit(w, model, day, reason=msg)
        except Exception as e:
            print(f"[bridge] 额度耗尽补满计数失败: {e}")
        try:
            w.quota_ok = False
            w.quota_msg = msg
            w.quota_marked_at = time.time()
            w.quota_recover_ts = mark.get("recover_at_ts", 0.0)
        except Exception:
            pass
        return mark

    # ---------------- 受限额模型每日生成额度（按模型独立计数） ----------------
    # 2026-11-13：用户要求控制台为 Seedance 2.0 Fast / Mini 各给一个 1~10 次下拉框，
    # 两者分别计数。旧版共用的 __seedance_2_0_shared__ 桶在启动时自动迁移（见下）。
    def _limited_models(self):
        return list(self.config.get("daily_limited_models") or DAILY_LIMIT_MODELS)

    def _canonical_model(self, model):
        return _canonical_limited_model(model, self._limited_models())

    def _daily_limit_for(self, model):
        """该模型今日上限（1~10）。不受限额的模型返回 0 = 不限制。"""
        canon = self._canonical_model(model)
        if not canon:
            return 0
        raw = self.config.get("daily_model_limits") or {}
        try:
            n = int(raw.get(canon, self.config.get("daily_seedance_limit", 3)))
        except (TypeError, ValueError):
            n = self.config.get("daily_seedance_limit", 3)
        try:
            return max(DAILY_LIMIT_MIN, min(DAILY_LIMIT_MAX, int(n)))
        except (TypeError, ValueError):
            return DEFAULT_CONFIG["daily_seedance_limit"]

    def daily_limits_snapshot(self):
        return daily_limits_snapshot(self.config)

    def _seedance_account_key(self, w):
        """每日计数主键：管理器账号 UUID 优先，跨重启/换顺序/换账号都稳定。

        2026-11-14 实测：旧版用「昵称 → CDP target_id」，重启后 target_id 全变、
        昵称常抓到 UI 文案，今天 3 次生成被重复记到 8 个 key，控制台把 A 账号
        的 2 次显示成 B 账号的 1 次。UUID 由管理器按账号资料注入，才是能长期
        对账的身份；探测暂不可用时才退回旧链路，且不会把漂移 key 当长期身份。
        """
        uid = str(getattr(w, "account_uuid", "") or "").strip().lower()
        if not _STABLE_UUID_RE.match(uid):
            info = account_identity_snapshot().get(
                str(getattr(w, "target_id", "") or "")) or {}
            uid = str(info.get("uuid") or "")
        key = stable_account_key(uid)
        if key:
            return key
        return (valid_nickname(getattr(w, "nickname", ""))
                or getattr(w, "target_id", "") or "")

    def _seedance_bucket(self, model):
        """Fast / Mini 各用自己的桶，互不挤占；非受限额模型按自身名返回（不计数）。"""
        canon = self._canonical_model(model)
        return "__seedance_model__" + canon if canon else (model or "")

    def _migrate_legacy_shared_buckets(self):
        """把旧版共享桶里的历史 tids 按任务实际模型拆到两个新桶。

        旧桶只有一条 "合计 N 次" 的记录，无法从计数本身分辨模型；这里按 tid 回查
        tasks.json 里的 model 字段归类，查不到的按当时默认模型归类，保证升级后
        不会把已用额度清零（那会让所有账号今天又被超额派单）。
        迁移完成后删除旧桶，本身就是"已迁移"标记，重启不会重复执行。
        """
        if not isinstance(self._seedance_quota, dict):
            self._seedance_quota = {}
            return
        models = self._limited_models()
        if not models:
            return
        default_model = (self._canonical_model(self.config.get("model_name") or "")
                         or models[0])
        changed = False
        for _day, accts in list(self._seedance_quota.items()):
            if not isinstance(accts, dict):
                continue
            for _acct, buckets in list(accts.items()):
                if not isinstance(buckets, dict):
                    continue
                legacy = buckets.get(LEGACY_SHARED_BUCKET)
                if not isinstance(legacy, dict):
                    continue
                tids = list(legacy.get("tids") or [])
                grouped = {m: [] for m in models}
                for tid in tids:
                    used_model = ""
                    try:
                        task = self.store.get(str(tid))
                        if task:
                            used_model = self._canonical_model(
                                task.get("model") or task.get("model_name") or "")
                    except Exception:
                        pass
                    grouped[used_model or default_model].append(tid)
                for m, ids in grouped.items():
                    if not ids:
                        continue
                    rec = buckets.setdefault(self._seedance_bucket(m),
                                             {"count": 0, "tids": []})
                    seq = rec.setdefault("tids", [])
                    for tid in ids:
                        if tid not in seq:
                            seq.append(tid)
                    rec["count"] = len(seq)
                buckets.pop(LEGACY_SHARED_BUCKET, None)
                changed = True
        if changed:
            try:
                save_json(SEEDANCE_QUOTA_PATH, self._seedance_quota)
                print("[doubao-bridge] 已把旧的 Fast/Mini 共享额度计数拆分为两个独立桶")
            except Exception as e:
                print(f"[bridge] 额度计数迁移落盘失败: {e}")

    # ---------------- 今日历史额度账本（2026-11-14）----------------
    def _ledger_rollover(self):
        """跨自然日自动清零：只保留当天（00:00:00–23:59:59）的流水。"""
        day = time.strftime("%Y-%m-%d", time.localtime())
        if not isinstance(self._today_ledger, dict):
            self._today_ledger = {}
        if self._today_ledger.get("day") != day:
            self._today_ledger = {"day": day, "tids": {}, "suppressed": []}
            self._ledger_save()
        self._today_ledger.setdefault("day", day)
        if not isinstance(self._today_ledger.get("tids"), dict):
            self._today_ledger["tids"] = {}
        if not isinstance(self._today_ledger.get("suppressed"), list):
            self._today_ledger["suppressed"] = []
        return day

    def _ledger_save(self):
        try:
            save_json(TODAY_LEDGER_PATH, self._today_ledger)
        except Exception as e:
            print(f"[bridge] 今日额度流水落盘失败: {e}")

    def _ledger_register(self, tid, model, account="", key="", at=""):
        """真实生成完成即登记一条账号无关的今日消费（同 tid 只记一次）。"""
        self._ledger_rollover()
        tid = str(tid or "").strip()
        if not tid:
            return False
        tids = self._today_ledger.setdefault("tids", {})
        if tid in tids or tid in set(str(x) for x in (self._today_ledger.get("suppressed") or [])):
            return False
        canon = (self._canonical_model(model)
                 or self._canonical_model(str(self.config.get("model_name") or ""))
                 or (self._limited_models()[0] if self._limited_models() else ""))
        tids[tid] = {
            "model": canon,
            "at": at or now_str(),
            "account": str(account or "")[:40],
            "key": str(key or "")[:64],
        }
        self._ledger_save()
        return True

    def _seedance_quota_add_key(self, key, model, day, tid):
        """按账号 key 记一次额度；生成计数与历史回填共用同一条写入路径。"""
        key, tid = str(key or "").strip(), str(tid or "").strip()
        if not key or not tid:
            return False
        limit = self._daily_limit_for(model)
        if not limit:
            return False
        rec = (self._seedance_quota.setdefault(day, {})
               .setdefault(key, {})
               .setdefault(self._seedance_bucket(model), {"count": 0, "tids": []}))
        seq = rec.setdefault("tids", [])
        if tid in seq or len(seq) >= limit:
            return False
        seq.append(tid)
        rec["count"] = len(seq)
        return True

    def _resolve_ledger_key(self, rec, store=None):
        """把账本一条消费解析成稳定账号 key。

        兼容三种历史写法：稳定 uuid key / 旧 CDP target_id / 账号显示名。
        解析不出来返回空串，交由保守回填处理，绝不猜顺序。
        """
        store = store if isinstance(store, dict) else load_account_identities()
        rec = rec or {}
        k = str(rec.get("key") or "").strip()
        if is_stable_account_key(k):
            return k.lower()
        uid = str((store.get("targets") or {}).get(k) or "")
        if uid:
            return stable_account_key(uid)
        name = str(rec.get("account") or "").strip()
        if name:
            for uid, info in (store.get("accounts") or {}).items():
                nm = str((info or {}).get("name") or "")
                if nm and (nm in name or name in nm):
                    return stable_account_key(uid)
        return ""

    def _rebuild_today_quota_from_ledger(self, day, tids, suppressed):
        """以今日流水为唯一真源重建当天额度，清理漂移 key 与重复计数。

        旧逻辑只统计在线账号 key 的 tids，再按 slot 升序盲回填「孤儿次数」，
        实测同一笔生成被重复记到 8 个漂移 target_id key。改为：
          ① 账本每条 tid 只归属一次，优先稳定 UUID key；
          ② 当天只保留稳定 key 的记录，漂移 key（32 位 target_id、脏昵称、
             伪 tid「quota_exhausted」）全部清除；
          ③ 实在解析不出归属的，按当前在线账号已用次数从少到多保守回填，
             并写回账本，下次不再重复。未在线的账号不会凭空被记次数。
        """
        store = load_account_identities()
        models = list(self._limited_models())
        default_model = (self._canonical_model(str(self.config.get("model_name") or ""))
                         or (models[0] if models else ""))
        grouped = {m: {} for m in models}
        orphan = []
        ordered = sorted(tids.items(), key=lambda x: str((x[1] or {}).get("at") or ""))
        for tid, rec in ordered:
            if tid in suppressed:
                continue
            rec = rec or {}
            m = self._canonical_model(str(rec.get("model") or "")) or default_model
            if m not in grouped:
                grouped[m] = {}
            k = self._resolve_ledger_key(rec, store)
            if k:
                grouped[m].setdefault(k, []).append(tid)
            else:
                orphan.append((tid, m, rec))
        old = self._seedance_quota.get(day, {}) or {}
        # 账本 key 丢失/被删时，从当天 quota 里已按稳定 key 记下的 tids 反推归属，
        # 避免重新分配造成重复计数（账本文件损坏、重装、手动清理都靠这条兜住）。
        recovered = False
        if orphan and old:
            owner = {}
            for k, buckets in old.items():
                if not is_stable_account_key(k):
                    continue
                for _b, rec in (buckets or {}).items():
                    if not isinstance(rec, dict):
                        continue
                    for tid in (rec.get("tids") or []):
                        owner[str(tid)] = k
            rest = []
            for tid, m, rec in orphan:
                k = owner.get(tid)
                if k:
                    grouped.setdefault(m, {}).setdefault(k, []).append(tid)
                    rec["key"] = k
                    recovered = True
                else:
                    rest.append((tid, m, rec))
            orphan = rest
        # ③ 保守回填：只给当前在线的稳定身份，优先已用次数最少者，写回账本
        filled = 0
        if orphan:
            try:
                workers = sorted(list(self.workers.values()),
                                 key=lambda x: int(getattr(x, "slot", 0) or 0))
            except Exception:
                workers = []
            keys = []
            for w in workers:
                k = self._seedance_account_key(w)
                if is_stable_account_key(k) and k not in keys:
                    keys.append(k)
            for tid, m, rec in orphan:
                if not keys:
                    break
                k = min(keys, key=lambda kk: (len(grouped.get(m, {}).get(kk, [])),
                                              keys.index(kk)))
                limit = self._daily_limit_for(m)
                if limit and len(grouped[m].setdefault(k, [])) >= limit:
                    continue
                grouped[m][k].append(tid)
                rec["key"] = k
                filled += 1
        # 一个稳定身份都没解析出来（管理器未就绪 / 旧版本没注入 UUID）时，
        # 绝不清空当天额度：保留旧数据等下次对账，避免把已用额度抹成 0 后超额派发。
        has_stable = any(is_stable_account_key(k)
                         for mapping in grouped.values() for k in mapping)
        if not has_stable and old:
            return {"filled": 0, "stable_keys": 0, "cleared": 0,
                    "changed": False, "skipped": "no_stable_identity"}
        # ② 重建：只保留受限额模型的稳定 key 记录，每个 tid 只出现一次
        rebuilt = {}
        for m, mapping in grouped.items():
            bucket = self._seedance_bucket(m)
            for k, seq in mapping.items():
                if not is_stable_account_key(k):
                    continue
                acct = rebuilt.setdefault(k, {})
                out = acct.setdefault(bucket, {"count": 0, "tids": []})
                for tid in seq:
                    if tid not in out["tids"]:
                        out["tids"].append(tid)
                out["count"] = len(out["tids"])
        changed = (old != rebuilt)
        self._seedance_quota[day] = rebuilt
        # 反推出来的归属也写回账本，下次重启直接解析，不必再走兜底
        if changed or recovered:
            try:
                save_json(SEEDANCE_QUOTA_PATH, self._seedance_quota)
            except Exception as e:
                print(f"[bridge] 今日额度重建落盘失败: {e}")
            self._ledger_save()
        return {"filled": filled, "stable_keys": len(rebuilt),
                "cleared": max(0, len(old) - len(rebuilt)), "changed": changed}

    def _reconcile_today_ledger(self, force=False):
        """重启 / 账号身份漂移后，重建今日全天历史使用额度并回填。

        两步：
          ① 从 tasks.json 扫描 day 当天已生成视频的终态任务，把 tid 补进
             账号无关的今日流水；账本文件丢失、被删、服务重装都能恢复。
          ② 流水里若有 tid 无法归属到「当前在线账号的额度 key」，说明账号
             身份在重启后变了（昵称/target_id/序号全变）。按账号序号升序把
             这些孤儿次数回填到各账号的 quota 记录并落盘，直到该账号额度
             用满；回填写进 tids 后下次即被认领，天然幂等。回填让控制台
             显示真实的 2/2，并让 seedance_daily_full 立刻停派，避免超额。
        """
        now = time.time()
        if not force and now - getattr(self, "_ledger_reconcile_ts", 0.0) < 5.0:
            return getattr(self, "_ledger_stats", {}) or {}
        lock = getattr(self, "_ledger_reconcile_lock", None)
        if lock is None:
            lock = threading.Lock()
            self._ledger_reconcile_lock = lock
        if not lock.acquire(blocking=False):
            return getattr(self, "_ledger_stats", {}) or {}
        try:
            day = self._ledger_rollover()
            suppressed = set(str(x) for x in (self._today_ledger.get("suppressed") or []))
            tids = self._today_ledger.setdefault("tids", {})
            added = 0
            # ① 重建今日 00:00:00–23:59:59 的历史消费
            try:
                tasks = self.store.list()
            except Exception:
                tasks = []
            default_model = (self._canonical_model(str(self.config.get("model_name") or ""))
                             or (self._limited_models()[0] if self._limited_models() else ""))
            _snapshot = account_identity_snapshot()
            _idstore = load_account_identities()
            for t in tasks or []:
                if not task_generated_today(t, day):
                    continue
                tid = str(t.get("id") or "").strip()
                if not tid or tid in suppressed or tid in tids:
                    continue
                model = (self._canonical_model(str(t.get("model") or t.get("model_name") or ""))
                         or default_model)
                old_key = str(t.get("assigned_to") or "")[:64]
                info = (_snapshot.get(old_key)
                        or identity_for_target(old_key, _idstore) or {})
                tids[tid] = {
                    "model": model,
                    "at": str(t.get("updated_at") or t.get("created_at") or now_str()),
                    "account": str(info.get("name") or t.get("worker_name") or "")[:40],
                    "key": str(info.get("key") or old_key)[:64],
                }
                added += 1
            if added:
                self._ledger_save()
                print(f"[doubao-bridge] 今日历史额度重建：从 {day} 任务记录补回 {added} 次已生成")
            # ② 以今日流水为唯一真源重建当天额度：清理漂移 key，每 tid 只归属一次
            try:
                stat = self._rebuild_today_quota_from_ledger(day, tids, suppressed)
            except Exception as e:
                print(f"[bridge] 今日额度重建失败（已忽略）: {e}")
                stat = {}
            filled = int(stat.get("filled") or 0)
            if stat.get("cleared"):
                print(f"[doubao-bridge] 今日额度按稳定账号 ID 对账："
                      f"清理 {stat['cleared']} 个漂移 key，保留 {stat.get('stable_keys', 0)} 个账号")
            self._ledger_stats = {
                "day": day,
                "total": len(tids),
                "by_model": {m: sum(1 for r in tids.values() if r.get("model") == m)
                             for m in self._limited_models()},
                "tids": [str(x)[-10:] for x in tids],
                "rebuilt": added,
                "filled": filled,
                "cleared": int(stat.get("cleared") or 0),
                "stable_keys": int(stat.get("stable_keys") or 0),
                "at": now_str(),
            }
            self._ledger_reconcile_ts = now
            return self._ledger_stats
        finally:
            lock.release()

    def today_history_snapshot(self):
        return dict(getattr(self, "_ledger_stats", {}) or {})

    def seedance_daily_count(self, w, model, day):
        """该账号该模型在 day（YYYY-MM-DD）已生成的视频数。"""
        try:
            bucket = self._seedance_bucket(model)
            return int(self._seedance_quota.get(day, {})
                       .get(self._seedance_account_key(w), {})
                       .get(bucket, {}).get("count", 0))
        except Exception:
            return 0

    def seedance_account_full_models(self, w, day):
        """该账号今日已达上限的受限额模型列表（两个桶分别判定）。"""
        out = []
        for m in self._limited_models():
            limit = self._daily_limit_for(m)
            if limit and self.seedance_daily_count(w, m, day) >= limit:
                out.append(m)
        return out

    def seedance_daily_full(self, w, model, day):
        """该账号今日是否不可再派发「受限额模型」的任务。

        ★ 2026-11-13 用户二次调整：两个模型仍各自计数、各自可设 1~10 次，
          但派发判定改为连坐 —— 任一模型达到上限，该账号 Fast / Mini
          两个模型当天都停派（Fast 满了 Mini 也不派，反之亦然）。
          非受限额模型不受此限制。
        """
        # 无论从编排器、实时扫描还是控制台看板进来，判定额度前都先确保
        # 今日历史流水已重建/回填（内部 5 秒节流 + 非阻塞锁，开销可忽略）。
        # 这条是「重启后额度被清零」的最后一道防线：不依赖调用方记得触发。
        try:
            self._reconcile_today_ledger()
        except Exception:
            pass
        if not self._canonical_model(model):
            return False
        return bool(self.seedance_account_full_models(w, day))

    def seedance_quota_inc(self, w, model, day, tid):
        """视频真实生成完成即按生成完成日归属 +1（无论回传成败，豆包侧已生成就算）；
        按模型独立计数，同一 tid 在同一桶内去重。"""
        limit = self._daily_limit_for(model)
        if not limit:
            return
        acct = self._seedance_account_key(w)
        # 先登记账号无关的今日流水：即使下面因封顶未累加，生成事实也不能丢，
        # 重启后靠它重建今日 00:00–23:59 的历史使用额度。
        try:
            name = (w.account_label() if hasattr(w, "account_label")
                    else (w.display_name() if hasattr(w, "display_name") else ""))
            self._ledger_register(tid, model, account=name, key=acct)
        except Exception:
            pass
        if self._seedance_quota_add_key(acct, model, day, tid):
            try:
                save_json(SEEDANCE_QUOTA_PATH, self._seedance_quota)
            except Exception as e:
                print(f"[bridge] seedance 配额落盘失败: {e}")

    def _seedance_all_full(self, day, model):
        """是否所有在线账号今日都已不可派发受限额模型（用于满额提示）。

        连坐规则下，只要某账号任意一个受限额模型达上限，该账号即视为停派。
        本方法在 Scheduler 内，直接用自己的 _lock/workers 快照（与 Orchestrator 的
        _live_workers_sorted 等价），不跨类调用，避免 AttributeError。"""
        if not self._daily_limit_for(model):
            return False
        with self._lock:
            workers = sorted(list(self.workers.values()), key=lambda x: x.slot)
        if not workers:
            return False
        return all(self.seedance_daily_full(w, model, day) or (not w.quota_ok)
                   for w in workers if not w.dead)

    # ---------------- 轮询游标（跨批次均衡分派）----------------
    def _save_dispatch_state(self):
        try:
            save_json(DISPATCH_STATE_PATH, {"cursor_key": self._dispatch_cursor_key or ""})
        except Exception as e:
            print(f"[bridge] 分派游标落盘失败: {e}")

    def _set_dispatch_cursor(self, key):
        """记录本轮最后分派的账号（稳定身份），下一轮从其后一位起扫。"""
        self._dispatch_cursor_key = key or ""
        self._save_dispatch_state()

    def clear_seedance_quota(self, day=None):
        """清除指定日期或全部每日计数（调试/手动重置用）。

        手动重置必须把当天已登记的 tid 放进 suppressed，否则下一次对账又会
        从 tasks.json 把它们原样补回，控制台「重置今日计数」等于没点。
        """
        if day is None:
            self._seedance_quota = {}
            day = time.strftime("%Y-%m-%d", time.localtime())
        else:
            self._seedance_quota.pop(day, None)
        try:
            save_json(SEEDANCE_QUOTA_PATH, self._seedance_quota)
        except Exception as e:
            print(f"[bridge] seedance 配额清除落盘失败: {e}")
        try:
            if day == self._ledger_rollover():
                suppressed = set(str(x) for x in (self._today_ledger.get("suppressed") or []))
                suppressed |= set(self._today_ledger.setdefault("tids", {}))
                self._today_ledger["suppressed"] = sorted(suppressed)
                self._today_ledger["tids"] = {}
                self._ledger_save()
                self._ledger_stats = {}
                self._ledger_reconcile_ts = 0.0
        except Exception as e:
            print(f"[bridge] 今日额度流水重置失败: {e}")

    # ---------------- 每账号强制冷却（控制台按钮 → 桥接不再派发新任务） ----------------
    # 与「额度不足」被动封禁完全独立：不会在次日 0:01 自动解除，也不会被
    # 「重置额度标记 / 重置今日计数」清掉，只能由用户在控制台点「解除冷却」。
    def save_cooldowns(self):
        try:
            save_json(COOLDOWN_PATH, self._cooldowns)
        except Exception as e:
            print(f"[bridge] 强制冷却名单落盘失败: {e}")

    def cooldown_records(self):
        with self._cooldown_lock:
            recs = [dict(v) for v in (self._cooldowns.get("accounts") or {}).values()
                    if isinstance(v, dict)]
        return sorted(recs, key=lambda r: str(r.get("at") or ""))

    def _cooldown_record_for(self, w):
        """返回命中该账号的冷却记录（无则 None）。

        nickname 优先（跨重启/页面重开稳定），target_id 兜底；两端都没有昵称时
        才退回 display_name 完全相等，避免不同账号串号。
        """
        with self._cooldown_lock:
            recs = [dict(v) for v in (self._cooldowns.get("accounts") or {}).values()
                    if isinstance(v, dict)]
        if not recs:
            return None
        nick = (getattr(w, "nickname", "") or "").strip()
        tid = (getattr(w, "target_id", "") or "").strip()
        key = self._seedance_account_key(w)
        try:
            name = w.display_name()
        except Exception:
            name = ""
        for r in recs:
            rk = str(r.get("key") or "")
            rnick = str(r.get("nickname") or "").strip()
            rtid = str(r.get("target_id") or "").strip()
            if key and (rk == key or (nick and rnick == nick)):
                return r
            if nick and (rk == nick or rnick == nick):
                return r
            if tid and (rk == tid or rtid == tid):
                return r
            if name and not nick and not rnick and str(r.get("name") or "") == name:
                return r
        return None

    def is_account_cooldown(self, w):
        return self._cooldown_record_for(w) is not None

    def set_account_cooldown(self, key, enabled, name="", nickname="", target_id="", slot=0):
        """开/关某账号冷却。key = 控制台传来的稳定身份（昵称优先，target_id 兜底）。

        只影响后续派发：在途任务照常生成/回收，不取消、不释放账号，
        避免浪费已扣的额度或把已生成的片子丢掉。
        """
        key = str(key or "").strip()
        if not key:
            return False, "缺少账号标识"
        rec = None
        if enabled:
            # 在线账号优先用 worker 的真实身份补齐全字段，页面重开后也能匹配上
            with self._lock:
                workers = list(self.workers.values())
            for w in workers:
                candidates = (self._seedance_account_key(w),
                              getattr(w, "target_id", "") or "",
                              (getattr(w, "nickname", "") or "").strip())
                if key not in candidates:
                    continue
                try:
                    name, slot = w.display_name(), w.slot
                except Exception:
                    pass
                nickname = (getattr(w, "nickname", "") or "").strip() or nickname
                target_id = (getattr(w, "target_id", "") or "").strip() or target_id
                break
            try:
                slot_num = int(slot or 0)
            except (TypeError, ValueError):
                slot_num = 0
            rec = {
                "key": key,
                "name": str(name or ""),
                "nickname": str(nickname or "").strip(),
                "target_id": str(target_id or ""),
                "slot": slot_num,
                "at": now_str(),
                "reason": "任务控制台手动强制冷却",
            }
        with self._cooldown_lock:
            accounts = self._cooldowns.setdefault("accounts", {})
            if enabled:
                accounts[key] = rec
            else:
                # 解除时把指向同一账号的旧记录一并清掉（身份升级/页面重开残留）
                for k, v in list(accounts.items()):
                    if not isinstance(v, dict):
                        accounts.pop(k, None)
                        continue
                    if (k == key
                            or (nickname and str(v.get("nickname") or "").strip() == nickname)
                            or (target_id and str(v.get("target_id") or "") == target_id)
                            or (name and str(v.get("name") or "") == name)):
                        accounts.pop(k, None)
            count = len(accounts)
        self.save_cooldowns()
        print(f"[doubao-bridge] {'强制冷却' if enabled else '解除冷却'} 账号 {key}"
              f"（当前冷却 {count} 个）", flush=True)
        return True, count

    def clear_all_cooldowns(self):
        with self._cooldown_lock:
            n = len(self._cooldowns.get("accounts") or {})
            self._cooldowns["accounts"] = {}
        self.save_cooldowns()
        return n

    def clear_quota_mark(self, target_id, nickname=""):
        """清除账号额度不足标记（按 target_id 和 nickname 双重匹配）。"""
        removed = False
        if target_id in self._quota_marks:
            self._quota_marks.pop(target_id, None)
            removed = True
        nick = (nickname or "").strip()
        if nick:
            for k, m in list(self._quota_marks.items()):
                if (m.get("nickname") or "").strip() == nick:
                    self._quota_marks.pop(k, None)
                    removed = True
        if removed:
            self.save_quota_marks()

    def find_quota_mark(self, target_id, nickname=""):
        """按双重身份查找额度标记：target_id 精确匹配，或 nickname 相等（非空）。

        已过恢复时间的标记自动清除并返回 None。
        """
        now_ts = time.time()
        # 先清理所有过期标记
        expired = [k for k, m in self._quota_marks.items()
                   if now_ts >= m.get("recover_at_ts", 0)]
        for k in expired:
            self._quota_marks.pop(k, None)
        if expired:
            self.save_quota_marks()
        mark = self._quota_marks.get(target_id)
        if mark:
            return mark
        nick = (nickname or "").strip()
        if nick:
            for m in self._quota_marks.values():
                if (m.get("nickname") or "").strip() == nick:
                    return m
        return None

    def _find_quota_mark_by_nickname(self, nickname):
        """按 nickname 在所有持久化标记中查找（不依赖 target_id，跨重启稳定）。

        用于 worker 重建时恢复额度状态：target_id 重启后变化，
        但 quota_marks.json 中保留了 nickname，由此可找回对应的标记。
        """
        nick = (nickname or "").strip()
        if not nick:
            return None
        for m in self._quota_marks.values():
            if (m.get("nickname") or "").strip() == nick:
                return m
        return None

    def start(self):
        threading.Thread(target=self._loop, daemon=True, name="dbm-scheduler").start()
        # 串行编排器：串行分发 → 并行生成 → 按分镜顺序逐个回收
        self.orchestrator = Orchestrator(self)
        self.orchestrator.start()

    def _loop(self):
        ev = getattr(self, "_wake", None)
        if ev is None:
            ev = threading.Event()
            self._wake = ev
        while True:
            try:
                self.tick()
            except Exception as e:
                print(f"[doubao-bridge] 调度异常: {e}")
            # 事件驱动：提交任务 / 新账号上线时立刻再枚举一次；
            # 无事件时保持原来 3 秒的巡检节奏。
            ev.wait(3)
            ev.clear()

    def tick(self):
        # 0. 今日历史额度对账：账号上线后立刻把重启前已用的次数回填，
        #    不能等控制台或派发时才想起来（内部 5 秒节流）。
        try:
            self._reconcile_today_ledger()
        except Exception:
            pass
        # 0. 环境自检：系统代理开着但端口没人监听时，豆包账号页必然全部加载失败。
        # 之前这种情况只会表现为"账号加载失败 / 需要标定"，用户完全无从下手。
        # 这里每 60 秒提示一次，并给出可执行的修复办法。
        try:
            now = time.time()
            if now - getattr(self, "_env_warn_ts", 0.0) >= 60:
                self._env_warn_ts = now
                for it in env_diagnostics():
                    print(f"[doubao-bridge][环境] {it['message']} —— 处理：{it['fix']}")
        except Exception:
            pass
        # 1. 管理器由调度器统一启动
        if not self.ctrl.manager_running():
            if not self.config.get("auto_start_manager", True):
                return
            try:
                self.ctrl.launch_manager()
                # 管理器重启后重置自动打开标记，下次 tick 重新尝试
                self._auto_opened = False
            except ManagerAlreadyRunning:
                # 管理器已在启动中，静默等待，不重复拉起
                return
            except Exception:
                return
        try:
            self.ctrl.wait_cdp_ready(timeout=8)
        except Exception:
            return
        accounts = self.ctrl.list_accounts()
        live_ids = {a["id"] for a in accounts}
        # 与派发前的实时扫描共用同一份"当前已打开账号"名单。
        # ★ 注意：list_targets() 在 CDP 抖动时会把异常吞成空列表，和"账号真的
        #   全被关掉了"无法区分。这里用能区分失败的 live_account_ids() 作权威
        #   来源：扫描成功（含空集合）才覆盖；扫描失败则保留上次名单，
        #   不让一次瞬时超时把全部账号误判成已关闭、白白停派 3 秒。
        try:
            scanned = self.ctrl.live_account_ids(timeout=3)
        except Exception:
            scanned = None
        if scanned is not None:
            self._live_ids = set(scanned)
            self._live_ids_ts = time.time()
        elif live_ids:
            # 权威扫描失败，但 list_accounts() 确实看到了账号：用它兜底，
            # 同时刷新时间戳，避免连续失败把账号误判成"名单过期"而停派。
            self._live_ids = set(live_ids)
            self._live_ids_ts = time.time()
        elif not getattr(self, "_live_ids", None):
            self._live_ids = set()
            self._live_ids_ts = time.time()
        # 两边都没探到、且已有旧名单：保留旧名单但不刷新时间戳，
        # 超过 LIVE_IDS_MAX_STALE_SEC 后自动停派，等 CDP 恢复再继续。

        # 管理器启动后自动打开所有账号（幂等，只执行一次）
        if not self._auto_opened and accounts:
            self._auto_opened = True
            try:
                r = self.ctrl.open_all_accounts(timeout=120)
                if r.get("ok"):
                    print(f"[doubao-bridge] 自动打开账号成功: {r.get('opened', 0)} 个，{r.get('note', '')}")
                else:
                    print(f"[doubao-bridge] 自动打开账号失败: {r.get('reason', '未知')}，下次 tick 重试")
                    self._auto_opened = False
            except Exception as e:
                print(f"[doubao-bridge] 自动打开账号异常: {e}，下次 tick 重试")
                self._auto_opened = False

        with self._lock:
            # 2. 同步现有 worker 的账号序号。
            #    ★ 2026-09-22：改成"首见即锁定"（_assign_slot），不再每 tick 跟着
            #    管理器上报值改号。管理器那个号是按 webview 的 DOM 顺序算的，本身就在
            #    不停抖（账号6→3→5→3→6→4→7…），照抄只会让日志前后对不上号。
            #    现在只有"这个 target 还没定过号"时才会定一次，之后不再变。
            id_to_slot = {a["id"]: int(a.get("slot") or 0) for a in accounts}
            for tid, w in sorted(self.workers.items(), key=lambda kv: kv[1].slot):
                # ⚠️ 任务进行中绝不改序号：display_name() 现在直接决定成品文件名
                # （<账号名>_<时间>.mp4）和归属判定，中途改名会让"认领/回传"
                # 前后对不上，也会让日志里出现"分发给账号3、完成却写账号1"。
                if getattr(w, "busy", False) or getattr(w, "current_tid", None):
                    continue
                want = self._assign_slot(tid, id_to_slot.get(tid, 0))
                if want != w.slot:
                    old = w.slot
                    w.slot = want
                    print(f"[doubao-bridge] 账号序号同步: 账号{old} → 账号{w.slot}")
            # 3. 清理失效 worker（账号页被关闭）
            for tid in list(self.workers.keys()):
                w = self.workers[tid]
                if w.dead or tid not in live_ids:
                    if not w.busy:
                        w.stop()
                        self.workers.pop(tid, None)
                        self._release_slot(tid)   # 归还锁定序号，否则号会越用越大
                        print(f"[doubao-bridge] 账号 worker 下线: 账号{w.slot}")
                    # 忙碌中的等它自行失败（任务会自动重排），下一 tick 再收
            # 3. 新账号 → 新 worker（受并发上限约束；0=自动=账号数）
            cap = int(self.config.get("max_concurrency", 0) or 0)
            limit = cap if cap > 0 else max(1, len(accounts))
            # 账号序号直接用豆包管理器的序号（account["slot"]），保证与管理器一致
            # 当管理器新增/调整账号时，序号自动同步
            added_workers = 0
            for a in sorted(accounts, key=lambda x: x.get("slot", 9999)):
                if a["id"] not in self.workers and len(self.workers) < limit:
                    # 管理器返回的 slot 有时全部相同（日志里会看到 N 个"账号4"），
                    # 这会让日志完全无法区分账号、也无法定位问题。这里强制去重：
                    # 缺失、非法或已被占用时顺序补号。
                    # ★ 2026-09-22：统一走 _assign_slot()，定号后锁定不再变。
                    slot = self._assign_slot(a["id"], int(a.get("slot") or 0))
                    self._slot_counter = max(self._slot_counter, slot)
                    w = AccountWorker(self, slot, a)
                    # 从持久化标记恢复额度不足状态：
                    # 先尝试 target_id 精确匹配（重启后 target_id 可能已变化）
                    mark = self.find_quota_mark(a["id"], "")
                    if not mark:
                        # target_id 未命中：补查昵称后按 nickname 查找（稳定跨重启）
                        try:
                            nick = w._eval_safe(
                                "(window.__dbm && window.__dbm.guessNick) ? window.__dbm.guessNick() : null")
                            if isinstance(nick, str) and nick.strip():
                                w.nickname = valid_nickname(nick)
                            mark = self._find_quota_mark_by_nickname(w.nickname)
                        except Exception:
                            pass
                    if mark:
                        w._apply_quota_mark(mark)
                        print(f"[doubao-bridge] 账号 worker 上线: {w.display_name()} "
                              f"(target {a['id'][:8]}) "
                              f"[额度不足→{mark.get('recover_at_str', '')}恢复]")
                    else:
                        # 带上豆包昵称（display_name 自动拼），序号万一再变也能认号
                        print(f"[doubao-bridge] 账号 worker 上线: {w.display_name()} "
                              f"(target {a['id'][:8]})")
                    # 2026-11-02：AccountWorker 不再继承 Thread，无需 w.start()
                    self.workers[a["id"]] = w
                    added_workers += 1
                    # 补查昵称并回填持久化标记中的空 nickname（修复跨重启 nickname 缺失问题）
                    if w.nickname:
                        self._refresh_quota_mark_nickname(w.target_id, w.nickname)
            # 4. 任务的分发/回收不再在本 tick 进行——统一由 Orchestrator 编排
            #    （parallel_submit=True 时各账号在独立线程里并发填表→提交→发确认；
            #     =False 时退回串行：切账号1→填表→提交→发确认→切账号2…。
            #     提交后约6分钟按分镜就绪顺序回收，回收本就是多线程）。
            #    本 tick 只负责账号 worker 的上下线管理。
            queued = [t for t in reversed(self.store.list())
                      if t.get("status") == "queued" and not t.get("assigned_to")]
            # 5. 指定了账号但账号不在线：提示一次
            for t in queued:
                kw = (t.get("account") or "").strip()
                if kw and not any(w.matches(kw) for w in self.workers.values()):
                    if t["id"] not in self._wait_hinted:
                        self._wait_hinted.add(t["id"])
                        self.store.log(t["id"],
                                       f"等待账号「{kw}」上线（当前在线 {len(self.workers)} 个账号）")

        # 6. 回收"宿主已放弃"的任务：字字动画侧判失败/被中断后就不再轮询该任务，
        #    桥接若继续排队重试只会白烧账号额度，这里用心跳兜底自动取消。
        try:
            self.reap_orphan_tasks()
        except Exception:
            pass
        # 7. 同步所有在线 worker 的实时额度状态（浏览器可能已恢复/新增耗尽）
        self.sync_quota_status()
        # 8. 本 tick 刚发现新账号 / 刚关掉账号：立刻让编排器重跑一次分派，
        #    别让已排队任务再等一个 2 秒的编排循环（点击即响应的收尾）。
        if added_workers:
            self.wake_orchestrator()

    def _refresh_quota_mark_nickname(self, target_id, nickname):
        """将持久化额度标记中的空 nickname 回填为当前实际昵称（跨重启稳定性修复）。

        原因：mark_quota_exhausted() 在 submit_stage 抛出 QuotaExceeded 时被调用，
        此时 w.nickname 仍为空字符串；提交完成后昵称才从页面获取。
        此方法确保所有持久化标记的 nickname 字段与实际一致，
        使 _find_quota_mark_by_nickname() 能在重启后正确匹配。
        """
        nick = (nickname or "").strip()
        if not nick:
            return
        updated = False
        for k, m in list(self._quota_marks.items()):
            if m.get("target_id") == target_id or (
                (m.get("nickname") or "").strip() == "" and m.get("target_id") == target_id
            ):
                m["nickname"] = nick
                updated = True
        if updated:
            self.save_quota_marks()
            print(f"[doubao-bridge] 已回填额度标记 nickname: {target_id[:8]} → {nick}")

    def cancel_task(self, tid, reason="用户请求取消"):
        """取消单个任务，并立即释放它占用的账号。

        只把任务置成 error 是不够的：任务可能正挂在某个 worker 上（busy=True），
        或已进了编排器的 inflight 等待回收。不立即释放的话，该账号会一直被占着，
        而 inflight 非空又会触发"批次屏障"，导致后面所有分镜都分发不出去。
        """
        t = self.store.get(tid)
        if not t:
            return {"ok": False, "error": "任务不存在"}
        st = t.get("status")
        err = t.get("error", "")
        if st == "done":
            return {"ok": False, "error": "任务已完成，无法取消"}
        if st == "failed":
            return {"ok": False, "error": "任务已因成品一致性校验失败终止，无需取消"}
        if st == "error" and err == "cancelled":
            return {"ok": False, "error": "任务已取消"}

        # 具体是"字字动画侧失败"还是"控制台手动取消"，记在日志的 reason 里
        patch = {"status": "error", "percent": 0,
                 "message": "已取消", "error": "cancelled"}
        if st == "queued":
            # 解绑账号，避免被原账号重新领走
            patch["assigned_to"] = ""
        self.store.update(tid, **patch)
        self.store.log(tid, reason)

        released_slot = None
        # 释放仍占着该任务的账号 worker
        for w in list(self.workers.values()):
            if w.current_tid == tid:
                # ★ 先作废旧线程，再释放账号。否则还卡在 CDP 长超时里的旧线程醒来后
                #   会把**下一个**任务刚拿到的 busy 清掉、把它的 WebSocket detach 掉
                #   （2026-09-22：两个任务先后派给同一个账号9，双双 CDP 失败）。
                #   详见 AccountWorker.retire()。
                try:
                    w.retire()
                except Exception:
                    pass
                w.busy = False
                w.current_tid = None
                try:
                    w._fg_release()
                except Exception:
                    pass
                try:
                    w.bridge.detach()
                except Exception:
                    pass
                released_slot = w.slot
        # 从编排器在途列表移除：inflight 非空会卡住批次屏障
        orch = getattr(self, "orchestrator", None)
        if orch is not None:
            try:
                for it in list(orch.inflight):
                    if it.get("tid") == tid:
                        orch.inflight.remove(it)
            except Exception:
                pass
        return {"ok": True, "released_slot": released_slot}

    def reap_orphan_tasks(self):
        """回收"宿主已放弃"的任务（心跳兜底）。

        字字动画里某个分镜判失败后，main.py 会回调取消接口；但如果宿主是直接杀掉
        插件线程（用户点停止、宿主崩溃、批量任务被中断），取消请求根本发不出去，
        桥接侧这个任务会继续排队重试或傻等回收 —— 白烧账号额度，产出的视频也没人
        来取。这里用心跳兜底：超过 orphan_timeout_sec 没有任何轮询就自动取消。
        """
        try:
            timeout = float(self.config.get("orphan_timeout_sec", 300) or 0)
        except (TypeError, ValueError):
            timeout = 300.0
        if timeout <= 0:
            return 0
        now = time.time()
        n = 0
        for t in self.store.list():
            tid = t.get("id")
            # failed 是终态，不能再被孤儿回收改成 error/cancelled 而抹掉原因
            if t.get("status") in ("done", "error", "failed"):
                continue
            poll = t.get("last_poll_ts") or 0
            if not poll:
                continue          # 还没被轮询过：可能刚提交，给足宽限期
            idle = now - poll
            if idle < timeout:
                continue
            r = self.cancel_task(
                tid, f"宿主已 {int(idle)} 秒未轮询该任务，判定为已放弃，自动取消")
            if r.get("ok"):
                n += 1
                print(f"[doubao-bridge] 孤儿任务已自动取消: {tid}（{int(idle)}s 无轮询）")
        return n

    def sync_quota_status(self):
        """周期性 / 事件驱动同步所有在线 worker 的浏览器实时额度状态。

        - 已标记额度不足的 worker：检测页面是否已恢复，若恢复则清除持久化标记
        - 未标记额度不足的 worker：检测页面是否新增耗尽，若有则追加标记
        - 同时补查所有 worker 的昵称（用于后续按 nickname 匹配额度标记）
        - 覆盖：空闲账号 + 生成等待中账号（busy=True 但当前任务由编排器托管）
          只要账号页面 CDP 可用就进行额度检测（无论 busy 状态），确保生成等待阶段
          的额度恢复也能被实时检测到。

        ★ 2026-11-13 两个关键修正（"没额度的账号还在被派单"的真实根因）：
          1) 原来 `_eval_safe(...) or ""` 把「CDP 求值失败 / __dbm 未注入」和
             「页面确实没有额度文案」都压成空串。后者会走进"浏览器已恢复 →
             清除封禁标记"，于是刚被判额度耗尽的账号在下一 tick 就被解封、
             又被派一个注定失败的任务。现在用哨兵串区分三种结果，
             **只有明确读到"页面正常且无额度文案"才允许解封**。
          2) 原来每次 evaluate 默认 30s 超时，一个卡死的账号能把整个 tick
             拖住 30s × N 个账号，表现就是"任务分批次、点了没反应"。
             这里统一压到 3s，并用非阻塞锁防止与点击派发的同步请求叠加。
        """
        _lock = getattr(self, "_quota_sync_lock", None)
        if _lock is None:
            _lock = threading.Lock()
            self._quota_sync_lock = _lock
        if not _lock.acquire(blocking=False):
            return
        try:
            self._sync_quota_status_inner()
        finally:
            _lock.release()

    def _sync_quota_status_inner(self):
        QUOTA_PROBE = ("(function(){"
                       "if(!window.__dbm||typeof window.__dbm.quotaExhausted!=='function')"
                       "return '__DBM_UNKNOWN__';"
                       "var q=window.__dbm.quotaExhausted();"
                       "return q?String(q):'__DBM_OK__';})()")
        for w in list(self.workers.values()):
            if w.dead:
                continue
            try:
                # 补查昵称（首次或昵称仍为空时）
                if not w.nickname:
                    nick = w._eval_safe(
                        "(window.__dbm && window.__dbm.guessNick) ? window.__dbm.guessNick() : null",
                        timeout=3)
                    if isinstance(nick, str) and nick.strip():
                        w.nickname = valid_nickname(nick)
                        # 回填持久化标记中的空 nickname
                        self._refresh_quota_mark_nickname(w.target_id, w.nickname)
                # 检测浏览器实时额度状态（哨兵区分"未知/正常/耗尽"）
                probe = w._eval_safe(QUOTA_PROBE, timeout=3)
                if probe is None or probe == "__DBM_UNKNOWN__":
                    # CDP 没连上 / 注入脚本不在：状态未知，绝不改判、绝不擅自解封
                    continue
                qe = "" if probe == "__DBM_OK__" else str(probe)
                if qe:
                    # 浏览器显示额度耗尽
                    if w.quota_ok:
                        w.quota_ok = False
                        w.quota_msg = qe
                        w.quota_marked_at = time.time()
                        mark = self.mark_quota_exhausted_full(w, qe)
                        w.quota_recover_ts = mark.get("recover_at_ts", 0.0)
                        print(f"[doubao-bridge] 额度耗尽检测: {w.display_name()} → {qe}")
                elif w.quota_ok is False:
                    # ★ 2026-11-03 v3：额度文案出现时已把当日计数补满（3/3），
                    #   此后即使文案因切换对话/刷新而消失，也不提前解除封禁——
                    #   必须等 quota_available() 在次日 00:01 自动恢复，与控制台
                    #   「已封禁 · 次日 00:01 解除额度」的提示保持一致。
                    try:
                        _day = time.strftime("%Y-%m-%d", time.localtime())
                        _model = str(self.config.get("model_name") or "").strip()
                        if (_model and self.seedance_daily_full(w, _model, _day)
                                and time.time() < (getattr(w, "quota_recover_ts", 0) or 0)):
                            continue
                    except Exception:
                        pass
                    # 浏览器已恢复，清除持久化标记
                    self.clear_quota_mark(w.target_id, w.nickname)
                    w.quota_ok = True
                    w.quota_msg = ""
                    w.quota_marked_at = 0.0
                    w.quota_recover_ts = 0.0
                    print(f"[doubao-bridge] 额度已恢复: {w.display_name()}")
            except Exception:
                pass  # CDP 暂时不可用，下一 tick 再试

    def _pick_for(self, worker, queued):
        # 优先：显式指定账号且匹配本 worker
        for t in queued:
            if (t.get("account") or "").strip() and worker.matches(t["account"]):
                return t
        # 其次：未指定账号的任务，任意空闲账号都能接
        for t in queued:
            if not (t.get("account") or "").strip():
                return t
        return None

    def worker_info(self):
        with self._lock:
            out = []
            for w in sorted(self.workers.values(), key=lambda x: x.slot):
                recover_at = ""
                if not w.quota_ok:
                    # 恢复时间从持久化标记读取（标记时固定），而非现场重算
                    mark = self.find_quota_mark(w.target_id, w.nickname)
                    if mark:
                        recover_at = mark.get("recover_at_str", "")
                    elif w.quota_recover_ts:
                        import datetime as _dt
                        recover_at = _dt.datetime.fromtimestamp(w.quota_recover_ts).strftime("%Y-%m-%d %H:%M")
                out.append({
                    "slot": w.slot,
                    "name": w.account_label(),
                    "display_name": w.display_name(),
                    "nickname": w.nickname,
                    "uuid": str(getattr(w, "account_uuid", "") or ""),
                    "stable_key": self._seedance_account_key(w),
                    "busy": w.busy,
                    "page_busy": w.page_busy,
                    "model": w.model_name,
                    "quota_ok": w.quota_ok,
                    "quota_msg": w.quota_msg,
                    "quota_recover_at": recover_at,
                    "current_tid": (w.current_tid or "")[-10:],
                    "done": w.done_count,
                    "target": w.target_id[:12],
                    "cooldown": self.is_account_cooldown(w),
                    "key": self._seedance_account_key(w),
                })
            return out


# ---------------------------------------------------------------------------
# 成品回传到分镜窗口（2026-11-03）
# ---------------------------------------------------------------------------
# 落点规则与 main.py._build_output_path 完全一致：
#   <project_dir>/<viewer_index:04d>_<unique_name>_<generation_round>_<position>.mp4
#
# 新任务提交时插件携带 scene.dest，_finish_done 里自动复制回分镜 —— 不依赖
# 宿主是否还在等 generate() 返回（宿主判失败/超时/关闭时最容易丢片）。
#
# 明确不做的事：不从下载目录「兜底认领」归属不明的 video.mp4。用户 2026-09-20
# 已要求关闭 dir_fallback_enabled（串片 / 可能带水印），本模块沿用该决定：没有
# 明确的 video_path 绝不猜文件归属。
# ---------------------------------------------------------------------------

_RECOVER_MIN_VIDEO_BYTES = 50 * 1024
_RECOVER_DEST_RE = re.compile(r"^(\d{4})_([A-Za-z0-9]+)_(\d+)_(\d+)\.mp4$", re.I)


def _recover_valid_video(path):
    """文件存在且体积达标，才算一份可以交付的成品。"""
    try:
        p = Path(str(path or ""))
        return p.is_file() and p.stat().st_size > _RECOVER_MIN_VIDEO_BYTES
    except Exception:
        return False


def deliver_to_scene(src, dest, tid=""):
    """把成品安全地回传到分镜目标路径，返回 (ok, info)。

    - 目标已存在且 MD5 一致 → 幂等视为已回传，不重复写；
    - 目标已存在但 MD5 不同 → conflict，绝不覆盖（防止盖掉别的分镜视频）；
    - 写入走「同目录临时文件 + os.replace」原子替换，避免宿主读到半截文件。
    """
    info = {"src": str(src or ""), "dest": str(dest or ""), "tid": str(tid or "")}
    try:
        if not src or not dest:
            info["error"] = "源文件或目标路径为空"
            return False, info
        if not _recover_valid_video(src):
            info["error"] = "源文件不存在或体积不合格"
            return False, info
        sp, dp = Path(str(src)), Path(str(dest))
        try:
            if sp.resolve() == dp.resolve():
                info.update(status="already", size=sp.stat().st_size,
                            md5=_file_md5(str(sp)))
                return True, info
        except Exception:
            pass
        try:
            dp.parent.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            info["error"] = "目标目录不可写: %s" % e
            return False, info
        src_md5 = _file_md5(str(sp))
        if dp.exists() and dp.stat().st_size > _RECOVER_MIN_VIDEO_BYTES:
            dst_md5 = _file_md5(str(dp))
            if dst_md5 and dst_md5 == src_md5:
                info.update(status="already", size=dp.stat().st_size, md5=dst_md5)
                return True, info
            info.update(status="conflict",
                        error="目标分镜已有内容不同的视频，未覆盖（防止串片）",
                        size=dp.stat().st_size, md5=dst_md5)
            return False, info
        tmp = dp.with_name(dp.name + ".dbm_recover.tmp")
        try:
            shutil.copy2(str(sp), str(tmp))
            os.replace(str(tmp), str(dp))
        finally:
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass
        info.update(status="delivered", size=dp.stat().st_size, md5=src_md5)
        return True, info
    except Exception as e:
        info["error"] = "回传失败: %s: %s" % (type(e).__name__, e)
        return False, info


def infer_project_dir(task):
    """从任务的参考项路径上溯，推断字字动画项目目录（含 project.db 的那一层）。

    图片形如 <...>/工作目录/默认/10月28日/character_images/xxx.png；
    参考音频可能在同一个项目目录的 audio / 素材子目录里。
    纯音频任务（0 张参考图）也必须能推断出来，否则成品回传的降级扫描会失效。
    只读推断，最多上溯 6 层；优先命中 project.db / project_settings.json。
    """
    cands = []
    for key in ("first_frame", "images", "audios"):
        v = (task or {}).get(key)
        if isinstance(v, str):
            cands.append(v)
        elif isinstance(v, (list, tuple)):
            cands.extend([str(x) for x in v if x])
    fallback = ""
    for c in cands:
        if not c:
            continue
        try:
            p = Path(c)
            cur = p if p.is_dir() else p.parent
            for _ in range(6):
                if not cur or str(cur) in ("", "."):
                    break
                try:
                    if ((cur / "project.db").exists()
                            or (cur / "project_settings.json").exists()
                            or (cur / "project_info.json").exists()):
                        return str(cur)
                    # 兜底：宿主没有 project.db（老项目 / 数据结构变更）时，
                    # 只要这一层带素材子目录，就把它当项目目录，让降级扫描
                    # 已有的 NNNN_*.mp4 仍能工作，而不是直接返回空。
                    if not fallback and any(
                            (cur / d).is_dir()
                            for d in ("character_images", "location_images", "item_images",
                                      "audio", "audios", "reference_audio", "参考音频")):
                        fallback = str(cur)
                except Exception:
                    pass
                parent = cur.parent
                if parent == cur:
                    break
                cur = parent
        except Exception:
            continue
    return fallback


# ---------------------------------------------------------------------------
# HTTP API
# ---------------------------------------------------------------------------

class BridgeState:
    def __init__(self):
        self.config = dict(DEFAULT_CONFIG)
        self.config.update(load_json(CONFIG_PATH, {}))
        if not self.config.get("download_dir"):
            try:
                self.config["download_dir"] = detect_download_dir()
            except Exception:
                self.config["download_dir"] = ""
        self.store = TaskStore()
        self.scheduler = Scheduler(self.store, self.config)
        self.httpd = None


STATE = None


class APIHandler(BaseHTTPRequestHandler):
    server_version = "DoubaoBridge/1.0"

    def log_message(self, fmt, *args):
        pass  # 静默常规访问日志

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        try:
            n = int(self.headers.get("Content-Length", 0))
            if not n:
                return {}
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def _reset_quota_marks(self):
        """清除被动「额度不足」封禁标记（GET / POST 两个入口共用）。"""
        n = 0
        with STATE.scheduler._lock:
            for w in STATE.scheduler.workers.values():
                w.quota_ok = True
                w.quota_msg = ""
                w.quota_recover_ts = 0.0
                n += 1
        STATE.scheduler._quota_marks.clear()
        STATE.scheduler.save_quota_marks()
        return n

    def do_GET(self):
        raw_path = self.path
        path = raw_path.split("?", 1)[0]
        # ★ 宿主存活信号：只有 main.py 发来的插件侧请求带 X-Doubao-Host 头，
        #   控制台（浏览器页面）的请求不带，绝不会被误判成宿主仍在线。
        try:
            _hpid = self.headers.get("X-Doubao-Host")
            if _hpid:
                HOST_GUARD.note(_hpid)
        except Exception:
            pass
        # 任务列表支持 ?brief=1：控制台每 3 秒轮询时只取渲染必需字段，
        # 不带 logs 正文（实测全量 11.4MB / 851 任务，日志占 ~6.8MB）。
        try:
            from urllib.parse import urlparse, parse_qs as _parse_qs
            _query = _parse_qs(urlparse(raw_path).query)
        except Exception:
            _query = {}
        try:
            if path == "/" or path == "/index.html":
                html = CONSOLE_PATH.read_text(encoding="utf-8") if CONSOLE_PATH.exists() else "<h1>Doubao Bridge</h1>"
                body = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if path == "/api/health":
                s = STATE
                running = s.scheduler.ctrl.manager_running()
                workers = s.scheduler.worker_info() if running else []
                queued = sum(1 for t in s.store.list() if t.get("status") == "queued")
                _cool = s.scheduler.cooldown_records()
                self._json({
                    "ok": True,
                    # 服务身份：视频插件桥接。图片插件是另一个桥接（默认 39231 端口），
                    # 插件侧靠这个字段判断端口上跑的到底是不是自己人。
                    "service": "doubao-video-bridge",
                    "manager_running": running,
                    # 管理器的真实 CDP 端口（可能不是配置里的 39233；卡密版会
                    # 写进 DevToolsActivePort）。插件「测试连接」用它开号，
                    # 避免拿 39233 白等 30 秒。
                    "cdp_port": _dbk_resolve_cdp_port(s.scheduler.ctrl),
                    "workers": workers,
                    "accounts": [{"title": w["name"], "busy": w["busy"], "slot": w["slot"]}
                                 for w in workers],
                    "worker_count": len(workers),
                    "busy_count": sum(1 for w in workers if w["busy"]),
                    "quota_blocked": sum(1 for w in workers if not w["quota_ok"]),
                    "model": s.config.get("model_name"),
                    # 控制台设置的每日额度 / 强制冷却名单：插件 main.py 从这里读回，
                    # 保证「控制台改了值、插件侧也知道」，且不会被宿主参数推回旧值。
                    "daily_limits": s.scheduler.daily_limits_snapshot(),
                    "cooldown_count": len(_cool),
                    "cooldown_accounts": [str(r.get("name") or r.get("key") or "")
                                         for r in _cool],
                    # 2026-11-13：派发前实时账号扫描 / 即时派发状态，
                    # 插件「测试连接」与任务控制台都从这里读。
                    "live_scan": s.scheduler.live_scan_info(),
                    "immediate_dispatch": not bool(
                        s.config.get("dispatch_stagger_enabled", False)),
                    "download_dir": s.config.get("download_dir"),
                    "queued": queued,
                    # 环境自检（头号杀手：系统代理开着但没人监听 → 账号全部加载失败）
                    "proxy": system_proxy_settings(),
                    "env_issues": env_diagnostics(),
                    "time": now_str(),
                    # 宿主存活守卫：字字动画关闭后控制台会显示醒目的离线横幅
                    "host": HOST_GUARD.info(),
                })
                return
            if path == "/api/env":
                sp = system_proxy_settings()
                self._json({
                    "ok": True,
                    "proxy": sp,
                    # True=可用 / False=确认不通 / None=无法判定
                    "proxy_reachable": (None if not sp["enabled"]
                                        else proxy_reachable(sp["server"])),
                    "issues": env_diagnostics(),
                    "download_dir": STATE.config.get("download_dir") or detect_download_dir(),
                    "manager_running": STATE.scheduler.ctrl.manager_running(),
                    "time": now_str(),
                })
                return
            if path == "/api/runtime":
                # 任务控制台「运行状态」看板：每日额度（按模型独立）/ 强制冷却 /
                # 轮询游标 / 已交付去重 / 下载目录隔离 一次性暴露，便于核对派发。
                sch = STATE.scheduler
                # 控制台每次刷新都强制对账一次：先重建今日历史流水并回填，
                # 再算各账号 used，保证重启后显示的是 2/2 而不是 0/2。
                try:
                    sch._reconcile_today_ledger(force=True)
                except Exception:
                    pass
                day = time.strftime("%Y-%m-%d", time.localtime())
                limits = sch.daily_limits_snapshot()
                limited = sch._limited_models()
                model = str(STATE.config.get("model_name") or "").strip()
                cur_model = sch._canonical_model(model) or model
                _is_limited = bool(sch._daily_limit_for(model))
                with sch._lock:
                    workers = sorted(list(sch.workers.values()), key=lambda x: x.slot)
                _base_dl = STATE.config.get("download_dir") or ""
                accts = []
                for w in workers:
                    key = sch._seedance_account_key(w)
                    cool_rec = sch._cooldown_record_for(w)
                    models = {}
                    for m in limited:
                        bucket = sch._seedance_bucket(m)
                        try:
                            rec = (sch._seedance_quota.get(day, {}).get(key, {})
                                   .get(bucket, {}) or {})
                            used = int(rec.get("count", 0))
                            tids = [str(x)[-10:] for x in (rec.get("tids") or [])]
                        except Exception:
                            used, tids = 0, []
                        lim = sch._daily_limit_for(m)
                        # 2026-11-03 v3：被动额度封禁（页面明确「免费额度已用完」）
                        # 视为当前默认模型今日已满，覆盖"封禁标记在、计数未补满"的重启场景。
                        if not w.quota_ok and m == cur_model and used < lim:
                            used = lim
                        models[m] = {"used": used, "limit": lim,
                                     "full": used >= lim, "tids": tids}
                    cur = models.get(cur_model, {})
                    # 连坐：任一模型达上限 → 该账号两个模型当天都停派
                    full_models = sch.seedance_account_full_models(w, day)
                    any_full = bool(full_models)
                    for m in limited:
                        models[m]["blocked"] = any_full
                    model_tids = {m: models[m]["tids"] for m in limited}
                    accts.append({
                        "slot": w.slot,
                        "name": w.account_label(),
                        "display_name": w.display_name(),
                        "uuid": str(getattr(w, "account_uuid", "") or ""),
                        "account_name": str(getattr(w, "account_name", "") or ""),
                        "key": key,
                        "nickname": str(getattr(w, "nickname", "") or ""),
                        "target": str(getattr(w, "target_id", "") or "")[:12],
                        # 旧字段保留，供旧版控制台/调用方兼容
                        "used": cur.get("used", 0),
                        "limit": cur.get("limit", 0),
                        "full": any_full or (not w.quota_ok),
                        "any_full": any_full,
                        "full_models": full_models,
                        "quota_blocked_by": full_models,
                        "tids": cur.get("tids", []),
                        "models": models,
                        "model_tids": model_tids,
                        "cooldown": cool_rec is not None,
                        "cooldown_at": str((cool_rec or {}).get("at") or ""),
                        "quota_ok": bool(w.quota_ok),
                        "quota_msg": str(w.quota_msg or ""),
                        "model": str(w.model_name or ""),
                        "busy": bool(w.busy),
                        "done": int(getattr(w, "done_count", 0) or 0),
                        "dl_dir": account_download_dir(_base_dl, w.display_name(), day),
                    })
                try:
                    with _DELIVERED_LOCK:
                        delivered_count = len(_DELIVERED_VIDEOS)
                except Exception:
                    delivered_count = 0
                self._json({
                    "ok": True,
                    "day": day,
                    "model": model,
                    "limited_models": limited,
                    "limits": limits,
                    "limit": limits.get(cur_model, 0),
                    "shared_bucket": False,   # 2026-11-13 起按模型独立计数
                    "accounts": accts,
                    "cooldown_count": len(sch.cooldown_records()),
                    "cooldown_records": sch.cooldown_records(),
                    "all_full": sch._seedance_all_full(day, model) if _is_limited else False,
                    "dispatch_cursor": str(getattr(sch, "_dispatch_cursor_key", "") or ""),
                    "delivered_count": delivered_count,
                    "download_dir": _base_dl,
                    "isolated_download": True,
                    "watchdog_sec": 90,
                    # 今日 00:00–23:59 全天历史生成次数（跨重启不清零）
                    "today_history": sch.today_history_snapshot(),
                    "time": now_str(),
                    "host": HOST_GUARD.info(),
                })
                return
            if path == "/api/accounts/reset":
                # 手动清除账号额度不足标记（充值/换号后立即恢复派单）
                # 注意：不影响「强制冷却」名单，后者只能由控制台逐账号解除。
                self._json({"ok": True, "reset": self._reset_quota_marks()})
                try:
                    STATE.scheduler.wake_dispatch()
                except Exception:
                    pass
                return
            if path == "/api/accounts/scan":
                # 只读版实时扫描摘要（控制台轮询用，不重复唤醒派发）
                self._json({"ok": True,
                            "live_scan": STATE.scheduler.live_scan_info(),
                            "immediate_dispatch": not bool(
                                STATE.config.get("dispatch_stagger_enabled", False))})
                return
            if path == "/api/accounts/cooldown":
                recs = STATE.scheduler.cooldown_records()
                self._json({"ok": True, "accounts": recs, "count": len(recs)})
                return
            if path == "/api/accounts":
                s = STATE
                raw = []
                try:
                    s.scheduler.ctrl.wait_cdp_ready(timeout=8)
                    raw = [{"title": t["title"], "url": t["url"][:120]}
                           for t in s.scheduler.ctrl.list_accounts()]
                except Exception:
                    pass
                self._json({"ok": True,
                            "workers": s.scheduler.worker_info(),
                            "accounts": raw,
                            "raw_count": len(raw)})
                return
            if path == "/api/accounts/open-all":
                try:
                    s.scheduler.ctrl.wait_cdp_ready(timeout=10)
                    result = s.scheduler.ctrl.open_all_accounts(timeout=90)
                except Exception as e:
                    result = {"ok": False, "reason": str(e)}
                self._json(result)
                return
            if path == "/api/accounts/close-all":
                try:
                    s.scheduler.ctrl.wait_cdp_ready(timeout=10)
                    result = s.scheduler.ctrl.close_all_accounts(timeout=90)
                except Exception as e:
                    result = {"ok": False, "reason": str(e)}
                self._json(result)
                return
            if path == "/api/tasks":
                _brief = (_query.get("brief") or [""])[0].lower() in ("1", "true", "yes", "on")
                if _brief:
                    # 控制台列表渲染字段白名单；日志正文按需走 /api/tasks/<id> 单取。
                    # 必须构造新 dict —— store.list() 返回的是原始任务对象引用，
                    # 直接 del t["logs"] 会把内存里的日志也删掉。
                    _FIELDS = ("id", "status", "percent", "prompt", "negative_prompt",
                               "duration", "aspect", "account", "assigned_to",
                               "worker_slot", "submitted", "model", "requeues",
                               "video_path", "video_url", "video_size", "video_md5",
                               "error", "message", "created_at", "updated_at",
                               # ★ 2026-11-14 全面检查修复：一致性拒绝原因与
                               #   分镜回传状态此前不在白名单，控制台拿不到，
                               #   只能靠 message 间接看到一行文本。
                               "deliver_consistency_error", "deliver_consistency_path",
                               "delivered_scene_error", "delivered_scene_status",
                               "delivered_scene_path_mismatch",
                               "audio_second_confirm_done", "audio_second_confirm_text",
                               # ★ 2026-11-14：回收闸门状态，控制台可直接看出
                               # 「这条任务是否还在协商、能不能回收」。
                               "generation_ready_ts", "has_reference_audio",
                               "negotiation_done")
                    _tasks = []
                    for _t in STATE.store.list():
                        _slim = {k: _t.get(k) for k in _FIELDS if k in _t}
                        _slim["logs_count"] = len(_t.get("logs") or [])
                        # ★ 2026-11-14：参考项计数要在列表里可见，否则控制台
                        #   看不出「这条任务到底带没带参考音频」，排查音频漏发
                        #   只能去翻日志。只传计数不传路径，保持 brief 响应轻量。
                        _slim["images_count"] = len(_t.get("images") or [])
                        _slim["audios_count"] = len(_t.get("audios") or [])
                        _tasks.append(_slim)
                else:
                    _tasks = STATE.store.list()
                self._json({"ok": True, "tasks": _tasks})
                return
            m = re.match(r"^/api/tasks/([\w-]+)$", path)
            if m:
                t = STATE.store.get(m.group(1))
                if not t:
                    self._json({"ok": False, "error": "任务不存在"}, 404)
                else:
                    # 只有带 X-Doubao-Host 的插件侧轮询才算宿主心跳。
                    # 控制台每 3 秒拉日志也走这个接口，不区分会把宿主早已
                    # 放弃的僵尸任务无限续期，孤儿回收永远收不回账号。
                    if self.headers.get("X-Doubao-Host"):
                        STATE.store.touch_poll(m.group(1))
                    self._json({"ok": True, "task": t})
                return
            if path == "/api/debug/pageinfo":
                ctrl = STATE.scheduler.ctrl
                ctrl.wait_cdp_ready(timeout=8)
                target = ctrl.pick_target()
                if not target:
                    self._json({"ok": False, "error": "没有已打开的豆包账号页面"})
                    return
                ws = ctrl.attach(target)
                ctrl.evaluate(build_inject_js(load_json(SELECTORS_PATH, {})))
                info = ctrl.evaluate("window.__dbm.pageInfo()")
                ctrl.detach()
                self._json({"ok": True, "target": {"title": target["title"], "url": target["url"]},
                            "page": info})
                return
            if path == "/api/config":
                self._json({"ok": True, "config": STATE.config})
                return
            self._json({"ok": False, "error": f"未知路径: {path}"}, 404)
        except Exception as e:
            self._json({"ok": False, "error": str(e)}, 500)

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        # 与 do_GET 同源的宿主存活信号刷新
        try:
            _hpid = self.headers.get("X-Doubao-Host")
            if _hpid:
                HOST_GUARD.note(_hpid)
        except Exception:
            pass
        try:
            body = self._read_body()
            if path == "/api/host/heartbeat":
                # 宿主插件侧独立心跳（main.py 每 5 秒一次）。header 已带 pid，
                # 这里额外兼容从 body 传 pid 的调用方。
                pid = body.get("host_pid") if isinstance(body, dict) else None
                if pid:
                    HOST_GUARD.note(pid)
                self._json({"ok": True, "host": HOST_GUARD.info()})
                return
            if path == "/api/accounts/reset":
                # 控制台「重置额度标记」发的是 POST；此前只注册了 GET，实测 404。
                # 两个入口共用同一实现，保留 GET 以兼容旧调用方。
                self._json({"ok": True, "reset": self._reset_quota_marks()})
                try:
                    STATE.scheduler.wake_dispatch()
                except Exception:
                    pass
                return
            if path == "/api/accounts/scan":
                # 控制台「立即扫描账号」：手动触发一次派发前实时扫描，
                # 返回已打开 / 可派发 / 被跳过的原因。
                try:
                    info = STATE.scheduler.preflight_dispatch("console_manual_scan")
                except Exception as e:
                    info = {"ok": False, "error": str(e)}
                self._json({"ok": True, "dispatch": info,
                            "live_scan": STATE.scheduler.live_scan_info()})
                return
            if path == "/api/accounts/cooldown":
                # 控制台每个账号一行的「强制冷却 / 解除冷却」按钮。
                # 只阻止后续派发，已在生成中的任务照常出片、下载、回传。
                action = str(body.get("action") or "").strip().lower()
                if action == "clear_all":
                    n = STATE.scheduler.clear_all_cooldowns()
                    self._json({"ok": True, "action": action, "cleared": n, "count": 0})
                    try:
                        STATE.scheduler.wake_dispatch()
                    except Exception:
                        pass
                    return
                if action not in ("on", "off"):
                    self._json({"ok": False, "error": "action 必须为 on / off / clear_all"}, 400)
                    return
                key = str(body.get("key") or "").strip()
                ok, res = STATE.scheduler.set_account_cooldown(
                    key, action == "on",
                    name=str(body.get("name") or ""),
                    nickname=str(body.get("nickname") or ""),
                    target_id=str(body.get("target") or ""),
                    slot=body.get("slot") or 0)
                if not ok:
                    self._json({"ok": False, "error": str(res)}, 400)
                else:
                    self._json({"ok": True, "action": action, "key": key, "count": res})
                    # 解除冷却后立刻继续派发，不等编排器的 2 秒循环
                    if action == "off":
                        try:
                            STATE.scheduler.wake_dispatch()
                        except Exception:
                            pass
                return
            if path == "/api/quota/daily/reset":
                # 手动清零今日主动计数（调试/换号/误计后用）。只清当天，
                # 传 {"day":"YYYY-MM-DD"} 可指定日期；不传则清今天。
                day = str((body.get("day") or "")).strip() or time.strftime("%Y-%m-%d", time.localtime())
                STATE.scheduler.clear_seedance_quota(day)
                self._json({"ok": True, "day": day})
                try:
                    STATE.scheduler.wake_dispatch()
                except Exception:
                    pass
                return
            if path == "/api/tasks":
                # ★ 宿主闸门：字字动画已关闭时，插件与控制台都不允许再提交新任务，
                #   避免"软件端都没人了，桥接还在往队列里塞任务"。
                #   宿主自己发来的请求在 do_POST 开头已刷新心跳，因此新会话的
                #   第一个提交请求会自动解除闸门并正常受理。
                if HOST_GUARD.enabled and HOST_GUARD.is_offline():
                    self._json({"ok": False,
                                "error": "字字动画已关闭，插件已停止派发；任务未提交（已有任务已全部自动取消）"},
                               409)
                    return
                prompt = (body.get("prompt") or "").strip()
                if not prompt:
                    self._json({"ok": False, "error": "prompt 不能为空"}, 400)
                    return
                dur = str(body.get("duration") or STATE.config["default_duration"])
                if not valid_duration(dur):
                    dur = STATE.config["default_duration"]
                asp = str(body.get("aspect") or STATE.config["default_aspect"])
                if asp not in VALID_ASPECTS:
                    asp = STATE.config["default_aspect"]
                ff = str(body.get("first_frame") or "").strip()
                if ff and not Path(ff).exists():
                    self._json({"ok": False, "error": f"首帧文件不存在: {ff}"}, 400)
                    return
                # 参考图列表（首帧/尾帧/角色场景图）；逐张校验存在性与图片扩展名
                images = []
                raw_images = body.get("images") or []
                if isinstance(raw_images, str):
                    raw_images = [raw_images]
                for item in raw_images:
                    p = str(item or "").strip()
                    if not p or p in images:
                        continue
                    if not Path(p).exists():
                        self._json({"ok": False, "error": f"参考图文件不存在: {p}"}, 400)
                        return
                    ext = Path(p).suffix.lower()
                    if ext not in IMAGE_ATTACHMENT_EXTS:
                        self._json({"ok": False, "error": f"参考图不是支持的图片格式: {p}"}, 400)
                        return
                    images.append(p)
                if ff and not images:
                    images = [ff]
                # ★ 2026-11-13：参考音频（字字动画「参考项」中的音频）。
                #   兼容插件提交与控制台手动建任务的多种字段名，也接受多行字符串。
                audios = []
                raw_audios = body.get("audios")
                if raw_audios is None:
                    # 兼容控制台/外部调用方的同义字段；注意不能用 `or` 链：
                    # 插件明确提交 audios: []（本任务无参考音频）时，不能让
                    # 其它字段把它悄悄覆盖回去。
                    for _k in ("reference_audios", "audio_paths", "reference_audio"):
                        if _k in body:
                            raw_audios = body[_k]
                            break
                if raw_audios is None:
                    raw_audios = []
                if isinstance(raw_audios, str):
                    raw_audios = [x.strip() for x in raw_audios.splitlines() if x.strip()]
                if not isinstance(raw_audios, (list, tuple)):
                    raw_audios = [raw_audios]
                for item in raw_audios:
                    p = str(item or "").strip()
                    if not p or p in audios:
                        continue
                    if not Path(p).exists():
                        self._json({"ok": False, "error": f"参考音频文件不存在: {p}"}, 400)
                        return
                    if Path(p).suffix.lower() not in AUDIO_ATTACHMENT_EXTS:
                        self._json({"ok": False, "error": f"参考音频不是支持的音频格式: {p}"}, 400)
                        return
                    audios.append(p)

                def _ref_cap(key, hard):
                    """读设置里的上限并收敛到豆包硬上限；0 / 非法 / 超限一律取硬上限。"""
                    try:
                        v = int(STATE.config.get(key, hard))
                    except (TypeError, ValueError):
                        return hard
                    return v if 1 <= v <= hard else hard

                cap = _ref_cap("max_reference_images", HARD_MAX_REFERENCE_IMAGES)
                acap = _ref_cap("max_reference_audios", HARD_MAX_REFERENCE_AUDIOS)
                if len(images) > cap:
                    print(f"[bridge] 参考图上限 {cap} 张，收到 {len(images)} 张，截断为 {cap} 张",
                          flush=True)
                    images = images[:cap]
                if len(audios) > acap:
                    print(f"[bridge] 参考音频上限 {acap} 个，收到 {len(audios)} 个，截断为 {acap} 个",
                          flush=True)
                    audios = audios[:acap]
                # 分镜映射：由插件 generate() 提交，dest 是字字动画分镜窗口对应的
                # 视频绝对路径。只接受合法 dict + .mp4 绝对路径，避免 API 被误用
                # 写入任意位置；不合格时静默忽略（不影响正常生成）。
                scene = {}
                raw_scene = body.get("scene")
                if isinstance(raw_scene, dict):
                    scene = {str(k): v for k, v in raw_scene.items()
                             if k in ("dest", "output_dir", "unique_name",
                                      "viewer_index", "generation_round",
                                      "position", "project_path")}
                    _sd = str(scene.get("dest") or "").strip()
                    if _sd and (not os.path.isabs(_sd)
                                or not _sd.lower().endswith(".mp4")):
                        scene.pop("dest", None)
                task = STATE.store.create({
                    "prompt": prompt,
                    "negative_prompt": body.get("negative_prompt", ""),
                    "duration": dur,
                    "aspect": asp,
                    "account": body.get("account", ""),
                    "first_frame": ff or (images[0] if images else ""),
                    "images": images,
                    "audios": audios,
                    "scene": scene,
                })
                # ★ 2026-11-13：字字动画点击"生成视频"的这一下，先同步扫描
                #   豆包管理器里此刻已打开的账号，剔除已关闭账号，再事件驱动
                #   唤醒编排器立即分派。扫描结果随响应回给插件，方便日志核对。
                dispatch = {}
                try:
                    dispatch = STATE.scheduler.preflight_dispatch("task_submitted")
                except Exception as e:
                    dispatch = {"ok": False, "error": str(e)}
                    try:
                        STATE.scheduler.wake_dispatch()
                    except Exception:
                        pass
                self._json({"ok": True, "task_id": task["id"], "task": task,
                            "dispatch": dispatch})
                return
            if path == "/api/config":
                # 不再写死白名单：白名单漏一个键（此前漏了 confirm_with_images、
                # min_collect_sec、return_delay_sec 等），宿主传过来的新设置就会被
                # 静默丢弃，表现为"设置页改了、实际还是旧值"。改为只接受
                # DEFAULT_CONFIG 里已声明的键，并按默认值做类型归一化。
                applied, skipped = {}, []
                for k, v in body.items():
                    if k not in DEFAULT_CONFIG:
                        skipped.append(k)
                        continue
                    if k in ("bridge_host", "bridge_port"):
                        # 监听地址/端口改了要重启服务才生效，运行中以旧值为准
                        skipped.append(k)
                        continue
                    STATE.config[k] = _coerce_cfg(k, v)
                    applied[k] = STATE.config[k]
                save_json(CONFIG_PATH, STATE.config)
                self._json({"ok": True, "config": STATE.config,
                            "applied": applied, "skipped": skipped})
                try:
                    STATE.scheduler.wake_dispatch()
                except Exception:
                    pass
                return
            if path == "/api/manager/launch":
                ctrl = STATE.scheduler.ctrl
                try:
                    if not ctrl.manager_running():
                        try:
                            ctrl.launch_manager()
                        except ManagerAlreadyRunning as ar:
                            # 已有实例正在启动（或没开调试端口）。绝不重拉，
                            # 在请求线程里等它把 CDP 起好；卡密版自解包约 13 秒。
                            _deadline = time.time() + 20
                            _ready = False
                            while time.time() < _deadline:
                                _DBK_CDP_PROBE_CACHE.clear()
                                _DBK_CDP_RESOLVE_CACHE.update(ts=0.0)
                                if ctrl.manager_running():
                                    _ready = True
                                    break
                                time.sleep(0.5)
                            if not _ready:
                                self._json({
                                    "ok": False,
                                    "reason": "already_running_no_cdp",
                                    "manager_pids": ar.pids[:6],
                                    "manager_running": False,
                                    "error": "豆包管理器已在运行，但调试端口未就绪"
                                             "（已跳过重复启动，避免弹出「请勿重复启动」）。"
                                             "请在任务管理器中完全退出所有「豆包管理器.exe」"
                                             "后重新点击「测试连接」，插件会自动以调试模式重新拉起。"})
                                return
                    port = ctrl.wait_cdp_ready(timeout=40)
                except Exception as e:
                    self._json({"ok": False, "reason": "launch_failed",
                                "manager_running": ctrl.manager_running(),
                                "error": str(e)})
                    return
                accounts = [{"title": t["title"], "url": t["url"]}
                            for t in ctrl.list_accounts()]
                self._json({"ok": True, "cdp_port": port,
                            "manager_running": True, "accounts": accounts,
                            "workers": STATE.scheduler.worker_info()})
                return
            if path == "/api/accounts/open-all":
                try:
                    STATE.scheduler.ctrl.wait_cdp_ready(timeout=10)
                    result = STATE.scheduler.ctrl.open_all_accounts(timeout=90)
                except Exception as e:
                    result = {"ok": False, "reason": str(e)}
                self._json(result)
                return
            if path == "/api/accounts/close-all":
                try:
                    STATE.scheduler.ctrl.wait_cdp_ready(timeout=10)
                    result = STATE.scheduler.ctrl.close_all_accounts(timeout=90)
                except Exception as e:
                    result = {"ok": False, "reason": str(e)}
                self._json(result)
                return
            m = re.match(r"^/api/tasks/([\w-]+)/delivered$", path)
            if m:
                # 插件 generate() 成功把视频放进分镜后回报，桥接据此标记「已回传」。
                _tid = m.group(1)
                _t = STATE.store.get(_tid)
                if not _t:
                    self._json({"ok": False, "error": "任务不存在"}, 404)
                    return
                _scene_dest = str((_t.get("scene") or {}).get("dest") or "").strip()
                _dest = str(body.get("dest") or "").strip() or _scene_dest
                if not _dest:
                    self._json({"ok": False, "error": "缺少 dest"}, 400)
                    return
                # ★ 2026-11-14 回传一致性：插件回报的 dest 必须与该任务提交时
                #   绑定的分镜 dest 一致；不一致时以任务绑定路径为准并留痕，
                #   防止「分镜 A 的成品被记到分镜 B」这类错配无声通过。
                if _scene_dest and os.path.normcase(os.path.normpath(_dest)) \
                        != os.path.normcase(os.path.normpath(_scene_dest)):
                    STATE.store.log(
                        _tid, "回传目标与任务分镜绑定路径不一致，已按分镜绑定记录："
                              "回报=%s 绑定=%s" % (_dest, _scene_dest))
                    STATE.store.update(_tid, delivered_scene_path_mismatch=_dest)
                    _dest = _scene_dest
                STATE.store.update(_tid, delivered_scene_path=_dest,
                                   delivered_scene_at=now_str())
                self._json({"ok": True, "task_id": _tid, "dest": _dest})
                return
            if path == "/api/tasks/cancel-all":
                # 取消所有未完成任务（排队中 + 进行中 + 待标定），已完成/已取消的跳过。
                # 与宿主离线自动取消共用同一实现：除了置终态，还会立刻释放占用的
                # 账号 worker 并把任务移出编排器 inflight，避免账号被占死。
                _total = len(STATE.store.list())
                cancelled = cancel_all_tasks("用户请求取消全部任务")
                self._json({"ok": True, "cancelled": cancelled,
                            "skipped": max(0, _total - cancelled)})
                return
            m = re.match(r"^/api/tasks/([\w-]+)/cancel$", path)
            if m:
                tid = m.group(1)
                t = STATE.store.get(tid)
                if not t:
                    self._json({"ok": False, "error": "任务不存在"}, 404)
                    return
                # 字字动画侧判失败时会调这个接口把桥接里的对应任务取消掉，
                # 避免它继续排队/自动重试。带 reason 的是插件回调；
                # 不带 reason 的是用户在任务控制台点"取消任务"。
                reason = "用户在任务控制台取消任务"
                try:
                    if isinstance(body, dict) and (body.get("reason") or "").strip():
                        reason = str(body["reason"]).strip()[:200]
                except Exception:
                    pass
                r = STATE.scheduler.cancel_task(tid, reason)
                if not r.get("ok"):
                    code = 404 if r.get("error") == "任务不存在" else 400
                    self._json(r, code)
                    return
                self._json({"ok": True, "released_slot": r.get("released_slot")})
                try:
                    STATE.scheduler.wake_dispatch()
                except Exception:
                    pass
                return
            self._json({"ok": False, "error": f"未知路径: {path}"}, 404)
        except Exception as e:
            self._json({"ok": False, "error": str(e)}, 500)


# ---------------------------------------------------------------------------
# 启动入口
# ---------------------------------------------------------------------------

_STARTED = False
_START_LOCK = threading.Lock()


def start_bridge(config_overrides=None):
    """供插件在宿主进程内调用：以守护线程启动桥接服务。幂等。

    幂等 ≠ 忽略新配置：服务一旦起来就不再吸收 overrides 的话，用户在设置页改的
    值永远传不进来（实测"自动确认发送文本"改了却还是填旧值）。所以已启动时也要
    把最新配置合并进去——STATE.config 是同一个 dict 对象，Scheduler / 各
    AccountWorker 持有的都是它的引用，原地 update 即刻生效。
    """
    global STATE
    with _START_LOCK:
        if _STARTED:
            if config_overrides and STATE is not None:
                STATE.config.update(
                    {k: _coerce_cfg(k, v) for k, v in config_overrides.items()
                     if v not in (None, "")})
            return STATE
        STATE = BridgeState()
        if config_overrides:
            STATE.config.update(
                {k: _coerce_cfg(k, v) for k, v in config_overrides.items()
                 if v not in (None, "")})
        # 宿主守卫开关以 STATE.config（DEFAULT_CONFIG + config.json 合并后）为准
        try:
            HOST_GUARD.set_enabled(bool(STATE.config.get("host_guard_enabled", True)))
            HOST_GUARD.set_timeout(STATE.config.get("host_offline_timeout_sec", 20))
            HOST_GUARD.set_idle_timeout(STATE.config.get("host_idle_timeout_sec", 120))
        except Exception:
            pass
        STATE.scheduler.start()
        host = STATE.config["bridge_host"]
        port = int(STATE.config["bridge_port"])
        # 关掉 SO_REUSEADDR：Windows 上它允许多个进程同时 bind 同一个端口，
        # 一旦视频桥接和图片桥接撞端口，就会变成"两个都起得来、请求随机进错门"。
        # 关掉后端口被占立刻抛错，问题一眼可见。
        class _StrictHTTPServer(ThreadingHTTPServer):
            allow_reuse_address = False
        httpd = _StrictHTTPServer((host, port), APIHandler)
        httpd.daemon_threads = True
        STATE.httpd = httpd
        t = threading.Thread(target=httpd.serve_forever, daemon=True)
        t.start()
        globals()["_STARTED"] = True
        # 宿主离线看门狗：宿主一关闭（心跳断 / 进程退出），立即取消所有未完成任务
        # 并立起派发闸门；宿主重新上线由 HostGuard.note() 自动解除。
        def _host_guard_watchdog():
            while True:
                time.sleep(2)
                try:
                    if STATE is None or not HOST_GUARD.enabled:
                        continue
                    if not HOST_GUARD.has_session() or HOST_GUARD.marked_offline():
                        continue
                    if not HOST_GUARD.is_offline():
                        continue
                    reason = "字字动画已关闭（宿主离线）"
                    HOST_GUARD.mark_offline(reason)
                    n = cancel_all_tasks(
                        "字字动画已关闭，自动取消全部未完成任务（不重新派发）")
                    HOST_GUARD.set_cancel_count(n)
                    print(f"[doubao-bridge] {reason}：已自动取消 {n} 个未完成任务，派发闸门已生效")
                except Exception as e:
                    print(f"[doubao-bridge] 宿主守卫看门狗异常: {e}")

        threading.Thread(target=_host_guard_watchdog, daemon=True,
                         name="dbm-host-guard").start()
        print(f"[doubao-bridge] API 已启动: http://{host}:{port}/")
        return STATE


def main():
    state = start_bridge()
    print(f"豆包桥接服务已启动：http://{state.config['bridge_host']}:{state.config['bridge_port']}/")
    print(f"管理器路径: {state.config['manager_exe']}")
    print(f"素材库目录: {state.config['download_dir']}")
    print("按 Ctrl+C 退出")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
豆包管理器图片插件
==================

把字字动画分镜的图片生成任务分发给本机"豆包管理器 V2.0"：
  分镜点"生成图片" → 插件启动/复用本地桥接服务 → 桥接通过 CDP 自动化
  操控管理器内的豆包账号 webview（填提示词/传参考图/点图像生成/取图片）
  → 成品图片自动下载回项目目录并按软件命名规范返回。

插件不直接操作管理器，全部通过桥接服务（bridge/server.py，标准库实现）
的 HTTP API 完成；桥接既可在宿主进程内以守护线程跑（默认），也可独立运行。
"""

import importlib.util
import json
import os
import re
import shutil
import sys
import threading
import time
import urllib.request
import urllib.error
import webbrowser
from pathlib import Path

_PLUGIN_FILE = __file__
_PLUGIN_DIR = Path(__file__).resolve().parent
_PLUGIN_FOLDER = _PLUGIN_DIR.name          # 宿主用「插件文件夹名」做唯一标识
_BRIDGE_SERVER = _PLUGIN_DIR / "bridge" / "server.py"

# 让插件在任何目录深度都能找到 plugin_utils（宿主也会注入 sys.path，双保险）
for _p in (
    _PLUGIN_DIR.parent.parent,          # plugins/
    _PLUGIN_DIR.parent.parent.parent,  # 兜底
):
    if str(_p) not in sys.path:
        sys.path.append(str(_p))

try:
    from plugin_utils import load_plugin_config
except Exception:
    load_plugin_config = None

PLUGIN_NAME = "豆包管理器图片插件"
PLUGIN_VERSION = "1.0.4"

# 桥接服务身份标识：图片插件专用桥接（端口默认 9231）。
# 视频插件是另一个独立桥接（默认 9230）。两个插件共用同一个豆包管理器，
# 如果端口撞车，插件会把任务发给对方的桥接 → 表现就是"一边能用一边不行"。
# health 接口会回传这个标识，用于识别"端口上跑的到底是不是自己人"。
SERVICE_ID = "doubao-image-bridge"

DEFAULT_PARAMS = {
    "bridge_host": "127.0.0.1",
    "bridge_port": 9231,  # 图片专用；视频插件用 9230，两者不可相同
    "manager_exe": "",  # 客户请在插件设置页填写本机 豆包管理器.exe 的完整路径
    "cdp_port": 9223,
    "download_dir": "",
    "default_account": "",
    "max_concurrency": 0,
    "max_reference_images": 4,
    "task_timeout_sec": 600,
    "poll_interval_sec": 3,
    "auto_start_manager": True,
    "auto_start_bridge": True,
    "parallel_submit": True,
    "auto_raise_manager_window": True,
    "force_render_all_webviews": True,
    "image_count": 1,
    "image_model": "Seedream 5.0 Flash",
    # 图像生成面板：比例 / 风格（宿主分镜传了就用宿主的，否则用这里的默认值）
    "image_aspect": "16:9",
    "image_style": "",
    # 下载前把页面上的带水印展示地址换成豆包签发的无水印原图地址
    "prefer_no_watermark": True,
    # ---------- 防霸占（不要在选中其它插件时抢跑）----------
    # 生成前核对宿主当前选中的图片插件；不是本插件就让出执行权
    "selection_guard": True,
    # 让出执行权时：True=把任务转发给真正选中的插件，False=直接报错不生成
    "delegate_to_selected_plugin": True,
    # 桥接空闲时不巡检账号 / 不注入页面 / 不重试历史任务 / 不占用豆包管理器
    "background_only_when_active": True,
}

_STATUS_TEXT = {
    "queued": "任务排队中",
    "starting_manager": "启动豆包管理器",
    "connecting": "连接管理器",
    "preparing_page": "准备豆包页面",
    "filling_form": "网页自动填写中",
    "submitting": "提交生成请求",
    "generating": "豆包生成中",
    "downloading": "取回图片中",
    "done": "完成",
    "error": "失败",
}

_bridge_started = False
_bridge_lock = threading.Lock()


# ---------------------------------------------------------------------------
# 参数
# ---------------------------------------------------------------------------

def get_info():
    return {
        "name": PLUGIN_NAME,
        "description": "把图片任务分发给豆包管理器并自动取回成品图片",
        "version": PLUGIN_VERSION,
    }


def get_models():
    return [{"id": "doubao-manager-seedream", "name": "豆包管理器-Seedream", "type": "image"}]


def get_params():
    params = dict(DEFAULT_PARAMS)
    if load_plugin_config:
        try:
            params.update(load_plugin_config(str(_PLUGIN_FILE)) or {})
        except Exception:
            pass
    return params


# ---------------------------------------------------------------------------
# HTTP 小工具
# ---------------------------------------------------------------------------

def _http(method, url, payload=None, timeout=15):
    data = None
    headers = {"Content-Type": "application/json"}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _base(params):
    return f"http://{params.get('bridge_host', '127.0.0.1')}:{int(params.get('bridge_port', 9231))}"


def _health(params, timeout=3):
    """探测桥接健康状态。

    只有端口上跑的确实是图片桥接才算健康：如果返回里的 service 不是自己人，
    说明端口被别的服务（最常见：视频插件桥接）占了，必须当成"未就绪"处理，
    否则任务会被发到错误的桥接上。
    """
    try:
        r = _http("GET", _base(params) + "/api/health", timeout=timeout)
    except Exception:
        return None
    if not isinstance(r, dict) or not r.get("ok"):
        return None
    svc = r.get("service")
    if svc and svc != SERVICE_ID:
        print("[doubao_manager_image] 端口 %s 上跑的是「%s」，不是图片桥接，判为不可用"
              % (params.get("bridge_port"), svc), file=sys.stderr, flush=True)
        return None
    return r


def _cancel_bridge_task(params, tid, reason):
    if not tid:
        return False
    url = _base(params) + "/api/tasks/%s/cancel" % tid
    try:
        _http("POST", url, {"reason": str(reason)[:200]}, timeout=8)
        print("[doubao_manager_image] 已同步取消桥接任务 %s（%s）" % (tid, reason),
              file=sys.stderr, flush=True)
        return True
    except Exception as e:
        print("[doubao_manager_image] 同步取消桥接任务失败 %s: %s" % (tid, e),
              file=sys.stderr, flush=True)
        return False


# ---------------------------------------------------------------------------
# 桥接服务启停
# ---------------------------------------------------------------------------

def _start_bridge_in_process(params):
    global _bridge_started
    with _bridge_lock:
        if _bridge_started:
            return
        if not _BRIDGE_SERVER.exists():
            raise RuntimeError(f"PLUGIN_ERROR:::找不到桥接服务文件 {_BRIDGE_SERVER}")
        spec = importlib.util.spec_from_file_location(
            "doubao_manager_image_bridge_server", str(_BRIDGE_SERVER))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        mod.start_bridge(config_overrides={
            "bridge_host": params.get("bridge_host", "127.0.0.1"),
            "bridge_port": int(params.get("bridge_port", 9231)),
            "cdp_port": int(params.get("cdp_port", 9223)),
            "manager_exe": params.get("manager_exe", ""),
            "download_dir": params.get("download_dir", ""),
            "auto_start_manager": bool(params.get("auto_start_manager", True)),
            "max_concurrency": int(params.get("max_concurrency", 0) or 0),
            "max_reference_images": max(1, int(params.get("max_reference_images", 4) or 4)),
            "task_timeout_sec": int(params.get("task_timeout_sec", 600)),
            "poll_interval_sec": int(params.get("poll_interval_sec", 3) or 3),
            "parallel_submit": bool(params.get("parallel_submit", True)),
            "auto_raise_manager_window": bool(params.get("auto_raise_manager_window", True)),
            "force_render_all_webviews": bool(params.get("force_render_all_webviews", True)),
            "image_count": int(params.get("image_count", 1) or 1),
            "image_model": str(params.get("image_model", "Seedream 5.0 Flash")),
            "image_aspect": str(params.get("image_aspect", "16:9")),
            "image_style": str(params.get("image_style", "")),
            "prefer_no_watermark": bool(params.get("prefer_no_watermark", True)),
            "background_only_when_active": bool(params.get("background_only_when_active", True)),
        })
        _bridge_started = True


_PUSH_CONFIG_KEYS = (
    "manager_exe", "download_dir", "auto_start_manager", "max_concurrency",
    "max_reference_images", "task_timeout_sec", "poll_interval_sec",
    "parallel_submit", "auto_raise_manager_window", "force_render_all_webviews",
    "image_count", "image_model", "prefer_no_watermark",
    "image_aspect", "image_style", "background_only_when_active",
)


def _push_config(params):
    try:
        payload = {k: params[k] for k in _PUSH_CONFIG_KEYS
                   if k in params and params[k] not in (None, "")}
        if payload:
            _http("POST", _base(params) + "/api/config", payload, timeout=8)
    except Exception:
        pass


def _ensure_bridge(params):
    health = _health(params)
    if health and health.get("ok"):
        _push_config(params)
        return health
    if not params.get("auto_start_bridge", True):
        raise RuntimeError("PLUGIN_ERROR:::豆包桥接服务未运行，且设置为不自动启动。"
                           "可手动运行 bridge/server.py 或在设置中开启自动启动。")
    _start_bridge_in_process(params)
    for _ in range(40):
        health = _health(params, timeout=2)
        if health and health.get("ok"):
            _push_config(params)
            return health
        time.sleep(0.5)
    raise RuntimeError(
        "PLUGIN_ERROR:::图片桥接服务启动超时（端口 %s）。"
        "常见原因：该端口被视频插件桥接或其它程序占用。"
        "请在插件设置里把图片桥接端口改成 9231（视频插件保持 9230）。"
        % params.get("bridge_port")
    )


# ---------------------------------------------------------------------------
# 图片收集
# ---------------------------------------------------------------------------

_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}


def _iter_context_images(value, label="参考图"):
    if value is None:
        return
    if isinstance(value, (str, os.PathLike)):
        text = os.fspath(value).strip()
        if text.startswith("file:///"):
            text = text[8:]
        elif text.startswith("file://"):
            text = text[7:]
        if text:
            clean = text.split("?", 1)[0]
            ext = os.path.splitext(clean)[1].lower()
            if ext in _IMAGE_EXTS and os.path.isfile(text):
                yield label, os.path.abspath(text)
        return
    if isinstance(value, dict):
        for key in ("path", "file_path", "local_path", "image_path",
                    "image_url", "url", "src"):
            if key in value:
                sub_label = str(value.get("name") or value.get("label") or label)
                found = list(_iter_context_images(value[key], sub_label))
                if found:
                    yield from found
                    return
        for key, item in value.items():
            yield from _iter_context_images(item, str(key))
        return
    if isinstance(value, (list, tuple)):
        for idx, item in enumerate(value, 1):
            yield from _iter_context_images(item, f"{label}{idx}")


def _collect_task_images(context, max_images=4):
    ordered = []
    seen = set()

    def add(value, label):
        for role, path in _iter_context_images(value, label):
            key = os.path.normcase(os.path.realpath(path))
            if key in seen:
                continue
            seen.add(key)
            ordered.append((role, path))

    raw_ref = context.get("reference_images", {})
    if isinstance(raw_ref, str):
        try:
            raw_ref = json.loads(raw_ref)
        except Exception:
            raw_ref = {}
    ref_map = raw_ref if isinstance(raw_ref, dict) else {}

    for key in ("first_frame_path", "first_frame_image",
                "start_frame_path", "start_frame_image"):
        add(context.get(key), "首帧")
    add(ref_map.get("首帧"), "首帧")

    for key in ("end_frame_path", "last_frame_path",
                "end_frame_image", "last_frame_image"):
        add(context.get(key), "尾帧")
    add(ref_map.get("尾帧"), "尾帧")

    add(raw_ref, "参考图")
    for key in ("reference_image_paths", "selected_reference_images",
                "selected_reference_image_paths", "ref_image_paths",
                "ref_images", "image_references", "reference_items",
                "selected_references", "references",
                "character_images", "character_image_paths",
                "scene_images", "scene_image_paths"):
        add(context.get(key), "参考图")

    try:
        limit = max(1, int(max_images or 4))
    except Exception:
        limit = 4
    return ordered[:limit]


def _build_output_path(context, suffix=".png"):
    output_dir = str(context.get("output_dir") or context.get("project_path") or ".").strip()
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    unique_name = str(context.get("unique_name") or "plugin").strip() or "plugin"
    viewer_index = int(context.get("viewer_index") or 0)
    generation_round = int(context.get("generation_round") or 0)
    position = 0
    output_position = context.get("output_position") or []
    if isinstance(output_position, list) and output_position:
        try:
            position = int(output_position[0])
        except Exception:
            position = 0
    return os.path.join(
        output_dir,
        f"{viewer_index:04d}_{unique_name}_{generation_round}_{position}{suffix}")


# ---------------------------------------------------------------------------
# 比例 / 风格解析
# ---------------------------------------------------------------------------

# 豆包「比例」菜单实际可选项（实测抓取）
_ASPECT_OPTIONS = ("16:9", "9:16", "1:1", "4:3", "3:4", "3:2", "2:3", "自动")

_ASPECT_KEYS = (
    "aspect_ratio", "image_aspect", "aspect", "ratio", "image_ratio",
    "default_aspect", "proportion", "image_proportion", "frame_ratio",
    "video_ratio", "picture_ratio", "size_ratio",
)

_STYLE_KEYS = ("image_style", "style", "art_style", "picture_style", "visual_style")


def _norm_aspect(value):
    """把宿主传来的各种写法归一到豆包菜单里的选项，认不出来返回 ''。"""
    text = str(value or "").strip()
    if not text:
        return ""
    text = text.replace("：", ":").replace("∶", ":").replace(" ", "")
    for opt in _ASPECT_OPTIONS:
        if opt in text:
            return opt
    # 兜底：纯中文/英文描述
    low = text.lower()
    if "横" in text or "landscape" in low:
        return "16:9"
    if "竖" in text or "portrait" in low:
        return "9:16"
    if "方" in text or "square" in low:
        return "1:1"
    return ""


def _first_str(source, keys):
    for key in keys:
        v = source.get(key)
        if v is None:
            continue
        s = str(v).strip()
        if s and s.lower() not in ("none", "null", "auto", "false", "0"):
            return s
    return ""


def _resolve_aspect(context, params):
    """优先用宿主分镜传的比例，其次用插件设置，最后回落到 16:9。"""
    raw = _first_str(context, _ASPECT_KEYS)
    got = _norm_aspect(raw)
    if got:
        return got, ("宿主" if raw else "")
    got = _norm_aspect(params.get("image_aspect", ""))
    if got:
        return got, "插件设置"
    return "16:9", "默认值"


def _resolve_style(context, params):
    raw = _first_str(context, _STYLE_KEYS)
    if raw:
        return raw.strip()
    return str(params.get("image_style", "") or "").strip()


# ---------------------------------------------------------------------------
# 选中守门（防霸占）
# ---------------------------------------------------------------------------
# 宿主用「插件文件夹名」标识插件，并把选择写进项目 model_setting.json：
#   {"current_tab": 4, "plugin_setting": {"current_plugin": "xxx"}}
# 当宿主的自动回退 / 旧项目快照 / 引擎单例把 generate() 打到本插件，
# 而实际选中的是别的插件时，本插件必须让出执行权：不启动桥接、不拉起
# 豆包管理器、不生成图片，把任务原样转交给真正被选中的插件。
# ---------------------------------------------------------------------------

_SELECTION_CONTEXT_KEYS = (
    "current_plugin", "selected_image_plugin", "image_plugin", "plugin_name",
)


def _norm_plugin_name(value):
    text = str(value or "").strip()
    if not text:
        return ""
    if text.startswith("Plugin - "):
        text = text[len("Plugin - "):].strip()
    text = text.replace("\\", "/").rstrip("/")
    if "/" in text:
        text = text.rsplit("/", 1)[-1]
    return text


def _plugin_search_roots():
    """宿主可能从多个根目录加载图片插件，全部纳入查找范围。"""
    roots = []
    if _PLUGIN_DIR.parent.name == "image_plugins":
        roots.append(_PLUGIN_DIR.parent)
    base = _PLUGIN_DIR.parent.parent           # .../plugins
    for top in (base, base.parent, base.parent.parent):
        for sub in ("user_resources/plugins/image_plugins",
                    "resources/plugins/image_plugins",
                    "plugins/image_plugins"):
            d = top / sub
            if d.is_dir():
                roots.append(d)
    appdata = os.environ.get("APPDATA")
    if appdata:
        for sub in ("字字动画/plugin-server/user_resources/plugins/image_plugins",
                    # 宿主插件服务器自带的插件目录（ZZDH-API-Image 等只在这里）
                    "字字动画/plugin-server/plugins/image_plugins",
                    "字字动画/plugin-server/plugins/plugins/image_plugins",
                    "zizidonghua/user_resources/plugins/image_plugins",
                    "zizidonghua/plugin-server/plugins/image_plugins"):
            d = Path(appdata) / sub
            if d.is_dir():
                roots.append(d)
    out, seen = [], set()
    for d in roots:
        key = os.path.normcase(str(d))
        if key not in seen:
            seen.add(key)
            out.append(d)
    return out


def _find_plugin_entry(name):
    """按宿主规范找插件入口（优先编译版 main.pyd，其次 main.py）。"""
    if not name or not re.fullmatch(r"[A-Za-z0-9_.\-]+", name):
        return None
    for root in _plugin_search_roots():
        folder = root / name
        if not folder.is_dir() or folder == _PLUGIN_DIR:
            continue
        for fn in ("main.cp312-win_amd64.pyd", "main.py"):
            entry = folder / fn
            if entry.is_file():
                return entry
    return None


def _resolve_selected_plugin(context):
    """返回 (插件文件夹名, 来源)。读不到就返回空，此时不拦截以免误伤。"""
    for key in _SELECTION_CONTEXT_KEYS:
        name = _norm_plugin_name(context.get(key))
        if name:
            return name, "context.%s" % key
    checked = set()
    for key in ("project_path", "output_dir"):
        raw = context.get(key)
        if not raw:
            continue
        try:
            base = Path(str(raw)).resolve()
        except Exception:
            continue
        chain = [base]
        parent = base
        for _ in range(2):
            parent = parent.parent
            chain.append(parent)
        for folder in chain:
            cfg = folder / "model_setting.json"
            key_path = os.path.normcase(str(cfg))
            if key_path in checked or not cfg.is_file():
                continue
            checked.add(key_path)
            try:
                data = json.loads(cfg.read_text(encoding="utf-8"))
            except Exception:
                continue
            ps = data.get("plugin_setting") or {}
            name = _norm_plugin_name(ps.get("current_plugin") or data.get("current_plugin"))
            if name:
                return name, str(cfg)
    return "", ""


def _delegate_generate(context, name, entry):
    """把本次 generate 调用原样交给真正被选中的插件执行。"""
    safe = re.sub(r"[^A-Za-z0-9_]", "_", name)
    mod_name = "_zzdh_delegated_%s" % safe
    cached = sys.modules.get(mod_name)
    if (cached is not None and
            os.path.normcase(str(getattr(cached, "__file__", ""))) == os.path.normcase(str(entry))):
        mod = cached
    else:
        if entry.suffix.lower() != ".py":
            raise RuntimeError("插件 %s 只有编译入口（%s），无法转发" % (name, entry.name))
        spec = importlib.util.spec_from_file_location(mod_name, str(entry))
        if spec is None or spec.loader is None:
            raise RuntimeError("无法加载插件 %s 的入口 %s" % (name, entry))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[mod_name] = mod
        # 目标插件可能 import plugin_utils 或同目录模块
        for extra in (str(entry.parent), str(entry.parent.parent),
                      str(_PLUGIN_DIR.parent.parent)):
            if extra not in sys.path:
                sys.path.append(extra)
        spec.loader.exec_module(mod)
    gen = getattr(mod, "generate", None)
    if not callable(gen):
        raise RuntimeError("插件 %s 没有 generate() 入口" % name)
    ctx = dict(context)
    try:
        cfg = load_plugin_config(str(entry)) if load_plugin_config else {}
    except Exception:
        cfg = {}
    if cfg:
        ctx["plugin_params"] = cfg          # 换成目标插件自己的参数
    else:
        ctx.pop("plugin_params", None)      # 让目标插件走自己的 get_params()
    return gen(ctx)


def _handle_foreign_selection(context, params, selected, source, report):
    """被错误调用时不霸占：让出执行权 / 转发给真正选中的插件。"""
    msg = ("宿主当前选中的是「%s」（来源：%s），不是豆包图片插件；"
           "本次不由豆包生成，也不启动豆包桥接" % (selected, source))
    print("[doubao_manager_image] 守门拦截：" + msg, file=sys.stderr, flush=True)
    if not params.get("delegate_to_selected_plugin", True):
        raise RuntimeError("PLUGIN_ERROR:::" + msg +
                           "。若要强制使用豆包插件，请在插件设置中关闭「选中校验」。")
    entry = _find_plugin_entry(selected)
    if entry is None:
        raise RuntimeError(
            "PLUGIN_ERROR:::" + msg +
            "；但未在 image_plugins 下找到「%s」的 main.py，无法转发。"
            "请在字字动画里重新选择一次插件，或重启软件刷新插件列表。" % selected)
    report("转发任务给已选插件「%s」…" % selected, 3)
    try:
        result = _delegate_generate(context, selected, entry)
    except Exception as e:
        raise RuntimeError("PLUGIN_ERROR:::豆包插件已让出执行权，但转发到「%s」失败：%s"
                           % (selected, e))
    print("[doubao_manager_image] 已把任务交给「%s」，豆包插件未参与生成" % selected,
          file=sys.stderr, flush=True)
    return result


# ---------------------------------------------------------------------------
# 插件主入口
# ---------------------------------------------------------------------------

def generate(context):
    context = context or {}

    progress = context.get("progress_callback")

    params = get_params()
    params.update(context.get("plugin_params") or {})

    def report(text, percent=None):
        if callable(progress):
            try:
                progress(text, percent)
            except Exception:
                pass

    # 防霸占：宿主若因自动回退/旧快照调用了本插件，而实际选中的是别的插件，
    # 这里就把执行权交出去。必须在 _ensure_bridge() 之前，否则桥接和管理器
    # 会先被拉起，用户看到的就是"选了别的插件，豆包却在跑"。
    if params.get("selection_guard", True):
        selected, source = _resolve_selected_plugin(context)
        if selected and selected != _PLUGIN_FOLDER:
            return _handle_foreign_selection(context, params, selected, source, report)

    report("连接豆包桥接服务…", 2)
    _ensure_bridge(params)

    prompt = (context.get("image_prompt") or context.get("prompt") or "").strip()
    if not prompt:
        raise RuntimeError("PLUGIN_ERROR:::当前分镜没有图片提示词，请先生成图片提示词")

    try:
        max_imgs = int(params.get("max_reference_images", 4) or 4)
    except Exception:
        max_imgs = 4
    task_images = _collect_task_images(context, max_imgs)
    image_paths = [p for _role, p in task_images]
    import sys as _sys
    if task_images:
        for role, p in task_images:
            print(f"[doubao_manager_image] 参考图[{role}]: {p}", file=_sys.stderr, flush=True)
    else:
        print("[doubao_manager_image] 未检测到参考图，走纯文生图", file=_sys.stderr, flush=True)

    account = str(params.get("default_account", "")).strip()

    aspect, aspect_from = _resolve_aspect(context, params)
    style = _resolve_style(context, params)
    print(f"[doubao_manager_image] 比例={aspect}({aspect_from or '?'}), 风格={style or '默认'}, "
          f"模型={params.get('image_model', '')}", file=_sys.stderr, flush=True)

    img_note = f" · 参考图 {len(image_paths)} 张" if image_paths else ""
    report(f"分发任务给豆包管理器（图片生成{img_note}）…", 5)
    try:
        resp = _http("POST", _base(params) + "/api/tasks", {
            "prompt": prompt,
            "images": image_paths,
            "account": account,
            "aspect": aspect,
            "style": style,
        }, timeout=30)
    except Exception as e:
        raise RuntimeError(f"PLUGIN_ERROR:::提交任务失败：{e}")
    if not resp.get("ok"):
        raise RuntimeError(f"PLUGIN_ERROR:::{resp.get('error', '提交任务失败')}")

    tid = resp["task_id"]
    deadline = time.time() + int(params.get("task_timeout_sec", 600)) + 120

    def _wait_and_fetch():
        last_status = ""
        while time.time() < deadline:
            try:
                r = _http("GET", _base(params) + f"/api/tasks/{tid}", timeout=15)
            except Exception:
                time.sleep(3)
                continue
            if not r.get("ok"):
                time.sleep(3)
                continue
            t = r["task"]
            status = t.get("status", "")
            pct = int(t.get("percent") or 0)
            msg = t.get("message") or _STATUS_TEXT.get(status, status)
            if status != last_status or pct % 5 == 0:
                report(f"豆包管理器：{msg}", max(5, min(99, pct)))
                last_status = status

            if status == "done":
                paths = t.get("output_paths", [])
                if not paths:
                    raise RuntimeError("PLUGIN_ERROR:::任务已完成但桥接未返回图片路径，请查看桥接控制台")
                dests = []
                for i, src in enumerate(paths):
                    ext = os.path.splitext(src)[1] or ".png"
                    dest = _build_output_path(context, ext)
                    # 只有第 2 张及以后才加序号：第 1 张必须保持宿主的分镜命名规范
                    # （{镜号}_{标识}_{轮次}_{位置}），否则多张回传时文件名全变成 _1/_2/... ，
                    # 宿主按规范名找不到图，表现就是"回传的图是乱的/丢失"。
                    if i > 0:
                        base, old_ext = os.path.splitext(dest)
                        dest = f"{base}_{i+1}{old_ext}"
                    shutil.copy2(src, dest)
                    dests.append(dest)
                for d in dests:
                    print(f"[doubao_manager_image] 回传分镜: {d}", file=_sys.stderr, flush=True)
                report("图片已取回分镜", 100)
                return dests

            if status == "error":
                raise RuntimeError(f"PLUGIN_ERROR:::{t.get('error') or t.get('message') or '任务失败'}")

            time.sleep(int(params.get("poll_interval_sec", 3) or 3))

        raise RuntimeError("PLUGIN_ERROR:::等待豆包管理器出图超时，请在桥接控制台查看任务状态")

    try:
        return _wait_and_fetch()
    except BaseException as e:
        try:
            reason = f"{type(e).__name__}: {str(e)[:120]}"
        except Exception:
            reason = type(e).__name__
        _cancel_bridge_task(params, tid, f"字字动画侧失败 → {reason}")
        raise


# ---------------------------------------------------------------------------
# UI 动作
# ---------------------------------------------------------------------------

def handle_action(action, data, context=None):
    data = data or {}
    try:
        if action == "ping":
            params = get_params()
            params.update(data.get("params") or {})
            health = _health(params, timeout=3)
            if health and health.get("ok"):
                return {"ok": True, "data": {
                    "bridge": "running",
                    "manager_running": health.get("manager_running"),
                    "accounts": health.get("accounts", []),
                    "download_dir": health.get("download_dir"),
                }}
            try:
                _ensure_bridge(params)
                health = _health(params, timeout=3)
                return {"ok": True, "data": {
                    "bridge": "started",
                    "manager_running": (health or {}).get("manager_running"),
                    "accounts": (health or {}).get("accounts", []),
                    "download_dir": (health or {}).get("download_dir"),
                }}
            except Exception as e:
                return {"ok": False, "error": f"桥接启动失败：{e}"}

        if action == "open_console":
            params = get_params()
            params.update(data.get("params") or {})
            url = f"http://{params.get('bridge_host', '127.0.0.1')}:{int(params.get('bridge_port', 9231))}/"
            try:
                _ensure_bridge(params)
            except Exception:
                pass
            webbrowser.open(url)
            return {"ok": True, "data": {"url": url}}

        if action == "launch_manager":
            params = get_params()
            params.update(data.get("params") or {})
            _ensure_bridge(params)
            try:
                r = _http("POST", _base(params) + "/api/manager/launch", {}, timeout=60)
                return {"ok": True, "data": {
                    "manager_running": r.get("manager_running"),
                    "accounts": r.get("accounts", []),
                    "msg": "管理器已就绪" if r.get("manager_running") else "管理器启动中",
                }}
            except Exception as e:
                return {"ok": False, "error": f"启动管理器失败：{e}"}

        return {"ok": False, "error": f"未知动作: {action}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

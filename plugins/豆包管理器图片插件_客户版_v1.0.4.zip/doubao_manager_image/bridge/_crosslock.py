# -*- coding: utf-8 -*-
"""
跨进程协调锁（图片桥 / 视频桥 共用）
======================================

问题背景
--------
图片插件与视频插件是**两个独立的 Python 进程**，各自带一个桥接服务（bridge），
都通过 CDP 操控**同一个**豆包管理器里的账号 webview。豆包管理器同一时刻只有一个
webview 处于 .active（可见、能收输入）。两个桥各自只在自己进程内串行
（video 用 scheduler.input_lock，image 用每账号 self.lock），但**跨进程不互斥**——
于是图片桥在驱动 A 账号、视频桥同时驱动 B 账号时，会互相抢 .active 标签页 /
前台焦点，表现为：页面被切走、注入脚本读不到 DOM、误报"网页结构需要标定"、任务卡死。

本模块提供一个纯标准库（Windows / macOS / Linux 通用）的跨进程互斥锁，让两个桥
在"真正操控管理器 UI"的那一小段时间里互斥，杜绝同时驱动冲突。

安全原则（最重要）
------------------
1. 任何异常都**降级为不加锁**并打日志，绝不会比当前行为更糟。
2. 获取有超时，超时即放行（不造成死锁）。
3. 仅靠 PID 是否存活来判断持有者是否崩溃：持有者进程已死 -> 直接抢锁；
   持有者进程还活着 -> 永远尊重它的锁（不会误抢活着的持有者）。
4. 锁文件只在持有者进程存活期间存在；持锁方必须在 finally 中释放（见调用处）。
"""

import os
import sys
import time
import tempfile

_COORD_DIR = os.path.join(tempfile.gettempdir(), "doubao_bridge_coordination")
FG_LOCK_PATH = os.path.join(_COORD_DIR, "manager_foreground.lock")
LAUNCH_LOCK_PATH = os.path.join(_COORD_DIR, "manager_launch.lock")


def _pid_alive(pid):
    """判断某 PID 的进程是否还活着（跨平台、纯标准库）。"""
    if not pid or pid <= 0:
        return False
    if sys.platform.startswith("win"):
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
            if not h:
                return False
            ec = ctypes.c_ulong()
            kernel32.GetExitCodeProcess(h, ctypes.byref(ec))
            kernel32.CloseHandle(h)
            # 259 == STILL_ACTIVE
            return ec.value == 259
        except Exception:
            # 拿不准就保守认为活着，不抢锁（避免误抢活着的持有者）
            return True
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False
    except Exception:
        return True


def _ensure_dir():
    try:
        os.makedirs(_COORD_DIR, exist_ok=True)
    except Exception:
        pass


def _read_pid(path):
    try:
        with open(path, "r") as f:
            head = f.readline().strip()
        return int(head.split()[0])
    except Exception:
        return None


def _safe_remove(path):
    try:
        os.remove(path)
    except Exception:
        pass


class CrossProcessMutex:
    """基于锁文件的跨进程互斥锁（O_EXCL 原子创建 + PID 存活判定抢锁）。"""

    def __init__(self, path, tag, acquire_timeout=180.0, poll=0.4):
        self.path = path
        self.tag = tag
        self.acquire_timeout = acquire_timeout
        self.poll = poll
        self._held = False

    def acquire(self):
        if self._held:
            return True
        _ensure_dir()
        deadline = time.time() + self.acquire_timeout
        while True:
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                fd = None
            except Exception:
                # 创建锁文件失败（权限/路径问题）-> 降级不加锁
                sys.stderr.write("[crosslock:%s] 无法创建锁文件，降级为不加锁\n" % self.tag)
                sys.stderr.flush()
                return False
            if fd is not None:
                try:
                    os.write(fd, ("%d %s %.3f\n" % (os.getpid(), self.tag, time.time())).encode("utf-8"))
                finally:
                    try:
                        os.close(fd)
                    except Exception:
                        pass
                self._held = True
                return True
            # 锁已存在：看持有者是否还活着
            holder = _read_pid(self.path)
            if holder is None or not _pid_alive(holder):
                _safe_remove(self.path)
                continue
            if time.time() > deadline:
                sys.stderr.write(
                    "[crosslock:%s] 跨进程锁获取超时（被 %s 持有），降级为不加锁（可能短暂冲突）\n"
                    % (self.tag, holder))
                sys.stderr.flush()
                return False
            time.sleep(self.poll)

    def release(self):
        if not self._held:
            return
        _safe_remove(self.path)
        self._held = False

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *exc):
        self.release()


def foreground_mutex(tag):
    """图片桥(tag='image')与视频桥(tag='video')共用同一 FG_LOCK_PATH -> 互相协调。"""
    return CrossProcessMutex(FG_LOCK_PATH, tag, acquire_timeout=180.0)


def launch_mutex(tag):
    """管理器启动单例锁（防止两个桥在竞态窗口里各拉起一个管理器）。"""
    return CrossProcessMutex(LAUNCH_LOCK_PATH, tag, acquire_timeout=60.0)

# -*- coding: utf-8 -*-
"""
豆包管理器图片插件桥接服务
==========================

职责：
1. 通过 CDP 操控管理器内的豆包账号 webview；
2. 自动填图生提示词、上传参考图、点「图像生成」、发送、取回成品图片；
3. 对外暴露 HTTP API（127.0.0.1），供字字动画图片插件调用；
4. 下载成品图片到管理器素材库目录，按任务 ID 落盘。

仅使用 Python 标准库。可独立运行，也可被插件以守护线程启动。
"""

import base64
import hashlib
import json
import os
import queue
import re
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import urllib.error
import urllib.parse
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

BRIDGE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BRIDGE_DIR / "config.json"
TASKS_PATH = BRIDGE_DIR / "tasks.json"
SELECTORS_PATH = BRIDGE_DIR / "selectors.json"
CONSOLE_PATH = BRIDGE_DIR / "web_console.html"

# 跨进程协调：图片桥/视频桥互斥驱动同一个豆包管理器，避免同时抢 .active 标签页
# （见 _crosslock.py，图片桥与视频桥共用同一锁文件，仅 tag 不同）。
# 任何异常都降级为空操作，保证桥接照常启动。
# 桥接由宿主进程经 importlib 加载，bridge/ 目录不一定在 sys.path 上，
# 这里显式把本目录加进去，确保 _crosslock 可被导入。
if str(BRIDGE_DIR) not in sys.path:
    sys.path.insert(0, str(BRIDGE_DIR))
try:
    from _crosslock import foreground_mutex
except Exception:
    class _NoopMutex:
        def __enter__(self):
            return self
        def __exit__(self, *a):
            return False
        def acquire(self):
            return True
        def release(self):
            return None
    def foreground_mutex(tag):
        return _NoopMutex()

DEFAULT_CONFIG = {
    "bridge_host": "127.0.0.1",
    "bridge_port": 9231,
    "cdp_port": 9223,
    "manager_exe": "",  # 客户请在插件设置页填写本机 豆包管理器.exe 的完整路径
    "download_dir": "",
    "auto_start_manager": True,
    "max_concurrency": 0,
    "max_reference_images": 4,
    "task_timeout_sec": 600,
    "poll_interval_sec": 3,
    "min_wait_sec": 10,
    "parallel_submit": True,
    "auto_raise_manager_window": True,
    "dispatch_stagger_sec": 2,
    "force_render_all_webviews": True,
    "auto_repair_degraded_page": True,
    "prefer_conversation_page": False,
    "image_count": 1,
    "image_model": "Seedream 5.0 Flash",
    # 图像生成面板参数（按顺序：模型 → 比例 → 风格）
    "image_aspect": "16:9",
    "image_style": "",
    "max_task_retries": 2,
    # 下载前把页面展示用的"带水印转码模板"地址换成豆包签发的无水印原图地址
    "prefer_no_watermark": True,
    # 防霸占：没有本桥接的活动任务时，不巡检账号、不注入页面、不重试历史任务，
    # 也不占用豆包管理器的 CDP 连接（用户选了别的插件就不该被豆包打扰）
    "background_only_when_active": True,
}

# 运行时生效的配置（由 start_bridge 写入）。自动探测必须读它，
# 而不是 DEFAULT_CONFIG —— 否则客户在设置页改了管理器路径也不生效。
_RUNTIME_CONFIG = {}

# 仍在进行中的任务状态。桥接启动时磁盘上残留的这类任务一律作废，
# 否则 _retry_loop / _dispatch_loop 会把上次会话的遗留任务当成"当前工作"续跑，
# 表现就是：用户没点生成、甚至已经切到别的插件，豆包却在自动出图、抢页面焦点。
_ACTIVE_TASK_STATES = {
    "queued", "starting_manager", "connecting", "preparing_page",
    "filling_form", "submitting", "generating", "downloading",
}

# ========================================================================
# 工具函数
# ========================================================================

def _coerce_cfg(key, value):
    if key in ("bridge_port", "cdp_port", "max_concurrency", "max_reference_images",
               "task_timeout_sec", "poll_interval_sec", "min_wait_sec",
               "dispatch_stagger_sec", "image_count"):
        return int(value) if value is not None else 0
    if key in ("auto_start_manager", "parallel_submit", "auto_raise_manager_window",
               "force_render_all_webviews", "auto_repair_degraded_page",
               "prefer_conversation_page", "prefer_no_watermark",
               "background_only_when_active"):
        return bool(value)
    return str(value) if value is not None else ""


def now_str():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def load_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    try:
        tmp = str(path) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, str(path))
        return True
    except Exception:
        return False


def http_get_json(url, timeout=5):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def http_download(url, dest_path, cookies=None, timeout=300):
    """下载文件，可选带 cookie header（自动跟随 301/302 跳转）。"""
    headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"),
        "Referer": "https://www.doubao.com/",
        "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    }
    if cookies:
        headers["Cookie"] = cookies
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    if len(data) < 1024:
        # 多半是把 403/404 的错误页当图片存了下来
        raise RuntimeError("下载内容异常，仅 %d 字节（可能是鉴权失败或链接过期）" % len(data))
    with open(dest_path, "wb") as f:
        f.write(data)
    return len(data)


# ---------------------------------------------------------------------------
# 无水印判定 / 扩展名推断
# ---------------------------------------------------------------------------
#
# 背景（对照"豆包管理器 V2.0"的无水印下载实现）：
#   管理器在 main.jsc 里内置了水印地址黑名单正则
#     video_gen_watermark|watermark_dyn|with_watermark|aigc_busi_mark|aigc_resize_mark
#     (?:^|[?&])(?:lr|logo_type)=watermarked(?:&|$)|with_watermark|video_gen_watermark
#   并靠嗅探 doubao_get_download_info(_backup) 接口拿到 main_url / backupUrl 两个
#   "已确认无水印"的地址（confirmedNoWatermark）。
#
#   图片侧同理：豆包生成图在页面上挂的 <img> 用的是**带水印的转码模板**，形如
#     .../rc_gen_image/<id>.jpeg~tplv-<bucket>-cgen_lwm3.png?x-signature=...
#   （cgen_lwm3 即 light-watermark 模板，右下角"豆包 AI 生成"水印就是它叠加的）。
#   而同一个对象用普通模板取回来就没有水印：
#     .../rc_gen_image/<id>.jpeg~tplv-<bucket>-image-qvalue.jpeg?x-signature=...
#   直接改写 URL 去掉 ~tplv 会破坏签名（实测 403），必须走豆包自己的签名接口
#   POST /alice/message/get_file_url（见注入脚本 dbm.resolveNoWatermark）。

_WATERMARK_RE = re.compile(
    r"lwm\d|cgen_lwm|cthumb_lwm|(?:^|[?&])(?:lr|logo_type)=watermarked(?:&|$)|with_watermark"
    r"|video_gen_watermark|watermark_dyn|aigc_busi_mask|aigc_resize_mask",
    re.IGNORECASE,
)

_EXT_SCAN_RE = re.compile(r"\.(jpe?g|png|webp|bmp|gif|heic|avif)(?=$|~tplv|[?#])", re.IGNORECASE)


def url_looks_watermarked(url):
    """URL 是否命中带水印模板/参数（与管理器 main.jsc 中的判定保持一致）。"""
    return bool(url) and bool(_WATERMARK_RE.search(str(url)))


def guess_ext(url, default=".png"):
    """从图片 URL 推断保存扩展名。

    豆包图片地址形如 <obj>.jpeg~tplv-<bucket>-<template>.png?a=b，
    真正的落盘格式是**最后**一个扩展名（模板里那个）。
    """
    try:
        path = urllib.parse.urlsplit(str(url or "")).path
    except Exception:
        path = str(url or "").split("?", 1)[0]
    hits = _EXT_SCAN_RE.findall(path)
    if not hits:
        return default
    ext = hits[-1].lower()
    return ".jpg" if ext in ("jpg", "jpeg") else "." + ext


def find_manager_userdata():
    """从管理器 exe 路径推算用户数据目录。

    V2.0 完整便携版把数据放在 exe 同目录的 Data/ 下；旧版用 userdata/。
    优先读运行时配置（客户在设置页填的路径），再回退到默认配置。
    """
    exe = str(_RUNTIME_CONFIG.get("manager_exe") or DEFAULT_CONFIG.get("manager_exe") or "").strip()
    if not exe or not os.path.isfile(exe):
        return ""
    exe_dir = os.path.dirname(exe)
    for base in (exe_dir, os.path.dirname(exe_dir)):
        for name in ("Data", "userdata", "UserData"):
            ud = os.path.join(base, name)
            if os.path.isdir(ud):
                return ud
    return ""


def detect_download_dir():
    """探测管理器素材库下载目录。"""
    ud = find_manager_userdata()
    if not ud:
        return ""
    candidates = [
        os.path.join(ud, "Downloads"),
        os.path.join(ud, "download"),
        os.path.join(ud, "Download"),
    ]
    for c in candidates:
        if os.path.isdir(c):
            return c
    return candidates[0] if candidates else ""


def read_cdp_port_from_userdata():
    """从管理器配置文件读 CDP 端口。"""
    ud = find_manager_userdata()
    if not ud:
        return 0
    pref = os.path.join(ud, "Preferences")
    if os.path.isfile(pref):
        try:
            data = load_json(pref, {})
            port = int(data.get("cdp_port", 0) or 0)
            if port:
                return port
        except Exception:
            pass
    # 便携版把当前 CDP 端口写在 DevToolsActivePort 第一行
    active = os.path.join(ud, "DevToolsActivePort")
    if os.path.isfile(active):
        try:
            with open(active, "r", encoding="utf-8", errors="replace") as f:
                return int(f.readline().strip())
        except Exception:
            pass
    return 0


# ========================================================================
# CDP / 管理器窗口
# ========================================================================

_NAV_LOCK = threading.Lock()

def _nav_lock(timeout=None):
    if timeout is None:
        timeout = 20
    acquired = _NAV_LOCK.acquire(timeout=timeout)
    if not acquired:
        raise RuntimeError("导航锁获取超时")
    return _NAV_LOCK


def find_manager_hwnd(title_kw="豆包管理器"):
    """Win32 找管理器窗口句柄。"""
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        enum_windows = user32.EnumWindows
        enum_windows_proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        get_window_text = user32.GetWindowTextW
        get_class_name = user32.GetClassNameW
        is_window_visible = user32.IsWindowVisible
        results = []
        def callback(hwnd, _):
            if not is_window_visible(hwnd):
                return True
            cls = ctypes.create_unicode_buffer(256)
            get_class_name(hwnd, cls, 256)
            if "Chrome_WidgetWin_1" not in cls.value:
                return True
            buf = ctypes.create_unicode_buffer(512)
            get_window_text(hwnd, buf, 512)
            text = buf.value
            if title_kw in text:
                rect = ctypes.wintypes.RECT()
                user32.GetWindowRect(hwnd, ctypes.byref(rect))
                area = (rect.right - rect.left) * (rect.bottom - rect.top)
                results.append((hwnd, area, text))
            return True
        enum_windows(enum_windows_proc(callback), 0)
        if results:
            results.sort(key=lambda x: -x[1])
            return results[0][0]
    except Exception:
        pass
    return 0


def raise_manager_window(title_kw="豆包管理器"):
    """把管理器窗口提到前台（但不抢焦点）。"""
    try:
        hwnd = find_manager_hwnd(title_kw)
        if not hwnd:
            return False
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        SW_SHOWNOACTIVATE = 4
        SW_RESTORE = 9
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, SW_RESTORE)
        else:
            user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)
        return True
    except Exception:
        return False


# ========================================================================
# WSClient
# ========================================================================

class WSClient:
    def __init__(self, ws_url, timeout=20):
        self.ws_url = ws_url
        m = re.match(r"ws://([^:/]+)(?::(\d+))?(/.*)", ws_url)
        if not m:
            raise ValueError(f"非法 ws 地址: {ws_url}")
        self.host = m.group(1)
        self.port = int(m.group(2) or 80)
        self.path = m.group(3)
        self.sock = socket.create_connection((self.host, self.port), timeout=timeout)
        self.sock.settimeout(None)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        handshake = (
            f"GET {self.path} HTTP/1.1\r\n"
            f"Host: {self.host}:{self.port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(handshake.encode("ascii"))
        resp = b""
        while b"\r\n\r\n" not in resp:
            chunk = self.sock.recv(1024)
            if not chunk:
                raise ConnectionError("WebSocket 握手失败：连接被关闭")
            resp += chunk
        if b"101" not in resp.split(b"\r\n", 1)[0]:
            raise ConnectionError(f"WebSocket 握手被拒: {resp[:120]!r}")
        self._id = 0
        self._id_lock = threading.Lock()
        self._send_lock = threading.Lock()
        self._results = {}
        self._events = queue.Queue()
        self._closed = False
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()

    def _recvn(self, n):
        data = b""
        while len(data) < n:
            chunk = self.sock.recv(n - len(data))
            if not chunk:
                raise ConnectionError("WebSocket 连接已关闭")
            data += chunk
        return data

    def _read_loop(self):
        frag = b""
        frag_op = 0
        while not self._closed:
            try:
                head = self._recvn(2)
            except Exception:
                self._closed = True
                self._events.put({"__ws_closed__": True})
                return
            b1, b2 = head[0], head[1]
            fin = (b1 & 0x80) != 0
            opcode = b1 & 0x0F
            length = b2 & 0x7F
            try:
                if length == 126:
                    length = struct.unpack(">H", self._recvn(2))[0]
                elif length == 127:
                    length = struct.unpack(">Q", self._recvn(8))[0]
                payload = self._recvn(length) if length else b""
            except Exception:
                self._closed = True
                self._events.put({"__ws_closed__": True})
                return
            if opcode == 0x9:
                self._send_frame(0xA, payload)
                continue
            if opcode == 0x8:
                self._closed = True
                self._events.put({"__ws_closed__": True})
                return
            if opcode == 0x0:
                frag += payload
            else:
                frag = payload
                frag_op = opcode
            if not fin:
                continue
            data = frag
            frag = b""
            if frag_op in (0x1, 0x2):
                try:
                    msg = json.loads(data.decode("utf-8", errors="ignore"))
                except Exception:
                    continue
                if "id" in msg:
                    self._results[msg["id"]] = msg
                else:
                    self._events.put(msg)
            frag_op = 0

    def _send_frame(self, opcode, payload: bytes):
        header = bytes([0x80 | opcode])
        mask_bit = 0x80
        n = len(payload)
        if n < 126:
            header += bytes([mask_bit | n])
        elif n < 65536:
            header += bytes([mask_bit | 126]) + struct.pack(">H", n)
        else:
            header += bytes([mask_bit | 127]) + struct.pack(">Q", n)
        mask = os.urandom(4)
        header += mask
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        with self._send_lock:
            self.sock.sendall(header + masked)

    def send(self, method, params=None, timeout=60):
        with self._id_lock:
            self._id += 1
            mid = self._id
        msg = {"id": mid, "method": method, "params": params or {}}
        self._send_frame(0x1, json.dumps(msg).encode("utf-8"))
        deadline = time.time() + timeout
        while time.time() < deadline:
            if mid in self._results:
                r = self._results.pop(mid)
                if "error" in r:
                    raise RuntimeError(f"CDP {method} 错误: {r['error']}")
                return r.get("result", {})
            time.sleep(0.05)
        raise TimeoutError(f"CDP 调用超时: {method}")

    def events(self, max_wait=0.2):
        out = []
        deadline = time.time() + max_wait
        while True:
            try:
                timeout = max(0.01, deadline - time.time())
                out.append(self._events.get(timeout=timeout))
            except queue.Empty:
                break
            if time.time() >= deadline:
                break
        return out

    def close(self):
        self._closed = True
        try:
            self.sock.close()
        except Exception:
            pass


# ========================================================================
# ManagerBridge
# ========================================================================

class ManagerBridge:
    """封装对豆包管理器的 CDP 操作。"""

    def __init__(self, config=None):
        self.config = config or {}
        self.cdp_port = int(self.config.get("cdp_port", 9223) or 9223)
        self._targets = []
        self._last_targets_ts = 0

    def _json_list(self):
        return http_get_json(f"http://127.0.0.1:{self.cdp_port}/json/list", timeout=3) or []

    def list_targets(self, refresh=False):
        now = time.time()
        if refresh or now - self._last_targets_ts > 3:
            self._targets = self._json_list()
            self._last_targets_ts = now
        return self._targets

    def list_accounts(self):
        """返回管理器里已打开的账号 webview 列表。"""
        return [t for t in self.list_targets() if t.get("type") == "webview"
                and "doubao.com/chat" in (t.get("url") or "")]

    def _manager_page_target(self):
        for t in self.list_targets(refresh=True):
            if t.get("type") == "page" and "index.html" in (t.get("url") or ""):
                return t
        return None

    def force_render_all_webviews(self, timeout=20):
        mgr = self._manager_page_target()
        if not mgr:
            return {"ok": False, "reason": "manager_page_not_found"}
        ws = None
        try:
            ws = WSClient(mgr.get("webSocketDebuggerUrl", ""), timeout=timeout)
            ws.send("Runtime.enable")
            js = (
                "(function(){\n"
                "  function isActive(w){ var c = w.className;"
                " if (c && typeof c.baseVal === 'string') c = c.baseVal;"
                " return String(c||'').indexOf('active') >= 0; }\n"
                "  function apply(){\n"
                "    var wvs = document.querySelectorAll('webview');\n"
                "    for (var i=0;i<wvs.length;i++){\n"
                "      var w = wvs[i];\n"
                "      try{\n"
                "        w.style.setProperty('visibility','visible','important');\n"
                "        if (isActive(w)){\n"
                "          w.style.setProperty('opacity','1','important');\n"
                "          w.style.setProperty('z-index','99','important');\n"
                "        } else {\n"
                "          w.style.setProperty('opacity','0.02','important');\n"
                "          w.style.setProperty('z-index','0','important');\n"
                "        }\n"
                "      }catch(e){}\n"
                "    }\n"
                "    return wvs.length;\n"
                "  }\n"
                "  if (window.__dbmImageVisTimer) clearInterval(window.__dbmImageVisTimer);\n"
                "  var n = apply();\n"
                "  window.__dbmImageVisTimer = setInterval(apply, 1000);\n"
                "  var vis = Array.from(document.querySelectorAll('webview'))\n"
                "              .map(function(w){ return getComputedStyle(w).visibility; });\n"
                "  return {ok:true, n:n, visibility:vis};\n"
                "})()"
            )
            r = ws.send("Runtime.evaluate",
                        {"expression": js, "awaitPromise": True, "returnByValue": True},
                        timeout=timeout)
            return r.get("result", {}).get("value") or {"ok": False, "reason": "no_value"}
        except Exception as e:
            return {"ok": False, "reason": f"ws_error:{e}"}
        finally:
            if ws is not None:
                try:
                    ws.close()
                except Exception:
                    pass

    def open_all_accounts(self, timeout=60):
        """让管理器打开所有账号（通过管理器 UI 自动化）。"""
        # 简化：直接返回已有账号
        accts = self.list_accounts()
        return {"ok": True, "accounts": accts}

    def pick_target(self, account_hint=""):
        """根据账号提示选目标 webview。"""
        accts = self.list_accounts()
        if not accts:
            return None
        if account_hint:
            for a in accts:
                title = a.get("title", "")
                if account_hint in title:
                    return a
        return accts[0]

    def attach(self, target, timeout=25):
        return WSClient(target.get("webSocketDebuggerUrl", ""), timeout=timeout)

    def evaluate(self, ws, expr, return_by_value=True, await_promise=False, timeout=25):
        result = ws.send("Runtime.evaluate", {
            "expression": expr,
            "returnByValue": return_by_value,
            "awaitPromise": await_promise,
        }, timeout=timeout)
        # result is the full CDP response dict
        if result.get("exceptionDetails"):
            desc = result["exceptionDetails"].get("exception", {}).get("description", "")
            raise RuntimeError(f"JS 异常: {desc[:200]}")
        return (result.get("result") or {}).get("value")

    def upload_images(self, ws, file_paths):
        """通过 CDP DOM.setFileInputFiles 上传图片。"""
        results = []
        for p in file_paths:
            if not os.path.isfile(p):
                results.append({"ok": False, "path": p, "reason": "not_found"})
                continue
            abs_path = os.path.abspath(p).replace("\\", "/")
            try:
                ws.send("DOM.enable", {}, timeout=10)
                # 找 file input
                node_id = self.evaluate(ws,
                    "(function(){\n"
                    "  var inp = document.querySelector('input[type=file]');\n"
                    "  if (!inp) return 0;\n"
                    "  var node = window.__lastFileInputNode;\n"
                    "  return node || 0;\n"
                    "})()", timeout=10)
                if not node_id:
                    # 用 querySelector 找
                    doc = ws.send("DOM.getDocument", {}, timeout=10)
                    root = doc["result"]["root"]["nodeId"]
                    res = ws.send("DOM.querySelector", {"nodeId": root, "selector": "input[type=file]"}, timeout=10)
                    node_id = res["result"]["nodeId"]
                if node_id:
                    ws.send("DOM.setFileInputFiles", {"nodeId": node_id, "files": [abs_path]}, timeout=15)
                    results.append({"ok": True, "path": p})
                else:
                    results.append({"ok": False, "path": p, "reason": "no_file_input"})
            except Exception as e:
                results.append({"ok": False, "path": p, "reason": str(e)[:100]})
        return results

    def get_cookies_header(self, ws):
        """获取 doubao.com 域的 cookie 字符串。"""
        try:
            ws.send("Network.enable", {}, timeout=5)
            r = ws.send("Network.getAllCookies", {}, timeout=10)
            cookies = r.get("result", {}).get("cookies", [])
            parts = []
            for c in cookies:
                if "doubao" in c.get("domain", ""):
                    parts.append(f"{c['name']}={c['value']}")
            return "; ".join(parts)
        except Exception:
            return ""


# ========================================================================
# 注入脚本生成
# ========================================================================

def js_quote(s):
    return json.dumps(str(s) if s is not None else "")


_INJECT_JS_CACHE = {}

def build_inject_js_cached(selectors):
    key = json.dumps(selectors, sort_keys=True)
    if key not in _INJECT_JS_CACHE:
        _INJECT_JS_CACHE[key] = build_inject_js(selectors)
    return _INJECT_JS_CACHE[key]


def build_inject_js(selectors):
    """生成注入到豆包页面的 JS，提供 dbm.* 工具函数。"""
    s = selectors or {}
    # 图像模式专用选择器（fallback）
    image_mode_btn = s.get("image_mode_button", "")
    if not image_mode_btn:
        image_mode_btn = "button"

    js = r"""
(function(){
  "use strict";
  if (window.__dbmImage && window.__dbmImage.__ver === "{VER}") return;
  var dbm = {};
  dbm.sleep = function(ms){ return new Promise(function(r){ setTimeout(r, ms); }); };
  dbm.now = function(){ return Date.now(); };

  // 可见性判断
  dbm.vis = function(el){
    if (!el) return false;
    var cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity > 0.01;
  };

  // 获取编辑器（即使隐藏也返回，由调用方决定是否 reveal）
  dbm.getEditor = function(allowHidden){
    var pm = document.querySelector('.tiptap.ProseMirror');
    if (pm && (allowHidden || dbm.vis(pm))) return pm;
    var ce = document.querySelector('[contenteditable="true"]');
    if (ce && (allowHidden || dbm.vis(ce))) return ce;
    var ta = document.querySelector('textarea');
    if (ta && (allowHidden || dbm.vis(ta))) return ta;
    return null;
  };

  // 唤醒隐藏编辑器
  dbm.revealEditor = function(){
    var el = dbm.getEditor(true);
    if (!el) return {ok:false, reason:'no_editor'};
    var cur = el;
    var fixed = [];
    for (var i=0;i<12 && cur;i++){
      var cs = getComputedStyle(cur);
      if (cs.visibility === 'hidden' || cs.pointerEvents === 'none' || parseFloat(cs.opacity) < 0.05){
        cur.style.setProperty('visibility','visible','important');
        cur.style.setProperty('pointer-events','auto','important');
        cur.style.setProperty('opacity','1','important');
        fixed.push(cur.tagName + (cur.className ? '.'+cur.className.split(' ').slice(0,2).join('.') : ''));
      }
      cur = cur.parentElement;
    }
    return {ok:true, mode:'force_unhide', fixed:fixed, tag:el.tagName, rect:Math.round(el.getBoundingClientRect().width)+'x'+Math.round(el.getBoundingClientRect().height)};
  };

  // 聚焦编辑器
  dbm.focusEditor = function(){
    var el = dbm.getEditor(true);
    if (!el) return {ok:false, reason:'no_editor'};
    el.focus();
    var sel = window.getSelection();
    var r = document.createRange();
    r.selectNodeContents(el);
    r.collapse(false);
    sel.removeAllRanges();
    sel.addRange(r);
    return {ok:true, tag:el.tagName, ce:el.isContentEditable, active:document.activeElement===el};
  };

  // 设置提示词
  dbm.setPrompt = function(text){
    var el = dbm.getEditor(true);
    if (!el) return {ok:false, reason:'no_editor'};
    el.focus();
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      el.value = text;
      el.dispatchEvent(new Event('input', {bubbles:true}));
    } else {
      el.innerHTML = '<p>' + text.replace(/\n/g, '</p><p>') + '</p>';
      el.dispatchEvent(new Event('input', {bubbles:true}));
    }
    return {ok:true, len:(el.innerText||'').length};
  };

  // 读取编辑器文本
  dbm.editorText = function(){
    var el = dbm.getEditor(true);
    if (!el) return '';
    return el.innerText || el.value || '';
  };

  // 按 Enter 发送
  dbm.pressEnter = function(){
    var el = dbm.getEditor(true);
    if (!el) return false;
    el.focus();
    var opts = {key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true, cancelable:true};
    el.dispatchEvent(new KeyboardEvent('keydown', opts));
    el.dispatchEvent(new KeyboardEvent('keypress', opts));
    el.dispatchEvent(new KeyboardEvent('keyup', opts));
    return true;
  };

  // 是否已发送（编辑器被清空）
  dbm.isSent = function(){
    return ((dbm.editorText() || '').trim().length < 3);
  };

  // 页面是否忙碌
  dbm.isPageBusy = function(){
    var spin = document.querySelector('[class*="loading"], [class*="spinner"], [class*="generating"]');
    return {busy: !!spin, spinner: spin ? spin.className.slice(0,60) : ''};
  };

  // 点击「图像生成」按钮
  dbm.pickImageMode = function(){
    var btns = Array.from(document.querySelectorAll('button,div[role=button],span'));
    var hit = null;
    for (var i=0;i<btns.length;i++){
      var b = btns[i];
      var tx = (b.innerText||b.textContent||'').trim();
      if (tx === '图像生成' || tx === '图片生成') { hit = b; break; }
    }
    if (!hit) {
      for (var i=0;i<btns.length;i++){
        var b = btns[i];
        var tx = (b.innerText||b.textContent||'').trim();
        if (/图像生成|图片生成/.test(tx) && tx.length < 20) { hit = b; break; }
      }
    }
    if (!hit) return {ok:false, reason:'no_image_mode_button'};
    hit.scrollIntoView({block:'center'});
    hit.click();
    return {ok:true, tag:hit.tagName, cls:String(hit.className||'').slice(0,80)};
  };

  // 获取当前模式
  dbm.getMode = function(){
    var pm = document.querySelector('.tiptap.ProseMirror');
    var ta = document.querySelector('textarea');
    var modes = [];
    document.querySelectorAll('button,div[role=button]').forEach(function(b){
      var tx = (b.innerText||b.textContent||'').trim();
      if (/对话|视频生成|图像生成|PPT|写作|研究/.test(tx) && tx.length < 20) modes.push(tx);
    });
    return {ta:!!ta, pm:!!pm, modes:modes.slice(0,10)};
  };

  // ============ 生成图识别 & 无水印原图解析 ============
  // 页面上的生成图 <img> 用的是带水印转码模板（...~tplv-<bucket>-cgen_lwm3.png），
  // 直接下载会拿到右下角带"豆包 AI 生成"水印的图（历史 bug 的根因）。
  // 无水印原图必须用对象 uri 走豆包自身的签名接口重新取地址，见 resolveNoWatermark。
  dbm.WM_RE = /lwm\d|cgen_lwm|cthumb_lwm|watermark|with_watermark|logo_type=watermarked|(?:^|[?&])lr=watermarked/i;

  // 从图片地址里拆出对象 uri（去掉 ~tplv 模板后缀），例如
  //   https://host/tos-cn-i-xxx/rc_gen_image/abc.jpeg~tplv-x-cgen_lwm3.png?a=b
  //   -> tos-cn-i-xxx/rc_gen_image/abc.jpeg
  dbm.uriOf = function(url){
    try{
      var u = new URL(String(url||''), location.href);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
      var p = decodeURIComponent(u.pathname.replace(/^\//, ''));
      p = p.replace(/~tplv[^\/?]*$/i, '');
      return p;
    }catch(e){ return ''; }
  };

  // 推断真实落盘格式（取最后一个扩展名，即模板里的那个）
  dbm.extOf = function(url){
    try{
      var p = decodeURIComponent(new URL(String(url||''), location.href).pathname);
      var m = p.match(/\.(jpe?g|png|webp|bmp|gif|heic|avif)(?=$|~tplv)/ig);
      if (!m || !m.length) return 'png';
      var e = m[m.length-1].slice(1).toLowerCase();
      if (e === 'jpeg') e = 'jpg';
      return e;
    }catch(err){ return 'png'; }
  };

  dbm.isGenerated = function(src){
    var s = String(src||'');
    if (!/^https?:/i.test(s)) return false;
    if (/avatar|emoji|icon|logo|favicon/i.test(s)) return false;
    return /rc_gen_image/i.test(s);
  };

  // 页面上的成品图列表（主判据 rc_gen_image，兜底：byteimg 大图）
  dbm.genImages = function(){
    var els = Array.prototype.slice.call(document.querySelectorAll('img,source,video'));
    var seen = {}, out = [];
    for (var i=0;i<els.length;i++){
      var el = els[i];
      var s = String(el.currentSrc || el.src || el.getAttribute('src') || '');
      if (!s || seen[s]) continue;
      var nw = el.naturalWidth || 0, nh = el.naturalHeight || 0;
      var ok = dbm.isGenerated(s) || (/~tplv/i.test(s) && nw >= 512);
      if (!ok) continue;
      seen[s] = 1;
      out.push({
        src: s,
        uri: dbm.uriOf(s),
        ext: dbm.extOf(s),
        w: nw, h: nh,
        watermark: dbm.WM_RE.test(s),
        alt: el.getAttribute('alt') || ''
      });
    }
    return out;
  };

  // 兼容旧接口
  dbm.getGeneratedImages = function(){
    var out = dbm.genImages();
    return {n: out.length, images: out};
  };

  // 提交前采集"页面上已存在的成图 uri"作为基线。
  // 多任务串行时，账号页面会留着上一轮任务的图，若不排除就会把旧图当成
  // 本次产出下载回传（并发场景下表现为"回传给分镜的图是乱的"）。
  dbm.genImageUris = function(){
    var seen = {}, out = [];
    var list = dbm.genImages();
    for (var i=0;i<list.length;i++){
      var u = list[i].uri || dbm.uriOf(list[i].src);
      if (!u || seen[u]) continue;
      seen[u] = 1;
      out.push(u);
    }
    return out;
  };

  // 只取页面末尾的最新文本：失败提示只会追加在末尾，
  // 用全页 innerText 匹配"违规"等词会被历史消息误伤（旧任务的内容也命中）。
  dbm.tailText = function(n){
    try{
      var t = (document.body && document.body.innerText) || '';
      n = n || 4000;
      return t.length > n ? t.slice(-n) : t;
    }catch(e){ return ''; }
  };

  // 用 uri 换取"无水印原图"地址（同源请求，自带 cookie）
  // 入参：url 字符串数组，或 [{src, uri, ext}] ；返回 {ok, items:[{src, uri, main_url, back_url, watermark}]}
  dbm.resolveNoWatermark = async function(urls, timeoutMs){
    var list = Array.isArray(urls) ? urls : [urls];
    var meta = [];
    for (var i=0;i<list.length;i++){
      var raw = list[i];
      var isObj = raw && typeof raw === 'object';
      var u = isObj ? String(raw.src || raw.url || '') : String(raw || '');
      var uri = (isObj && raw.uri) ? raw.uri : dbm.uriOf(u);
      if (!uri) continue;
      meta.push({src: u, uri: uri, ext: (isObj && raw.ext) ? raw.ext : dbm.extOf(u)});
    }
    if (!meta.length) return {ok:false, reason:'no_uri', items:[]};

    // 按 format 分组（接口的 format 是整体参数）
    var groups = {};
    for (var k=0;k<meta.length;k++){
      var f = meta[k].ext || 'png';
      (groups[f] = groups[f] || []).push(meta[k].uri);
    }

    var byUri = {}, lastCode = null, errMsg = '';
    var formats = Object.keys(groups);
    for (var gi=0; gi<formats.length; gi++){
      var fmt = formats[gi], uris = groups[fmt];
      var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      var timer = null;
      if (ctrl && timeoutMs){
        timer = setTimeout(function(){ try{ ctrl.abort(); }catch(e){} }, timeoutMs);
      }
      try{
        var resp = await fetch('/alice/message/get_file_url', {
          method: 'POST',
          credentials: 'include',
          cache: 'no-store',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            uris: uris,
            type: 'image',
            format: fmt,
            expire_second: 3600
          }),
          signal: ctrl ? ctrl.signal : undefined
        });
        if (timer) { clearTimeout(timer); timer = null; }
        var j = await resp.json();
        lastCode = (j && j.code);
        var arr = (j && j.data && j.data.file_urls) || [];
        for (var ui=0; ui<uris.length; ui++){
          var fu = arr[ui] || {};
          var m1 = String(fu.main_url || ''), b1 = String(fu.back_url || '');
          byUri[uris[ui]] = {
            main_url: m1,
            back_url: b1,
            watermark: dbm.WM_RE.test(m1) || dbm.WM_RE.test(b1),
            ok: !!(m1 || b1)
          };
        }
      }catch(e){
        if (timer) clearTimeout(timer);
        errMsg = String(e && e.message || e);
      }
    }
    // 一个对象在页面上可能挂多个展示地址（缩略图 / 大图），这里逐条回填，
    // 保证调用方按 src 查找时都能命中同一份原图地址。
    var items = meta.map(function(mt){
      var hit = byUri[mt.uri] || {};
      return {
        src: mt.src,
        uri: mt.uri,
        ext: mt.ext,
        main_url: hit.main_url || '',
        back_url: hit.back_url || '',
        watermark: !!hit.watermark,
        ok: !!hit.ok
      };
    });
    return {
      ok: items.some(function(x){ return x.ok; }),
      code: lastCode,
      error: errMsg,
      items: items
    };
  };

  // 页面健康
  dbm.pageHealth = function(){
    var btns = document.querySelectorAll('button');
    var ta = document.querySelectorAll('textarea').length;
    var pm = document.querySelectorAll('.tiptap.ProseMirror').length;
    var ce = document.querySelectorAll('[contenteditable="true"]').length;
    var ready = document.readyState;
    var url = location.href;
    return {ready:ready, url:url, buttons:btns.length, ta:ta, pm:pm, ce:ce,
            usable: ready==='complete' && (ta>0 || ce>0)};
  };

  // 检查是否有图像生成模式按钮
  dbm.hasImageModeButton = function(){
    var btns = document.querySelectorAll('button,div[role=button],span');
    for (var i=0;i<btns.length;i++){
      var tx = (btns[i].innerText||btns[i].textContent||'').trim();
      if (/图像生成|图片生成/.test(tx) && tx.length < 20) return true;
    }
    // 已经处于图像生成模式时，"图像生成"按钮会变成工具栏里的激活项，
    // 此时靠"模型/比例/风格"这三个参数按钮来判定，避免误判为"没按钮"而刷新页面。
    return !!dbm.paramBtn('模型');
  };

  // ============ 图像参数：模型 / 比例 / 风格 ============
  // 这三个是工具栏上的下拉按钮，按钮文案里直接带着当前值，例如
  //   "模型 Seedream 5.0 Flash" / "比例 自动" / "风格"
  // ⚠️ 实测：这类 React 浮层对 el.click() 无反应，必须由 Python 端用 CDP
  //    真实鼠标事件点击（而且要先 bringToFront + setFocusEmulationEnabled，
  //    否则被管理器隐藏的 webview 收不到输入事件）。这里只负责定位坐标。
  dbm.paramBtn = function(kind){
    var els = Array.prototype.slice.call(document.querySelectorAll('button,div[role=button]'));
    for (var i=0;i<els.length;i++){
      var tx = (els[i].innerText||els[i].textContent||'').trim().replace(/\s+/g,' ');
      if (tx.indexOf(kind) !== 0 || tx.length > 40) continue;
      var r = els[i].getBoundingClientRect();
      if (r.width < 20 || r.height < 16) continue;
      return {tx:tx, x:Math.round(r.left + r.width/2), y:Math.round(r.top + r.height/2),
              w:Math.round(r.width), h:Math.round(r.height)};
    }
    return null;
  };

  // 按钮当前选中的值（去掉前缀就是，例如 "比例 自动" -> "自动"）
  dbm.paramValue = function(kind){
    var b = dbm.paramBtn(kind);
    if (!b) return '';
    return b.tx.slice(kind.length).trim();
  };

  // 在已展开的菜单里按文案找选项，返回坐标（取面积最小的最内层元素）
  dbm.menuItem = function(text, exact){
    if (!text) return null;
    var els = Array.prototype.slice.call(document.querySelectorAll('*'));
    var best = null;
    for (var i=0;i<els.length;i++){
      var e = els[i];
      if (e.children.length > 3) continue;
      var tx = (e.innerText||e.textContent||'').trim().replace(/\s+/g,' ');
      if (!tx || tx.length > 30) continue;
      var hit = exact ? (tx === text) : (tx.indexOf(text) >= 0);
      if (!hit) continue;
      var r = e.getBoundingClientRect();
      if (r.width < 20 || r.height < 14) continue;
      var area = r.width * r.height;
      if (!best || area < best.area){
        best = {tx:tx, x:Math.round(r.left + r.width/2), y:Math.round(r.top + r.height/2),
                w:Math.round(r.width), h:Math.round(r.height), area:area};
      }
    }
    return best;
  };

  // 关掉可能打开的浮层（点页面空白处）
  dbm.closeMenu = function(){
    try { document.body.click(); } catch(e) {}
  };

  // 版本标记
  dbm.__ver = "{VER}";
  window.__dbmImage = dbm;
})();
"""
    return js


def inject_js_ver(selectors):
    return hashlib.md5(build_inject_js(selectors).encode("utf-8")).hexdigest()[:12]


def build_inject_js_with_ver(selectors):
    """生成注入脚本，版本号已嵌入。"""
    ver = inject_js_ver(selectors)
    js = build_inject_js(selectors)
    return js.replace('"{VER}"', json.dumps(ver))


# ========================================================================
# TaskStore
# ========================================================================

class TaskStore:
    def __init__(self, path=None):
        self.path = str(path) if path else str(TASKS_PATH)
        self.lock = threading.Lock()
        self.tasks = {}
        self._load()

    def _load(self):
        data = load_json(self.path, {})
        self.tasks = data.get("tasks", {})

    def _save(self):
        save_json(self.path, {"tasks": self.tasks, "updated": time.time()})

    def create(self, prompt, images=None, **meta):
        tid = str(uuid.uuid4())
        with self.lock:
            self.tasks[tid] = {
                "id": tid,
                "prompt": prompt,
                "images": images or [],
                "status": "queued",
                "percent": 0,
                "message": "排队中",
                "error": "",
                "retries": 0,
                "created": time.time(),
                "updated": time.time(),
                "submit_ts": 0,
                "done_ts": 0,
                "output_paths": [],
                "logs": [],
            }
            for k, v in meta.items():
                if v not in (None, ""):
                    self.tasks[tid][k] = v
            self._save()
        return tid

    def get(self, tid):
        with self.lock:
            return dict(self.tasks.get(tid, {}))

    def update(self, tid, **kwargs):
        with self.lock:
            t = self.tasks.get(tid)
            if not t:
                return
            for k, v in kwargs.items():
                if v is not None:
                    t[k] = v
            t["updated"] = time.time()
            self._save()

    def log(self, tid, msg):
        with self.lock:
            t = self.tasks.get(tid)
            if not t:
                return
            logs = t.get("logs", [])
            logs.append(f"[{now_str()}] {msg}")
            if len(logs) > 200:
                logs = logs[-200:]
            t["logs"] = logs
            self._save()

    def list(self):
        with self.lock:
            items = [dict(t) for t in self.tasks.values()]
        items.sort(key=lambda t: t.get("created", 0), reverse=True)
        return items

    def cancel(self, tid):
        """把任务标记为已取消（不影响正在跑的 worker 线程，worker 会在生成循环里
        检测到 cancelled 标记后主动中止，见 AccountWorker._wait_for_images）。"""
        with self.lock:
            t = self.tasks.get(tid)
            if not t:
                return
            t["status"] = "error"
            t["percent"] = 0
            t["message"] = "已取消"
            t["error"] = "cancelled"
            t["cancelled"] = True
            t["updated"] = time.time()
            self._save()

    def is_cancelled(self, tid):
        with self.lock:
            t = self.tasks.get(tid, {})
            return bool(t.get("cancelled")) or t.get("error") == "cancelled"


# ========================================================================
# 异常
# ========================================================================

class GenerationFailed(Exception):
    def __init__(self, message="", kind="", page_text=""):
        super().__init__(message)
        self.kind = kind
        self.page_text = page_text


class GenerationTimeout(Exception):
    pass


class TaskCancelled(Exception):
    pass


class DownloadFailed(Exception):
    pass


# ========================================================================
# AccountWorker
# ========================================================================

class AccountWorker(threading.Thread):
    """每个账号一个 worker，负责图像生成任务。"""

    def __init__(self, bridge, store, config, target, slot=0):
        super().__init__(daemon=True)
        self.bridge = bridge
        self.store = store
        self.config = config
        self.target = target
        self.slot = slot
        self.ws = None
        self.busy = False
        self.current_tid = None
        self.epoch = 0
        self._inject_js = ""
        self._inject_ver = ""
        self._last_render_ts = 0
        self._cookies = ""
        self._last_health_ok = False
        self._last_health_ts = 0
        self.done = 0                      # 已完成任务计数（健康卡展示用）
        self.quota_ok = True               # 额度是否充足（命中额度上限时置 False）
        self.quota_recover_at = None       # 额度恢复时间（None=未知/未受限）

    def display_name(self):
        return f"账号{self.slot}"

    def run(self):
        while True:
            time.sleep(0.5)

    def _attach(self):
        if self.ws is not None:
            return True
        try:
            self.ws = self.bridge.attach(self.target, timeout=25)
            try:
                self.ws.send("Runtime.enable", {}, timeout=10)
            except Exception:
                pass
            try:
                self.ws.send("Network.enable", {}, timeout=10)
            except Exception:
                pass
            return True
        except Exception as e:
            self.store.log(self.current_tid or "", f"{self.display_name()} 连接失败: {e}")
            return False

    def _eval_safe(self, expr, timeout=25):
        if not self.ws:
            return None
        try:
            return self.bridge.evaluate(self.ws, expr, return_by_value=True, await_promise=False, timeout=timeout)
        except Exception as e:
            self.store.log(self.current_tid or "", f"{self.display_name()} JS 执行失败: {e}")
            return None

    def _eval_async(self, expr, timeout=60):
        """执行返回 Promise 的 JS（用于页面内 fetch 等异步逻辑）。"""
        if not self.ws:
            return None
        try:
            return self.bridge.evaluate(self.ws, expr, return_by_value=True, await_promise=True, timeout=timeout)
        except Exception as e:
            self.store.log(self.current_tid or "", f"{self.display_name()} JS(异步) 执行失败: {e}")
            return None

    def _ensure_injected(self):
        if not self._attach():
            return False
        alive = self._eval_safe(
            "window.__dbmImage && window.__dbmImage.__ver === '%s'" % self._inject_ver, timeout=10)
        if alive:
            return True
        try:
            self.bridge.evaluate(self.ws, self._inject_js, return_by_value=False, await_promise=False, timeout=30)
            time.sleep(0.5)
            alive2 = self._eval_safe(
                "window.__dbmImage && window.__dbmImage.__ver === '%s'" % self._inject_ver, timeout=10)
            return bool(alive2)
        except Exception as e:
            self.store.log(self.current_tid or "", f"{self.display_name()} 注入失败: {e}")
            return False

    def _ensure_all_webviews_render(self):
        now = time.time()
        if now - self._last_render_ts < 90:
            return True
        self._last_render_ts = now
        try:
            r = self.bridge.force_render_all_webviews(timeout=20)
            return r.get("ok", False)
        except Exception:
            return False

    def _ensure_window_visible(self):
        if not self.config.get("auto_raise_manager_window", True):
            return
        try:
            raise_manager_window()
        except Exception:
            pass

    def _get_cookies(self):
        if self._cookies:
            return self._cookies
        if not self.ws:
            return ""
        try:
            self._cookies = self.bridge.get_cookies_header(self.ws)
        except Exception:
            pass
        return self._cookies

    def _check_health(self):
        """快速检查页面是否可用（有图像生成按钮或已知可用会话页）。"""
        dn = self.display_name()
        if not self.ws:
            # 尝试 attach
            if not self._attach():
                self._last_health_ok = False
                self._last_health_ts = time.time()
                return False
        try:
            # 注入脚本必须先存活
            if not self._ensure_injected():
                self._last_health_ok = False
                self._last_health_ts = time.time()
                return False
            # 检查是否有图像生成按钮
            has_btn = self._eval_safe("window.__dbmImage.hasImageModeButton()", timeout=10)
            if has_btn:
                self._last_health_ok = True
                self._last_health_ts = time.time()
                return True
            # 检查是否是已知的可用会话页（有模式按钮的会话页）
            url = self._eval_safe("location.href", timeout=10) or ""
            if "/chat/" in url and not url.rstrip("/").endswith("/chat"):
                # 会话页：检查是否有任何模式按钮
                modes = self._eval_safe("JSON.stringify(window.__dbmImage.getMode())", timeout=10)
                try:
                    md = json.loads(modes) if isinstance(modes, str) else modes
                    if md and len(md.get("modes", [])) > 0:
                        self._last_health_ok = True
                        self._last_health_ts = time.time()
                        return True
                except Exception:
                    pass
            self._last_health_ok = False
            self._last_health_ts = time.time()
            return False
        except Exception:
            self._last_health_ok = False
            self._last_health_ts = time.time()
            return False

    def _pick_image_mode(self, tid, budget_sec=45):
        """点击「图像生成」按钮，无按钮时自动刷新修复。"""
        t0 = time.time()
        refresh_attempted = False
        while time.time() - t0 < budget_sec:
            # 先检查是否有图像生成按钮
            has_btn = self._eval_safe("window.__dbmImage.hasImageModeButton()", timeout=10)
            if not has_btn and not refresh_attempted:
                self.store.log(tid, f"{self.display_name()} 无图像生成按钮，尝试刷新")
                try:
                    self.ws.send("Page.navigate", {"url": "https://www.doubao.com/chat/"}, timeout=30)
                except Exception as e:
                    self.store.log(tid, f"{self.display_name()} 刷新失败: {e}")
                time.sleep(6)
                refresh_attempted = True
                # 刷新后重新注入
                self._ensure_injected()
                continue

            r = self._eval_safe("JSON.stringify(window.__dbmImage.pickImageMode())", timeout=15)
            try:
                d = json.loads(r) if isinstance(r, str) else r
            except Exception:
                d = {}
            if d and d.get("ok"):
                self.store.log(tid, f"{self.display_name()} 已切换到图像生成模式")
                return True
            time.sleep(2)
        self.store.log(tid, f"{self.display_name()} 切换图像生成模式超时")
        return False

    def _send_image_prompt(self, tid, prompt, images=None):
        """填提示词并发送。"""
        # 等待编辑器出现（图像模式切换后可能有延迟）
        editor_ready = False
        for _ in range(15):
            r = self._eval_safe("JSON.stringify(window.__dbmImage.revealEditor())", timeout=10)
            try:
                d = json.loads(r) if isinstance(r, str) else r
            except Exception:
                d = {}
            if d and d.get("ok"):
                editor_ready = True
                break
            time.sleep(1)
        if not editor_ready:
            self.store.log(tid, f"{self.display_name()} 编辑器未就绪")
            return False

        f = self._eval_safe("JSON.stringify(window.__dbmImage.focusEditor())", timeout=10)
        self.store.log(tid, f"{self.display_name()} focusEditor: {f}")
        # 填字
        r = self._eval_safe("JSON.stringify(window.__dbmImage.setPrompt(%s))" % js_quote(prompt), timeout=15)
        self.store.log(tid, f"{self.display_name()} setPrompt raw: {r}")
        try:
            d = json.loads(r) if isinstance(r, str) else r
        except Exception as e:
            self.store.log(tid, f"{self.display_name()} setPrompt parse error: {e}")
            d = {}
        if not d or not d.get("ok"):
            self.store.log(tid, f"{self.display_name()} setPrompt 失败: {r}")
            return False
        # 上传参考图（如果有）
        if images:
            # 找 file input 并上传
            try:
                self.ws.send("DOM.enable", {}, timeout=10)
                doc = self.ws.send("DOM.getDocument", {}, timeout=10)
                root = doc["result"]["root"]["nodeId"]
                res = self.ws.send("DOM.querySelector", {"nodeId": root, "selector": "input[type=file]"}, timeout=10)
                node_id = res["result"]["nodeId"]
                if node_id:
                    for p in images[:int(self.config.get("max_reference_images", 4))]:
                        if os.path.isfile(p):
                            abs_path = os.path.abspath(p).replace("\\", "/")
                            self.ws.send("DOM.setFileInputFiles", {"nodeId": node_id, "files": [abs_path]}, timeout=15)
                            time.sleep(0.5)
            except Exception as e:
                self.store.log(tid, f"{self.display_name()} 上传参考图失败: {e}")
        # pressEnter 发送，支持多次重试
        for attempt in range(3):
            self._eval_safe("window.__dbmImage.pressEnter()", timeout=10)
            wait_sec = 2 + attempt  # 首次 2s，第二次 3s，第三次 4s
            time.sleep(wait_sec)
            sent = self._eval_safe("window.__dbmImage.isSent()", timeout=10)
            self.store.log(tid, f"{self.display_name()} pressEnter 尝试{attempt+1} isSent={sent}")
            if sent:
                self.store.log(tid, f"{self.display_name()} 提示词已发送")
                return True
            if attempt < 2:
                time.sleep(2)
        return False

    def _snapshot_uris(self):
        """提交前采集页面上已有成图的 uri，作为"本次新增"判定的基线。

        多任务串行/多账号并发时，账号页面会保留上一轮任务的图，
        不排除就会把旧图当成本次产出下载回传给分镜。
        """
        # 兼容尚未刷新到新版注入脚本的页面：没有 genImageUris 时自己从 genImages 取 uri
        raw = self._eval_safe(
            "JSON.stringify(window.__dbmImage.genImageUris ? window.__dbmImage.genImageUris() "
            ": (window.__dbmImage.genImages() || []).map(function(x){ return x.uri || ''; }))", timeout=15)
        try:
            arr = json.loads(raw) if isinstance(raw, str) else (raw or [])
        except Exception:
            arr = []
        return [u for u in (arr or []) if u]

    def _wait_for_images(self, tid, timeout_sec=300, baseline=None):
        """轮询等待图片生成完成，只返回本次新生成的图（排除基线里已有的）。"""
        baseline = set(baseline or ())
        min_wait = int(self.config.get("min_wait_sec", 10) or 0)
        t0 = time.time()
        last_count = -1
        stable_count = 0
        first_seen = 0.0
        while time.time() - t0 < timeout_sec:
            if self.store.is_cancelled(tid):
                raise TaskCancelled()
            r = self._eval_safe("JSON.stringify(window.__dbmImage.getGeneratedImages())", timeout=15)
            try:
                d = json.loads(r) if isinstance(r, str) else r
            except Exception:
                d = {}
            imgs = d.get("images", []) if d else []
            # 关键：过滤掉提交前就存在的图，只留本次新增的
            fresh = [x for x in imgs if (x.get("uri") or x.get("src")) not in baseline]
            n = len(fresh)
            if n > 0:
                if not first_seen:
                    first_seen = time.time()
                if n == last_count:
                    stable_count += 1
                    # 连续 3 轮数量不变，且已过最短等待时间，才算真正生成完毕
                    if stable_count >= 3 and (time.time() - first_seen) >= min_wait:
                        wm = sum(1 for x in fresh if x.get("watermark"))
                        self.store.log(
                            tid,
                            f"{self.display_name()} 检测到本次新增 {n} 张图片已稳定"
                            f"（页面共 {len(imgs)} 张，基线 {len(baseline)} 张已排除；"
                            f"其中 {wm} 张为带水印展示模板，下载前换成原图地址）")
                        return fresh
                else:
                    stable_count = 0
                    last_count = n
                    self.store.log(tid, f"{self.display_name()} 本次已新增 {n} 张图片...")
            # 检查是否失败（只看页面末尾新增文本，避免历史消息误判）
            busy = self._eval_safe("JSON.stringify(window.__dbmImage.isPageBusy())", timeout=10)
            try:
                bd = json.loads(busy) if isinstance(busy, str) else busy
            except Exception:
                bd = {}
            # 只看页面末尾的最新文本，避免历史消息里的"违规"等词误判为本次失败
            # （旧版注入脚本没有 tailText，回退为整页文本取末尾 4000 字）
            txt = self._eval_safe(
                "(window.__dbmImage.tailText ? window.__dbmImage.tailText(4000) "
                ": String((document.body && document.body.innerText) || '').slice(-4000))", timeout=10)
            if txt and ("生成失败" in txt or "无法生成" in txt or "内容违规" in txt or "涉嫌违规" in txt):
                self.store.log(tid, f"{self.display_name()} 页面显示生成失败")
                raise GenerationFailed("页面显示生成失败", kind="failed")
            time.sleep(int(self.config.get("poll_interval_sec", 3)))
        self.store.log(tid, f"{self.display_name()} 等待图片生成超时（基线 {len(baseline)} 张，本次新增 {max(last_count, 0)} 张）")
        raise GenerationTimeout("等待图片生成超时")

    def _resolve_no_watermark(self, tid, imgs):
        """把页面上的带水印展示地址，换成豆包签发的无水印原图地址。

        返回 {原始src: {"main_url":..., "back_url":..., "watermark":bool}}
        解析失败时返回空 dict，调用方回落到原始地址（行为与改动前一致）。
        """
        dn = self.display_name()
        if not self.config.get("prefer_no_watermark", True):
            self.store.log(tid, f"{dn} 已关闭无水印解析，直接使用页面展示地址")
            return {}
        if not self.ws:
            return {}

        payload = []
        for img in imgs or []:
            src = img.get("src", "")
            if not src:
                continue
            payload.append({
                "src": src,
                "uri": img.get("uri") or "",
                "ext": img.get("ext") or "",
            })
        if not payload:
            return {}

        expr = ("window.__dbmImage.resolveNoWatermark(%s, 25000)"
                ".then(function(r){ return JSON.stringify(r); })"
                % json.dumps(payload, ensure_ascii=False))
        raw = self._eval_async(expr, timeout=90)
        try:
            data = json.loads(raw) if isinstance(raw, str) else (raw or {})
        except Exception as e:
            self.store.log(tid, f"{dn} 无水印解析返回无法解析: {e}")
            return {}

        items = (data or {}).get("items") or []
        if not items:
            self.store.log(tid, f"{dn} 无水印解析无结果(code={data.get('code')} err={data.get('error')})")
            return {}

        resolved = {}
        for it in items:
            src = it.get("src") or ""
            uri = it.get("uri") or ""
            main_url = it.get("main_url") or ""
            back_url = it.get("back_url") or ""
            if not (main_url or back_url):
                continue
            rec = {
                "main_url": main_url,
                "back_url": back_url,
                "watermark": bool(it.get("watermark")),
            }
            if src:
                resolved[src] = rec
            if uri and uri not in resolved:
                resolved[uri] = rec
        n_wm = sum(1 for it in items if it.get("watermark"))
        n_ok = sum(1 for it in items if it.get("main_url") or it.get("back_url"))
        self.store.log(
            tid,
            f"{dn} 无水印解析完成：{n_ok}/{len(items)} 条展示地址拿到原图地址"
            f"（其中仍带水印模板 {n_wm} 条）")
        return resolved

    def _ensure_interactive(self):
        """让被管理器隐藏的 webview 能接收输入事件。

        管理器同一时刻只显示一个账号，其余 webview 不可见 —— 实测这种情况下
        CDP 的鼠标事件**不会**派发到页面（下拉菜单点了没反应）。
        Page.bringToFront + Emulation.setFocusEmulationEnabled 是必需的。
        """
        for method, params in (("Page.bringToFront", {}),
                               ("Page.setWebLifecycleState", {"state": "active"}),
                               ("Emulation.setFocusEmulationEnabled", {"enabled": True})):
            try:
                self.ws.send(method, params, timeout=10)
            except Exception:
                pass

    def _cdp_click(self, x, y, settle=0.0):
        """CDP 真实鼠标点击（这类 React 浮层对 el.click() 无反应）。"""
        try:
            self.ws.send("Input.dispatchMouseEvent",
                         {"type": "mouseMoved", "x": int(x), "y": int(y), "button": "none"}, timeout=10)
            time.sleep(0.25)
            self.ws.send("Input.dispatchMouseEvent",
                         {"type": "mousePressed", "x": int(x), "y": int(y),
                          "button": "left", "clickCount": 1}, timeout=10)
            time.sleep(0.12)
            self.ws.send("Input.dispatchMouseEvent",
                         {"type": "mouseReleased", "x": int(x), "y": int(y),
                          "button": "left", "clickCount": 1}, timeout=10)
            if settle:
                time.sleep(settle)
            return True
        except Exception as e:
            self.store.log(self.current_tid or "", f"{self.display_name()} CDP 点击失败: {e}")
            return False

    def _select_param(self, tid, kind, want):
        """按顺序选择图像参数：模型 / 比例 / 风格。

        want 为空表示"不改动这��"（豆包自带默认值）。
        返回 (ok, 说明)
        """
        want = str(want or "").strip()
        if not want:
            return True, f"{kind}=保持默认"
        dn = self.display_name()
        btn_raw = self._eval_safe(
            "JSON.stringify(window.__dbmImage.paramBtn(%s))" % json.dumps(kind, ensure_ascii=False), timeout=10)
        try:
            btn = json.loads(btn_raw) if isinstance(btn_raw, str) else btn_raw
        except Exception:
            btn = None
        if not btn:
            self.store.log(tid, f"{dn} 未找到「{kind}」按钮，跳过该参数设置")
            return False, f"{kind} 按钮未找到"

        cur = str(btn.get("tx", "")).replace(kind, "").strip()
        if want in cur or cur in want:
            self.store.log(tid, f"{dn} {kind} 已是 {cur}，无需切换")
            return True, f"{kind}={cur}"

        # 展开下拉
        if not self._cdp_click(btn["x"], btn["y"], settle=1.4):
            return False, f"{kind} 展开失败"
        item_raw = self._eval_safe(
            "JSON.stringify(window.__dbmImage.menuItem(%s, false))" % json.dumps(want, ensure_ascii=False), timeout=10)
        try:
            item = json.loads(item_raw) if isinstance(item_raw, str) else item_raw
        except Exception:
            item = None
        if not item:
            self._eval_safe("window.__dbmImage.closeMenu()", timeout=5)
            self.store.log(tid, f"{dn} {kind} 菜单里没找到选项「{want}」，保持 {cur or '默认'}")
            return False, f"{kind} 无「{want}」选项"

        self._cdp_click(item["x"], item["y"], settle=1.0)
        new = self._eval_safe(
            "window.__dbmImage.paramValue(%s)" % json.dumps(kind, ensure_ascii=False), timeout=10)
        ok = bool(new) and (want in str(new) or str(new) in want)
        self.store.log(tid, f"{dn} {kind} 设置为 {new or '?'}"
                            + ("" if ok else f"（目标 {want}，可能未生效）"))
        return ok, f"{kind}={new or '?'}"

    def _apply_image_params(self, tid, aspect=None, style=None):
        """按顺序设置：模型 → 比例 → 风格（必须在这个顺序，豆包面板是从左到右排列的）。"""
        dn = self.display_name()
        self._ensure_interactive()
        results = []
        for kind, want in (("模型", self.config.get("image_model", "Seedream 5.0 Flash")),
                           ("比例", aspect or self.config.get("image_aspect", "")),
                           ("风格", style if style is not None else self.config.get("image_style", ""))):
            ok, desc = self._select_param(tid, kind, want)
            results.append((ok, desc))
            time.sleep(0.6)
        self.store.log(tid, f"{dn} 图像参数：{' / '.join(d for _o, d in results)}")
        # 比例/风格没选上不算致命（豆包会用默认值继续生成），模型也失败才提示
        return results

    def _download_images(self, tid, imgs, download_dir):
        """下载所有图片到本地，优先使用无水印原图地址。

        注意：同一个生成对象在页面上可能同时挂着"带水印缩略图"和"大图"两个
        <img>（uri 相同），这里按 uri 去重，并把不带水印的地址排在前面优先使用。
        """
        dn = self.display_name()
        paths = []
        cookies = self._get_cookies()
        resolved = self._resolve_no_watermark(tid, imgs)

        # 去重 + 排序：干净的地址优先，缩略/水印模板最后
        unique = []
        seen_uri = set()
        for img in sorted(imgs or [], key=lambda x: (
                url_looks_watermarked(x.get("src", "")),
                0 if (x.get("w") or 0) >= 512 else 1)):
            src = img.get("src", "")
            if not src:
                continue
            uri = img.get("uri") or src
            if uri in seen_uri:
                continue
            seen_uri.add(uri)
            unique.append(img)

        for idx, img in enumerate(unique):
            src = img.get("src", "")
            info = resolved.get(src) or resolved.get(img.get("uri") or "") or {}

            # 候选顺序：无水印原图 main_url -> 备用 back_url -> 页面展示地址
            candidates = []
            for u in (info.get("main_url"), info.get("back_url"), src):
                if u and u not in candidates:
                    candidates.append(u)
            # 命中水印模板的排到最后（只在没有干净地址时才用）
            clean = [u for u in candidates if not url_looks_watermarked(u)]
            dirty = [u for u in candidates if url_looks_watermarked(u)]
            order = clean + dirty

            ext = guess_ext(order[0] if order else src)
            # 文件名带任务 ID（uuid4），多账号并发下载到同一个目录也不会撞名；
            # 同一个任务重试时会覆盖上次的文件，属于预期行为。
            dest = os.path.join(download_dir, f"{tid}_{idx+1}{ext}")
            if os.path.exists(dest):
                try:
                    os.remove(dest)
                except Exception:
                    pass

            saved = False
            for u in order:
                try:
                    sz = http_download(u, dest, cookies=cookies, timeout=180)
                    paths.append(dest)
                    saved = True
                    tag = "无水印原图" if not url_looks_watermarked(u) else "⚠ 带水印模板"
                    self.store.log(
                        tid,
                        f"{dn} 下载图片 {idx+1}/{len(unique)}: {sz} bytes [{tag}] {u[:140]}")
                    break
                except Exception as e:
                    self.store.log(tid, f"{dn} 下载图片 {idx+1} 该地址失败({str(e)[:80]})，换下一个地址")
            if not saved:
                self.store.log(tid, f"{dn} 下载图片 {idx+1} 全部地址均失败")

        return paths

    def submit_image_task(self, tid, prompt, images=None, aspect="", style=""):
        """执行完整的图像生成任务（图像模式 → 模型 → 比例 → 风格 → 发送）。"""
        my_epoch = self.epoch
        self.current_tid = tid
        self.busy = True
        # 任务被取消（全部取消/单任务取消）时，尽早中止，避免空跑一整轮
        if self.store.is_cancelled(tid):
            raise TaskCancelled()
        try:
            self.store.update(tid, status="preparing_page", percent=5, message="准备页面")
            self._ensure_window_visible()
            self._ensure_all_webviews_render()
            if not self._ensure_injected():
                self.store.update(tid, status="error", percent=0, message="注入脚本失败", error="inject_failed")
                return

            # 检查当前页面，不强制导航（避免破坏已有的可用会话页）
            self.store.update(tid, status="preparing_page", percent=10, message="检查页面状态")
            current_url = self._eval_safe("location.href", timeout=10) or ""
            self.store.log(tid, f"{self.display_name()} 当前页面: {current_url}")

            # 如果当前不是豆包页面，导航到首页
            if "doubao.com/chat" not in current_url:
                self.store.log(tid, f"{self.display_name()} 页面异常，导航到首页")
                try:
                    self.ws.send("Page.enable", {}, timeout=10)
                    self.ws.send("Page.navigate", {"url": "https://www.doubao.com/chat/"}, timeout=30)
                except Exception:
                    pass
                time.sleep(6)
                for _ in range(20):
                    ready = self._eval_safe("document.readyState", timeout=10)
                    if ready == "complete":
                        break
                    time.sleep(1)
                # 导航后重新注入
                if not self._ensure_injected():
                    self.store.update(tid, status="error", percent=0, message="注入脚本失败", error="inject_failed")
                    return

            # ---- 跨进程前台互斥：图片桥与视频桥共用一个豆包管理器，必须错开
            #      "真正操控 UI"（切模式/填参/发提示词）这一小段时间，避免互相抢
            #      .active 标签页与前台焦点。等待出图的被动轮询阶段会释放锁，
            #      不阻塞对方，也保留本桥内多账号并发。----
            _xp = foreground_mutex("image")
            _xp.acquire()
            try:
                # 切换图像模式
                self.store.update(tid, status="filling_form", percent=20, message="切换到图像生成模式")
                if not self._pick_image_mode(tid, budget_sec=30):
                    self.store.update(tid, status="error", percent=0, message="无法切换到图像生成模式", error="image_mode_failed")
                    return
                time.sleep(3)

                # 图像参数：模型 → 比例 → 风格（必须按这个顺序，面板从左到右排列）
                self.store.update(tid, status="filling_form", percent=25, message="设置模型/比例/风格")
                self._apply_image_params(tid, aspect=aspect, style=style)
                time.sleep(1)

                # 记录基线：提交前页面上已有的成图（多任务串行时必须排除，
                # 否则上一轮的图会被当成这次的产出下载回传给分镜）
                baseline = self._snapshot_uris()
                if baseline:
                    self.store.log(tid, f"{self.display_name()} 记录成图基线 {len(baseline)} 张（页面历史图，本次不回传）")

                # 发送提示词
                self.store.update(tid, status="submitting", percent=30, message="发送生成请求")
                if not self._send_image_prompt(tid, prompt, images):
                    self.store.update(tid, status="error", percent=0, message="发送失败", error="send_failed")
                    return
            finally:
                _xp.release()

            self.store.update(tid, status="generating", percent=40, message="豆包生成中...")
            self.store.log(tid, f"{self.display_name()} 已提交，等待出图")

            # 等待图片（只取基线之外的新增图）
            imgs = self._wait_for_images(tid, timeout_sec=int(self.config.get("task_timeout_sec", 600)),
                                         baseline=baseline)

            # 按"每任务生成张数"裁剪：豆包一次可能出多张，全量回传会让分镜收到
            # 一堆图（且第 1 张之外的文件名都带序号），宿主按规范名只认第一张。
            try:
                limit = int(self.config.get("image_count", 1) or 0)
            except Exception:
                limit = 1
            if limit > 0 and len(imgs) > limit:
                self.store.log(tid, f"{self.display_name()} 本次新增 {len(imgs)} 张，按配置只取前 {limit} 张")
                imgs = imgs[:limit]

            # 下载（先解析无水印原图地址）
            self.store.update(tid, status="downloading", percent=80, message="解析无水印原图地址…")
            download_dir = self.config.get("download_dir", "") or detect_download_dir()
            if not download_dir:
                download_dir = str(BRIDGE_DIR / "downloads")
            os.makedirs(download_dir, exist_ok=True)
            paths = self._download_images(tid, imgs, download_dir)

            if not paths:
                self.store.update(tid, status="error", percent=0, message="下载图片失败", error="download_failed")
                return

            self.store.update(tid, status="done", percent=100, message="完成", output_paths=paths)
            self.done += 1
            self.store.log(tid, f"{self.display_name()} 任务完成，产出 {len(paths)} 张图片")

        except GenerationFailed as e:
            self.store.update(tid, status="error", percent=0, message=str(e), error=f"generation_failed:{e.kind}")
        except GenerationTimeout as e:
            self.store.update(tid, status="error", percent=0, message=str(e), error="generation_timeout")
        except TaskCancelled:
            self.store.log(tid, f"{self.display_name()} 任务被取消")
        except Exception as e:
            self.store.update(tid, status="error", percent=0, message=f"异常: {e}", error=str(e)[:200])
        finally:
            if self.epoch == my_epoch:
                self.busy = False
                self.current_tid = None

    def retire(self):
        self.epoch += 1
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
            self.ws = None


# ========================================================================
# Scheduler
# ========================================================================

class Scheduler:
    def __init__(self, bridge, store, config):
        self.bridge = bridge
        self.store = store
        self.config = config
        self.workers = []
        self.queue = []
        self.lock = threading.Lock()
        self._slot_lock = {}
        self._running = True
        self.background_only_when_active = bool(
            config.get("background_only_when_active", True))

        # 桥接启动前 tasks.json 里的任务全部视为"历史遗留"：
        # 1) 未完成的旧状态改成已取消，避免 _has_active_work 误判成当前工作；
        # 2) 记下 ID，_retry_loop 永不自动重试它们（历史失败任务自动复活，
        #    是"没点生成豆包却一直在出图"的直接原因）。
        with self.store.lock:
            self._legacy_task_ids = set(self.store.tasks.keys())
            changed = False
            for t in self.store.tasks.values():
                if t.get("status") in _ACTIVE_TASK_STATES and not t.get("cancelled"):
                    t["status"] = "error"
                    t["error"] = "cancelled"
                    t["message"] = "上次会话遗留任务已作废（桥接重启，不自动续跑）"
                    t["cancelled"] = True
                    t["updated"] = time.time()
                    changed = True
            if changed:
                self.store._save()

        threading.Thread(target=self._dispatch_loop, daemon=True).start()
        threading.Thread(target=self._health_loop, daemon=True).start()
        threading.Thread(target=self._retry_loop, daemon=True).start()

    def _has_active_work(self):
        """本会话真实提交的、仍在进行中的任务。空闲时后台循环必须完全静默。"""
        with self.lock:
            if self.queue:
                return True
        with self.store.lock:
            for t in self.store.tasks.values():
                if (t.get("status") in _ACTIVE_TASK_STATES
                        and not t.get("cancelled")
                        and t.get("error") != "cancelled"):
                    return True
        return False

    def _detach_idle_workers(self):
        """空闲时断开 CDP 连接，不再持有/注入豆包页面；下次任务会重新 attach。"""
        with self.lock:
            workers = list(self.workers)
        for w in workers:
            if not w.busy:
                try:
                    w.retire()
                except Exception:
                    pass

    def _assign_slot(self, target_id, reported_slot):
        if target_id in self._slot_lock:
            return self._slot_lock[target_id]
        used = set(self._slot_lock.values())
        slot = reported_slot if reported_slot and reported_slot not in used else 0
        if slot == 0 or slot in used:
            for i in range(1, 100):
                if i not in used:
                    slot = i
                    break
        self._slot_lock[target_id] = slot
        return slot

    def _release_slot(self, target_id):
        self._slot_lock.pop(target_id, None)

    def _refresh_workers(self):
        accts = self.bridge.list_accounts()
        current_ids = {a.get("id", a.get("webSocketDebuggerUrl", "")) for a in accts}
        with self.lock:
            # 移除已下线的
            for w in list(self.workers):
                wid = w.target.get("id", w.target.get("webSocketDebuggerUrl", ""))
                if wid not in current_ids:
                    w.retire()
                    self._release_slot(wid)
                    self.workers.remove(w)
            # 新增上线的
            existing_ids = {w.target.get("id", w.target.get("webSocketDebuggerUrl", "")) for w in self.workers}
            for a in accts:
                aid = a.get("id", a.get("webSocketDebuggerUrl", ""))
                if aid not in existing_ids:
                    slot = self._assign_slot(aid, 0)
                    w = AccountWorker(self.bridge, self.store, self.config, a, slot=slot)
                    w._inject_js = build_inject_js_with_ver({})
                    w._inject_ver = inject_js_ver({})
                    w.start()
                    self.workers.append(w)
                    # 新 worker 立即后台健康检查
                    threading.Thread(target=w._check_health, daemon=True).start()

    def _pick_worker(self, account_hint=""):
        import random
        with self.lock:
            candidates = [w for w in self.workers if not w.busy]
            if account_hint:
                candidates = [w for w in candidates if account_hint in (w.target.get("title") or "")]
            if not candidates:
                return None
            # 优先选择最近健康检查通过的 worker
            healthy = [w for w in candidates if w._last_health_ok]
            if healthy:
                return random.choice(healthy)
            # 没有健康 worker 时随机选，避免总是命中同一个坏页面
            return random.choice(candidates)
        return None

    def submit(self, tid, prompt, images=None, account_hint="", aspect="", style=""):
        self.store.update(tid, status="queued", percent=0, message="排队中")
        with self.lock:
            self.queue.append({"tid": tid, "prompt": prompt, "images": images or [],
                               "account_hint": account_hint, "aspect": aspect, "style": style})

    def cancel(self, tid):
        # 仅把任务移出队列并标记 cancelled：
        # - 排队中的任务：移出队列即不会再被派发，标记后列表直接显示"已取消"。
        # - 进行中的任务：worker 的 _wait_for_images 循环会周期性检查 store 的
        #   cancelled 标记并抛 TaskCancelled 主动中止（不 retire worker，否则会留下
        #   一个 busy=True 的僵尸账号，且旧线程还在空跑）。
        with self.lock:
            self.queue = [q for q in self.queue if q["tid"] != tid]
        self.store.cancel(tid)

    def cancel_all(self):
        """取消所有未完成（且未取消）的任务，返回 (已取消数, 跳过数)。"""
        with self.lock:
            self.queue = []
        cancelled = 0
        skipped = 0
        with self.store.lock:
            for tid, t in list(self.store.tasks.items()):
                st = t.get("status")
                is_cancelled = st == "error" and t.get("error") == "cancelled"
                if st == "done" or is_cancelled:
                    skipped += 1
                    continue
                t["status"] = "error"
                t["error"] = "cancelled"
                t["percent"] = 0
                t["message"] = "已取消"
                t["cancelled"] = True
                t["updated"] = time.time()
                cancelled += 1
        self.store._save()
        return {"cancelled": cancelled, "skipped": skipped}

    def reset_accounts(self):
        """清除所有账号的额度不足标记（健康卡"重置额度标记"按钮）。"""
        n = 0
        for w in self.workers:
            if not w.quota_ok:
                w.quota_ok = True
                w.quota_recover_at = None
                n += 1
        return {"reset": n}

    def _dispatch_loop(self):
        while self._running:
            # 防霸占：没有本桥接的活动任务时，完全不连 CDP、不刷账号、
            # 不新建 worker、不占用豆包页面。用户选了别的插件就不该被打扰。
            if self.background_only_when_active and not self._has_active_work():
                self._detach_idle_workers()
                time.sleep(2)
                continue
            self._refresh_workers()
            with self.lock:
                if self.queue:
                    item = self.queue.pop(0)
                else:
                    item = None
            if item:
                w = None
                for _ in range(60):
                    w = self._pick_worker(item.get("account_hint", ""))
                    if w:
                        if not w._last_health_ok:
                            # 不健康或从未检查，触发后台检查并跳过
                            if w._last_health_ts == 0:
                                threading.Thread(target=w._check_health, daemon=True).start()
                            w = None
                        else:
                            break
                    time.sleep(1)
                    self._refresh_workers()
                if w:
                    # 先同步置忙再起线程：worker 线程里也会设 busy，但那要等线程真正跑起来，
                    # 这中间的窗口会让下一轮 dispatch 又选中同一个账号 —— 两个任务同时操作
                    # 一个豆包页面（抢着填提示词、抢着提交），是并发混乱的另一大来源。
                    w.busy = True
                    threading.Thread(target=w.submit_image_task,
                                   args=(item["tid"], item["prompt"], item["images"]),
                                   kwargs={"aspect": item.get("aspect", ""), "style": item.get("style", "")},
                                   daemon=True).start()
                else:
                    self.store.update(item["tid"], status="error", percent=0,
                                    message="无空闲账号", error="no_idle_worker")
            time.sleep(2)

    def _health_loop(self):
        while self._running:
            # 空闲时不巡检账号、不注入 JS（这些操作会抢 .active 标签页/焦点）
            if self.background_only_when_active and not self._has_active_work():
                self._detach_idle_workers()
                time.sleep(15)
                continue
            self._refresh_workers()
            for w in list(self.workers):
                if not w.busy:
                    w._check_health()
            time.sleep(15)

    def _retry_loop(self):
        """对可重试失败的 task 自动重新入队。"""
        RETRYABLE_ERRORS = {"send_failed", "image_mode_failed", "inject_failed", "no_idle_worker"}
        while self._running:
            time.sleep(15)
            with self.lock:
                for tid, t in list(self.store.tasks.items()):
                    # 历史遗留任务（本次桥接启动前就存在的）永不自动复活
                    if tid in self._legacy_task_ids or t.get("cancelled"):
                        continue
                    if t.get("status") != "error":
                        continue
                    err = t.get("error", "")
                    # 只重试特定错误
                    if not any(err.startswith(e) or err == e for e in RETRYABLE_ERRORS):
                        continue
                    retries = t.get("retries", 0)
                    max_retries = int(self.config.get("max_task_retries", 2))
                    if retries >= max_retries:
                        continue
                    retries += 1
                    self.store.update(tid, status="queued", percent=0,
                                    message=f"排队中(重试{retries})", error="", retries=retries)
                    self.queue.append({
                        "tid": tid,
                        "prompt": t.get("prompt", ""),
                        "images": t.get("images", []),
                        "account_hint": "",
                        "aspect": t.get("aspect", ""),
                        "style": t.get("style", ""),
                    })

    def stop(self):
        self._running = False
        self._detach_idle_workers()
        for w in self.workers:
            w.retire()


# ========================================================================
# HTTP API
# ========================================================================

def _fmt(ts):
    """epoch 秒 → "YYYY-MM-DD HH:MM:SS"（UI 的 parseTaskTime 按此格式解析）。"""
    if not ts:
        return ""
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(ts)))
    except Exception:
        return ""


def _task_view(t):
    """把内部任务结构转成控制台 UI 期望的字段。

    store 内部用 epoch 时间戳 + output_paths，而控制台 UI 期望字符串时间
    created_at/updated_at、单文件路径 video_path、以及 submitted 标记。"""
    created = t.get("created", 0) or 0
    updated = t.get("updated", 0) or 0
    outputs = t.get("output_paths", []) or []
    return {
        "id": t.get("id"),
        "status": t.get("status"),
        "percent": t.get("percent", 0),
        "prompt": t.get("prompt", ""),
        "images": t.get("images", []),
        "aspect": t.get("aspect", ""),
        "style": t.get("style", ""),
        "account": t.get("account", ""),
        "message": t.get("message", ""),
        "error": t.get("error", ""),
        "created_at": _fmt(created),
        "updated_at": _fmt(updated),
        "video_path": outputs[0] if outputs else "",
        "output_paths": outputs,
        "logs": t.get("logs", []),
        "submitted": t.get("status") in ("generating", "downloading", "submitting", "filling_form")
                     or bool(t.get("submitted")),
    }


class APIHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _json_resp(self, code, data):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = self.path
        state = self.server.state

        if path == "/api/health":
            accts = state.bridge.list_accounts() if state.bridge else []
            sc = state.scheduler
            workers = []
            busy = 0
            if sc:
                for w in sc.workers:
                    if w.busy:
                        busy += 1
                    workers.append({
                        "name": w.display_name(),
                        "busy": w.busy,
                        "current_tid": w.current_tid,
                        "quota_ok": w.quota_ok,
                        "quota_recover_at": w.quota_recover_at,
                        "done": w.done,
                    })
            queued = 0
            if sc:
                with sc.lock:
                    queued = len(sc.queue)
            self._json_resp(200, {
                "ok": True,
                # 服务身份：图片插件桥接。视频插件是另一个桥接（默认 9230 端口），
                # 插件侧靠这个字段判断端口上跑的到底是不是自己人。
                "service": "doubao-image-bridge",
                "manager_running": len(accts) > 0,
                "worker_count": len(workers),
                "busy_count": busy,
                "queued": queued,
                "quota_blocked": sum(1 for w in workers if not w["quota_ok"]),
                "time": now_str(),
                "download_dir": state.config.get("download_dir", "") or detect_download_dir(),
                "workers": workers,
            })
            return

        if path == "/api/config":
            self._json_resp(200, {"ok": True, "config": state.config})
            return

        if path == "/api/tasks":
            self._json_resp(200, {"ok": True, "tasks": [_task_view(t) for t in state.store.list()]})
            return

        if path.startswith("/api/tasks/"):
            parts = path.split("/")
            if len(parts) >= 4:
                tid = parts[3]
                t = state.store.get(tid)
                if t:
                    self._json_resp(200, {"ok": True, "task": _task_view(t)})
                else:
                    self._json_resp(404, {"ok": False, "error": "任务不存在"})
                return

        if path == "/":
            try:
                html = open(CONSOLE_PATH, "r", encoding="utf-8").read()
            except Exception:
                html = "<h1>豆包管理器图片插件桥接服务</h1>"
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html.encode("utf-8"))
            return

        self._json_resp(404, {"ok": False, "error": "未找到"})

    def do_POST(self):
        path = self.path
        state = self.server.state
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8", "replace") if length > 0 else "{}"
        try:
            payload = json.loads(body)
        except Exception:
            payload = {}

        if path == "/api/tasks":
            prompt = str(payload.get("prompt", "")).strip()
            if not prompt:
                self._json_resp(400, {"ok": False, "error": "提示词不能为空"})
                return
            images = payload.get("images", []) or []
            account = str(payload.get("account", "")).strip()
            aspect = str(payload.get("aspect", "") or "").strip()
            style = str(payload.get("style", "") or "").strip()
            tid = state.store.create(prompt, images, account=account, aspect=aspect, style=style)
            state.scheduler.submit(tid, prompt, images, account, aspect=aspect, style=style)
            self._json_resp(200, {"ok": True, "task_id": tid})
            return

        if path.startswith("/api/tasks/") and path.endswith("/cancel"):
            parts = path.split("/")
            if len(parts) >= 4:
                tid = parts[3]
                state.scheduler.cancel(tid)
                self._json_resp(200, {"ok": True})
                return

        if path == "/api/tasks/cancel-all":
            res = state.scheduler.cancel_all()
            self._json_resp(200, {"ok": True, **res})
            return

        if path == "/api/accounts/reset":
            res = state.scheduler.reset_accounts()
            self._json_resp(200, {"ok": True, **res})
            return

        if path == "/api/config":
            for k, v in payload.items():
                if k in DEFAULT_CONFIG:
                    state.config[k] = _coerce_cfg(k, v)
            if state.scheduler:
                state.scheduler.background_only_when_active = bool(
                    state.config.get("background_only_when_active", True))
            self._json_resp(200, {"ok": True, "config": state.config})
            return

        if path == "/api/no-watermark/peek":
            # 调试用：不生成、不下载，只把指定账号页面上现有成图的
            # "带水印展示地址" 与 "无水印原图地址" 列出来，便于核对。
            account = str(payload.get("account", "")).strip()
            target = None
            if state.bridge:
                target = state.bridge.pick_target(account)
            if not target:
                self._json_resp(200, {"ok": False, "error": "没有可用的豆包账号页面"})
                return
            try:
                ws = state.bridge.attach(target, timeout=25)
            except Exception as e:
                self._json_resp(200, {"ok": False, "error": f"连接页面失败：{e}"})
                return
            try:
                ws.send("Runtime.enable", {}, timeout=10)
                js = build_inject_js_with_ver({})
                state.bridge.evaluate(ws, js, return_by_value=False, timeout=30)
                raw = state.bridge.evaluate(
                    ws, "(function(){return JSON.stringify(window.__dbmImage.genImages());})()",
                    return_by_value=True, timeout=20)
                page_imgs = json.loads(raw) if isinstance(raw, str) else (raw or [])
                expr = ("window.__dbmImage.resolveNoWatermark(%s, 25000)"
                        ".then(function(r){ return JSON.stringify(r); })"
                        % json.dumps(page_imgs, ensure_ascii=False))
                resolved = state.bridge.evaluate(
                    ws, expr, return_by_value=True, await_promise=True, timeout=60)
                data = json.loads(resolved) if isinstance(resolved, str) else (resolved or {})
                items = (data or {}).get("items") or []
                for it in items:
                    it["watermark_before"] = url_looks_watermarked(it.get("src", ""))
                    it["watermark_after"] = url_looks_watermarked(
                        it.get("main_url", "") or it.get("back_url", ""))
                self._json_resp(200, {
                    "ok": bool(data.get("ok")),
                    "account": target.get("title", ""),
                    "page_url": target.get("url", ""),
                    "code": data.get("code"),
                    "error": data.get("error", ""),
                    "count": len(items),
                    "items": items,
                })
            except Exception as e:
                self._json_resp(200, {"ok": False, "error": str(e)[:200]})
            finally:
                try:
                    ws.close()
                except Exception:
                    pass
            return

        self._json_resp(404, {"ok": False, "error": "未找到"})


class BridgeState:
    def __init__(self):
        self.config = dict(DEFAULT_CONFIG)
        self.store = TaskStore()
        self.bridge = None
        self.scheduler = None


def start_bridge(config_overrides=None):
    state = BridgeState()

    # 顺序很关键：先读磁盘上的历史配置，再用插件传进来的设置覆盖。
    # 反过来写的话，用户在插件设置页改的端口会被旧文件顶回去，
    # 图片/视频两个插件就可能被旧配置同时按在同一个端口上。
    cfg = load_json(CONFIG_PATH, {})
    for k, v in cfg.items():
        if k in DEFAULT_CONFIG:
            state.config[k] = _coerce_cfg(k, v)
    if config_overrides:
        for k, v in config_overrides.items():
            if k in DEFAULT_CONFIG:
                state.config[k] = _coerce_cfg(k, v)

    _RUNTIME_CONFIG.clear()
    _RUNTIME_CONFIG.update(state.config)

    state.bridge = ManagerBridge(state.config)
    state.scheduler = Scheduler(state.bridge, state.store, state.config)

    host = state.config["bridge_host"]
    port = int(state.config["bridge_port"])
    # 关掉 SO_REUSEADDR：Windows 上它允许多个进程同时 bind 同一个端口，
    # 一旦图片/视频桥接撞端口就会变成"两个服务都起得来、请求随机进错门"的鬼故事。
    # 关掉后端口被占会立刻抛错，问题一眼可见。
    class _StrictHTTPServer(ThreadingHTTPServer):
        allow_reuse_address = False
    server = _StrictHTTPServer((host, port), APIHandler)
    server.state = state
    print(f"[bridge] 图片插件桥接服务启动于 http://{host}:{port}/")
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return state


def main():
    start_bridge()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
